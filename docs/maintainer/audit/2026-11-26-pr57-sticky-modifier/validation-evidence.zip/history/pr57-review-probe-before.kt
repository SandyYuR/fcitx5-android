/* SPDX-License-Identifier: LGPL-2.1-or-later */
package org.fcitx.fcitx5.android.input.keyboard

import android.util.LruCache
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.core.view.allViews
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import org.fcitx.fcitx5.android.FcitxApplication
import org.fcitx.fcitx5.android.core.InputMethodEntry
import org.fcitx.fcitx5.android.data.prefs.SplitKeyboardStateManager
import org.fcitx.fcitx5.android.data.theme.ThemePreset
import org.fcitx.fcitx5.android.input.EditorSessionTracker
import org.fcitx.fcitx5.android.input.FcitxInputMethodService
import org.fcitx.fcitx5.android.ui.main.settings.behavior.editor.EditorApplicationShadow
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.util.ReflectionHelpers
import org.robolectric.util.ReflectionHelpers.ClassParameter

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = FcitxApplication::class, shadows = [EditorApplicationShadow::class])
class Pr57ReviewProbeTest {
    private fun withKeyboard(keys: String, block: (TextKeyboard, FcitxInputMethodService) -> Unit) {
        val layout = Json.parseToJsonElement("""{"default":[[$keys]]}""").jsonObject
        TextKeyboard.withPreviewLayout(layout) {
            SplitKeyboardStateManager.init(RuntimeEnvironment.getApplication())
            val service = Robolectric.buildService(FcitxInputMethodService::class.java).get()
            val activity = Robolectric.buildActivity(ComponentActivity::class.java).setup().visible()
            val ime = InputMethodEntry("review")
            val keyboard = TextKeyboard(service, ThemePreset.PixelLight, ime, isPreview = true)
            keyboard.onInputMethodUpdate(ime)
            activity.get().setContentView(keyboard)
            keyboard.onAttach()
            service.editorSession.start(EditorSessionTracker.Editor("app", 1, 1, 0), false)
            keyboard.keyActionListener = KeyActionListener { _, _ -> }
            try { block(keyboard, service) } finally {
                service.stickyModifiers.cancelAll()
                keyboard.onDetach()
                activity.get().finish()
                activity.pause().stop().destroy()
            }
        }
    }

    private fun latch(service: FcitxInputMethodService, modifier: StickyModifier) {
        val id = service.stickyModifiers.onDown(modifier)!!
        service.stickyModifiers.onUp(modifier, id, clickEligible = true, cancelled = false)
    }

    private fun events(service: FcitxInputMethodService): List<KeyEvent> =
        ReflectionHelpers.getField<LruCache<Int, KeyEvent>>(service, "cachedKeyEvents")
            .snapshot().values.toList()

    @Test fun ctrlUnderscoreMustKeepTheSymbolsRequiredShift() {
        withKeyboard("""{"type":"MacroKey","label":"_","tap":{"macro":[{"type":"tap","keys":[{"fcitx":"underscore"}]}]}}""") { keyboard, service ->
            latch(service, StickyModifier.Ctrl)
            assertTrue(keyboard.allViews.filterIsInstance<KeyView>().single().performClick())
            val events = events(service)
            val minus = events.single { it.action == KeyEvent.ACTION_DOWN && it.keyCode == KeyEvent.KEYCODE_MINUS }
            assertTrue(minus.toString(), minus.isCtrlPressed)
            assertTrue("underscore needs Shift; actual emitted event: $minus", minus.isShiftPressed)
        }
    }

    @Test fun ctrlCommaMustActuallyEmitTheOrdinaryCommaKey() {
        withKeyboard("""{"type":"CommaKey"}""") { keyboard, service ->
            latch(service, StickyModifier.Ctrl)
            assertTrue(keyboard.allViews.filterIsInstance<KeyView>().single().performClick())
            val events = events(service)
            assertTrue("Ctrl+, was consumed but emitted events: $events", events.any {
                it.action == KeyEvent.ACTION_DOWN && it.keyCode == KeyEvent.KEYCODE_COMMA && it.isCtrlPressed
            })
        }
    }

    @Test fun stickyShiftLetterMustConsumeTheExistingOneShotCaps() {
        withKeyboard("""{"type":"CapsKey"},{"type":"AlphabetKey","main":"a","alt":"!"}""") { keyboard, service ->
            ReflectionHelpers.callInstanceMethod<Unit>(keyboard, "onAction",
                ClassParameter.from(KeyAction::class.java, KeyAction.CapsAction(false)),
                ClassParameter.from(KeyActionListener.Source::class.java, KeyActionListener.Source.Keyboard))
            assertEquals(TextKeyboard.CapsState.Once, ReflectionHelpers.getField<TextKeyboard.CapsState>(keyboard, "capsState"))
            latch(service, StickyModifier.Shift)
            assertTrue(keyboard.allViews.filterIsInstance<KeyView>().last().performClick())
            assertFalse(service.stickyModifiers.hasActiveModifiers)
            assertEquals("one-shot caps remains armed after the letter", TextKeyboard.CapsState.None,
                ReflectionHelpers.getField<TextKeyboard.CapsState>(keyboard, "capsState"))
        }
    }
}
