基于本 PR 当前提交 **210104fa62dfeb9c4e81fb05a261bde6b36ea73a** 审阅（与共同祖先 bcfe31fe3fe0a458acd15eddca6a462d0af85d97 比较）。建议先修复下面 3 个功能问题再合并。

### 1. [P2] 粘滞组合会吞掉内置逗号键等使用字面字符的按键

位置：[consumeStickyTap / stickyShortcutTarget](https://github.com/SandyYuR/fcitx5-android/blob/210104fa62dfeb9c4e81fb05a261bde6b36ea73a/app/src/main/java/org/fcitx/fcitx5/android/input/keyboard/BaseKeyboard.kt#L3189-L3205)。

这里先 `consume()` 清掉粘滞状态，再解析 Android 键位；`target == null` 时仅记录日志并 `return true`，原动作也不再派发。

这会影响现有内置键：默认 CommaKey 的动作使用字面字符 `","`（[定义](https://github.com/SandyYuR/fcitx5-android/blob/210104fa62dfeb9c4e81fb05a261bde6b36ea73a/app/src/main/java/org/fcitx/fcitx5/android/input/keyboard/KeyDefPreset.kt#L367-L400)），但 [mapFcitxToAndroidKey](https://github.com/SandyYuR/fcitx5-android/blob/210104fa62dfeb9c4e81fb05a261bde6b36ea73a/app/src/main/java/org/fcitx/fcitx5/android/input/keyboard/BaseKeyboard.kt#L3686-L3732) 只识别 `comma` 等键名，不识别 `","`，因此得到 -1。句号字面字符 `"."` 也有相同的静态路径。

**复现：**在包含 Ctrl 粘滞键和内置 CommaKey 的布局中，点亮 Ctrl 后点逗号。独立 Robolectric 探针使用 `{"type":"CommaKey"}` 创建真实 KeyView、启动 editorSession、激活 Ctrl 后 `performClick()`，读取服务 cachedKeyEvents，结果为 **[]**：没有产生 Ctrl+逗号事件，粘滞状态却已消费。

**建议：**统一普通键与单键宏的目标解析，支持内置键使用的字面字符和对应 keysym 名称；对确实无法映射的 keysym，在消费状态前决定明确的处理方式，避免“消费成功但没有任何按键”。回退也应保留修饰语义，不能静默把快捷键变成无修饰文本。

建议至少补 CommaKey 的 Ctrl/Shift/Alt 组合，以及字面句号与 comma/period 键名的等价性回归。

### 2. [P2] 符号目标的必需 Shift 被丢弃，快捷键变成另一个组合

位置：[stickyShortcutTarget 的 FcitxKeyAction 分支](https://github.com/SandyYuR/fcitx5-android/blob/210104fa62dfeb9c4e81fb05a261bde6b36ea73a/app/src/main/java/org/fcitx/fcitx5/android/input/keyboard/BaseKeyboard.kt#L3202-L3205)。

`resolveMacroKey()` 的返回值包含 `shift`，但新路径只保留 keyCode 和 scanCode。对于 underscore，既有映射是 KEYCODE_MINUS + Shift；[resolveMacroKey](https://github.com/SandyYuR/fcitx5-android/blob/210104fa62dfeb9c4e81fb05a261bde6b36ea73a/app/src/main/java/org/fcitx/fcitx5/android/input/keyboard/BaseKeyboard.kt#L3758-L3829) 已计算这一信息，普通宏路径也会据此补发 Shift。粘滞分支绕过原宏执行后丢失了它。

**复现：**激活 Ctrl，再点击下面的单键宏：

```json
{"type":"MacroKey","label":"_","tap":{"macro":[{"type":"tap","keys":[{"fcitx":"underscore"}]}]}}
```

独立探针实际读到普通键 DOWN：

```text
keyCode=69 (KEYCODE_MINUS), scanCode=12, metaState=META_CTRL_ON
```

缺少 Shift，因此实际发出的是 **Ctrl+-**，而不是按当前符号映射表达的 **Ctrl+Shift+-（Ctrl+_）**。这是事件层的实测结论。plus、question 等同样依赖 shouldShiftSymbol() 的符号从源码看也受影响，但本轮没有逐个执行。

**建议：**让目标解析返回完整的物理按键描述，保留符号必需修饰；发送前将它与粘滞修饰合并、去重，再按统一顺序按下和逆序释放。尤其要覆盖用户本来就激活 Shift 的情况，避免重复按下导致计数失衡。

建议补 Ctrl+underscore、Alt+question、Ctrl+plus，以及粘滞 Shift 与符号必需 Shift 重叠时的完整 DOWN/UP 和 metaState 断言；只检查 listener 没收到普通动作，无法证明物理快捷键正确发出。

### 3. [P2] 直接调用 listener 绕过一次大写状态消费

位置：[仅 Shift+字母的消费分支](https://github.com/SandyYuR/fcitx5-android/blob/210104fa62dfeb9c4e81fb05a261bde6b36ea73a/app/src/main/java/org/fcitx/fcitx5/android/input/keyboard/BaseKeyboard.kt#L3172-L3187)，以及 [onStickyConsumableAction](https://github.com/SandyYuR/fcitx5-android/blob/210104fa62dfeb9c4e81fb05a261bde6b36ea73a/app/src/main/java/org/fcitx/fcitx5/android/input/keyboard/BaseKeyboard.kt#L3134-L3151)。

现有 [TextKeyboard.onAction](https://github.com/SandyYuR/fcitx5-android/blob/210104fa62dfeb9c4e81fb05a261bde6b36ea73a/app/src/main/java/org/fcitx/fcitx5/android/input/keyboard/TextKeyboard.kt#L1658-L1704) 会在普通字母消费 CapsState.Once 后 switchCapsState()；单键宏通过 preprocessMacroAction() 也会消费 Once。新分支直接 `listener.onKeyAction()`，绕过了两处状态处理。[生产 CommonKeyActionListener](https://github.com/SandyYuR/fcitx5-android/blob/210104fa62dfeb9c4e81fb05a261bde6b36ea73a/app/src/main/java/org/fcitx/fcitx5/android/input/keyboard/CommonKeyActionListener.kt#L215-L239) 只负责将对应按键入队，不负责清理 TextKeyboard 的 CapsState。

**复现：**布局同时保留普通 CapsKey 与新的 Shift 粘滞键。先点普通 CapsKey 进入 Once，再点亮粘滞 Shift，最后点击 AlphabetKey。独立探针确认粘滞状态已清空，但 capsState 仍为 **Once**，预期应为 None。按现有普通字母处理逻辑，下一字母仍会被一次大写处理；这一后续影响是源码推导，本轮没有验证宿主最终上屏文本。

**建议：**抽出共用的“普通按键预处理与 Once 消费”入口，让粘滞路径也执行相同的状态更新，同时保留本 PR 的 Shift+字母虚拟键语义。避免直接套用现有变换而把已组合好的 states 覆盖，或在 DOWN/UP 两次派发时重复消费。

建议补 CapsKey Once → 粘滞 Shift → 字母 → 下一字母的组合测试，并分别覆盖 AlphabetKey 与单键 Tap 宏。

### 验证范围

- 已编译并运行现有 StickyModifier* 与 CustomGestureView* 相关 JVM 测试：**39 项，失败/错误/跳过均为 0**。
- 在隔离审阅副本增加了 3 个临时 Robolectric 探针：创建并点击真实 KeyView，检查服务缓存的模拟 KeyEvent 或 TextKeyboard 状态。**3 项均执行到上述正确性断言并失败，错误/跳过均为 0**，对应逗号零事件、underscore 缺 Shift、Once 残留；这些探针未提交到 PR。
- 探针使用 SDK 28 和空动作监听器隔离键盘分发；物理路径的事件由服务生成并读取。第三项同时核对了生产监听器源码，但未运行真实引擎和宿主应用链路。
- 本轮未安装 APK、未做设备交互验证，因此不把 JVM 结果等同于真机或宿主应用验收。

[![](https://img.shields.io/badge/powered_by-dsh-4D6BFE?style=flat-square&logo=deepseek&logoColor=white)](https://github.com/deepseek-ai/deepseek-harness)
