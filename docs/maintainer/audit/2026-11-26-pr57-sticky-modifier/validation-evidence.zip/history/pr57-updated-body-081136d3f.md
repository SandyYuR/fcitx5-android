在 `fx`（Rime 直连）键盘中，可先点亮 Ctrl / Shift / Alt，再用下一次单键动作触发组合快捷键，方便单手和小屏操作。本 PR 包含原作者的功能实现，以及维护者审阅后补充的派发、大小写和布局编辑器修复。

## 功能与行为

- 新增 `StickyModifierKey`，支持 Ctrl、Shift、Alt 组合，具有点亮、取消和消费后的状态反馈。
- 单击，以及等价于单键 tap 的长按、上滑、下滑动作，可消费已点亮的修饰键；Repeat、双击、左右滑、弹窗长按和多步宏保持既定的消费边界。
- 组合快捷键通过现有服务发送修饰键 DOWN、目标键 DOWN/UP、修饰键逆序 UP；编辑器失效时保护会话并释放内部修饰状态。
- 修复长按字符弹窗后松手又触发基础字母 click 的问题。
- 普通键盘可配置粘滞修饰键；文本编辑面板 `text_editor` 过滤其执行器不支持的这一键型。已有不支持的配置会保留并标明不可用，需明确改为受支持类型后保存。

## 原作者与维护者的贡献

| 贡献者 | 工作内容 | 对应提交 |
| --- | --- | --- |
| @lihuichang（原作者） | 实现粘滞修饰键类型、状态控制、组合派发、手势消费边界、外观与布局编辑配置；修复长按弹窗松手多余 click，补充初始资源与测试。 | [ccaa0178b](https://github.com/SandyYuR/fcitx5-android/commit/ccaa0178b47931e84e192ea09e22217b1df65fdc) |
| @SandyYuR（维护者） | 修复逗号、句号等字面符号快捷键被吞；保留下划线等符号必需的 Shift 并避免重复；让粘滞 Shift 字母正确消费一次性大写，补充 12 项派发回归测试。 | [124f2ade4](https://github.com/SandyYuR/fcitx5-android/commit/124f2ade4bff132628b80918d6b66b3efa4a70d2) |
| @SandyYuR（维护者） | 修复文本编辑面板可配置但无法执行粘滞键的问题：贯通两个编辑入口与嵌套编辑的布局上下文，使用配置类型值绑定选项，保护已有草稿，补充 6 项编辑器回归测试。 | [dd0149db1](https://github.com/SandyYuR/fcitx5-android/commit/dd0149db1f1445747e0a60f2a379df80b9c51b51) |
| @SandyYuR（维护者） | 补齐德语、西班牙语、日语、韩语、俄语的不可用键型提示，修复 Android lint 的 MissingTranslation 错误。 | [081136d3f](https://github.com/SandyYuR/fcitx5-android/commit/081136d3fb1fa7531fb2f8485d36a9d390b98222) |

维护者另完成代码审阅、将分支同步到默认分支强推后的 `f48ab57429cc53f36d69053a0215dbb18756d83a` 基础（固定引擎 SDK `android-sdk-20261125-4`），并执行以下验证。

## 验证与安装包

- 本地相关 JVM 回归：18 份报告、182 项测试，失败 / 错误 / 跳过均为 0。
- 本地 ARM64 Debug 构建、APK 内容检查和 native 链接审计通过。
- 补齐翻译后，本地 `:app:lintFxDebug` 通过；未修改 lint baseline。
- 最新提交：`081136d3fb1fa7531fb2f8485d36a9d390b98222`。
- [PR CI](https://github.com/SandyYuR/fcitx5-android/actions/runs/45653909746) 与 [Direct Rime CI](https://github.com/SandyYuR/fcitx5-android/actions/runs/45653909852) 均已通过；远端前端触摸与引擎测试通过。
- [Commit CI](https://github.com/SandyYuR/fcitx5-android/actions/runs/45655377298) 已通过，JVM 测试与四种 ABI 的签名 Release 构建全部成功。

| 架构 | 安装包下载 |
| --- | --- |
| arm64-v8a（常见 Android 手机） | [签名 Release APK 产物](https://github.com/SandyYuR/fcitx5-android/actions/runs/45655377298/artifacts/15043546478) |
| armeabi-v7a | [签名 Release APK 产物](https://github.com/SandyYuR/fcitx5-android/actions/runs/45655377298/artifacts/15043926030) |
| x86_64 | [签名 Release APK 产物](https://github.com/SandyYuR/fcitx5-android/actions/runs/45655377298/artifacts/15044016056) |
| x86 | [签名 Release APK 产物](https://github.com/SandyYuR/fcitx5-android/actions/runs/45655377298/artifacts/15043291551) |

GitHub Artifacts 下载需要登录，下载 ZIP 后取出其中的 APK 安装。

原作者在初版说明中报告已真机验证粘滞键点亮 / 熄灭、字母组合和长按弹窗。该记录属于原作者的验证；维护者本轮尚未进行人工真机复测。

[![](https://img.shields.io/badge/powered_by-dsh-4D6BFE?style=flat-square&logo=deepseek&logoColor=white)](https://github.com/deepseek-ai/deepseek-harness)
