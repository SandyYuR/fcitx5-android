维护者更新：修复已推送至本 PR 作者分支，当前提交为 `081136d3fb1fa7531fb2f8485d36a9d390b98222`；标题与描述已按最终改动更新。

**贡献分工**

- 原作者 @lihuichang 完成了粘滞 Ctrl / Shift / Alt 的功能实现、状态与外观、手势消费边界、布局配置和初始测试，并修复长按弹窗松手多输入基础字母的问题（`ccaa0178b`）。
- 维护者 @SandyYuR 审阅后修复了字面逗号/句号快捷键、符号必需 Shift 的合并和释放、粘滞 Shift 消费一次性大写的问题，新增 12 项派发回归（`124f2ade4`）。
- 维护者补齐文本编辑面板的键型能力边界：两个编辑入口与嵌套编辑传递布局上下文，过滤不可执行的粘滞键，保留已有草稿并阻止直接保存非法类型，新增 6 项编辑器回归（`dd0149db1`）。
- 本次 PR CI 红灯是维护者补充提示时漏了五种语言翻译。现已补齐德语、西班牙语、日语、韩语、俄语，本地 lint 与远端检查均通过（`081136d3f`）。
- 维护者另完成重新审阅、同步到默认分支强推后的 `f48ab5742` / SDK `android-sdk-20261125-4` 基础，以及构建和 APK 审计。

**验证与下载**

- 本地相关回归：182 项测试，失败、错误和跳过均为 0；ARM64 Debug、APK 内容/native 链接审计及补翻译后的 Android lint 通过。
- [PR CI](https://github.com/SandyYuR/fcitx5-android/actions/runs/45653909746) 与 [Direct Rime CI](https://github.com/SandyYuR/fcitx5-android/actions/runs/45653909852) 均通过，包括远端前端触摸与引擎测试。
- [Commit CI](https://github.com/SandyYuR/fcitx5-android/actions/runs/45655377298) 全部通过，四种 ABI 的签名 Release APK 已生成。
- 常见 Android 手机可下载 [arm64-v8a 签名 Release 产物](https://github.com/SandyYuR/fcitx5-android/actions/runs/45655377298/artifacts/15043546478)；其他 ABI 在同一 Commit CI 的 Artifacts 中。登录 GitHub 后下载 ZIP，取出 APK 安装。

原作者初版的真机验证记录已保留并注明来源；维护者本轮尚未进行人工真机复测。

<!-- pr57-maintainer-update-081136d3f -->
[![](https://img.shields.io/badge/powered_by-dsh-4D6BFE?style=flat-square&logo=deepseek&logoColor=white)](https://github.com/deepseek-ai/deepseek-harness)
