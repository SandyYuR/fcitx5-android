在 fx（Rime 直连）键盘中，可先点亮 Ctrl / Shift / Alt，再用下一次单键动作触发组合快捷键，方便单手和小屏操作。本 PR 包含原作者的功能实现及维护者审阅后补充的兼容修复。

已压缩合入默认分支：[c1307b794](https://github.com/SandyYuR/fcitx5-android/commit/c1307b794f6376977e17145c0a24b433f952e0bc)。唯一父提交为 6a42fa288f5bea20564873ea9b1a2fc8c0aa3495，默认分支仅新增这一个功能提交；源码树与已验证候选 11d1efa6fd628c5d832d88f2f0a1ca6f1449295a 完全相同。

## 功能与行为

- 新增 StickyModifierKey，支持 Ctrl、Shift、Alt 组合，具有点亮、取消和消费后的状态反馈。
- 单击，以及等价于单键 tap 的长按、上滑、下滑动作可消费状态；Repeat、双击、左右滑、弹窗长按和多步宏保持既定边界。
- 组合沿既有服务发送修饰键 DOWN、目标键 DOWN/UP、修饰键逆序 UP；编辑器失效时保护会话并释放内部状态。
- 修复长按字符弹窗后松手又触发基础字母 click。
- 普通键盘支持粘滞修饰键；text_editor 编辑器禁止新选或保存其执行器不支持的这一键型。旧配置保留并标明不可用，需明确改为受支持类型后保存。

## 原作者与维护者贡献

| 贡献者 | 工作内容 | 原审阅提交 → 最终候选提交 |
| --- | --- | --- |
| @lihuichang（原作者） | 粘滞键类型、状态控制、组合派发、手势消费、外观、布局配置、初始资源和测试；长按弹窗松手额外 click 修复。 | ccaa0178b → e1772c02b |
| @SandyYuR（维护者） | 字面逗号、句号等符号映射；符号必需 Shift 的合并与去重；CapsState.Once 消费；12 项派发回归。 | 124f2ade4 → 3bbbaa06d |
| @SandyYuR（维护者） | text_editor 两个编辑入口与嵌套上下文限制，配置值绑定、旧草稿保护；6 项编辑器回归。 | dd0149db1 → 6313d5080 |
| @SandyYuR（维护者） | 补齐德、西、日、韩、俄五种语言提示，修复 lint MissingTranslation；审阅、变基、验证、压缩合入和文档维护。 | 081136d3f → 11d1efa6f |

以上四个修饰键补丁等价重放后压缩为上述单提交，双方共同作者信息已保留。语音生产代码、语音测试和整个 app/src/main/assets 与合入前默认分支 6a42fa288 完全一致，未重放此前已被改写的旧 JS 语音提交。

## 最终候选验证

- 本地 19 份 JUnit 报告、188 项测试，失败 / 错误 / 跳过均为 0，包含 6 项 JS PCM 对齐回归。
- 本地 ARM64 Debug、Android lint、APK 内容和 native 链接审计通过，未修改 lint baseline。
- 候选 [PR CI](https://github.com/SandyYuR/fcitx5-android/actions/runs/45674039183)和[Direct Rime CI](https://github.com/SandyYuR/fcitx5-android/actions/runs/45674039262)均成功；后者前端触摸与引擎报告为 60 项测试、失败 / 错误 / 跳过均为 0。
- 合并后核对单父提交、单新增提交和源码树完全一致。

本轮未进行本机安装、AVD 操作或新的人工真机、真实宿主 InputConnection 和像素验收。原作者初版报告的真机测试属于原作者记录。

旧源码 081136d3f 的 [Commit CI 四 ABI 签名安装包](https://github.com/SandyYuR/fcitx5-android/actions/runs/45655377298)已交付；它属于变基前构建，不代表最终默认分支语音代码。现行用法和完整来源分别见[粘滞修饰键说明](https://github.com/SandyYuR/fcitx5-android/blob/docs/docs/features/keys/sticky-modifier-key.md)与[合入记录及原始证据](https://github.com/SandyYuR/fcitx5-android/blob/docs/docs/maintainer/changes/2026-11-26-sticky-modifier-key.md)。

[![](https://img.shields.io/badge/powered_by-dsh-4D6BFE?style=flat-square&logo=deepseek&logoColor=white)](https://github.com/deepseek-ai/deepseek-harness)
