param([string]$Source, [string]$Destination)
Add-Type -AssemblyName System.Drawing
$canvas = [System.Drawing.Bitmap]::new(1620, 864)
$graphics = [System.Drawing.Graphics]::FromImage($canvas)
$font = [System.Drawing.Font]::new("Segoe UI", 14)
$brush = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(40, 40, 40))
try {
    $graphics.Clear([System.Drawing.Color]::FromArgb(245,245,245))
    $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $themes = @("watercolor", "pulan")
    $kinds = @("keyboard", "numpad", "editor")
    for ($row=0; $row -lt 2; $row++) {
        for ($column=0; $column -lt 3; $column++) {
            $image = [System.Drawing.Image]::FromFile((Join-Path $Source ($themes[$row] + "-" + $kinds[$column] + ".png")))
            try {
                $x = $column * 540; $y = $row * 432
                $graphics.DrawString(($themes[$row] + " / " + $kinds[$column]), $font, $brush, [single]($x+12), [single]($y+7))
                $target = [System.Drawing.Rectangle]::new($x, ($y+34), 540, 396)
                $region = [System.Drawing.Rectangle]::new(0,1368,1080,792)
                $graphics.DrawImage($image, $target, $region, [System.Drawing.GraphicsUnit]::Pixel)
            } finally { $image.Dispose() }
        }
    }
    $canvas.Save($Destination, [System.Drawing.Imaging.ImageFormat]::Png)
} finally { $brush.Dispose(); $font.Dispose(); $graphics.Dispose(); $canvas.Dispose() }
