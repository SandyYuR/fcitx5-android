import hashlib, json, pathlib, sys, zipfile, xml.etree.ElementTree as ET
ROOT = pathlib.Path("D:/GitHub/fx2-rime")
ASSETS = ROOT / "fx-rime-only/app/src/main/assets"
SOURCE = pathlib.Path("D:/GitHub/foxy/布局主题等/水彩+蓝狐狸主题/水彩")
def sha(data): return hashlib.sha256(data).hexdigest()
def shape(svg):
    root = ET.fromstring(svg.removeprefix("svg:"))
    for key in ("id", "data-name", "width", "height"): root.attrib.pop(key, None)
    def node(el): return [el.tag, sorted(el.attrib.items()), (el.text or "").strip(), [node(c) for c in el]]
    return node(root)
def main():
    apk = pathlib.Path(sys.argv[1])
    names = ["bundled/icon_themes/水彩.json", "bundled/icon_themes/普蓝.json", "bundled/keyboard_layouts/TextKeyboardLayout.水彩.json", "bundled/keyboard_layouts/TextKeyboardLayout.普蓝.json", "bundled/fonts/字体图标.otf", "bundled/themes/水彩.json"]
    report = {"apk": {"name":apk.name,"sha256":sha(apk.read_bytes())}, "assets":[],"slotSources":[]}
    with zipfile.ZipFile(apk, metadata_encoding="utf-8") as package:
        if "--inspect" in sys.argv:
            entries = [entry for entry in package.infolist() if entry.filename.startswith("assets/")]
            print([(entry.filename, entry.flag_bits) for entry in entries if any(token in entry.filename for token in ("icon_themes", "keyboard_layouts", "fonts/"))] or [entry.filename for entry in entries[:30]])
            return
        for name in names:
            current = (ASSETS/name).read_bytes()
            packed = package.read("assets/"+name)
            assert current == packed, "APK asset does not match current source: "+name
            report["assets"].append({"path":name,"bytes":len(packed),"sha256":sha(packed)})
        theme = json.loads(package.read("assets/bundled/icon_themes/水彩.json"))["icons"]
    source = json.loads((SOURCE/"水彩布局.json").read_text(encoding="utf-8"))
    bottom = source["layouts"]["default"]["sections"][0]["rows"][-1]
    if isinstance(bottom,dict): bottom = bottom["keys"]
    expected = {"system.toolbar_toggle":(SOURCE/"工具栏/方案.svg").read_text(encoding="utf-8"), "toolbar.icon_theme":(SOURCE/"工具栏/布局预览.svg").read_text(encoding="utf-8"), "text_editor.layout":(SOURCE/"数字键盘/返回.svg").read_text(encoding="utf-8"), "toolbar.virtual_keyboard":(SOURCE/"数字键盘/返回.svg").read_text(encoding="utf-8"), "keys.symbols":bottom[2]["icon"], "keys.space":bottom[3]["icon"]}
    for slot,svg in expected.items():
        assert shape(theme[slot]) == shape(svg), "Wrong source image in "+slot
        report["slotSources"].append({"slot":slot,"sourceGeometryMatches":True,"sha256":sha(theme[slot].encode())})
    font = (ASSETS/"bundled/fonts/字体图标.otf").read_bytes()
    assert font == (SOURCE/"字体字符.otf").read_bytes(), "Bundled font is not the current author font"
    report["fontMatchesAuthor"] = True
    blue = json.loads((ASSETS/"bundled/icon_themes/普蓝.json").read_text(encoding="utf-8"))["icons"]
    blue_source = SOURCE.parent/"蓝狐狸/工具栏/方案.svg"
    assert shape(blue["system.toolbar_toggle"]) == shape(blue_source.read_text(encoding="utf-8"))
    report["prussianMenuMatchesAuthor"] = True
    colors = json.loads((ASSETS/"bundled/themes/水彩.json").read_text(encoding="utf-8"))
    assert colors["altKeyBackgroundColor"] == -1447447
    assert colors["accentKeyBackgroundColor"] == -3481622
    assert colors["accentKeyTextColor"] == -15592166
    report["pickerColorsMatchMainKeys"] = True
    report["numericColumnAlignment"] = []
    for name in ("水彩", "普蓝"):
        doc = json.loads((ASSETS/f"bundled/keyboard_layouts/TextKeyboardLayout.{name}.json").read_text(encoding="utf-8"))
        main_rows = doc["rime"]["default"]; numeric = doc["rime"]["__layer__:数字"]
        left = main_rows[2][0]["weight"]; right = main_rows[2][-1]["weight"]
        assert left == right == main_rows[3][0]["weight"] == main_rows[3][-1]["weight"] == 0.15
        assert all(row[0]["weight"] == left and row[-1]["weight"] == right and abs(sum(k["weight"] for k in row)-1) < 1e-9 for row in numeric)
        report["numericColumnAlignment"].append({"theme":name,"leftFraction":left,"rightFraction":right,"rows":len(numeric)})
    for target,original in (("keys.home","text_editor.home"),("keys.end","text_editor.end"),("keys.pageup","keys.cursor_up"),("keys.pagedown","keys.cursor_down")):
        assert theme[target] == theme[original], "Watercolor navigation artwork differs: " + target
    report["watercolorNavigationReusesColoredEditorIcons"] = True
    text = json.dumps(report,ensure_ascii=False,indent=2)+"\n"
    (ROOT/".dsh-tmp/foxy-update/final-resources.json").write_text(text,encoding="utf-8")
    print(text)
if __name__ == "__main__": main()
