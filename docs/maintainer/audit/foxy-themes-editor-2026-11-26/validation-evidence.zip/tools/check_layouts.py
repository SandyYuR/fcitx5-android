import json, pathlib
ROOT=pathlib.Path("D:/GitHub/fx2-rime")
SOURCE=pathlib.Path("D:/GitHub/foxy/布局主题等/水彩+蓝狐狸主题")
for name,original in [("水彩","水彩"),("普蓝","蓝狐狸")]:
    source=json.loads((SOURCE/original/(original+"布局.json")).read_text(encoding="utf-8"))
    dest=json.loads((ROOT/"fx-rime-only/app/src/main/assets/bundled/keyboard_layouts"/("TextKeyboardLayout."+name+".json")).read_text(encoding="utf-8"))
    native=dest["editor"]
    expected=source["layouts"]["editor"]["sections"][0]
    bypos={(key["row"],key["column"]):key for key in expected["keys"]}
    count=0
    colors=0
    for row,keys in enumerate(native):
        for key in keys:
            src=bypos[(row,key["column"])]
            for field in ["columnSpan","rowSpan"]:
                assert key.get(field,1)==src.get(field,1),(name,row,key,field)
            for old,new in [("background","backgroundColor"),("text","textColor"),("shadow","shadowColor")]:
                value=src.get("override",{}).get("colors",{}).get(old)
                if value:
                    n=int(value.removeprefix("#"),16)
                    if len(value)==7:n|=0xff000000
                    assert key[new]&0xffffffff==n,(name,row,key["column"],new,key[new],value)
                    colors+=1
            count+=1
    assert count==len(bypos)==15
    assert len(native)==4 and expected["columns"]==26 and expected["rows"]==4
    print(name,"grid=26x4", "unique_keys=",count,"author_colors_matched=",colors,"source_spans_match=True")
