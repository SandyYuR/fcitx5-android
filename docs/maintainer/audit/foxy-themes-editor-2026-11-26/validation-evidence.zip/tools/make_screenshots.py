import hashlib,json,pathlib,shutil,struct,subprocess
ROOT=pathlib.Path("D:/GitHub/fx2-rime")
SOURCE=ROOT/".dsh-tmp/foxy-update/device-20261126-final"
DEST=ROOT/"docs-site-worktree/docs/public/images"
def main():
    names=[f"{theme}-{kind}" for theme in ("watercolor","pulan") for kind in ("keyboard","numpad","editor","editor-selected","swipe","status")]+["watercolor-symbols","watercolor-emoji","watercolor-icon-list","watercolor-navigation-icons"]
    result=[]
    for name in names:
        source=SOURCE/(name+".png")
        assert source.is_file(), source
        data=source.read_bytes()
        assert data[:8] == bytes((137,80,78,71,13,10,26,10)), name
        size=struct.unpack(">II",data[16:24])
        assert size==(1080,2280), (name,size)
        destination=DEST/(name+"-20261126.png")
        shutil.copyfile(source,destination)
        result.append({"name":destination.name,"sha256":hashlib.sha256(destination.read_bytes()).hexdigest(),"bytes":destination.stat().st_size})
    # Keep the unmodified full screenshots above; this overview only crops the IME area.
    path=DEST/"key-svg-icons-grid-20261126.png"
    subprocess.run(["pwsh","-NoProfile","-File",str(ROOT/".dsh-tmp/foxy-update/make_contact_sheet.ps1"),"-Source",str(SOURCE),"-Destination",str(path)],check=True)
    result.append({"name":path.name,"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"bytes":path.stat().st_size})
    (SOURCE/"screenshots-manifest.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+chr(10),encoding="utf-8")
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=="__main__": main()
