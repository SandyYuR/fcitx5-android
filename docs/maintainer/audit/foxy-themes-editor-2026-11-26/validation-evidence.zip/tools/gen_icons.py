import json, os, re, sys

REPO = r'D:/GitHub/fx2-rime/fx-rime-only'
THEME_DIR = REPO + '/app/src/main/assets/bundled/icon_themes'
FOXY = r'D:/GitHub/foxy/布局主题等/水彩+蓝狐狸主题'

# 主题名 -> foxy 素材目录名（蓝狐狸即普蓝）
FOXY_DIR = {'水彩': '水彩', '普蓝': '蓝狐狸'}


def read(path):
    with open(path, encoding='utf-8') as f:
        return f.read()


def clean_svg(src):
    s = src
    s = re.sub(r'<\?xml[^>]*\?>', '', s)
    s = re.sub(r'<!--.*?-->', '', s, flags=re.S)
    s = s.strip()
    m = re.search(r'<svg\b[^>]*>', s)
    if not m:
        return None
    tag = m.group(0)
    newtag = re.sub(r'\s(id|data-name|width|height)="[^"]*"', '', tag)
    s = s[:m.start()] + newtag + s[m.end():]
    return s


def inline_icons(theme):
    if theme != '水彩':
        return {}
    layout = json.loads(read(os.path.join(FOXY, '水彩', '水彩布局.json')))
    keys = layout['layouts']['default']['sections'][0]['rows'][3]['keys']
    return {
        'keys.symbols': clean_svg(keys[2]['icon']),
        'keys.space': clean_svg(keys[3]['icon']),
        'keys.language': clean_svg(keys[4]['icon']),
        'keys.language_ascii': clean_svg(keys[4]['variants'][0]['icon']),
    }


def slots_for(theme):
    """theme name -> dict slot -> file path"""
    sub = FOXY_DIR[theme]
    root = os.path.join(FOXY, sub)
    out = {}
    if theme == '水彩':
        m = {
            'keys.capslock.none': '功能键/shift.svg',
            'keys.capslock.once': '功能键/shift单击.svg',
            'keys.capslock.lock': '功能键/shift锁定.svg',
            'keys.language': '功能键/中英.svg',
            'keys.language_ascii': '功能键/中英2.svg',
            'keys.comma': '功能键/逗号.svg',
            'keys.period': '功能键/句号.svg',
            'keys.semicolon': '功能键/分号.svg',
            'keys.semicolon_alt': '功能键/分号2.svg',
            'keys.slash': '功能键/斜杠.svg',
            'keys.left_bracket': '功能键/左括.svg',
            'keys.right_bracket': '功能键/右括.svg',
            'keys.space': '功能键/空格.svg',
            'keys.backspace': '功能键/删除.svg',
            'keys.return.default': '功能键/回车.svg',
            'toolbar.language_switch': '功能键/中英.svg',
            'toolbar.language_switch_ascii': '功能键/中英2.svg',
            'toolbar.rime_schema_menu': '工具栏/方案.svg',
            'toolbar.reload_config': '工具栏/部署.svg',
            'toolbar.clipboard': '工具栏/剪切板.svg',
            'toolbar.one_handed_keyboard': '工具栏/单手.svg',
            'toolbar.one_handed_keyboard_active': '工具栏/单手激活.svg',
            'toolbar.floating_toggle': '工具栏/尺寸2.svg',
            'toolbar.floating_toggle_active': '工具栏/尺寸2激活.svg',
            'toolbar.split_keyboard': '工具栏/分体.svg',
            'toolbar.split_keyboard_active': '工具栏/分体激活.svg',
            'toolbar.edit_layout': '工具栏/编辑.svg',
            'toolbar.edit_fontset': '工具栏/编辑.svg',
            'toolbar.ai_assistant': '工具栏/ai.svg',
            'toolbar.js_app.youdao_translate': '工具栏/有道.svg',
            'toolbar.js_app.bilibili_translate': '工具栏/b站.svg',
            'toolbar.settings_global': '工具栏/设置.svg',
            'toolbar.settings_ime': '工具栏/设置.svg',
            'toolbar.input_method_options': '工具栏/设置.svg',
            'toolbar.theme': '工具栏/主题.svg',
            'toolbar.theme_toggle': '工具栏/主题.svg',
            'toolbar.random_theme': '工具栏/主题.svg',
            'toolbar.icon_theme': '工具栏/布局预览.svg',
            'toolbar.virtual_keyboard': '数字键盘/返回.svg',
            'toolbar.voice_input': '工具栏/语音.svg',
            'toolbar.voice_input_active': '工具栏/语音激活.svg',
            'system.hide_keyboard': '工具栏/收起.svg',
            'system.voice_input': '工具栏/语音.svg',
            'system.toolbar_toggle': '工具栏/方案.svg',
            'text_editor.layout': '数字键盘/返回.svg',
        }
        for c in 'abcdefghijklmnopqrstuvwxyz':
            m['keys.letter.' + c] = '英文字母/%s.svg' % c
        num = {'add': '加', 'subtract': '减', 'multiply': '星', 'divide': '除',
               'equal': '等于', 'decimal': '点', 'at': '艾特', 'percent': '百分号',
               'space': '空格', 'layout': '返回'}
        for d in '0123456789':
            m['keys.numpad.' + d] = '数字键盘/%s.svg' % d
        for k, v in num.items():
            m['keys.numpad.' + k] = '数字键盘/%s.svg' % v
        ed = {'cursor_left': '左', 'cursor_right': '右', 'cursor_up': '上', 'cursor_down': '下',
              'select_all': '全选', 'select': '选择', 'select_locked': '选择锁定',
              'cut': '剪切', 'copy': '复制', 'paste': '粘贴', 'home': '行首', 'end': '行尾'}
        for k, v in ed.items():
            if k.startswith('cursor_'):
                m['keys.' + k] = '编辑键盘/%s.svg' % v
            else:
                m['text_editor.' + k] = '编辑键盘/%s.svg' % v
        m['keys.home'] = m['text_editor.home']
        m['keys.end'] = m['text_editor.end']
        m['keys.pageup'] = m['keys.cursor_up']
        m['keys.pagedown'] = m['keys.cursor_down']
        m['text_editor.backspace'] = '功能键/删除.svg'
        m['text_editor.space'] = '数字键盘/空格.svg'
        m['text_editor.return'] = '功能键/回车.svg'
    else:
        m = {
            'keys.capslock.none': '功能键/shi.svg',
            'keys.capslock.once': '功能键/shi单击.svg',
            'keys.capslock.lock': '功能键/shi锁定.svg',
            'keys.language': '功能键/中英.svg',
            'keys.language_ascii': '功能键/中英2.svg',
            'keys.space': '功能键/大空格.svg',
            'keys.backspace': '功能键/del.svg',
            'keys.return.default': '功能键/ent.svg',
            'toolbar.language_switch': '功能键/中英.svg',
            'toolbar.language_switch_ascii': '功能键/中英2.svg',
            'system.voice_input': '工具栏/语音.svg',
            'toolbar.rime_schema_menu': '工具栏/方案.svg',
            'toolbar.reload_config': '工具栏/部署.svg',
            'toolbar.clipboard': '工具栏/剪切板.svg',
            'toolbar.one_handed_keyboard': '工具栏/单手.svg',
            'toolbar.one_handed_keyboard_active': '工具栏/单手激活.svg',
            'toolbar.floating_toggle': '工具栏/尺寸.svg',
            'toolbar.floating_toggle_active': '工具栏/尺寸激活.svg',
            'toolbar.split_keyboard': '工具栏/分体.svg',
            'toolbar.split_keyboard_active': '工具栏/分体激活.svg',
            'toolbar.edit_layout': '工具栏/编辑.svg',
            'toolbar.edit_fontset': '工具栏/编辑.svg',
            'toolbar.ai_assistant': '工具栏/ai.svg',
            'toolbar.js_app.youdao_translate': '工具栏/有道.svg',
            'toolbar.js_app.bilibili_translate': '工具栏/哔哩哔哩.svg',
            'toolbar.settings_global': '工具栏/设置.svg',
            'toolbar.settings_ime': '工具栏/设置.svg',
            'toolbar.input_method_options': '工具栏/设置.svg',
            'toolbar.theme': '工具栏/主题.svg',
            'toolbar.theme_toggle': '工具栏/主题.svg',
            'toolbar.random_theme': '工具栏/主题.svg',
            'toolbar.icon_theme': '工具栏/主题.svg',
            'toolbar.virtual_keyboard': '工具栏/布局预览2.svg',
            'toolbar.voice_input': '工具栏/语音.svg',
            'toolbar.voice_input_active': '工具栏/语音激活.svg',
            'system.hide_keyboard': '工具栏/收起.svg',
            'system.toolbar_toggle': '工具栏/方案.svg',
            'keys.cursor_left': '编辑键盘/左.svg',
            'keys.cursor_right': '编辑键盘/右.svg',
            'keys.cursor_up': '编辑键盘/上.svg',
            'keys.cursor_down': '编辑键盘/下.svg',
            'text_editor.select_all': '编辑键盘/全选.svg',
            'text_editor.cut': '编辑键盘/剪切.svg',
            'text_editor.copy': '编辑键盘/复制.svg',
            'text_editor.paste': '编辑键盘/粘贴.svg',
            'text_editor.home': '编辑键盘/行首.svg',
            'text_editor.end': '编辑键盘/行尾.svg',
            'text_editor.space': '编辑键盘/小空格.svg',
            'text_editor.backspace': '功能键/del.svg',
            'text_editor.return': '功能键/ent.svg',
            'text_editor.layout': '工具栏/布局预览.svg',
        }
    for slot, rel in m.items():
        out[slot] = os.path.join(root, rel)
    return out


def build(theme, dry=True):
    path = os.path.join(THEME_DIR, theme + '.json')
    data = json.loads(read(path))
    icons = data['icons']
    mapping = slots_for(theme)
    inline = inline_icons(theme)
    mapping.update({slot: None for slot in inline})
    added, replaced, missing, unchanged = [], [], [], []
    for slot, fp in mapping.items():
        if slot in inline:
            svg = inline[slot]
        else:
            if not os.path.exists(fp):
                missing.append((slot, fp))
                continue
            svg = clean_svg(read(fp))
        if svg is None:
            missing.append((slot, fp + ' (no root svg)'))
            continue
        if slot in icons:
            if icons[slot] == svg:
                unchanged.append(slot)
            else:
                replaced.append(slot)
        else:
            added.append(slot)
        icons[slot] = svg
    print(theme, 'added', len(added), 'replaced', len(replaced), 'unchanged', len(unchanged),
          'missing', len(missing), 'total', len(icons))
    for x in missing:
        print('  MISSING', x)
    print('  added:', added)
    print('  replaced:', replaced)
    if not dry:
        with open(path, 'w', encoding='utf-8', newline='\n') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write('\n')
        print('  written', os.path.getsize(path))


if __name__ == '__main__':
    dry = '--write' not in sys.argv
    for t in ['水彩', '普蓝']:
        build(t, dry=dry)
