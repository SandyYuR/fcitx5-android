import hashlib, json, pathlib, subprocess, sys, zipfile
import xml.etree.ElementTree as ET

ROOT = pathlib.Path("D:/GitHub/fx2-rime")
CODE = ROOT / "fx-rime-only"
OUT = ROOT / "docs-site-worktree/docs/maintainer/audit/foxy-themes-editor-2026-11-26"
TMP = ROOT / ".dsh-tmp/foxy-update"
NAMES = ["TextEditingLayoutResolverTest", "TextEditingLayoutLoaderTest", "ConfiguredTextEditingUiTest", "IconTextKeyViewTest", "KeyEditorFormTest", "IconThemeSlotCatalogTest", "LanguageSwitchIconFallbackTest", "JsAppButtonBindingTest", "LetterIconKeyTest", "NumericLayoutResolverTest", "ThemePreviewLayoutTest", "BundledThemeLayoutTest", "BundledPresetsUpgradeTest", "IconThemeGrayPaletteTest", "SymbolPanelColorTest", "SymbolPanelIconThemeTest", "SymbolPanelTabRadiusTest", "IconThemeEditorPreviewTest", "IconThemeManagerCacheSelectionTest"]

def digest(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(["git", "-C", str(CODE), *args])

def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: collect_evidence.py APK_PATH TEST_APK_PATH")
    reports = CODE / "app/build/test-results/testFxDebugUnitTest"
    selected = []
    totals = dict(tests=0, failures=0, errors=0, skipped=0)
    for name in NAMES:
        matches = list(reports.glob("TEST-*." + name + ".xml"))
        if len(matches) != 1: raise RuntimeError(f"Expected one XML for {name}: {matches}")
        path = matches[0]
        suite = ET.parse(path).getroot()
        counts = {key:int(suite.attrib.get(key, 0)) for key in totals}
        if not counts["tests"] or any(counts[key] for key in ("failures", "errors", "skipped")):
            raise RuntimeError(f"Not a clean executed suite: {name} {counts}")
        for key in totals: totals[key] += counts[key]
        selected.append((path, counts))
    tracked = git("diff", "--name-only", "-z", "HEAD").decode("utf-8").split("\0")
    untracked = git("ls-files", "--others", "--exclude-standard", "-z").decode("utf-8").split("\0")
    files = sorted(set(path for path in tracked + untracked if path.startswith("app/src/")))
    parallel = {"app/src/main/java/org/fcitx/fcitx5/android/input/keyboard/KeyView.kt", "app/src/test/java/org/fcitx/fcitx5/android/input/keyboard/KeyPressHighlightGeometryTest.kt"}
    source = [{"path":p, "sha256":digest((CODE/p).read_bytes()), "bytes":(CODE/p).stat().st_size, "scope":"parallel-session" if p in parallel else "foxy-themes-editor"} for p in files]
    apks = [{"name":pathlib.Path(p).name, "bytes":pathlib.Path(p).stat().st_size, "sha256":digest(pathlib.Path(p).read_bytes())} for p in sys.argv[1:]]
    logs = [TMP/"final-jvm.log", TMP/"final-build.log", TMP/"final-instrumentation-build.log", TMP/"final-device.log"]
    for path in logs:
        if not path.is_file() or not path.stat().st_size: raise RuntimeError(f"Missing log: {path}")
    device = logs[-1].read_text(encoding="utf-8-sig")
    if "OK (1 test)" not in device or "FAILURES!!!" in device: raise RuntimeError("Device regression did not pass")
    OUT.mkdir(parents=True, exist_ok=True)
    archive = OUT/"validation-evidence.zip"
    members = {}
    for path, _ in selected: members["junit/" + path.name] = path.read_bytes()
    for path in logs: members["logs/" + path.name] = path.read_bytes()
    for name in ("jvm-compile-failure-130219.log", "jvm-fixture-failure-131351.zip", "jvm-bitmap-fixture-failure-131804.zip", "jvm-visual-compile-failure-1445.log", "device-startup-fixture-failure-1452.log"):
        path = TMP/name
        if path.is_file(): members["earlier-failures/" + path.name] = path.read_bytes()
    resources = TMP/"final-resources.json"
    if not resources.is_file(): raise RuntimeError("Missing packaged resource verification")
    packaged = json.loads(resources.read_text(encoding="utf-8"))
    if packaged["apk"]["sha256"] != apks[0]["sha256"]: raise RuntimeError("Resource report targets a different APK")
    members["resources/packaged-assets.json"] = resources.read_bytes()
    for relative in ("pre-install-assets.json", "pre-install-assets-latest.json", "pre-install-assets-visual.json", "post-install-assets.json", "device-20261126-final/screenshots-manifest.json", "device-20261126-final/numeric-edge-bounds.json"):
        snapshot = TMP/relative
        if not snapshot.is_file(): raise RuntimeError("Missing device resource evidence: "+relative)
        json.loads(snapshot.read_text(encoding="utf-8"))
        members["device/"+snapshot.name] = snapshot.read_bytes()
    for name in ("device-wrapper-notes.txt", "editor-review-evidence.txt"):
        members["device/"+name] = (TMP/name).read_bytes()
    for name in ("gen_icons.py", "check_layouts.py", "verify_packaged.py", "verify_installed.py", "make_screenshots.py", "make_contact_sheet.ps1", "build_review_evidence.py", "build_s1_final.py", "align_numeric_columns.py", "collect_evidence.py"):
        members["tools/"+name] = (TMP/name).read_bytes()
    for name in ("s1-final-1.txt", "s1-final-2.txt", "s1-final-3.txt", "s1-final-4.txt", "s1-review-result.json"):
        members["review/"+name] = (TMP/name).read_bytes()
    members["source/worktree.patch"] = git("diff", "--binary", "HEAD", "--", "app/src")
    for p in untracked:
        if p.startswith("app/src/"): members["source/untracked/" + p] = (CODE/p).read_bytes()
    members["source/source-manifest.json"] = (json.dumps(source, ensure_ascii=False, indent=2)+"\n").encode()
    members["source/rime-sdk.lock.json"] = (CODE/"native/rime-sdk.lock.json").read_bytes()
    manifest = {"codeBase":git("rev-parse", "HEAD").decode().strip(), "uncommitted":True, "junit":{"suites":len(selected), **totals, "details":[{"suite":p.name, **c} for p,c in selected]}, "apks":apks, "sourceFiles":source, "members":[{"path":p,"bytes":len(data),"sha256":digest(data)} for p,data in sorted(members.items())]}
    with zipfile.ZipFile(archive,"w",zipfile.ZIP_DEFLATED) as z:
        for name,data in sorted(members.items()): z.writestr(name,data)
    manifest["archive"]={"name":archive.name,"bytes":archive.stat().st_size,"sha256":digest(archive.read_bytes())}
    (OUT/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    with zipfile.ZipFile(archive) as z:
        for entry in manifest["members"]:
            if digest(z.read(entry["path"])) != entry["sha256"]: raise RuntimeError("Archive verification failed")
    print(json.dumps({"junit":manifest["junit"],"apks":apks,"archive":manifest["archive"],"sourceFiles":len(source)},ensure_ascii=False,indent=2))

if __name__ == "__main__": main()
