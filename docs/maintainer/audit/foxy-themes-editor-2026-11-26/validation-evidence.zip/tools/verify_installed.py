import hashlib, json, pathlib, subprocess, sys
ROOT = pathlib.Path("D:/GitHub/fx2-rime")
BASE = ROOT / ".dsh-tmp/foxy-update"
report = json.loads((BASE / "final-resources.json").read_text(encoding="utf-8"))
paths = {"icon_themes": "icon_themes", "keyboard_layouts": "config", "fonts": "fonts", "themes": "theme"}
before = "--before" in sys.argv
results = []
for entry in report["assets"]:
    _, folder, name = entry["path"].split("/", 2)
    relative = paths[folder] + "/" + name
    remote = "/sdcard/Android/data/org.fcitx.fcitx5.android.fx.rime.debug/files/" + relative
    data = subprocess.run(["adb", "-s", "emulator-5574", "exec-out", "cat", remote], check=True, capture_output=True).stdout
    digest = hashlib.sha256(data).hexdigest()
    assert before or digest == entry["sha256"], "Installed asset differs from final APK: " + relative
    results.append({"path": relative, "bytes": len(data), "sha256": digest, "matchesPackagedAsset": digest == entry["sha256"]})
(BASE / ("pre-install-assets-latest.json" if before else "post-install-assets.json")).write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(results, ensure_ascii=False, indent=2))
