import json,pathlib,hashlib,re,zipfile
R=pathlib.Path("D:/GitHub/fx2-rime/fx-rime-only/app/src/main/assets/bundled/keyboard_layouts")
APK=pathlib.Path("D:/GitHub/fx2-rime/fx-rime-only/app/build/outputs/apk/fx/debug/org.fcitx.fcitx5.android.fx.rime-nightly-0.1.3-877-ge3ea3af9-20261124-143052-5-gc1307b794-fx-x86_64-debug.apk")
expected={"水彩":"080fc425b471b0e6ad2d0d81fc5af116ac78cc313e500199a1b57926022d03e1","普蓝":"9797e1c2fd105849c949efdc5e8f1f5520adf36ac25390edc96a38fc062b2fb6"}
with zipfile.ZipFile(APK,metadata_encoding="utf-8") as z:
    for name in ("水彩","普蓝"):
        p=R/f"TextKeyboardLayout.{name}.json"; raw=z.read("assets/bundled/keyboard_layouts/"+p.name)
        assert hashlib.sha256(raw).hexdigest()==expected[name]
        text=raw.decode("utf-8"); doc=json.loads(text); current=json.loads(p.read_text(encoding="utf-8"))
        main=doc["rime"]["default"]; numeric=doc["rime"]["__layer__:数字"]
        left=main[2][0]["weight"]; right=main[2][-1]["weight"]
        assert left==right==main[3][0]["weight"]==main[3][-1]["weight"]==0.15
        for row in numeric:
            middle=sum(k["weight"] for k in row[1:-1]); row[0]["weight"]=left; row[-1]["weight"]=right
            for k in row[1:-1]: k["weight"]=(1-left-right)*k["weight"]/middle
        assert doc==current, "Existing layout changed outside the intended width values"
        key=text.index(chr(34)+"__layer__:数字"+chr(34)); start=text.index("[",key)
        _,length=json.JSONDecoder().raw_decode(text[start:]); section=text[start:start+length]
        weights=[k["weight"] for row in numeric for k in row]; i=iter(weights)
        pattern=r'("weight"\s*:\s*)([-+0-9.eE]+)'
        assert len(re.findall(pattern,section))==len(weights)
        replaced=re.sub(pattern,lambda m:m.group(1)+repr(next(i)),section)
        updated=text[:start]+replaced+text[start+length:]
        assert json.loads(updated)==doc
        p.write_bytes(updated.encode("utf-8"))
        data=p.read_bytes(); print(name,"original",len(raw),"updated",len(data),"sha256",hashlib.sha256(data).hexdigest())
