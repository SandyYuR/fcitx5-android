import hashlib,json,pathlib,xml.etree.ElementTree as ET
ROOT=pathlib.Path("D:/GitHub/fx2-rime")
BASE=ROOT/".dsh-tmp/foxy-update"
CODE=ROOT/"fx-rime-only"
parts=["Final APK: "+json.loads((BASE/"final-resources.json").read_text(encoding="utf-8"))["apk"]["sha256"]]
parts.append("Final actual instrumentation log; the earlier wrapper mismatch and startup fixture failure are preserved separately:")
parts.append((BASE/"final-device.log").read_text(encoding="utf-8-sig"))
totals={key:0 for key in ("tests","failures","errors","skipped")}
for report in sorted((CODE/"app/build/test-results/testFxDebugUnitTest").glob("TEST-*.xml")):
    suite=ET.parse(report).getroot()
    counts={key:int(suite.attrib.get(key,0)) for key in totals}
    assert counts["tests"]>0 and not any(counts[key] for key in ("failures","errors","skipped"))
    for key in totals: totals[key]+=counts[key]
    parts.append(json.dumps({"report":report.name,"sha256":hashlib.sha256(report.read_bytes()).hexdigest(),**counts},ensure_ascii=False))
    if any(name in suite.attrib["name"] for name in ("ConfiguredTextEditingUiTest","TextEditingLayoutLoaderTest","KeyEditorFormTest")):
        parts.extend("  PASS "+case.attrib["name"] for case in suite.findall("testcase"))
parts.append("TOTAL "+json.dumps(totals))
path=CODE/"app/src/main/java/org/fcitx/fcitx5/android/ui/main/settings/behavior/dialog/KeyEditorForm.kt"
lines=path.read_text(encoding="utf-8").splitlines()
parts.append("Exact source excerpts: "+str(path)+" sha256="+hashlib.sha256(path.read_bytes()).hexdigest())
for start,end in ((1830,1875),(2380,2425)):
    parts.extend(str(i+1)+": "+lines[i] for i in range(start-1,end))
(BASE/"editor-review-evidence.txt").write_text(chr(10).join(parts)+chr(10),encoding="utf-8")
print(json.dumps({"totals":totals,"proofBytes":(BASE/"editor-review-evidence.txt").stat().st_size}))
