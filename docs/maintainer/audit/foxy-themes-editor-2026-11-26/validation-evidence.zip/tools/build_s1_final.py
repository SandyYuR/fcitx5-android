import hashlib,json,pathlib,xml.etree.ElementTree as ET
R=pathlib.Path("D:/GitHub/fx2-rime"); C=R/"fx-rime-only"; O=R/".dsh-tmp/foxy-update"
def excerpt(path,start=1,end=None):
    p=C/path; data=p.read_bytes(); lines=data.decode("utf-8").splitlines(); end=end or len(lines)
    rows=[f"SOURCE {path} sha256={hashlib.sha256(data).hexdigest()}"]
    for i in range(start-1,min(end,len(lines))):
        text=lines[i]; stripped=text.strip()
        if stripped and not stripped.startswith(("//","/*","*")): rows.append(f"{i+1}: {text}")
    return chr(10).join(rows)
def between(path,first,last):
    lines=(C/path).read_text(encoding="utf-8").splitlines()
    start=next(i+1 for i,line in enumerate(lines) if first in line)
    end=next(i+1 for i,line in enumerate(lines) if i+1>start and last in line)
    return excerpt(path,start,end)
M="app/src/main/java/org/fcitx/fcitx5/android/"; T="app/src/test/java/org/fcitx/fcitx5/android/"; E=M+"input/editing/"; P=M+"ui/main/settings/behavior/"
groups=[
 [excerpt(E+"TextEditingLayoutResolver.kt"),excerpt(E+"TextEditingLayout.kt",49,64),excerpt(E+"TextEditingWindow.kt",299,337)],
 [excerpt(T+"input/editing/ConfiguredTextEditingUiTest.kt",106,160),excerpt(E+"ConfiguredTextEditingUi.kt",109,148),between("app/src/androidTest/java/org/fcitx/fcitx5/android/input/editing/TextEditingDeviceTest.kt","val keys = ui!!.keyViews",'screenshot("$imagePrefix-keyboard")')],
 [excerpt(T+"input/editing/TextEditingLayoutLoaderTest.kt"),excerpt(T+"ui/main/settings/behavior/editor/KeyEditorFormTest.kt",467,490),excerpt(P+"preview/KeyboardPreviewManager.kt",265,292),excerpt(P+"dialog/KeyEditorForm.kt",1847,1858),excerpt(P+"dialog/KeyEditorForm.kt",2398,2409)]
 ]
for i,parts in enumerate(groups,1):
    text=(chr(10)*2).join(parts)+chr(10); p=O/f"s1-final-{i}.txt"; p.write_text(text,encoding="utf-8"); print(p.name,len(text),len(text.splitlines()))
parts=["FINAL APK SHA256 "+json.loads((O/"final-resources.json").read_text(encoding="utf-8"))["apk"]["sha256"],(O/"final-device.log").read_text(encoding="utf-8-sig")]
assert "OK (1 test)" in parts[-1] and "FAILURES!!!" not in parts[-1]
total={key:0 for key in ("tests","failures","errors","skipped")}
for p in sorted((C/"app/build/test-results/testFxDebugUnitTest").glob("TEST-*.xml")):
    s=ET.parse(p).getroot(); counts={key:int(s.attrib.get(key,0)) for key in total}; assert counts["tests"]>0 and not any(counts[k] for k in ("failures","errors","skipped"))
    parts.append(p.name+" "+json.dumps(counts)+" SHA256="+hashlib.sha256(p.read_bytes()).hexdigest())
    for key in total: total[key]+=counts[key]
    if any(n in s.attrib["name"] for n in ("ConfiguredTextEditingUiTest","TextEditingLayoutLoaderTest","KeyEditorFormTest")): parts.extend("PASS "+c.attrib["name"] for c in s.findall("testcase"))
parts.append("TOTAL "+json.dumps(total)); text=chr(10).join(parts)+chr(10); (O/"s1-final-4.txt").write_text(text,encoding="utf-8"); print("s1-final-4.txt",len(text),len(text.splitlines()))
