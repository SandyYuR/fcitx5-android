/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2026 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.input.keyboard

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import android.os.Looper
import android.view.View
import android.widget.ImageView
import androidx.annotation.Keep
import org.fcitx.fcitx5.android.data.theme.IconThemeManager
import androidx.core.view.allViews
import java.lang.ref.WeakReference
import java.util.WeakHashMap
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.core.InputMethodEntry
import org.fcitx.fcitx5.android.core.KeyState
import org.fcitx.fcitx5.android.core.KeyStates
import org.fcitx.fcitx5.android.input.FcitxInputMethodService
import org.fcitx.fcitx5.android.data.prefs.AppPrefs
import org.fcitx.fcitx5.android.data.prefs.ManagedPreference
import org.fcitx.fcitx5.android.data.theme.Theme
import org.fcitx.fcitx5.android.data.theme.ThemeManager
import org.fcitx.fcitx5.android.data.theme.ThemePrefs
import org.fcitx.fcitx5.android.input.popup.PopupAction
import splitties.views.imageResource
import kotlinx.serialization.json.*
import kotlinx.serialization.Serializable
import org.fcitx.fcitx5.android.ui.main.settings.behavior.utils.LayoutJsonUtils

internal fun interface NumericLayoutFallbackListener {
    fun onNumericLayoutOverrideInvalidated()
}

@SuppressLint("ViewConstructor")
class TextKeyboard private constructor(
    context: Context,
    theme: Theme,
    initialLayoutState: TextKeyboardLayoutState,
    private val isPreview: Boolean
) : BaseKeyboard(
    context,
    theme,
    initialLayoutState::getLayout,
    { initialLayoutState.auxBarConfig },
    initialLayoutState::getAuxBarKeyDefs
) {
    /**
     * @param initialIme the input method this keyboard renders for. Previews pass their own
     * preview entry, so they can no longer overwrite the real keyboard's layout state; the
     * real keyboard is seeded with the current input method by [KeyboardWindow] to avoid an
     * initial default layout followed by an immediate rebuild.
     *
     * @param isPreview whether this keyboard is a settings preview. Previews keep rendering
     * their own layout and are excluded from numeric-override broadcasts.
     */
    constructor(
        context: Context,
        theme: Theme,
        initialIme: InputMethodEntry? = null,
        isPreview: Boolean = false
    ) : this(context, theme, beginConstruction(TextKeyboardLayoutState(initialIme)), isPreview)

    /**
     * Assigned only after the superclass constructor has returned: [BaseKeyboard]'s init block
     * already resolves a layout (`reloadLayout` -> [currentLayoutSignature]), and instance
     * fields are still unset at that point. Never read this directly — use [layoutState].
     */
    private val ownLayoutState: TextKeyboardLayoutState? = initialLayoutState

    /** This keyboard's layout state, also readable while its constructor is still running. */
    private val layoutState: TextKeyboardLayoutState
        get() = ownLayoutState ?: constructingLayoutState

    enum class CapsState { None, Once, Lock }

    companion object {
        const val Name = "Text"
        private const val LAYOUT_META_KEY = "__meta__"
        private const val LAYOUT_META_HEIGHT_PERCENT_KEY = "keyboard_height_percent"
        private const val LAYOUT_META_HEIGHT_PERCENT_LANDSCAPE_KEY = "keyboard_height_percent_landscape"
        private const val LAYOUT_META_AUX_BAR_KEY = "aux_bar"

        private fun legacySwipeTargetIsUp(): Boolean =
            LayoutJsonUtils.legacySwipeTargetsUpFromSettings(
                AppPrefs.getInstance().keyboard.swipeSymbolDirection.getValue(),
                ThemeManager.prefs.punctuationPosition.getValue()
            )
        private var lastModified = 0L

        /**
         * Layout state of the keyboard whose constructor is currently running. [BaseKeyboard]
         * resolves a layout from its own init block, before the instance field is assigned, so
         * early override calls read the state through here. Keyboards are only constructed on
         * the main thread and the instance field takes over as soon as the superclass
         * constructor returns, so a single slot is enough.
         */
        @Volatile
        private var constructingLayoutState = TextKeyboardLayoutState()

        private fun beginConstruction(
            state: TextKeyboardLayoutState
        ): TextKeyboardLayoutState {
            check(Looper.myLooper() == Looper.getMainLooper()) {
                "TextKeyboard must be constructed on the main thread (single-slot construction state)"
            }
            constructingLayoutState = state
            return state
        }

        /**
         * The real keyboard's current input method, kept in sync by [KeyboardWindow]. Only
         * window-level state that must follow the real input method reads this (keyboard
         * height overrides, layer targets, the base entry of preview IMEs). Per-instance
         * layout resolution uses [TextKeyboardLayoutState.ime] instead.
         */
        var ime: InputMethodEntry? = null
        private var listenerRegistered = false
        private var resolvedLayoutHeightPercentOverride: Int? = null
        private val attachedKeyboards = mutableListOf<WeakReference<TextKeyboard>>()

        @Synchronized
        private fun ensureListenerRegistered() {
            if (listenerRegistered) return
            org.fcitx.fcitx5.android.input.config.ConfigProviders.addTextKeyboardLayoutListener {
                onTextLayoutFileChanged()
            }
            listenerRegistered = true
        }

        @Synchronized
        private fun registerKeyboard(keyboard: TextKeyboard) {
            attachedKeyboards.removeAll { it.get() == null || it.get() === keyboard }
            attachedKeyboards.add(WeakReference(keyboard))
            ensureListenerRegistered()
        }

        @Synchronized
        private fun unregisterKeyboard(keyboard: TextKeyboard) {
            attachedKeyboards.removeAll { it.get() == null || it.get() === keyboard }
        }

        @Synchronized
        private fun onTextLayoutFileChanged() {
            handleLayoutSourceChanged()
            val living = attachedKeyboards.mapNotNull { it.get() }
            attachedKeyboards.removeAll { it.get() == null }
            living.forEach { keyboard ->
                keyboard.refreshStyle()
                keyboard.refreshSpaceLabelFromState()
            }
        }

        @Synchronized
        fun refreshCapsPresentationOnAll() {
            val living = attachedKeyboards.mapNotNull { it.get() }
            attachedKeyboards.removeAll { it.get() == null }
            living.forEach { keyboard ->
                keyboard.refreshCapsPresentation()
            }
        }

        @Synchronized
        fun clearCapsStateOnAll() {
            val living = attachedKeyboards.mapNotNull { it.get() }
            attachedKeyboards.removeAll { it.get() == null }
            living.forEach { keyboard ->
                keyboard.clearLocalCapsState()
            }
        }

        // Cache for raw JSON layout (preserves submode structure)
        internal var cachedRawLayoutJson: JsonObject? = null
        private var lastRawModified = 0L
        private var lastRawLayoutFile: String? = null

        // Compatibility alias for cachedRawLayoutJson (used by SplitKeyboardCalibrationActivity)
        @JvmStatic
        var cachedLayoutJsonMap: JsonObject?
            get() = cachedRawLayoutJson
            set(value) {
                cachedRawLayoutJson = value
                if (value == null) {
                    lastRawLayoutFile = null
                }
            }

        /**
         * Maximum number of parsed layouts kept in [cachedKeyDefLayouts].
         *
         * Cache keys combine input method, sub mode, showLangSwitch and display-text context,
         * so the set of distinct keys grows with usage; the map is only cleared wholesale when
         * the layout file changes. A bound keeps it proportional to what the user actually
         * switches between, while still covering a normal rotation of layouts.
         */
        private const val MAX_CACHED_KEY_DEF_LAYOUTS = 12

        /**
         * Cache for parsed KeyDef layouts, to avoid recreating them on every reloadLayout().
         *
         * Access-ordered and size-bounded: the least recently used layout is evicted, which is
         * the right policy here because the keyboard keeps returning to the layouts the user
         * switches between most.
         */
        private val cachedKeyDefLayouts =
            object : LinkedHashMap<String, List<List<KeyDef>>>(16, 0.75f, true) {
                override fun removeEldestEntry(
                    eldest: MutableMap.MutableEntry<String, List<List<KeyDef>>>?
                ): Boolean = size > MAX_CACHED_KEY_DEF_LAYOUTS
            }
        private var forcedLayoutKey: String? = null
        // 密码输入框专用：fcitx 对密码框回退成裸键盘（keyboard-us），编码不走 Rime，
        // 但 currentIme() 会回退到缓存的上一个 Rime 方案，导致键盘视图仍显示上次的
        // 九键/二十六键。开启此标记后，getLayout 一律用布局文件里的全局 "default"
        // 排列（ascii 直录用的那套），优先级高于 forcedLayoutKey 与方案变体解析，
        // 且不受 onImeUpdate 的 clearAllLayerOverrides 影响（只有 onStartInput 按
        // Password 能力增删它）。
        private var passwordDefaultLayout = false
        private val numericOverride = NumericLayoutOverrideController()
        private var numericLayoutFallbackTarget: WeakReference<NumericLayoutFallbackListener>? = null

        /**
         * 密码框是否固定使用全局 "default" 布局。仅由 [KeyboardWindow.onStartInput]
         * 依据 Password 能力增删。返回是否发生变化（变化时调用方需要触发重排）。
         */
        fun setPasswordDefaultLayout(active: Boolean): Boolean {
            if (passwordDefaultLayout == active) return false
            passwordDefaultLayout = active
            return true
        }

        fun isPasswordDefaultLayout(): Boolean = passwordDefaultLayout

        /**
         * Clear KeyDef layout cache. Call this after saving layout changes.
         */
        fun clearCachedKeyDefLayouts() {
            cachedKeyDefLayouts.clear()
        }

        /**
         * Layout JSON a settings preview wants rendered, instead of the real layout file.
         *
         * The preview used to assign `ConfigProviders.provider`, a process-wide singleton, and
         * then clear this whole cache twice per refresh. With the IME service alive in the same
         * process (entering settings from the keyboard) the running keyboard could read the
         * preview JSON, and every preview invalidated the real keyboard's parsed layouts (see E9).
         */
        @Volatile
        private var previewLayoutOverride: JsonObject? = null

        /** Distinguishes preview cache entries so [dropPreviewCacheEntries] can target them. */
        private const val PREVIEW_CACHE_PREFIX = "preview|"

        /**
         * Render [json] as the layout source for the duration of [block].
         *
         * Only affects lookups made while [block] runs; the real provider and the real cache
         * entries are untouched.
         */
        fun <T> withPreviewLayout(json: JsonObject, block: () -> T): T {
            val previous = previewLayoutOverride
            previewLayoutOverride = json
            return try {
                block()
            } finally {
                previewLayoutOverride = previous
                dropPreviewCacheEntries()
            }
        }

        private fun dropPreviewCacheEntries() {
            val previewKeys = cachedKeyDefLayouts.keys.filter { it.startsWith(PREVIEW_CACHE_PREFIX) }
            previewKeys.forEach { cachedKeyDefLayouts.remove(it) }
        }

        /** Cache-key prefix for the current lookup; see [previewLayoutOverride]. */
        private fun cacheKeyPrefix(): String =
            if (previewLayoutOverride != null) PREVIEW_CACHE_PREFIX else ""

        /**
         * Force a latched/one-shot layer, or clear it (falling back to the numeric-input
         * layout when one is active). The numeric layout is configured per input session
         * by [setNumericLayoutKey], so input method updates that clear layer latches keep
         * the numeric editor on its layout.
         */
        @Synchronized
        fun setForcedLayoutKey(layoutKey: String?) {
            numericOverride.force(layoutKey)
            val normalized = numericOverride.forcedKey
            if (forcedLayoutKey == normalized) return
            forcedLayoutKey = normalized
            forEachAttachedKeyboard { keyboard ->
                keyboard.refreshStyle()
                keyboard.markLayoutSignatureApplied()
                keyboard.refreshSpaceLabelFromState()
            }
        }

        @Synchronized
        fun clearForcedLayoutKey() = setForcedLayoutKey(null)

        @Synchronized
        fun activateManualNumericLayout(layoutKey: String, userRequested: Boolean = false): Boolean {
            if (!numericOverride.activateManual(layoutKey, userRequested)) {
                return false
            }
            setForcedLayoutKey(layoutKey)
            return true
        }

        @Synchronized
        fun releaseManualNumericLayout(): Boolean {
            if (!numericOverride.releaseManual()) return false
            setForcedLayoutKey(null)
            return true
        }

        /**
         * Drop only the manually activated numeric layout because a latching layer switch
         * (see [NumericLayoutOverrideController.releaseManualOnLayerSwitch]) moved the
         * keyboard to another layer. Unlike [releaseManualNumericLayout] this does not
         * re-apply the forced layout by itself: the caller applies the new layer right
         * after via [setForcedLayoutKey], which performs that single refresh and also
         * corrects the transient [forcedLayoutKey] mismatch the controller-side drop
         * leaves behind.
         */
        @Synchronized
        fun releaseManualNumericLayoutOnLayerSwitch(target: String?): Boolean =
            numericOverride.releaseManualOnLayerSwitch(target)

        /**
         * Release ONLY the manually activated numeric layout because the input method
         * changed (language switch). Called from [KeyboardWindow.onImeUpdate] BEFORE the
         * layer latches are cleared; otherwise the forced-layout fallback would resurrect
         * the remembered manual key over the newly selected keyboard ("switching
         * Chinese/English lands on the number pad", regression introduced by bc82c97e).
         * Session-based overrides for numeric editors are preserved and still survive
         * IME updates while their editor stays numeric.
         *
         * @return whether a manual override was actually released.
         */
        @Synchronized
        fun releaseManualNumericLayoutOnImeUpdate(): Boolean {
            if (!numericOverride.releaseManualOnImeUpdate()) return false
            setForcedLayoutKey(null)
            return true
        }

        /**
         * Set the layout used for numeric-only editors of the current input session
         * (resolved from the numeric_layout_override preference). Called from
         * [KeyboardWindow.onStartInput] after layer latches have been cleared, so a single
         * update covers both transitions. `null` restores the default resolution path.
         */
        @Synchronized
        fun setNumericLayoutKey(layoutKey: String?) {
            val normalized = layoutKey?.trim()?.takeIf { it.isNotEmpty() }
            if (numericOverride.sessionKey == normalized &&
                forcedLayoutKey == normalized &&
                !numericOverride.dismissed
            ) return
            numericOverride.beginSession(normalized)
            // Latched layers were just cleared by the caller; the forced slot now carries
            // the numeric layout and keeps falling back to it for the rest of the session.
            forcedLayoutKey = normalized
            var refreshedAny = false
            forEachAttachedKeyboard { keyboard ->
                keyboard.refreshStyle()
                refreshedAny = true
                keyboard.refreshSpaceLabelFromState()
            }
            // Mark the layout signature as applied only for keyboards that actually reloaded
            // just now. Otherwise the next attach/onInputMethodUpdate must still see the
            // signature mismatch and rebuild the correct forced layout.
            if (refreshedAny) {
                forEachAttachedKeyboard { it.markLayoutSignatureApplied() }
            }
        }

        /**
         * Whether the current input session is a numeric editor carrying a resolvable
         * layout override (set by [setNumericLayoutKey] from [KeyboardWindow.onStartInput]).
         * While active, requests to show the built-in Number keyboard are redirected to the
         * text keyboard so the override applies uniformly no matter how it is reached.
         */
        @Synchronized
        fun isNumericLayoutActive(): Boolean = numericOverride.sessionKey != null

        @Synchronized
        fun isNumericLayoutShowing(): Boolean =
            numericOverride.sessionKey != null || numericOverride.manualKey != null

        /**
         * Whether the manually activated numeric layout is the layout currently being
         * rendered (see [NumericLayoutOverrideController.isManualNumericShowing]).
         * KeyboardWindow uses this to tell a first "?123" entry (which must be recorded
         * in the layer history so BACK can undo the jump) from a re-affirming press.
         */
        @Synchronized
        internal fun isManualNumericLayoutShowing(): Boolean =
            numericOverride.isManualNumericShowing()

        /**
         * Release the numeric-input layout override for the rest of the current session,
         * clearing both the session slot and the forced slot. Used when the user explicitly
         * switches back to the text keyboard (e.g. an "ABC"-style key in the custom numeric
         * layout). Unlike [clearForcedLayoutKey], this does not fall back to the numeric
         * layout, so input method updates will not silently pull the editor back onto it.
         * A new [onStartInput] call re-applies the override via [setNumericLayoutKey].
         */
        @Synchronized
        fun dismissNumericLayoutOverride() {
            if (numericOverride.sessionKey == null && forcedLayoutKey == null) return
            numericOverride.dismiss()
            forcedLayoutKey = null
            forEachAttachedKeyboard { keyboard ->
                keyboard.refreshStyle()
                keyboard.markLayoutSignatureApplied()
                keyboard.refreshSpaceLabelFromState()
            }
        }

        /**
         * Snapshot the current numeric override state (session/manual/forced slots).
         * Voice input commits text directly through the InputConnection and bypasses
         * fcitx's preedit pipeline, so [KeyboardWindow] snapshots this state before a
         * voice session starts and restores it afterwards to keep the keyboard on the
         * layout the user was looking at.
         */
        @Synchronized
        internal fun snapshotNumericLayoutOverride(): NumericLayoutOverrideController.Snapshot =
            numericOverride.snapshot()

        /**
         * Restore a numeric override state captured by [snapshotNumericLayoutOverride]
         * and re-apply it to attached keyboards.
         */
        @Synchronized
        internal fun restoreNumericLayoutOverride(snapshot: NumericLayoutOverrideController.Snapshot) {
            numericOverride.restore(snapshot)
            val normalized = numericOverride.forcedKey
            if (forcedLayoutKey == normalized) return
            forcedLayoutKey = normalized
            forEachAttachedKeyboard { keyboard ->
                keyboard.refreshStyle()
                keyboard.markLayoutSignatureApplied()
                keyboard.refreshSpaceLabelFromState()
            }
        }

        @Synchronized
        private fun forEachAttachedKeyboard(
            includePreview: Boolean = false,
            action: (TextKeyboard) -> Unit
        ) {
            val living = attachedKeyboards.mapNotNull { it.get() }
            attachedKeyboards.removeAll { it.get() == null }
            living.filter { includePreview || !it.isPreview }.forEach(action)
        }

        /**
         * Resolve the layout used for numeric-only editors from the app preference
         * "numeric_layout_override" (键盘 → 数字键盘布局). The preference names any
         * layout key, including IME submode keys such as "rime:wanxiang"; users are
         * responsible for the value. Returns null when unset or unresolvable, in which
         * case the built-in number keyboard applies. Deliberately decoupled from the
         * layout JSON: TextKeyboardLayout.json only defines text keyboard layouts.
         */
        @Synchronized
        fun resolveNumericLayoutKey(): String? {
            val json = textLayoutJson ?: return null
            val option = AppPrefs.getInstance().keyboard.numericLayoutOverride.getValue()
                .trim().takeIf { it.isNotEmpty() } ?: return null
            return option.takeIf { containsLayoutKey(json, it) }
        }

        /**
         * Re-resolve the numeric-input layout override against the current layout profile.
         * A layout file/profile change can invalidate the session override set at the last
         * [onStartInput]: the referenced layout key may have been removed or renamed, or it
         * may now map to a different layout. Returns true when a previously active override
         * no longer resolves and has been dropped.
         */
        @Synchronized
        fun revalidateNumericLayoutOverride(): Boolean {
            val sessionDropped = numericOverride.revalidateSession(resolveNumericLayoutKey())
            val manualDropped = numericOverride.manualKey?.let { manualKey ->
                numericOverride.revalidateManual(textLayoutJson?.let { containsLayoutKey(it, manualKey) } == true)
            } ?: false
            if (forcedLayoutKey != numericOverride.forcedKey) {
                forcedLayoutKey = numericOverride.forcedKey
            }
            return sessionDropped || manualDropped
        }

        @Synchronized
        fun handleLayoutSourceChanged(): Boolean {
            cachedRawLayoutJson = null
            lastRawModified = 0L
            lastRawLayoutFile = null
            val droppedOverride = revalidateNumericLayoutOverride()
            if (droppedOverride) {
                numericLayoutFallbackTarget?.get()?.onNumericLayoutOverrideInvalidated()
            }
            return droppedOverride
        }

        @Synchronized
        internal fun setNumericLayoutFallbackTarget(listener: NumericLayoutFallbackListener?) {
            numericLayoutFallbackTarget = listener?.let(::WeakReference)
        }

        @Synchronized
        fun currentLayoutHeightPercentOverride(): Int? {
            resolvedLayoutHeightPercentOverride = resolveCurrentLayoutHeightPercentOverride()
            return resolvedLayoutHeightPercentOverride
        }

        private fun resolveCurrentLayoutHeightPercentOverride(): Int? {
            val currentIme = ime ?: return null
            val json = textLayoutJson ?: return null

            // forced（数字盘/层）优先于密码默认布局，顺序与 getLayout 一致。
            forcedLayoutKey?.let { forced ->
                val forcedLayout = findLayoutElementByKey(json, forced)
                if (forcedLayout != null) {
                    val baseName = forced.substringBefore(':')
                    val forcedSub = forced.substringAfter(':', "")
                    return if (forcedSub.isNotEmpty()) {
                        parseLayoutHeightPercentOverride((json[baseName] as? JsonObject)?.get(forcedSub))
                            ?: parseLayoutHeightPercentOverride(json[baseName])
                    } else {
                        parseLayoutHeightPercentOverride(json[baseName])
                    }
                }
            }
            if (passwordDefaultLayout) {
                return parseLayoutHeightPercentOverride(json["default"])
            }

            val imeLayoutElement = json[currentIme.uniqueName] ?: json[currentIme.displayName]
            if (imeLayoutElement != null) {
                val subModeLabel = currentIme.subMode.label
                val subModeName = currentIme.subMode.name
                val schemaId = schemaIdFromSubModeIcon(currentIme.subMode.icon)
                // 键盘高度只按屏幕方向取（keyboard_height_percent_landscape），与排列形态无关：
                // 分体与否取决于键盘宽度，这里读不到（本函数是窗口级调用，可能先于任何键盘存在）。
                val rowsElement = resolveVariantRowsElement(
                    layoutElement = imeLayoutElement,
                    variant = LayoutVariant.Docked,
                    subModeLabel = subModeLabel,
                    schemaId = schemaId,
                    subModeName = subModeName
                )
                if (parseLayoutArray(rowsElement) != null) {
                    return parseLayoutHeightPercentOverride(rowsElement)
                        ?: parseLayoutHeightPercentOverride(imeLayoutElement)
                }
            }

            val defaultLayoutElement = json["default"]
            if (parseLayoutArray(defaultLayoutElement) != null) {
                return parseLayoutHeightPercentOverride(defaultLayoutElement)
            }
            return null
        }

        @Synchronized
        fun currentBaseLayoutKey(): String? {
            val currentIme = ime ?: return null
            val json = textLayoutJson
            return when {
                json?.containsKey(currentIme.uniqueName) == true -> currentIme.uniqueName
                json?.containsKey(currentIme.displayName) == true -> currentIme.displayName
                else -> "default"
            }
        }

        @Synchronized
        private fun currentHeightOverrideTargetLayoutKey(): String? {
            val json = textLayoutJson
            forcedLayoutKey?.let { forced ->
                if (json != null && containsLayoutKey(json, forced)) return forced
            }
            val base = currentBaseLayoutKey() ?: return null
            if (json == null) return base
            val subMode = ime?.subMode
            val subModeKey = resolveExistingSubModeKey(
                json = json,
                base = base,
                subModeLabel = subMode?.label.orEmpty(),
                schemaId = schemaIdFromSubModeIcon(subMode?.icon.orEmpty()),
                subModeName = subMode?.name.orEmpty()
            )
            return subModeKey ?: base
        }

        private fun schemaIdFromSubModeIcon(icon: String): String {
            return if (icon.startsWith("fcitx-rime:")) {
                icon.substringAfter("fcitx-rime:")
            } else {
                ""
            }
        }

        private fun subModeCandidates(
            subModeLabel: String,
            schemaId: String,
            subModeName: String
        ): List<String> {
            return listOf(schemaId, subModeLabel, subModeName)
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
        }

        private fun resolveSubModeLayoutElement(
            imeLayoutElement: JsonElement,
            subModeLabel: String,
            schemaId: String,
            subModeName: String
        ): JsonElement? {
            return if (imeLayoutElement is JsonObject) {
                matchSubMode(imeLayoutElement, subModeLabel, schemaId, subModeName) ?: imeLayoutElement
            } else {
                imeLayoutElement
            }
        }

        private fun resolveExistingSubModeKey(
            json: JsonObject,
            base: String,
            subModeLabel: String,
            schemaId: String,
            subModeName: String
        ): String? {
            val candidate = subModeCandidates(subModeLabel, schemaId, subModeName)
                .firstOrNull { sub -> containsLayoutKey(json, "$base:$sub") }
                ?: return null
            return "$base:$candidate"
        }

        @Synchronized
        fun resolveLayerTargetKey(target: String): String? {
            val normalized = target.trim()
            if (normalized.isEmpty()) return null
            val json = textLayoutJson ?: return null
            val base = currentBaseLayoutKey() ?: return null
            if (normalized.contains(':')) {
                val subModeFromTarget = normalized.substringAfter(':', "")
                if (subModeFromTarget.isNotEmpty()) {
                    val baseScoped = "$base:$subModeFromTarget"
                    if (containsLayoutKey(json, baseScoped)) return baseScoped
                    val normalizedSubMode = if (LayoutJsonUtils.isLayerSubModeLabel(subModeFromTarget)) {
                        subModeFromTarget
                    } else {
                        LayoutJsonUtils.toLayerSubModeLabel(subModeFromTarget)
                    }
                    val baseScopedLayer = "$base:$normalizedSubMode"
                    if (containsLayoutKey(json, baseScopedLayer)) return baseScopedLayer
                }
            }
            if (containsLayoutKey(json, normalized)) return normalized
            val subModeLabel = if (LayoutJsonUtils.isLayerSubModeLabel(normalized)) {
                normalized
            } else {
                LayoutJsonUtils.toLayerSubModeLabel(normalized)
            }
            val candidate = "$base:$subModeLabel"
            return candidate.takeIf { containsLayoutKey(json, it) }
        }

        /**
         * 认得出 [layoutKey] 这个条目名（布局名、或 `布局:子布局`）——不要求它一定给得出
         * 行集合。
         *
         * 不能拿 [findLayoutElementByKey] 兼作这个用途。分体布局按**子布局**存放之后，
         * `rime:倉頡五代:__variant__:split` 这种条目确实存在，但它是"倉頡五代这一层的分体
         * 排列"，不是 `rime:倉頡五代` 这个条目本身；要求它必须解析出行集合，会让这类键被
         * 判成"不存在"。这里的 key 只用于 `ime:` 分支的签名，宽松一点是对的。
         */
        private fun containsLayoutKey(json: JsonObject, layoutKey: String): Boolean {
            val base = layoutKey.substringBefore(':')
            val element = json[base] ?: return false
            val sub = layoutKey.substringAfter(':', "")
            if (sub.isEmpty()) return true
            return (element as? JsonObject)?.containsKey(sub) == true
        }

        private fun findLayoutElementByKey(json: JsonObject, layoutKey: String): JsonArray? {
            val base = layoutKey.substringBefore(':')
            val sub = layoutKey.substringAfter(':', "")
            val element = json[base] ?: return null
            return if (sub.isEmpty()) {
                when (element) {
                    is JsonArray -> element
                    is JsonObject -> parseLayoutArray(element["default"]) ?: parseLayoutArray(element[""])
                    else -> null
                }
            } else {
                parseLayoutArray((element as? JsonObject)?.get(sub))
            }
        }

        private fun parseLayoutArray(layoutElement: JsonElement?): JsonArray? {
            return when (layoutElement) {
                is JsonArray -> layoutElement
                is JsonObject -> (layoutElement["default"] as? JsonArray) ?: (layoutElement[""] as? JsonArray)
                else -> null
            }
        }

        /**
         * 在 [layoutElement] 里按当前 [variant] 挑出该形态的行集合元素。
         *
         * 形态变体是布局对象里以保留前缀命名的普通条目，磁盘上形如
         * `"rime": { "default": [...], "__variant__:split_landscape": [...] }`
         * （见 [LayoutJsonUtils.VARIANT_SUBMODE_PREFIX]）。
         *
         * 判定逻辑全在 [LayoutVariantResolver.resolveRowsElement]（那里有完整说明与单测），
         * 这里只负责把方案候选键算出来。
         */
        private fun resolveVariantRowsElement(
            layoutElement: JsonElement?,
            variant: LayoutVariant,
            subModeLabel: String,
            schemaId: String,
            subModeName: String
        ): JsonElement? = LayoutVariantResolver.resolveRowsElement(
            layoutElement = layoutElement,
            variant = variant,
            subModeCandidates = subModeCandidates(subModeLabel, schemaId, subModeName)
        )

        /**
         * 本层按方案（子模式）细分：命中方案 → `default` → `""`，都没有则返回 null。
         */
        private fun matchSubMode(
            container: JsonObject,
            subModeLabel: String,
            schemaId: String,
            subModeName: String
        ): JsonElement? =
            subModeCandidates(subModeLabel, schemaId, subModeName)
                .firstNotNullOfOrNull { key -> container[key] }
                ?: container["default"]
                ?: container[""]

        private fun isLandscapeNow(): Boolean =
            android.content.res.Resources.getSystem().configuration.orientation ==
                android.content.res.Configuration.ORIENTATION_LANDSCAPE

        private fun parseLayoutHeightPercentOverride(layoutElement: JsonElement?): Int? {
            val objectElement = layoutElement as? JsonObject ?: return null
            val meta = objectElement[LAYOUT_META_KEY] as? JsonObject ?: return null
            fun readKey(key: String): Int? {
                val raw = (meta[key] as? JsonPrimitive)?.intOrNull
                    ?: (meta[key] as? JsonPrimitive)?.content?.toIntOrNull()
                return raw?.takeIf { it in 10..90 }
            }
            return if (isLandscapeNow()) {
                readKey(LAYOUT_META_HEIGHT_PERCENT_LANDSCAPE_KEY) ?: readKey(LAYOUT_META_HEIGHT_PERCENT_KEY)
            } else {
                readKey(LAYOUT_META_HEIGHT_PERCENT_KEY)
            }
        }

        private fun parseAuxBarConfig(layoutElement: JsonElement?): AuxBarConfig? {
            val objectElement = layoutElement as? JsonObject ?: return null
            val meta = objectElement[LAYOUT_META_KEY] as? JsonObject ?: return null
            val auxBarConfig = meta[LAYOUT_META_AUX_BAR_KEY] as? JsonObject ?: return null
            val position = when (auxBarConfig["position"]?.jsonPrimitive?.content) {
                "top" -> AuxBarPosition.Top
                "bottom" -> AuxBarPosition.Bottom
                "left" -> AuxBarPosition.Left
                "right" -> AuxBarPosition.Right
                "above_preedit" -> AuxBarPosition.AbovePreedit
                else -> return null
            }
            val sizePercent = if (position == AuxBarPosition.AbovePreedit) {
                0f
            } else {
                auxBarConfig["size_percent"]?.jsonPrimitive?.floatOrNull
                    ?.takeIf { it.isFinite() }
                    ?.coerceIn(5f, 95f)
                    ?: return null
            }
            return AuxBarConfig(position, sizePercent)
        }

        /**
         * 解析辅助选择栏的附加自定义按键（无 tabs 时用于填充辅助选择栏）。
         */
        private fun parseAuxBarKeys(layoutElement: JsonElement?): List<Map<String, Any?>> {
            val objectElement = layoutElement as? JsonObject ?: return emptyList()
            val meta = objectElement[LAYOUT_META_KEY] as? JsonObject ?: return emptyList()
            val auxBarConfig = meta[LAYOUT_META_AUX_BAR_KEY] as? JsonObject ?: return emptyList()
            val keysElement = auxBarConfig["keys"] as? JsonArray ?: return emptyList()
            val rows = LayoutJsonUtils.parseLayoutRows(JsonArray(listOf(keysElement)))
            return rows.firstOrNull() ?: emptyList()
        }

        internal fun getAuxBarKeyDefs(state: TextKeyboardLayoutState): List<KeyDef> {
            val currentIme = state.ime
            val subModeLabel = currentIme?.subMode?.label.orEmpty()
            val subModeName = currentIme?.subMode?.name.orEmpty()
            val schemaId = schemaIdFromSubModeIcon(currentIme?.subMode?.icon.orEmpty())
            val legacyTargetIsUp = legacySwipeTargetIsUp()
            return state.auxBarKeys.mapNotNull { keyMap ->
                runCatching {
                    val jsonObject = JsonObject(
                        keyMap.mapValues { (_, v) -> LayoutJsonUtils.convertToJsonProperty(v) }
                    )
                    val keyJson = LayoutJsonUtils.parseKeyJson(jsonObject) ?: return@runCatching null
                    LayoutJsonUtils.createKeyDef(
                        keyJson,
                        subModeLabel,
                        schemaId,
                        subModeName,
                        legacyTargetIsUp
                    )
                }.getOrNull()
            }
        }

        @Synchronized
        fun setCurrentLayoutHeightPercentOverride(percent: Int): Boolean {
            val layoutKey = currentHeightOverrideTargetLayoutKey() ?: return false
            return setLayoutHeightPercentOverride(layoutKey, percent)
        }

        @Synchronized
        private fun setLayoutHeightPercentOverride(layoutKey: String, percent: Int): Boolean {
            if (percent !in 10..90) return false
            val metaKey = if (isLandscapeNow()) {
                LAYOUT_META_HEIGHT_PERCENT_LANDSCAPE_KEY
            } else {
                LAYOUT_META_HEIGHT_PERCENT_KEY
            }
            val snapshot = org.fcitx.fcitx5.android.input.config.ConfigProviders
                .readTextKeyboardLayout<JsonObject>() ?: return false
            val root = snapshot.value.toMutableMap()
            val base = layoutKey.substringBefore(':')
            val sub = layoutKey.substringAfter(':', "")
            val existingBase = root[base] ?: return false

            if (sub.isEmpty()) {
                val updatedLayoutElement = when (existingBase) {
                    is JsonArray -> {
                        JsonObject(
                            mapOf(
                                LAYOUT_META_KEY to JsonObject(
                                    mapOf(metaKey to JsonPrimitive(percent))
                                ),
                                "default" to existingBase
                            )
                        )
                    }
                    is JsonObject -> {
                        val mutable = existingBase.toMutableMap()
                        val meta = (mutable[LAYOUT_META_KEY] as? JsonObject)?.toMutableMap() ?: mutableMapOf()
                        meta[metaKey] = JsonPrimitive(percent)
                        mutable[LAYOUT_META_KEY] = JsonObject(meta)
                        JsonObject(mutable)
                    }
                    else -> return false
                }
                root[base] = updatedLayoutElement
            } else {
                val baseObject = when (existingBase) {
                    is JsonObject -> mutableMapOf<String, JsonElement>().apply { putAll(existingBase) }
                    is JsonArray -> mutableMapOf<String, JsonElement>("default" to existingBase)
                    else -> return false
                }
                val existingSub = baseObject[sub] ?: return false
                val updatedSubElement = when (existingSub) {
                    is JsonArray -> {
                        JsonObject(
                            mapOf(
                                LAYOUT_META_KEY to JsonObject(
                                    mapOf(metaKey to JsonPrimitive(percent))
                                ),
                                "default" to existingSub
                            )
                        )
                    }
                    is JsonObject -> {
                        val mutable = existingSub.toMutableMap()
                        val meta = (mutable[LAYOUT_META_KEY] as? JsonObject)?.toMutableMap() ?: mutableMapOf()
                        meta[metaKey] = JsonPrimitive(percent)
                        mutable[LAYOUT_META_KEY] = JsonObject(meta)
                        JsonObject(mutable)
                    }
                    else -> return false
                }
                baseObject[sub] = updatedSubElement
                root[base] = JsonObject(baseObject)
            }
            val targetFile = snapshot.file
                ?: org.fcitx.fcitx5.android.input.config.ConfigProviders.provider.textKeyboardLayoutFile()
                ?: return false
            return runCatching {
                targetFile.parentFile?.mkdirs()
                targetFile.writeText(JsonObject(root).toString() + "\n")
                resolvedLayoutHeightPercentOverride = percent
                onTextLayoutFileChanged()
            }.isSuccess
        }

        val textLayoutJson: JsonObject?
            @Synchronized
            get() {
                // A preview supplies its own JSON and must not disturb the real snapshot or the
                // file watcher (see E9).
                previewLayoutOverride?.let { return it }
                val providers = org.fcitx.fcitx5.android.input.config.ConfigProviders
                val provider = providers.provider
                val memoryJson = provider.textKeyboardLayoutJson()
                if (memoryJson != null) {
                    providers.ensureWatching()
                    if (cachedRawLayoutJson !== memoryJson || lastRawLayoutFile != null) {
                        cachedRawLayoutJson = memoryJson
                        lastRawLayoutFile = null
                        // Keep an in-memory snapshot distinct from a missing default file,
                        // which also has a null path and zero last-modified timestamp.
                        lastRawModified = Long.MIN_VALUE
                        cachedKeyDefLayouts.clear()
                    }
                    return cachedRawLayoutJson
                }

                val file = provider.textKeyboardLayoutFile()
                val currentFile = file?.absolutePath
                val currentModified = file?.takeIf { it.exists() }?.lastModified() ?: 0L
                if (cachedRawLayoutJson != null &&
                    currentFile == lastRawLayoutFile &&
                    currentModified == lastRawModified
                ) {
                    providers.ensureWatching()
                    return cachedRawLayoutJson
                }

                val snapshot = providers.readTextKeyboardLayout<JsonObject>() ?: run {
                    cachedRawLayoutJson = null
                    lastRawLayoutFile = null
                    lastRawModified = 0L
                    return null
                }
                if (cachedRawLayoutJson == null ||
                    currentFile != lastRawLayoutFile ||
                    snapshot.lastModified != lastRawModified
                ) {
                    lastRawModified = snapshot.lastModified
                    lastRawLayoutFile = currentFile
                    cachedRawLayoutJson = snapshot.value
                    // Invalidate KeyDef cache when JSON changes
                    cachedKeyDefLayouts.clear()
                }
                return cachedRawLayoutJson
            }

        private fun getTextLayoutJsonForIme(displayName: String): JsonArray? {
            val json = textLayoutJson ?: return null
            return json[displayName]?.jsonArray
        }

        internal fun getLayout(state: TextKeyboardLayoutState): List<List<KeyDef>> {
            // Resolve against the caller's own input method, never the shared companion one.
            val ime = state.ime
            val imeName = ime?.uniqueName
            val subModeLabel = ime?.subMode?.label ?: ""
            val subModeName = ime?.subMode?.name ?: ""
            val schemaId = schemaIdFromSubModeIcon(ime?.subMode?.icon ?: "")
            val displayTextContextCacheKey = listOf(schemaId, subModeLabel, subModeName)
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
                .joinToString(separator = "|")
                .ifEmpty { "none" }
            val showLangSwitch = AppPrefs.getInstance().keyboard.showLangSwitchKey.getValue()
            val legacyTargetIsUp = legacySwipeTargetIsUp()
            val variant = state.variant
            val json = textLayoutJson

            fun auxBarElement(layoutElement: JsonElement?): JsonElement? =
                LayoutVariantResolver.resolveAuxBarElement(
                    layoutElement,
                    variant,
                    subModeCandidates(subModeLabel, schemaId, subModeName)
                )

            forcedLayoutKey?.let { forced ->
                if (json != null) {
                    val forcedLayout = findLayoutElementByKey(json, forced)
                    if (forcedLayout != null) {
                        val cacheKey = "${cacheKeyPrefix()}forced:$forced:${state.variant.name}:$showLangSwitch:$displayTextContextCacheKey:legacyUp=$legacyTargetIsUp"
                        val baseName = forced.substringBefore(':')
                        val forcedSub = forced.substringAfter(':', "")
                        val forcedElement: JsonElement = if (forcedSub.isNotEmpty()) {
                            (json[baseName] as? JsonObject)?.get(forcedSub) ?: json[baseName] ?: forcedLayout
                        } else {
                            json[baseName] ?: forcedLayout
                        }
                        // 强制层（数字键盘 / 层切换目标）同样支持形态变体：横屏分体下把
                        // 数字层换成一套更宽的排列是常见诉求。
                        val rowsElement = resolveVariantRowsElement(
                            layoutElement = forcedElement,
                            variant = state.variant,
                            subModeLabel = subModeLabel,
                            schemaId = schemaId,
                            subModeName = subModeName
                        ) ?: forcedElement
                        val forcedRows = parseLayoutArray(rowsElement) ?: forcedLayout
                        resolvedLayoutHeightPercentOverride = if (forcedSub.isNotEmpty()) {
                            parseLayoutHeightPercentOverride(rowsElement)
                                ?: parseLayoutHeightPercentOverride((json[baseName] as? JsonObject)?.get(forcedSub))
                                ?: parseLayoutHeightPercentOverride(json[baseName])
                        } else {
                            parseLayoutHeightPercentOverride(rowsElement)
                                ?: parseLayoutHeightPercentOverride(json[baseName])
                        }
                        val auxElement = auxBarElement(forcedElement)
                        state.auxBarConfig = parseAuxBarConfig(auxElement)
                            ?: parseAuxBarConfig(rowsElement)
                            ?: parseAuxBarConfig(forcedElement)
                            ?: parseAuxBarConfig(json[baseName])
                        state.auxBarKeys = parseAuxBarKeys(auxElement)
                            .ifEmpty { parseAuxBarKeys(rowsElement) }
                            .ifEmpty { parseAuxBarKeys(forcedElement) }
                            .ifEmpty { parseAuxBarKeys(json[baseName]) }
                        return cachedKeyDefLayouts.getOrPut(cacheKey) {
                            forcedRows.map { rowElement ->
                                LayoutJsonUtils.parseKeyJsonArray(rowElement.jsonArray, showLangSwitch)
                                    .mapNotNull {
                                        LayoutJsonUtils.createKeyDef(
                                            key = it,
                                            subModeLabel = subModeLabel,
                                            schemaId = schemaId,
                                            subModeName = ime?.subMode?.name ?: "",
                                            legacyTargetIsUp = legacyTargetIsUp
                                        )
                                    }
                            }
                        }
                    }
                }
            }

            // 密码框固定走「default 布局」回退链（忽略可能是缓存的当前 Rime 方案）。
            // 优先级在 forcedLayoutKey 之下：用户在密码框里按 ?123 / 层切换等显式动作
            // 产生的 forcedLayoutKey（含自定义数字盘、层）仍然优先，密码默认布局只作为
            // 「没有任何强制层时」的基础布局。回退顺序取每个条目的 default 变体（即
            // ascii 直录那套，不按方案子模式挑变体）：
            //   1) 当前输入法键名（通常是 rime）→ 即 rime/default；
            //   2) 显式写死的 "rime"；3) 全局 "default"；4) "keyboard-us"；5) 内置 QWERTY。
            if (passwordDefaultLayout) {
                if (json != null) {
                    val candidateKeys = buildList {
                        imeName?.let { add(it) }
                        ime?.displayName?.let { add(it) }
                        add("rime")
                        add("default")
                        add("keyboard-us")
                    }.distinct()
                    for (key in candidateKeys) {
                        val element = json[key] ?: continue
                        // 取该布局的 default 变体（忽略方案子模式），与 ascii 模式一致。
                        try {
                            val rows = findLayoutElementByKey(json, key) ?: continue
                            resolvedLayoutHeightPercentOverride =
                                parseLayoutHeightPercentOverride(element)
                            state.auxBarConfig = parseAuxBarConfig(element)
                            state.auxBarKeys = parseAuxBarKeys(element)
                            val cacheKey = "${cacheKeyPrefix()}pwd:$key:${variant.name}:$showLangSwitch:$lastRawModified:legacyUp=$legacyTargetIsUp"
                            val keys = cachedKeyDefLayouts.getOrPut(cacheKey) {
                                rows.map { rowElement ->
                                    LayoutJsonUtils.parseKeyJsonArray(rowElement.jsonArray, showLangSwitch)
                                        .mapNotNull {
                                            LayoutJsonUtils.createKeyDef(
                                                it,
                                                legacyTargetIsUp = legacyTargetIsUp
                                            )
                                        }
                                }
                            }
                            // A row made only of spacers cannot enter a password.
                            if (keys.any { row -> row.any { it !is PlaceholderKey } }) return keys
                        } catch (e: Exception) {
                            // A valid JSON object can still contain malformed key definitions.
                            // Keep the password keyboard usable, including before first unlock.
                            timber.log.Timber.w(e, "Invalid password keyboard layout: %s", key)
                        }
                    }
                }
                // 布局文件里一个候选键都没命中 → 退回内置默认 QWERTY 布局。
                resolvedLayoutHeightPercentOverride = null
                state.auxBarConfig = null
                state.auxBarKeys = emptyList()
                return getDefaultLayout(showLangSwitch)
            }

            if (imeName != null) {
                if (json != null) {
                    // Try uniqueName first, then displayName
                    val layoutKey = imeName
                    // imeName (= ime?.uniqueName) is non-null here, so ime is smart-cast non-null.
                    val imeLayoutElement = json[layoutKey]
                        ?: json[ime.displayName]

                    if (imeLayoutElement != null) {
                        val matchedSubModeKey = (imeLayoutElement as? JsonObject)
                            ?.let { obj ->
                                subModeCandidates(subModeLabel, schemaId, subModeName)
                                    .firstOrNull { obj[it] != null }
                            }
                        // 先按排列形态挑行（横屏 / 分体 / 横屏分体），没配就回退到
                        // 竖屏停靠那份；详见 resolveVariantRowsElement。
                        val rowsElement = resolveVariantRowsElement(
                            layoutElement = imeLayoutElement,
                            variant = variant,
                            subModeLabel = subModeLabel,
                            schemaId = schemaId,
                            subModeName = subModeName
                        )

                        val layoutArray = parseLayoutArray(rowsElement)
                        if (layoutArray != null) {
                            resolvedLayoutHeightPercentOverride =
                                parseLayoutHeightPercentOverride(rowsElement)
                                    ?: parseLayoutHeightPercentOverride(imeLayoutElement)
                            val auxElement = auxBarElement(imeLayoutElement)
                            state.auxBarConfig =
                                parseAuxBarConfig(auxElement)
                                    ?: parseAuxBarConfig(rowsElement)
                                    ?: parseAuxBarConfig(imeLayoutElement)
                            state.auxBarKeys =
                                parseAuxBarKeys(auxElement)
                                    .ifEmpty { parseAuxBarKeys(rowsElement) }
                                    .ifEmpty { parseAuxBarKeys(imeLayoutElement) }
                            // Use a cache key that includes submode and showLangSwitch for proper caching
                            // Include showLangSwitch in cache key so layout is re-created when setting changes
                            val cacheSubMode = matchedSubModeKey ?: "default"
                            val cacheKey = "${cacheKeyPrefix()}$layoutKey:$cacheSubMode:${variant.name}:$showLangSwitch:$displayTextContextCacheKey:legacyUp=$legacyTargetIsUp"
                            return cachedKeyDefLayouts.getOrPut(cacheKey) {
                                layoutArray.map { rowElement ->
                                    LayoutJsonUtils.parseKeyJsonArray(rowElement.jsonArray, showLangSwitch)
                                        .mapNotNull {
                                            LayoutJsonUtils.createKeyDef(
                                                key = it,
                                                subModeLabel = subModeLabel,
                                                schemaId = schemaId,
                                                subModeName = subModeName,
                                                legacyTargetIsUp = legacyTargetIsUp
                                            )
                                        }
                                }
                            }
                        }
                    }

                    // Fallback to global "default" layout
                    json["default"]?.let { layoutElement ->
                        val rowsElement = resolveVariantRowsElement(
                            layoutElement = layoutElement,
                            variant = variant,
                            subModeLabel = subModeLabel,
                            schemaId = schemaId,
                            subModeName = subModeName
                        )
                        resolvedLayoutHeightPercentOverride = parseLayoutHeightPercentOverride(rowsElement)
                            ?: parseLayoutHeightPercentOverride(layoutElement)
                        val auxElement = auxBarElement(layoutElement)
                        state.auxBarConfig = parseAuxBarConfig(auxElement)
                            ?: parseAuxBarConfig(rowsElement)
                            ?: parseAuxBarConfig(layoutElement)
                        state.auxBarKeys = parseAuxBarKeys(auxElement)
                            .ifEmpty { parseAuxBarKeys(rowsElement) }
                            .ifEmpty { parseAuxBarKeys(layoutElement) }
                        val layoutArray = parseLayoutArray(rowsElement)
                        if (layoutArray != null) {
                            val cacheKey = "${cacheKeyPrefix()}default:${variant.name}:$showLangSwitch:$lastRawModified:legacyUp=$legacyTargetIsUp"
                            return cachedKeyDefLayouts.getOrPut(cacheKey) {
                                layoutArray.map { rowElement ->
                                    LayoutJsonUtils.parseKeyJsonArray(rowElement.jsonArray, showLangSwitch)
                                        .mapNotNull {
                                            LayoutJsonUtils.createKeyDef(
                                                it,
                                                legacyTargetIsUp = legacyTargetIsUp
                                            )
                                        }
                                }
                            }
                        }
                    }
                }
            }
            resolvedLayoutHeightPercentOverride = null
            state.auxBarConfig = null
            state.auxBarKeys = emptyList()
            return getDefaultLayout(showLangSwitch)
        }

        fun getDefaultLayout(showLangSwitch: Boolean = true): List<List<KeyDef>> {
            return listOf(
                listOf(
                    AlphabetKey("Q", "1"),
                    AlphabetKey("W", "2"),
                    AlphabetKey("E", "3"),
                    AlphabetKey("R", "4"),
                    AlphabetKey("T", "5"),
                    AlphabetKey("Y", "6"),
                    AlphabetKey("U", "7"),
                    AlphabetKey("I", "8"),
                    AlphabetKey("O", "9"),
                    AlphabetKey("P", "0")
                ),
                listOf(
                    AlphabetKey("A", "@"),
                    AlphabetKey("S", "*"),
                    AlphabetKey("D", "+"),
                    AlphabetKey("F", "-"),
                    AlphabetKey("G", "="),
                    AlphabetKey("H", "/"),
                    AlphabetKey("J", "#"),
                    AlphabetKey("K", "("),
                    AlphabetKey("L", ")")
                ),
                listOf(
                    CapsKey(),
                    AlphabetKey("Z", "'"),
                    AlphabetKey("X", ":"),
                    AlphabetKey("C", "\""),
                    AlphabetKey("V", "?"),
                    AlphabetKey("B", "!"),
                    AlphabetKey("N", "~"),
                    AlphabetKey("M", "\\"),
                    BackspaceKey()
                ),
                listOf(
                    LayoutSwitchKey("?123", ""),
                    CommaKey(0.1f, KeyDef.Appearance.Variant.Alternative),
                    *if (showLangSwitch) arrayOf(LanguageKey()) else emptyArray(),
                    SpaceKey(),
                    SymbolKey(".", 0.1f, KeyDef.Appearance.Variant.Alternative),
                    ReturnKey()
                )
            )
        }
    }

    private var specialKeyViews: SpecialKeyViews = SpecialKeyViews(
        caps = emptyList(),
        backspace = emptyList(),
        space = emptyList(),
        `return` = emptyList()
    )
    private val specialIconTintCache = WeakHashMap<ImageView, ColorStateList>()

    data class SpecialKeyViews(
        val caps: List<ImageView>,
        val backspace: List<ImageView>,
        val space: List<TextKeyView>,
        val `return`: List<ImageView>
    )

    private fun iconViewOf(view: View): ImageView? = when (view) {
        is ImageKeyView -> view.img
        is ImageAltTextKeyView -> view.img
        is ImageTextKeyView -> view.img
        else -> null
    }

    private fun findAllSpecialKeyViews(): SpecialKeyViews {
        val caps = mutableListOf<ImageView>()
        val backspace = mutableListOf<ImageView>()
        val space = mutableListOf<TextKeyView>()
        val returnKeys = mutableListOf<ImageView>()

        allViews.forEach { view ->
            when (view.tag) {
                R.id.button_caps -> iconViewOf(view)?.let(caps::add)
                R.id.button_backspace -> iconViewOf(view)?.let(backspace::add)
                R.id.button_space -> (view as? TextKeyView)?.let(space::add)
                R.id.button_return -> iconViewOf(view)?.let(returnKeys::add)
            }
        }

        val specialViews = SpecialKeyViews(
            caps = caps,
            backspace = backspace,
            space = space,
            `return` = returnKeys
        )
        (specialViews.caps + specialViews.backspace + specialViews.`return`)
            .forEach { iconView ->
                iconView.imageTintList?.let { specialIconTintCache[iconView] = it }
            }
        return specialViews
    }
    
    private fun ensureSpecialKeyViewsInitialized() {
        specialKeyViews = findAllSpecialKeyViews()
        // The key views may have been recreated, so the text-key cache has to be rebuilt too —
        // lazily, on the next read, since not every caller here touches it (see E6).
        textKeysDirty = true
    }

    private val showLangSwitchKey = AppPrefs.getInstance().keyboard.showLangSwitchKey
    private val spaceKeyLabelMode = AppPrefs.getInstance().keyboard.spaceKeyLabelMode
    private val swipeSymbolDirection = AppPrefs.getInstance().keyboard.swipeSymbolDirection
    private val punctuationPosition = ThemeManager.prefs.punctuationPosition

    private fun refreshLegacySwipeDirections() {
        cachedKeyDefLayouts.clear()
        reloadLayout()
        ensureSpecialKeyViewsInitialized()
    }

    @Keep
    private val showLangSwitchKeyListener = ManagedPreference.OnChangeListener<Boolean> { _, _ ->
        // Clear cache when showLangSwitch setting changes
        cachedKeyDefLayouts.clear()
        // Reload layout to show/hide LanguageKey
        reloadLayout()
        // The rows were rebuilt; the cached view lookups no longer refer to this tree.
        ensureSpecialKeyViewsInitialized()
    }

    @Keep
    private val swipeSymbolDirectionListener =
        ManagedPreference.OnChangeListener<SwipeSymbolDirection> { _, _ ->
            refreshLegacySwipeDirections()
        }

    @Keep
    private val punctuationPositionListener =
        ManagedPreference.OnChangeListener<ThemePrefs.PunctuationPosition> { _, _ ->
            refreshLegacySwipeDirections()
        }

    @Keep
    private val spaceKeyLabelModeListener = ManagedPreference.OnChangeListener<SpaceKeyLabelMode> { _, _ ->
        refreshSpaceLabelFromState()
    }

    private val keepLettersUppercase by AppPrefs.getInstance().keyboard.keepLettersUppercase

    init {
        // BaseKeyboard has already built the initial layout. If the current IME was supplied
        // before construction, remember its signature so onInputMethodUpdate does not rebuild
        // the exact same custom layout immediately afterwards.
        layoutState.ime?.let { lastLayoutSignature = layoutSignature(it) }
    }

    /**
     * Cached list of text keys, invalidated whenever the key views may have been recreated.
     *
     * This used to be `get() = allViews.filterIsInstance(...).toList()`, which re-walked the
     * entire view tree and allocated a new list on every read — and it is read on every
     * Shift/caps change and every composition-state flip, i.e. once per word in Chinese input
     * (see E6). Rebuilt lazily so a caller that never touches text keys pays nothing.
     */
    private var cachedTextKeys: List<TextKeyView> = emptyList()
    private var textKeysDirty = true

    private val textKeys: List<TextKeyView>
        get() {
            if (textKeysDirty) {
                cachedTextKeys = allViews.filterIsInstance(TextKeyView::class.java).toList()
                textKeysDirty = false
            }
            return cachedTextKeys
        }

    private var capsState: CapsState = CapsState.None

    private fun isDisplayCapsOn(): Boolean {
        return capsState != CapsState.None || isSimulatedCapsLockOn()
    }

    private fun transformAlphabet(c: String): String {
        return when (capsState) {
            CapsState.None -> c.lowercase()
            else -> c.uppercase()
        }
    }

    private var punctuationMapping: Map<String, String> = mapOf()
    private var lastLayoutSignature: String? = null
    private fun transformPunctuation(p: String) = punctuationMapping.getOrDefault(p, p)

    private fun selectedLayoutArray(ime: InputMethodEntry): JsonArray? {
        val json = textLayoutJson ?: return null
        forcedLayoutKey?.let { forced ->
            val base = forced.substringBefore(':')
            val sub = forced.substringAfter(':', "")
            val element = if (sub.isNotEmpty()) {
                (json[base] as? JsonObject)?.get(sub) ?: json[base]
            } else {
                json[base]
            }
            return element?.let {
                parseLayoutArray(
                    resolveVariantRowsElement(
                        layoutElement = it,
                        variant = layoutVariant,
                        subModeLabel = ime.subMode.label,
                        schemaId = schemaIdFromSubModeIcon(ime.subMode.icon),
                        subModeName = ime.subMode.name
                    )
                )
            } ?: findLayoutElementByKey(json, forced)
        }
        val imeLayoutElement = json[ime.uniqueName] ?: json[ime.displayName]
        if (imeLayoutElement != null) {
            val subModeLabel = ime.subMode.run { label.ifEmpty { name.ifEmpty { "" } } }
            val schemaId = schemaIdFromSubModeIcon(ime.subMode.icon)
            val subModeName = ime.subMode.name
            // 形态优先：本层的形态变体 → 方案细分 → 方案条目内部的形态变体。
            val rowsElement = resolveVariantRowsElement(
                layoutElement = imeLayoutElement,
                variant = layoutVariant,
                subModeLabel = subModeLabel,
                schemaId = schemaId,
                subModeName = subModeName
            )
            // Note: parenthesize explicitly — `?:` binds looser than `?.`,
            // so without grouping a non-null first operand would NOT return here
            // and the function would fall through to the "default" lookup (and
            // wrongly report null for flat layouts that have no "default" key).
            val layoutArray = parseLayoutArray(rowsElement)
                ?: parseLayoutArray(imeLayoutElement)
            if (layoutArray != null) return layoutArray
        }
        val defaultElement = json["default"] ?: return null
        return parseLayoutArray(
            resolveVariantRowsElement(
                layoutElement = defaultElement,
                variant = layoutVariant,
                subModeLabel = ime.subMode.label,
                schemaId = schemaIdFromSubModeIcon(ime.subMode.icon),
                subModeName = ime.subMode.name
            )
        ) ?: parseLayoutArray(defaultElement)
    }

    private fun layoutArrayUsesSubMode(rows: JsonArray): Boolean {
        for (rowElement in rows) {
            val row = rowElement as? JsonArray ?: return true
            for (keyElement in row) {
                val key = keyElement as? JsonObject ?: return true
                if (key["displayText"] is JsonObject) return true
                val composeOverride = key["composeOverride"] as? JsonObject
                if (composeOverride?.get("displayText") is JsonObject) return true
            }
        }
        return false
    }

    private var cachedUsesSubModeKey: String? = null
    private var cachedUsesSubModeValue = false

    /**
     * Whether the resolved layout renders sub-mode-specific content. Runs on every layout
     * signature computation, so memoize the scan result per (layer, ime, sub mode, layout
     * file revision); the layout JSON is only invalidated when [lastRawModified] changes.
     */
    private fun layoutUsesSubMode(ime: InputMethodEntry): Boolean {
        val cacheKey = buildString {
            append(forcedLayoutKey ?: "")
            append('|').append(ime.uniqueName)
            append('|').append(ime.displayName)
            append('|').append(ime.subMode.label)
            append('|').append(ime.subMode.name)
            append('|').append(ime.subMode.icon)
            append('|').append(layoutVariant.name)
            append('|').append(lastRawModified)
        }
        if (cachedUsesSubModeKey == cacheKey) return cachedUsesSubModeValue
        val result = layoutUsesSubModeInternal(ime)
        cachedUsesSubModeKey = cacheKey
        cachedUsesSubModeValue = result
        return result
    }

    private fun layoutUsesSubModeInternal(ime: InputMethodEntry): Boolean {
        val json = textLayoutJson ?: return true
        forcedLayoutKey?.let { forced ->
            val rows = findLayoutElementByKey(json, forced) ?: return true
            return layoutArrayUsesSubMode(rows)
        }
        val baseElement = json[ime.uniqueName] ?: json[ime.displayName]
        if (baseElement is JsonObject) {
            val hasSubModeLayout = baseElement.keys.any { key ->
                key != LAYOUT_META_KEY &&
                    key != "default" &&
                    key != "" &&
                    // 排列形态变体（__variant__:...）是布局结构的一部分，不是"按方案细分"，
                    // 不能让它把平铺布局判成"随子模式变化"——那会让行缓存在每次 Shift
                    // 切换子模式时全部失效（见 usesSubMode 的说明）。
                    !LayoutJsonUtils.isVariantSubModeLabel(key) &&
                    parseLayoutArray(baseElement[key]) != null
            }
            if (hasSubModeLayout) return true
        }
        return layoutArrayUsesSubMode(selectedLayoutArray(ime) ?: return true)
    }

    private fun layoutSignature(ime: InputMethodEntry): String {
        val json = textLayoutJson
        val layoutSource = when {
            json?.containsKey(ime.uniqueName) == true -> "u:${ime.uniqueName}"
            json?.containsKey(ime.displayName) == true -> "d:${ime.displayName}"
            else -> "default"
        }
        val subModeLabel = ime.subMode.run { label.ifEmpty { name.ifEmpty { "" } } }
        val forced = forcedLayoutKey ?: ""
        return buildString {
            // 密码框固定走 default 回退链：基础段用 "pwd-default" 占位。forced 永远追加在
            // 后面，所以密码框里按 ?123/层切换设置了 forcedLayoutKey 时签名也会变化，
            // onInputMethodUpdate 的「签名变了才 reloadLayout」据此在进/出密码框、以及
            // 密码框内切到数字盘/层时都能触发重排。
            if (passwordDefaultLayout) {
                append("pwd-default")
            } else {
                append(layoutSource)
                if (layoutUsesSubMode(ime)) {
                    append('|')
                    append(subModeLabel)
                }
            }
            append('|')
            append(forced)
            append('|')
            append(lastRawModified)
            append('|')
            append(legacySwipeTargetIsUp())
        }
    }

    internal fun markLayoutSignatureApplied() {
        val currentIme = layoutState.ime ?: return
        lastLayoutSignature = layoutSignature(currentIme)
    }

    /**
     * Signature describing which KeyDef layout the keyboard currently renders.
     * It mirrors the branch logic of [getLayout] so rows cached by BaseKeyboard are only
     * reused when the resolved layout (layer / input method / sub mode / layout file) is
     * actually the same.
     */
    protected override fun currentLayoutSignature(): String {
        val json = textLayoutJson
        val currentIme = layoutState.ime
        val showLangSwitch = AppPrefs.getInstance().keyboard.showLangSwitchKey.getValue()
        val imeName = currentIme?.uniqueName
        val displayName = currentIme?.displayName
        val subModeLabel = currentIme?.subMode?.label ?: ""
        val subModeName = currentIme?.subMode?.name ?: ""
        val schemaId = schemaIdFromSubModeIcon(currentIme?.subMode?.icon ?: "")
        // Only distinguish by sub mode when the layout actually renders sub-mode-specific
        // content; for flat layouts the KeyDef output is identical across sub modes and
        // including this context would invalidate the row cache on every shift toggle.
        val usesSubMode = currentIme?.let { layoutUsesSubMode(it) } ?: false
        val contextKey = if (usesSubMode) {
            listOf(schemaId, subModeLabel, subModeName)
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
                .joinToString(separator = "|")
                .ifEmpty { "none" }
        } else {
            "none"
        }
        val forced = forcedLayoutKey
        val branch = when {
            forced != null && json != null && findLayoutElementByKey(json, forced) != null ->
                "forced:$forced"
            passwordDefaultLayout -> "pwd-default:${layoutVariant.name}"
            imeName != null && json != null &&
                (json[imeName] != null || displayName?.let { json[it] } != null) -> {
                val imeLayoutElement = json[imeName] ?: displayName?.let { json[it] }
                if (imeLayoutElement != null) {
                    val rowsElement = resolveVariantRowsElement(
                        layoutElement = imeLayoutElement,
                        variant = layoutVariant,
                        subModeLabel = subModeLabel,
                        schemaId = schemaId,
                        subModeName = subModeName
                    )
                    if (parseLayoutArray(rowsElement) != null) {
                        val matchedSubModeKey = (imeLayoutElement as? JsonObject)?.let { obj ->
                            subModeCandidates(subModeLabel, schemaId, subModeName)
                                .firstOrNull { obj[it] != null }
                        } ?: "default"
                        "ime:$imeName:$matchedSubModeKey:${layoutVariant.name}"
                    } else if (json["default"]?.let { parseLayoutArray(it) } != null) {
                        "default"
                    } else {
                        "builtin"
                    }
                } else if (json["default"]?.let { parseLayoutArray(it) } != null) {
                    "default"
                } else {
                    "builtin"
                }
            }
            json?.get("default")?.let { parseLayoutArray(it) } != null -> "default"
            else -> "builtin"
        }
        return buildString {
            append(branch)
            append('|').append(showLangSwitch)
            append('|').append(contextKey)
            append('|').append(lastRawModified)
            append('|').append(legacySwipeTargetIsUp())
        }
    }

    override fun onAction(action: KeyAction, source: KeyActionListener.Source) {
        var transformed = action
        when (action) {
            is KeyAction.FcitxKeyAction -> when (source) {
                KeyActionListener.Source.Keyboard -> {
                    when (capsState) {
                        CapsState.None -> {
                            transformed = if (isSimulatedCapsLockOn()) {
                                action.copy(
                                    act = action.act.uppercase(),
                                    states = KeyStates(KeyState.Virtual, KeyState.CapsLock)
                                )
                            } else {
                                action.copy(act = action.act.lowercase())
                            }
                        }
                        CapsState.Once -> {
                            transformed = action.copy(
                                act = action.act.uppercase(),
                                states = KeyStates(KeyState.Virtual, KeyState.Shift)
                            )
                            switchCapsState()
                        }
                        CapsState.Lock -> {
                            transformed = action.copy(
                                act = action.act.uppercase(),
                                states = KeyStates(KeyState.Virtual, KeyState.Shift)
                            )
                        }
                    }
                }
                KeyActionListener.Source.Popup -> {
                    if (capsState == CapsState.Once) {
                        switchCapsState()
                    }
                }
            }
            is KeyAction.CapsAction -> {
                if (!action.lock && source == KeyActionListener.Source.Keyboard && tryConsumeMacroCapsLock()) {
                    // MacroKey tap Caps_Lock opened lock state: single tap on CapsKey should send Caps_Lock again.
                } else {
                    switchCapsState(action.lock)
                }
            }
            else -> {}
        }
        super.onAction(transformed, source)
    }

    override fun preprocessMacroAction(
        action: MacroAction,
        source: KeyActionListener.Source
    ): MacroAction {
        val allowConsumeCapsOnce = source == KeyActionListener.Source.Keyboard
        var consumeCapsOnce = false
        val simulatedCapsOn = isSimulatedCapsLockOn()
        val pendingUppercaseDown = mutableMapOf<String, Int>()

        fun isLetter(code: String): Boolean = code.length == 1 && code[0].isLetter()

        fun consumeUppercaseDecision(): Boolean {
            return when (capsState) {
                CapsState.None -> simulatedCapsOn
                CapsState.Once -> {
                    if (allowConsumeCapsOnce && !consumeCapsOnce) {
                        consumeCapsOnce = true
                        true
                    } else {
                        simulatedCapsOn
                    }
                }
                CapsState.Lock -> true
            }
        }

        fun nonConsumingUppercaseDecision(): Boolean {
            return when (capsState) {
                CapsState.None -> simulatedCapsOn
                CapsState.Once -> simulatedCapsOn
                CapsState.Lock -> true
            }
        }

        fun transformTapLetter(code: String): String {
            if (!isLetter(code)) return code
            val lower = code.lowercase()
            return if (consumeUppercaseDecision()) lower.uppercase() else lower
        }

        fun transformDownLetter(code: String): String {
            if (!isLetter(code)) return code
            val lower = code.lowercase()
            val transformed = if (consumeUppercaseDecision()) {
                pendingUppercaseDown[lower] = (pendingUppercaseDown[lower] ?: 0) + 1
                lower.uppercase()
            } else {
                lower
            }
            return transformed
        }

        fun transformUpLetter(code: String): String {
            if (!isLetter(code)) return code
            val lower = code.lowercase()
            val pending = pendingUppercaseDown[lower] ?: 0
            return if (pending > 0) {
                if (pending == 1) pendingUppercaseDown.remove(lower) else pendingUppercaseDown[lower] = pending - 1
                lower.uppercase()
            } else {
                if (nonConsumingUppercaseDecision()) lower.uppercase() else lower
            }
        }

        fun transformShortcutKey(code: String): String {
            if (code.length != 1 || !code[0].isLetter()) return code
            val lower = code.lowercase()
            return if (consumeUppercaseDecision()) lower.uppercase() else lower
        }

        fun transformKeyRef(keyRef: KeyRef, step: MacroStep): KeyRef {
            return when (keyRef) {
                is KeyRef.Fcitx -> keyRef.copy(
                    code = when (step) {
                        is MacroStep.Down -> transformDownLetter(keyRef.code)
                        is MacroStep.Up -> transformUpLetter(keyRef.code)
                        is MacroStep.Tap -> transformTapLetter(keyRef.code)
                        else -> keyRef.code
                    }
                )
                is KeyRef.Android -> keyRef
            }
        }

        val transformedSteps = action.steps.map { step ->
            when (step) {
                is MacroStep.Down -> step.copy(keys = step.keys.map { transformKeyRef(it, step) })
                is MacroStep.Up -> step.copy(keys = step.keys.map { transformKeyRef(it, step) })
                is MacroStep.Tap -> step.copy(keys = step.keys.map { transformKeyRef(it, step) })
                is MacroStep.Shortcut -> step.copy(
                    modifiers = step.modifiers,
                    key = when (step.key) {
                        is KeyRef.Fcitx -> step.key.copy(code = transformShortcutKey(step.key.code))
                        is KeyRef.Android -> step.key
                    }
                )
                is MacroStep.Text,
                is MacroStep.Edit,
                is MacroStep.AppAction,
                is MacroStep.LayerSwitch -> step
            }
        }

        if (consumeCapsOnce) {
            switchCapsState()
        }

        return action.copy(steps = transformedSteps)
    }

    private fun tryConsumeMacroCapsLock(): Boolean {
        val service = getService() ?: return false
        if (!service.isSimulatedCapsLockOnByMacroTap()) return false
        service.sendSimulatedCapsLockTapFromMacro()
        return true
    }

    private fun getService(): FcitxInputMethodService? {
        var ctx = context
        while (ctx is android.content.ContextWrapper) {
            if (ctx is FcitxInputMethodService) {
                return ctx
            }
            ctx = ctx.baseContext
        }
        return context as? FcitxInputMethodService
    }

    override fun onAttach() {
        ensureSpecialKeyViewsInitialized()
        capsState = if (getService()?.isVirtualShiftLockOn() == true) CapsState.Lock else CapsState.None
        updateCapsButtonIcon()
        updateAlphabetKeys()
    }

    protected override fun defaultRowHeightPercent(rowCount: Int): Float =
        super.defaultRowHeightPercent(rowCount)

    override fun preferredKeyboardHeightPercentOverride(): Int? =
        TextKeyboard.currentLayoutHeightPercentOverride()

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        registerKeyboard(this)
        showLangSwitchKey.registerOnChangeListener(showLangSwitchKeyListener)
        spaceKeyLabelMode.registerOnChangeListener(spaceKeyLabelModeListener)
        swipeSymbolDirection.registerOnChangeListener(swipeSymbolDirectionListener)
        punctuationPosition.registerOnChangeListener(punctuationPositionListener)
    }

    override fun onDetachedFromWindow() {
        unregisterKeyboard(this)
        showLangSwitchKey.unregisterOnChangeListener(showLangSwitchKeyListener)
        spaceKeyLabelMode.unregisterOnChangeListener(spaceKeyLabelModeListener)
        swipeSymbolDirection.unregisterOnChangeListener(swipeSymbolDirectionListener)
        punctuationPosition.unregisterOnChangeListener(punctuationPositionListener)
        super.onDetachedFromWindow()
    }

    override fun onReturnDrawableUpdate(returnDrawable: Int) {
        specialKeyViews.`return`.forEach { returnKey ->
            returnKey.imageResource = returnDrawable
        }
    }

    override fun onReturnDrawableOverride(drawable: Drawable?) {
        if (drawable != null) {
            specialKeyViews.`return`.forEach { returnKey ->
                returnKey.setImageDrawable(drawable)
            }
        }
    }

    override fun onPunctuationUpdate(mapping: Map<String, String>) {
        punctuationMapping = mapping
        updatePunctuationKeys()
    }

    /** Aux bar config resolved by this keyboard's own last layout pass. */
    internal val resolvedAuxBarConfig: AuxBarConfig?
        get() = layoutState.auxBarConfig

    /** Re-apply the space key label from this keyboard's own input method. */
    private fun refreshSpaceLabelFromState() {
        updateSpaceLabel(layoutState.ime)
    }

    private fun updateSpaceLabel(ime: InputMethodEntry?) {
        // 密码框固定走 default 布局、输入法不参与（keyboard-us 已移除，该 IC 无活动输入法，
        // 按键直接转发上屏）。此时空格键不应再显示上一次 Rime 方案名，改成有辨识度的提示，
        // 明确「这里不走输入法」。
        if (passwordDefaultLayout) {
            val hint = context.getString(R.string.space_bar_password_hint)
            ensureSpecialKeyViewsInitialized()
            specialKeyViews.space.forEach { spaceKey ->
                spaceKey.mainText.text = hint
            }
            return
        }
        if (ime == null) return
        val directRime = ime.uniqueName == "rime"
        // Keep the canonical mode name for existing layout keys; localize its display only.
        val subModeText = if (directRime && ime.subMode.name == "Latin Mode") {
            context.getString(R.string.direct_rime_ascii_mode)
        } else ime.subMode.run { name.ifEmpty { label.ifEmpty { "" } } }
        fun combinedLabel(name: String) = when {
            subModeText.isEmpty() -> name
            directRime -> context.getString(R.string.direct_rime_space_label, name, subModeText)
            else -> "$name ($subModeText)"
        }
        val newText = when (spaceKeyLabelMode.getValue()) {
            SpaceKeyLabelMode.Default -> combinedLabel(ime.displayName)
            SpaceKeyLabelMode.CompactWhenSubMode -> {
                val imeText = if (subModeText.isNotEmpty()) ime.label.ifEmpty { ime.displayName } else ime.displayName
                val combined = combinedLabel(imeText)
                if (subModeText.isNotEmpty() && combined.length > 10) subModeText else combined
            }
            SpaceKeyLabelMode.SubModeOnly -> {
                if (subModeText.isNotEmpty()) subModeText else ime.displayName
            }
        }
        ensureSpecialKeyViewsInitialized()
        specialKeyViews.space.forEach { spaceKey ->
            spaceKey.mainText.text = newText
        }
    }

    override fun onInputMethodUpdate(ime: InputMethodEntry) {
        // Keep the input method in this keyboard's own layout state; the companion mirror of
        // the real input method is maintained by KeyboardWindow, so a settings preview can no
        // longer repoint the real keyboard's layout resolution at its preview entry.
        layoutState.ime = ime
        val signature = layoutSignature(ime)
        if (signature != lastLayoutSignature) {
            reloadLayout()
            lastLayoutSignature = signature
        }
        // Re-find special key views after layout reload (or ensure initialized on first call)
        ensureSpecialKeyViewsInitialized()
        updateSpaceLabel(ime)
        refreshCapsPresentation()
    }

    override fun onStyleRefreshFinished() {
        ensureSpecialKeyViewsInitialized()
        updateCapsButtonIcon()
        updateAlphabetKeys()
        updatePunctuationKeys()
        refreshSpaceLabelFromState()
    }

    override fun onThemeUpdate(newTheme: Theme) {
        ensureSpecialKeyViewsInitialized()
        updateCapsButtonIcon()
        // Note: returnDrawable is managed by KeyboardWindow
    }

    override fun onCompositionStateChanged(composing: Boolean) {
        super.onCompositionStateChanged(composing)
        ensureSpecialKeyViewsInitialized()
        // Compose-state switches may recreate key views; re-apply caps presentation immediately.
        updateCapsButtonIcon()
        updateAlphabetKeys()
    }

    private fun transformPopupPreview(c: String): String {
        if (c.length != 1) return c
        if (c[0].isLetter()) return transformAlphabet(c)
        return transformPunctuation(c)
    }

    override fun onPopupAction(action: PopupAction) {
        val newAction = when (action) {
            is PopupAction.PreviewAction -> action.copy(content = transformPopupPreview(action.content))
            is PopupAction.PreviewUpdateAction -> action.copy(content = transformPopupPreview(action.content))
            is PopupAction.ShowKeyboardAction -> {
                when (action.keyboard) {
                    is KeyDef.Popup.Keyboard.Preset -> {
                        val label = action.keyboard.label
                        if (label.length == 1 && label[0].isLetter())
                            action.copy(
                                keyboard = action.keyboard.copy(label = transformAlphabet(label))
                            )
                        else action
                    }
                    is KeyDef.Popup.Keyboard.Explicit -> action
                }
            }
            else -> action
        }
        super.onPopupAction(newAction)
    }

    private fun switchCapsState(lock: Boolean = false) {
        val oldCapsState = capsState
        capsState =
            if (lock) {
                when (capsState) {
                    CapsState.Lock -> CapsState.None
                    else -> CapsState.Lock
                }
            } else {
                when (capsState) {
                    CapsState.None -> CapsState.Once
                    else -> CapsState.None
                }
            }
        val oldLocked = oldCapsState == CapsState.Lock
        val newLocked = capsState == CapsState.Lock
        if (oldLocked != newLocked) {
            getService()?.setVirtualShiftLockState(newLocked)
        }
        refreshCapsPresentation()
    }

    private fun refreshCapsPresentation() {
        updateCapsButtonIcon()
        updateAlphabetKeys()
    }

    private fun clearLocalCapsState() {
        if (capsState == CapsState.None) return
        capsState = CapsState.None
        refreshCapsPresentation()
    }

    private fun updateCapsButtonIcon() {
        val displayLock = isDisplayCapsOn()
        val slots = when (capsState) {
            CapsState.None -> if (displayLock) listOf("keys.capslock.lock") else listOf("keys.capslock.none")
            CapsState.Once -> listOf("keys.capslock.once")
            CapsState.Lock -> listOf("keys.capslock.lock")
        }
        val iconInfo = slots.firstNotNullOfOrNull { IconThemeManager.resolveIconDrawableInfo(it) }
        val fallbackRes = when (capsState) {
            CapsState.None -> if (displayLock) R.drawable.ic_capslock_lock else R.drawable.ic_capslock_none
            CapsState.Once -> R.drawable.ic_capslock_once
            CapsState.Lock -> R.drawable.ic_capslock_lock
        }
        specialKeyViews.caps.forEach { cap ->
            cap.apply {
                imageTintList?.let { specialIconTintCache[this] = it }
                val themedTint = specialIconTintCache[this]
                    ?: ColorStateList.valueOf(theme.altKeyTextColor)
                if (iconInfo != null) {
                    setImageDrawable(iconInfo.drawable)
                    if (iconInfo.tintWithTheme) {
                        imageTintList = themedTint
                    } else {
                        imageTintList = null
                        drawable?.setTintList(null)
                    }
                } else {
                    imageResource = fallbackRes
                    imageTintList = themedTint
                }
            }
        }
    }

    private fun updateAlphabetKeys() {
        val displayUppercase = isDisplayCapsOn()
        textKeys.forEach {
            val keyDef = it.def
            // 纯外观键（空白占位键）：文字是用户指定的装饰内容，不参与任何状态改写。
            // 放在最前面短路，键面上写 "G" 就恒定是 "G"，不跟着 Shift/Caps 变。
            if (keyDef.staticDisplay) return@forEach
            if (keyDef is KeyDef.Appearance.AltText) {
                val renderedText = it.mainText.text.toString()
                val sourceFromDef = renderedText.isEmpty() || renderedText == keyDef.displayText
                    || renderedText.equals(keyDef.character, ignoreCase = true)
                val displayText = if (sourceFromDef) keyDef.displayText else renderedText
                val character = keyDef.character
                val displayIsSingleLetter = displayText.length == 1
                    && (displayText[0] in 'A'..'Z' || displayText[0] in 'a'..'z')
                // 用户显式设置的 displayText（MacroKey）按原样显示：这里绝不能把它改写成小写，
                // 否则设成 "A" 的键在 Shift 关闭时仍显示 "a"，跟 AlphabetKey 毫无区别，
                // 显示文本这个设置就等于没生效。但 Shift/Caps 的"小写变大写"仍然保留（见下方
                // 的兼容注释），所以只应用大写那一支，不应用小写那一支。
                if (keyDef.keepDisplayTextCase) {
                    it.mainText.text = if (
                        displayIsSingleLetter && (displayUppercase || keepLettersUppercase)
                    ) {
                        displayText.uppercase()
                    } else {
                        displayText
                    }
                    return@forEach
                }
                val characterIsSingleLetter = sourceFromDef && character.length == 1
                    && (character[0] in 'A'..'Z' || character[0] in 'a'..'z')

                it.mainText.text = when {
                    keepLettersUppercase && displayIsSingleLetter -> displayText.uppercase()
                    keepLettersUppercase -> displayText
                    !displayUppercase && displayIsSingleLetter -> displayText.lowercase()
                    !displayUppercase -> displayText
                    displayIsSingleLetter -> displayText.uppercase()
                    characterIsSingleLetter -> character.uppercase()
                    else -> displayText
                }
            } else if (keyDef is KeyDef.Appearance.Text) {
                val renderedText = it.mainText.text.toString()
                val str = if (renderedText.isEmpty() || renderedText == keyDef.displayText) {
                    keyDef.displayText
                } else {
                    renderedText
                }
                if (str.length == 1 && (str[0] in 'A'..'Z' || str[0] in 'a'..'z')) {
                     it.mainText.text = if (keepLettersUppercase) {
                        str.uppercase()
                    } else {
                        if (displayUppercase) str.uppercase() else str.lowercase()
                    }
                }
            }
        }
    }

    private fun updatePunctuationKeys() {
        textKeys.forEach {
            if (it.def.staticDisplay) return@forEach
            if (it is AltTextKeyView) {
                it.def as KeyDef.Appearance.AltText
                it.altText.text = transformPunctuation(it.def.altText)
                it.altText1.text = it.def.altText1?.let(::transformPunctuation) ?: ""
            } else {
                it.def as KeyDef.Appearance.Text
                it.mainText.text = it.def.displayText.let { str ->
                    val first = str.firstOrNull() ?: return@forEach
                    if (first.run { isLetter() || isWhitespace() }) return@forEach
                    transformPunctuation(str)
                }
            }
        }
    }

}
