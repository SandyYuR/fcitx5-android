/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2026 Fcitx5 for Android Contributors
 */

package org.fcitx.fcitx5.android.input

import android.annotation.SuppressLint
import android.content.ClipDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.app.Dialog
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.text.InputType
import android.util.LruCache
import android.util.SparseIntArray
import android.util.Size
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.InputDevice
import android.graphics.Rect
import android.graphics.Region
import android.inputmethodservice.InputMethodService.Insets
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.CursorAnchorInfo
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InlineSuggestionsRequest
import android.view.inputmethod.InlineSuggestionsResponse
import android.view.inputmethod.InputMethodSubtype
import android.widget.FrameLayout
import android.widget.inline.InlinePresentationSpec
import androidx.annotation.Keep
import androidx.annotation.RequiresApi
import androidx.autofill.inline.UiVersions
import androidx.autofill.inline.common.ImageViewStyle
import androidx.autofill.inline.common.TextViewStyle
import androidx.autofill.inline.common.ViewStyle
import androidx.autofill.inline.v1.InlineSuggestionUi
import androidx.core.view.updateLayoutParams
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.consumeEach
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.BuildConfig
import org.fcitx.fcitx5.android.core.CapabilityFlags
import org.fcitx.fcitx5.android.core.CapabilityFlag
import org.fcitx.fcitx5.android.core.FcitxAPI
import org.fcitx.fcitx5.android.core.FcitxEvent
import org.fcitx.fcitx5.android.core.FcitxKeyMapping
import org.fcitx.fcitx5.android.core.FormattedText
import org.fcitx.fcitx5.android.core.InputMethodEntry
import org.fcitx.fcitx5.android.core.InputStatisticsSource
import org.fcitx.fcitx5.android.core.KeyState
import org.fcitx.fcitx5.android.core.KeyStates
import org.fcitx.fcitx5.android.core.KeySym
import org.fcitx.fcitx5.android.core.ScancodeMapping
import org.fcitx.fcitx5.android.core.SubtypeManager
import org.fcitx.fcitx5.android.core.TextFormatFlag
import org.fcitx.fcitx5.android.common.ipc.VoiceInputIpc
import org.fcitx.fcitx5.android.clipboardsync.MainService
import org.fcitx.fcitx5.android.daemon.FcitxConnection
import org.fcitx.fcitx5.android.daemon.FcitxDaemon
import org.fcitx.fcitx5.android.daemon.FcitxDisconnectedException
import org.fcitx.fcitx5.android.data.InputFeedbacks
import org.fcitx.fcitx5.android.data.stats.InputStats
import org.fcitx.fcitx5.android.data.stats.StatsLayout
import org.fcitx.fcitx5.android.data.prefs.AppPrefs
import org.fcitx.fcitx5.android.input.candidates.floating.FloatingCandidatesMode
import org.fcitx.fcitx5.android.data.prefs.ManagedPreference
import org.fcitx.fcitx5.android.data.prefs.ManagedPreferenceProvider
import org.fcitx.fcitx5.android.data.theme.Theme
import org.fcitx.fcitx5.android.data.theme.ThemeManager
import org.fcitx.fcitx5.android.input.clipboard.ClipboardSearchController
import org.fcitx.fcitx5.android.input.cursor.CursorRange
import org.fcitx.fcitx5.android.input.voice.js.JsAppInputConnection
import org.fcitx.fcitx5.android.input.cursor.CursorTracker
import org.fcitx.fcitx5.android.input.keyboard.SpaceLongPressBehavior
import org.fcitx.fcitx5.android.input.keyboard.TextKeyboard
import org.fcitx.fcitx5.android.input.voice.VoiceInputProviderManager
import org.fcitx.fcitx5.android.utils.InputMethodUtil
import org.fcitx.fcitx5.android.utils.ClipboardSharedContent
import org.fcitx.fcitx5.android.utils.ClipboardUriStore
import org.fcitx.fcitx5.android.utils.alpha
import org.fcitx.fcitx5.android.utils.forceShowSelf
import org.fcitx.fcitx5.android.utils.inputMethodManager
import org.fcitx.fcitx5.android.utils.isTypeNull
import org.fcitx.fcitx5.android.utils.monitorCursorAnchor
import org.fcitx.fcitx5.android.utils.styledColorOrDefault
import org.fcitx.fcitx5.android.utils.styledFloat
import org.fcitx.fcitx5.android.utils.userManager
import org.fcitx.fcitx5.android.utils.withBatchEdit
import splitties.bitflags.hasFlag
import splitties.dimensions.dp
import splitties.resources.styledColor
import timber.log.Timber
import kotlin.math.max

/**
 * All numpad key codes, from [KeyEvent.KEYCODE_NUMPAD_0] to [KeyEvent.KEYCODE_NUMPAD_RIGHT_PAREN].
 * For these keys the simulated key events always carry [KeyEvent.META_NUM_LOCK_ON] so that
 * Android KeyCharacterMap resolves the digit/symbol characters instead of navigation keys.
 */
private val NUMPAD_KEYCODE_RANGE = KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_RIGHT_PAREN

/**
 * How long a synthesized standalone modifier key is held down.
 *
 * Only an *upper* bound matters, and this value is far below every one of them:
 * - librime's `AsciiComposer` only toggles `ascii_mode` when the modifier is released within
 *   500ms of its press (`toggle_duration_limit`);
 * - fcitx5 core's modifier-only hotkeys require release within `ModifierOnlyKeyTimeout`
 *   (default 250ms), for the branches that pass `Instance::canTrigger()`.
 *
 * There is no lower bound. What distinguishes a standalone modifier tap from a
 * "modifier + letter" combo is event *order*, not elapsed time: `AsciiComposer` clears
 * `shift_key_pressed_` as soon as any non-modifier key arrives, so a combo can never toggle.
 * Ordering is already guaranteed independently of wall-clock time — `forwardKeyEvent` tags each
 * event with a self-incrementing index precisely because down/up can share a timestamp, and
 * `postFcitxJob` drains its queue sequentially.
 *
 * So this hold is kept short: it is pure added latency on the language key (the toggle only fires
 * on release), and it is also the window in which a letter typed right after the tap could pick up
 * the shared simulated-Shift state. This value is not a safety margin against the engine — it is
 * only kept at the low end of the typical human key-hold range so the pair still looks like a real
 * keystroke to apps that receive the forwarded events. Same value as `keyHoldDelayMs` in
 * `BaseKeyboard.sendFcitxKeyTap`, which no longer holds modifiers longer than ordinary keys either.
 */
private const val STANDALONE_MODIFIER_HOLD_MS = 50L

class FcitxInputMethodService : LifecycleInputMethodService() {

    private val inputDeliveryDiagnostics = org.fcitx.fcitx5.android.core.InputDiagnostics.Collector()
    private var timedSelectionGeneration = Long.MIN_VALUE
    private var timedSelections = 0
    private var timedCommitGeneration = Long.MIN_VALUE
    private var timedCommits = 0

    internal lateinit var fcitx: FcitxConnection

    private var jobs = Channel<Job>(capacity = Channel.UNLIMITED)
    private var inputBindingGeneration = 0
    private var inputSessionGeneration = 0
    internal val editorSession = EditorSessionTracker()
    private var statisticsStore: InputStats? = null
    private var statisticsSourceStore: InputStats? = null
    private var statisticsSourceCache: InputStatisticsSource? = null
    private var lastStatisticsLayout: Pair<String, StatsLayout>? = null
    private var lastStatisticsLayoutEpoch = -1L
    private var statisticsSchemaActions: Array<org.fcitx.fcitx5.android.core.Action>? = null
    private var statisticsSchema: Pair<String, String>? = null
    internal val macroInput = org.fcitx.fcitx5.android.input.keyboard.MacroInputController {
        Timber.w(it, "Failed to release a macro key")
    }

    private fun endEditorWork() {
        statisticsStore?.endSession()
        jsAppDismiss?.invoke()
        macroInput.cancelAll()
        if (VoiceInputProviderManager.isActive()) VoiceInputProviderManager.stop(this)
    }
    private var pendingCandidatePagingMode: Int? = null
    private var appliedCandidatePagingMode: Int? = null
    private var candidatePagingModeJob: Job? = null

    /**
     * Marks if we're in a critical input lifecycle phase to delay theme changes and avoid race conditions.
     */
    private var isInInputLifecycleCriticalPhase = false

    /**
     * Keep latest theme change while input lifecycle is unstable, and apply once it's safe.
     */
    private var pendingThemeUpdate: Theme? = null

    private val cachedKeyEvents = LruCache<Int, KeyEvent>(78)
    private val cachedScancodes = SparseIntArray(64)
    private var cachedKeyEventIndex = 0

    /**
     * Saves MetaState produced by hardware keyboard with "sticky" modifier keys, to clear them in order.
     * See also [InputConnection#clearMetaKeyStates(int)](https://developer.android.com/reference/android/view/inputmethod/InputConnection#clearMetaKeyStates(int))
     */
    private var lastMetaState: Int = 0

    private lateinit var pkgNameCache: PackageNameCache

    private lateinit var decorView: View
    private lateinit var contentView: FrameLayout
    internal var inputView: InputView? = null
    internal var candidatesView: CandidatesView? = null

    private val navbarMgr = NavigationBarManager()
    internal val inputDeviceManager = InputDeviceManager(
        onChange = { isVirtualKeyboard ->
            requestCandidatePagingMode(1)
            currentInputConnection?.monitorCursorAnchor(!isVirtualKeyboard)
            updateStatusIcon()
            window.window?.let {
                navbarMgr.evaluate(it, isVirtualKeyboard)
            }
            // Update candidates position when virtual keyboard visibility changes
            if (AppPrefs.getInstance().candidates.mode.getValue() == FloatingCandidatesMode.Always) {
                updateCandidatesViewPagingAndBounds()
            }
        },
        floatingModeProvider = {
            AppPrefs.getInstance().candidates.mode.getValue()
        }
    )

    internal fun restoreVirtualKeyboardForKawaiiBarAction() {
        if (!inputDeviceManager.isPhysicalCandidateBarMode) return
        inputDeviceManager.forceVirtualKeyboardForKawaiiBarAction()
    }

    /**
     * Listener for floating candidates mode changes
     * Reset state when switching away from "Always" mode
     */
    @Keep
    private val onFloatingModeChangeListener = ManagedPreference.OnChangeListener<FloatingCandidatesMode> { _, newMode ->
        // Reset state when switching away from "Always" mode
        if (newMode != FloatingCandidatesMode.Always) {
            // Keep paged candidate mode for consistent highlight + page behavior.
            requestCandidatePagingMode(1)
            // Disable cursor anchor monitoring
            currentInputConnection?.monitorCursorAnchor(false)
        } else {
            // Switching to "Always" mode: enable paging mode for digit key selection
            requestCandidatePagingMode(1)
            // Enable cursor anchor monitoring for floating candidates positioning
            currentInputConnection?.monitorCursorAnchor(true)
            // Update candidates view position
            updateCandidatesViewPagingAndBounds()
        }
        // Re-configure InputView and CandidatesView based on the new mode
        inputDeviceManager.onFloatingModeChanged()
    }

    /**
     * Update paging mode and cursor anchor for "Always" floating mode
     */
    internal fun updateCandidatesViewPagingAndBounds() {
        val floatingMode = AppPrefs.getInstance().candidates.mode.getValue()
        if (floatingMode != FloatingCandidatesMode.Always) return

        // Enable candidate paging mode for "Always" floating mode
        requestCandidatePagingMode(1)
        
        // Enable cursor anchor monitoring to get actual cursor position from app
        // This will trigger onUpdateCursorAnchorInfo callback
        currentInputConnection?.monitorCursorAnchor(true)
        
        // Also update position immediately with current anchor info
        updateCursorAnchorForFloatingCandidates()
    }
    
    /**
     * Update cursor anchor position for floating candidates in "Always" mode
     */
    private fun updateCursorAnchorForFloatingCandidates() {
        val cv = candidatesView ?: return
        val iv = inputView ?: return

        val parentWidth = contentView.width.toFloat()
        val parentHeight = contentView.height.toFloat()

        // Use the anchor position from system cursor anchor info
        // This is updated by onUpdateCursorAnchorInfo with the actual cursor position
        // anchorPosition[1] = cursor bottom, anchorPosition[3] = cursor top
        var cursorBottom = anchorPosition[1]
        var cursorTop = anchorPosition[3]

        // Get keyboard top position for reference
        // This is used to position candidates near keyboard when cursor is far away
        val keyboardTop = iv.getInputFieldTopY()

        // Check if virtual keyboard is visible
        val isKeyboardVisible = inputDeviceManager.isVirtualKeyboard

        // Fallback: if system doesn't provide valid cursor position,
        // use keyboard top as reference. Only apply when cursor position
        // is truly unset (both are 0), not when cursor is above the IME
        // window (which produces negative values after coordinate transform).
        if (cursorTop == 0f && cursorBottom == 0f) {
            // System didn't provide any cursor position, assume near keyboard top
            cursorBottom = keyboardTop
            cursorTop = keyboardTop
        }

        // Pass keyboard top as additional reference for positioning
        cv.updateCursorAnchorForFloating(
            floatArrayOf(anchorPosition[0], cursorBottom, cursorTop),
            floatArrayOf(parentWidth, parentHeight),
            keyboardTop,
            isKeyboardVisible
        )
    }
    private var capabilityFlags = CapabilityFlags.DefaultFlags

    private val selection = CursorTracker()

    /**
     * 万象退格保护的 Android 应用层实现（持按住序列，直到手指抬起）。
     *
     * 背景见 [BackspaceBoundaryGuard] 类文档：Lua 侧的
     * `super_processor/enable_backspace_limit` 在移动端恒不拦截，且空 composing 的
     * BackSpace 在本链路会回落到 Java 直删编辑器正文。这里在"删空编码"之后接管退格，
     * 同一按住序列内的重复退格全部吞掉，直到手指抬起。
     *
     * 状态机输入（全部在 IME 主线程，详见 guard 类文档）：
     * - ClientPreeditEvent/InputPanelEvent → composing 状态（合并两部分后喂入）；
     * - 任何非退格按键动作（含退格键抬起发出的 DeleteSelection/MoveSelection）
     *   → onUserKeyAction，见 [CommonKeyActionListener]；
     * - CommitStringEvent/回车/字符提交 → onCommit（抑制上屏清空）；
     * - 会话切换/剪贴板搜索启停 → onSessionChanged（复位+抑制）；
     * - [handleBackspaceKey]：退格到达、引擎未消费、直删编辑器之前 → 判决。
     */
    internal val backspaceBoundaryGuard = BackspaceBoundaryGuard()

    // client preedit 与 panel preedit 是同一输入区的两部分，事件各自到达、只带自己
    // 那一半；缓存两部分后合并成"composing 是否非空"再喂给退格保护。
    private var backspaceGuardClientPreeditNotEmpty = false
    private var backspaceGuardPanelPreeditNotEmpty = false

    private fun feedBackspaceGuardComposingState() {
        backspaceBoundaryGuard.onComposingStateChanged(
            backspaceGuardClientPreeditNotEmpty || backspaceGuardPanelPreeditNotEmpty
        )
    }

    /** 输入会话切换时同时清掉 composing 缓存，避免旧会话状态污染新编辑器。 */
    private fun resetBackspaceGuardComposingCache() {
        backspaceGuardClientPreeditNotEmpty = false
        backspaceGuardPanelPreeditNotEmpty = false
    }

    /** 会话切换/搜索启停：复位退格保护并清 composing 缓存。 */
    private fun onBackspaceGuardSessionChanged() {
        backspaceBoundaryGuard.onSessionChanged()
        resetBackspaceGuardComposingCache()
    }

    val currentInputSelection: CursorRange
        get() = if (jsAppInputConnection != null)
            (jsAppInputConnection as? JsAppInputConnection)?.selection ?: CursorRange()
        else selection.latest

    private val composing = CursorRange()
    private var composingText = FormattedText.Empty

    private fun resetComposingState() {
        composing.clear()
        composingText = FormattedText.Empty
    }

    private fun updateStatusIcon(entry: InputMethodEntry = fcitx.runImmediately { inputMethodEntryCached }) {
        if (inputDeviceManager.isVirtualKeyboard) {
            hideStatusIcon()
            return
        }

        val iconRes = StatusIconMapping.fromEntry(entry)
        // Skip placeholder icon when IM info has not been initialized yet.
        if (entry.uniqueName.isEmpty() && iconRes == R.drawable.ic_baseline_keyboard_24) {
            hideStatusIcon()
            return
        }
        showStatusIcon(iconRes)
    }

    private var cursorUpdateIndex: Int = 0

    private var highlightColor: Int = DefaultHighlightColor

    private val prefs = AppPrefs.getInstance()
    private val inlineSuggestions by prefs.keyboard.inlineSuggestions
    private val ignoreSystemCursor by prefs.advanced.ignoreSystemCursor

    private val recreateInputViewPrefs: Array<ManagedPreference<*>> = arrayOf(
        prefs.keyboard.expandKeypressArea,
        prefs.advanced.disableAnimation,
        prefs.advanced.ignoreSystemWindowInsets,
    )

    private val voiceInputCommitReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val message = intent ?: return
            val final = when (message.action) {
                BuildConfig.APPLICATION_ID + VoiceInputIpc.PARTIAL_ACTION_SUFFIX -> false
                BuildConfig.APPLICATION_ID + VoiceInputIpc.COMMIT_ACTION_SUFFIX -> true
                else -> return
            }
            val payload = runCatching {
                val token = message.getStringExtra(VoiceInputIpc.EXTRA_FLOATING_SESSION_TOKEN) ?: return
                val text = message.getStringExtra(if (final) VoiceInputIpc.EXTRA_COMMIT_TEXT else VoiceInputIpc.EXTRA_PARTIAL_TEXT)
                    ?.takeIf { it.isNotBlank() } ?: return
                token to text
            }.getOrNull() ?: return
            VoiceInputProviderManager.deliverFloatingResult(payload.first, final) {
                val text = payload.second
                android.util.Log.i("FcitxVoiceInput", "floating result accepted final=$final len=${text.length}")
                if (final) {
                    commitVoiceText(text)
                    VoiceInputProviderManager.floatingCommitListener?.invoke(text)
                    inputView?.onVoiceInputFinished()
                } else setVoiceComposingText(text)
            }
        }
    }

    private fun replaceInputView(theme: Theme): InputView {
        val startedAt = SystemClock.elapsedRealtime()
        val newInputView = InputView(this, fcitx, theme)
        setInputView(newInputView)
        inputDeviceManager.setInputView(newInputView)
        inputView = newInputView
        android.util.Log.i(
            "FcitxColdStart",
            "replaceInputView duration=${SystemClock.elapsedRealtime() - startedAt}ms"
        )
        return newInputView
    }

    private fun replaceCandidateView(theme: Theme): CandidatesView {
        val newCandidatesView = CandidatesView(this, fcitx, theme)
        // replace CandidatesView manually
        contentView.removeView(candidatesView)
        // put CandidatesView directly under content view
        contentView.addView(newCandidatesView)
        inputDeviceManager.setCandidatesView(newCandidatesView)
        candidatesView = newCandidatesView
        candidatesView?.onPositionChanged = { inputView?.updateAuxBarPosition() }
        return newCandidatesView
    }


    private fun replaceInputViews(theme: Theme) {
        window.window?.let {
            navbarMgr.evaluate(it, inputDeviceManager.isVirtualKeyboard)
        }
        replaceInputView(theme)
        replaceCandidateView(theme)
    }

    /**
     * Theme-driven InputView replacement should only happen when IME window is stable.
     * Applying it too early (eg. during config/input lifecycle transitions) may race with
     * framework initViews/reset flow and leave virtual keyboard in a bad state.
     */
    private fun canApplyPendingThemeNow(): Boolean {
        if (!this::contentView.isInitialized) return false
        if (isInInputLifecycleCriticalPhase) return false
        if (currentInputBinding == null) return false
        if (!isInputViewShown) return false
        return window.window?.decorView?.isAttachedToWindow == true
    }

    private fun applyPendingThemeIfPossible() {
        if (!canApplyPendingThemeNow()) return
        contentView.post {
            if (!canApplyPendingThemeNow()) return@post
            val theme = pendingThemeUpdate ?: return@post
            pendingThemeUpdate = null
            replaceInputViews(theme)
            inputView?.syncImeFromCache()
        }
    }

    @Keep
    private val recreateInputViewListener = ManagedPreference.OnChangeListener<Any> { _, _ ->
        replaceInputView(ThemeManager.activeTheme)
    }

    @Keep
    private val recreateCandidatesViewListener = ManagedPreferenceProvider.OnChangeListener {
        replaceCandidateView(ThemeManager.activeTheme)
    }

    /**
     * Theme change listener that delays InputView replacement during critical lifecycle phases.
     */
    @Keep
    private val onThemeChangeListener = ThemeManager.OnThemeChangeListener { theme ->
        if (!this::contentView.isInitialized) return@OnThemeChangeListener
        pendingThemeUpdate = theme
        applyPendingThemeIfPossible()
    }

    /**
     * Post a fcitx operation to [jobs] to be executed
     *
     * Unlike `fcitx.runOnReady` or `fcitx.launchOnReady` where
     * subsequent operations can start if the prior operation is not finished (suspended),
     * [postFcitxJob] ensures that operations are executed sequentially.
     */
    fun postFcitxJob(block: suspend FcitxAPI.() -> Unit): Job {
        val job = fcitx.lifecycleScope.launch(start = CoroutineStart.LAZY) {
            try {
                fcitx.runOnReady(block)
            } catch (e: FcitxDisconnectedException) {
                // The connection went away between queueing and running this job — the service
                // was destroyed, or fcitx restarted. Since C31 that is an ordinary exception
                // rather than a CancellationException, so an uncaught one here would reach the
                // default handler and take the process down instead of being absorbed by
                // structured concurrency.
                Timber.d(e, "Dropping queued fcitx job: connection is gone")
            }
        }
        jobs.trySend(job)
        return job
    }

    /** Capture at the time of the key, before either the service or native owner queues it. */
    fun postFcitxKeyJob(block: suspend FcitxAPI.() -> Unit): Job {
        // Showing an inherited keyboard window on a TYPE_NULL/non-editor focus
        // is not typing demand. Promote only a real key, before its ticket is
        // captured, and bind ahead of it in this same ordered service queue.
        if (FcitxDaemon.requireInputSession()) {
            postFcitxSessionJob(inputSessionGeneration) { focus(true) }
        }
        val ticket = FcitxDaemon.captureInputKey() ?: return Job().apply { complete() }
        val statisticsSource = captureStatisticsSource(ticket.generation)
        return postFcitxJob {
            if (FcitxDaemon.canDeliverInputKey(ticket)) {
                if (statisticsSource == null) block()
                else {
                    val api = this
                    withContext(statisticsSource) { block(api) }
                }
            }
        }.also { job -> job.invokeOnCompletion { FcitxDaemon.releaseInputKey(ticket) } }
    }

    /** All privacy checks are repeated at delivery, before statistics receives any text. */
    private fun activeStatistics(): InputStats? {
        if (statisticsStore?.isEnabled == false) return null
        return try {
            val editor = currentInputEditorInfo
            if (editor == null || editor.inputType and InputType.TYPE_MASK_CLASS == InputType.TYPE_NULL ||
                org.fcitx.fcitx5.android.FcitxApplication.getInstance().isDirectBootMode ||
                capabilityFlags.flags and (CapabilityFlag.PasswordOrSensitive.flag or CapabilityFlag.Disable.flag) != 0UL ||
                jsAppInputConnection != null || ClipboardSearchController.isActive) null
            else {
                val store = statisticsStore ?: InputStats.get(this).also { statisticsStore = it }
                store.takeIf { it.isEnabled && editorSession.isActive && applicationInputConnection != null }
            }
        } catch (_: Exception) { null }
    }

    private fun captureStatisticsSource(generation: Long): InputStatisticsSource? {
        val store = activeStatistics() ?: return null
        val epoch = store.recordingEpoch
        val cached = statisticsSourceCache
        if (statisticsSourceStore === store && cached?.generation == generation && cached.epoch == epoch) return cached
        return InputStatisticsSource(generation, epoch) { store.isEnabled && store.recordingEpoch == epoch }.also {
            statisticsSourceStore = store
            statisticsSourceCache = it
        }
    }

    internal fun isStatisticsRecordingEnabled(): Boolean = activeStatistics() != null

    internal fun recordStatisticsHeat(label: String, layout: StatsLayout) {
        val store = activeStatistics() ?: return
        if (!::fcitx.isInitialized) return
        val epoch = store.recordingEpoch
        try {
            val schema = fcitx.runImmediately {
                if (!acceptsInput) return@runImmediately null
                val actions = statusAreaActionsCached
                if (actions === statisticsSchemaActions) return@runImmediately statisticsSchema
                statisticsSchemaActions = actions
                statisticsSchema = null
                val selected = org.fcitx.fcitx5.android.ui.main.settings.behavior.manager.SubModeManager.resolveSelectedSchemaAction(actions)
                    ?: return@runImmediately null
                fun find(items: Array<org.fcitx.fcitx5.android.core.Action>): org.fcitx.fcitx5.android.core.Action? =
                    items.firstNotNullOfOrNull { item -> if (item.id == selected) item else item.menu?.let(::find) }
                find(actions)?.let { it.name to it.shortText }.also { statisticsSchema = it }
            } ?: return
            store.recordHeat(schema.first, schema.second, label, expectedEpoch = epoch)
            val current = schema.first to layout
            if (layout.geometry.isNotEmpty() && (current != lastStatisticsLayout || epoch != lastStatisticsLayoutEpoch)) {
                lastStatisticsLayout = current
                lastStatisticsLayoutEpoch = epoch
                lifecycleScope.launch {
                    try { store.setLayout(schema.first, layout, expectedEpoch = epoch) }
                    catch (_: Exception) { /* Statistics never interrupts the keyboard. */ }
                }
            }
        } catch (_: Exception) { /* A statistics failure must not reject a press. */ }
    }

    private fun recordStatisticsKey(event: FcitxEvent.StatisticsKeyEvent) {
        if (event.inputSession == 0L || !FcitxDaemon.isCurrentInputSession(event.inputSession)) return
        val store = activeStatistics() ?: return
        val data = event.statistics
        try {
            store.recordKey(data.schemaId, data.schemaName, KeySym(event.sym).toString(),
                isDeletion = event.sym == FcitxKeyMapping.FcitxKey_BackSpace || event.sym == FcitxKeyMapping.FcitxKey_Delete,
                composing = data.composing, wallTimeMs = data.wallTimeMs, monotonicTimeMs = data.monotonicTimeMs,
                expectedEpoch = data.epoch)
        } catch (_: Exception) { /* Statistics is optional; editor events still continue. */ }
    }

    private fun recordStatisticsKeys(event: FcitxEvent.StatisticsKeysEvent) {
        if (event.inputSession == 0L || !FcitxDaemon.isCurrentInputSession(event.inputSession)) return
        val store = activeStatistics() ?: return
        if (store.recordingEpoch != event.epoch) return
        try {
            val samples = event.keys.map { key ->
                val data = key.statistics
                org.fcitx.fcitx5.android.data.stats.StatsKeySample(data.schemaId, data.schemaName, "rime",
                    key.sym == FcitxKeyMapping.FcitxKey_BackSpace || key.sym == FcitxKeyMapping.FcitxKey_Delete,
                    data.composing, data.wallTimeMs, data.monotonicTimeMs)
            }
            store.recordKeys(samples, expectedEpoch = event.epoch)
            if (event.dropped > 0) store.recordDropped(event.dropped, expectedEpoch = event.epoch)
        } catch (_: Exception) { /* Optional metrics cannot delay or replay editor operations. */ }
    }

    private fun recordStatisticsCommit(event: FcitxEvent.CommitStringEvent, accepted: Boolean) {
        if (!accepted || event.inputSession == 0L || !FcitxDaemon.isCurrentInputSession(event.inputSession)) return
        val data = event.statistics?.takeUnless { it.command } ?: return
        val store = activeStatistics() ?: return
        try {
            store.recordCommit(data.schemaId, data.schemaName, event.data.text, data.codeLength,
                wallTimeMs = data.wallTimeMs, monotonicTimeMs = data.monotonicTimeMs, expectedEpoch = data.epoch,
                composing = data.composing)
        } catch (_: Exception) { /* Never retry or alter an already delivered commit. */ }
    }

    /** Same ordered queue as keys, with bounded timing for the first candidate taps. */
    fun postCandidateSelection(block: suspend FcitxAPI.() -> Unit): Job {
        val generation = FcitxDaemon.currentInputSession
        if (timedSelectionGeneration != generation) {
            timedSelectionGeneration = generation
            timedSelections = 0
        }
        val ordinal = ++timedSelections
        val capturedAt = if (ordinal <= 2) SystemClock.elapsedRealtimeNanos() else 0L
        return postFcitxKeyJob {
            if (capturedAt != 0L) android.util.Log.i("RimeInputTiming",
                "select_queue generation=$generation ordinal=$ordinal service_wait_us=${(SystemClock.elapsedRealtimeNanos() - capturedAt) / 1000}")
            block()
        }
    }

    fun postCandidateSelection(target: org.fcitx.fcitx5.android.core.CandidateSelectionTarget): Job =
        postCandidateSelection { selectCandidateIfCurrent(target.index, target.global, target.context) }

    private suspend fun FcitxAPI.applyCandidatePagingModeIfNeeded(mode: Int) {
        if (appliedCandidatePagingMode == mode) return
        setCandidatePagingMode(mode)
        appliedCandidatePagingMode = mode
    }

    private fun resetCandidatePagingModeCache() {
        pendingCandidatePagingMode = null
        appliedCandidatePagingMode = null
    }

    private fun requestCandidatePagingMode(mode: Int) {
        pendingCandidatePagingMode = mode
        if (candidatePagingModeJob?.isActive == true) return
        val job = postFcitxJob {
            while (true) {
                val nextMode = pendingCandidatePagingMode ?: break
                pendingCandidatePagingMode = null
                applyCandidatePagingModeIfNeeded(nextMode)
            }
        }
        candidatePagingModeJob = job
        job.invokeOnCompletion {
            if (candidatePagingModeJob === job) {
                candidatePagingModeJob = null
            }
            pendingCandidatePagingMode?.let {
                requestCandidatePagingMode(it)
            }
        }
    }

    private fun postFcitxBindingJob(
        expectedGeneration: Int,
        block: suspend FcitxAPI.() -> Unit
    ): Job = postFcitxJob {
        if (expectedGeneration != inputBindingGeneration) return@postFcitxJob
        block()
    }

    private fun postFcitxSessionJob(
        expectedGeneration: Int,
        block: suspend FcitxAPI.() -> Unit
    ): Job = postFcitxJob {
        if (expectedGeneration != inputSessionGeneration) return@postFcitxJob
        block()
    }

    /**
     * Re-apply the current Android input binding/session state to fcitx.
     *
     * This is needed after fcitx process restart (e.g. plugin package replaced) because
     * Android may keep IME UI visible without re-triggering onBindInput/onStartInput callbacks.
     */
    private fun rebindCurrentInputStateToFcitx() {
        val binding = currentInputBinding
        if (binding != null) {
            val uid = binding.uid
            val pkgName = pkgNameCache.forUid(uid)
            val bindingGeneration = inputBindingGeneration
            postFcitxBindingJob(bindingGeneration) {
                activate(uid, pkgName)
            }
        }
        val editorInfo = currentInputEditorInfo ?: return
        // Readiness/restart must not turn a visible TYPE_NULL window into a
        // session. The backend retains actual key demand for this generation.
        val shouldFocus = !editorInfo.isTypeNull()
        val flags = capabilityFlags
        val engineGeneration = FcitxDaemon.currentInputSession
        val program = editorInfo.packageName.orEmpty()
        FcitxDaemon.prepareInputSession(engineGeneration, program, flags, shouldFocus)
        val inputSessionGeneration = this.inputSessionGeneration
        postFcitxSessionJob(inputSessionGeneration) {
            startInputSession(engineGeneration, program)
            setCapFlags(flags)
            if (shouldFocus) focus(true)
        }
    }

    override fun onCreate() {
        val startedAt = SystemClock.elapsedRealtime()
        android.util.Log.i("FcitxColdStart", "service.onCreate begin")
        fcitx = FcitxDaemon.connect(javaClass.name)
        // The jobs already run off-main. Drain/join them there too, so layout or
        // drawing cannot delay starting the next binding/key/candidate operation.
        lifecycleScope.launch(Dispatchers.Default) {
            jobs.consumeEach { it.join() }
        }
        lifecycleScope.launch {
            // runImmediately throws FcitxDisconnectedException once this service's connection is
            // gone (see C31), and this collector lives as long as the service does, so a
            // disconnect racing onCreate/onDestroy must not become an uncaught exception.
            // Only that one exception is caught: runCatching would also swallow cancellation.
            val events = try {
                fcitx.runImmediately { eventFlow }
            } catch (e: FcitxDisconnectedException) {
                Timber.d(e, "fcitx event flow unavailable")
                return@launch
            }
            events.collect { event ->
                if (!FcitxDaemon.isCurrentInputSession(event.inputSession)) return@collect
                androidx.tracing.trace("rime.direct.consume") { handleFcitxEvent(event) }
            }
        }
        pkgNameCache = PackageNameCache(this)
        recreateInputViewPrefs.forEach {
            it.registerOnChangeListener(recreateInputViewListener)
        }
        prefs.candidates.registerOnChangeListener(recreateCandidatesViewListener)
        // Register listener for floating mode changes to reset state when switching away from "Always" mode
        prefs.candidates.mode.registerOnChangeListener(onFloatingModeChangeListener)
        ThemeManager.addOnChangedListener(onThemeChangeListener)
        val voiceIntentFilter = IntentFilter().apply {
            addAction(BuildConfig.APPLICATION_ID + VoiceInputIpc.COMMIT_ACTION_SUFFIX)
            addAction(BuildConfig.APPLICATION_ID + VoiceInputIpc.PARTIAL_ACTION_SUFFIX)
        }
        androidx.core.content.ContextCompat.registerReceiver(
            this, voiceInputCommitReceiver, voiceIntentFilter,
            BuildConfig.APPLICATION_ID + ".permission.PLUGIN", null,
            androidx.core.content.ContextCompat.RECEIVER_EXPORTED
        )
        android.util.Log.i("FcitxVoiceInput", "registered floating voice receiver actions=$voiceIntentFilter")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            postFcitxJob {
                SubtypeManager.syncWith(enabledIme())
            }
        }
        super.onCreate()
        decorView = window.window!!.decorView
        contentView = decorView.findViewById(android.R.id.content)
        lastKnownConfig = resources.configuration
        android.util.Log.i(
            "FcitxColdStart",
            "service.onCreate duration=${SystemClock.elapsedRealtime() - startedAt}ms"
        )
    }

    private fun handleFcitxEvent(event: FcitxEvent<*>) {
        inputDeliveryDiagnostics.received(event)
        when (event) {
            is FcitxEvent.ReadyEvent -> {
                resetCandidatePagingModeCache()
                rebindCurrentInputStateToFcitx()
            }
            is FcitxEvent.CommitStringEvent -> {
                if (timedCommitGeneration != event.inputSession) {
                    timedCommitGeneration = event.inputSession
                    timedCommits = 0
                }
                val ordinal = ++timedCommits
                val startedAt = if (ordinal <= 2) SystemClock.elapsedRealtimeNanos() else 0L
                backspaceBoundaryGuard.onCommit()
                val mainEditor = jsAppInputConnection == null && !ClipboardSearchController.isActive
                val requestResult = androidx.tracing.trace("rime.direct.commit") {
                    dispatchCommitText(event.data.text, event.data.cursor)
                }
                recordStatisticsCommit(event, mainEditor && requestResult == CommitRequestResult.REQUEST_ACCEPTED)
                if (requestResult == CommitRequestResult.NO_CONNECTION || requestResult == CommitRequestResult.REQUEST_REJECTED)
                    android.util.Log.w("RimeInputQueue", "commit_request_failed generation=${event.inputSession} result=$requestResult")
                if (startedAt != 0L) android.util.Log.i("RimeInputTiming",
                    "commit generation=${event.inputSession} ordinal=$ordinal event_wait_us=${if (event.commitProducedNanos > 0) (startedAt - event.commitProducedNanos) / 1000 else -1} service_commit_us=${(SystemClock.elapsedRealtimeNanos() - startedAt) / 1000} request_result=$requestResult")
            }
            is FcitxEvent.StatisticsKeyEvent -> recordStatisticsKey(event)
            is FcitxEvent.StatisticsKeysEvent -> recordStatisticsKeys(event)
            is FcitxEvent.KeyEvent -> event.data.let event@{
                if (it.states.virtual) {
                    // 剪贴板历史搜索会话期间：退格修改查询、回车与方向键直接吞掉，
                    // 其余字符仍走正常提交流程并在 commitText 中被搜索拦截。
                    if (ClipboardSearchController.isActive) {
                        when (it.sym.sym) {
                            FcitxKeyMapping.FcitxKey_BackSpace -> {
                                ClipboardSearchController.onBackspace()
                                return@event
                            }
                            FcitxKeyMapping.FcitxKey_Return,
                            FcitxKeyMapping.FcitxKey_Left,
                            FcitxKeyMapping.FcitxKey_Right,
                            FcitxKeyMapping.FcitxKey_Up,
                            FcitxKeyMapping.FcitxKey_Down -> return@event
                        }
                    }
                    // KeyEvent from virtual keyboard
                    //
                    // 退格保护：这里只处理"退格到达"和"其它按键结束退格按住序列"。
                    // 退格删码自身产生的 preedit 变化由 onComposingStateChanged 的
                    // 边沿检测处理，不在这里复位。
                    when (it.sym.sym) {
                        FcitxKeyMapping.FcitxKey_BackSpace -> handleBackspaceKey()
                        FcitxKeyMapping.FcitxKey_Return -> {
                            backspaceBoundaryGuard.onCommit()
                            handleReturnKey()
                        }
                        FcitxKeyMapping.FcitxKey_Left -> {
                            backspaceBoundaryGuard.onUserKeyAction()
                            handleArrowKey(KeyEvent.KEYCODE_DPAD_LEFT)
                        }
                        FcitxKeyMapping.FcitxKey_Right -> {
                            backspaceBoundaryGuard.onUserKeyAction()
                            handleArrowKey(KeyEvent.KEYCODE_DPAD_RIGHT)
                        }
                        FcitxKeyMapping.FcitxKey_Up -> {
                            backspaceBoundaryGuard.onUserKeyAction()
                            handleArrowKey(KeyEvent.KEYCODE_DPAD_UP)
                        }
                        FcitxKeyMapping.FcitxKey_Down -> {
                            backspaceBoundaryGuard.onUserKeyAction()
                            handleArrowKey(KeyEvent.KEYCODE_DPAD_DOWN)
                        }
                        else -> if (it.unicode > 0 && !it.up) {
                            backspaceBoundaryGuard.onCommit()
                            commitText(Character.toString(it.unicode))
                        } else {
                            Timber.w("Unhandled Virtual KeyEvent: $it")
                        }
                    }
                } else {
                    // KeyEvent from physical keyboard (or input method engine forwardKey)
                    // use cached event if available
                    cachedKeyEvents.remove(it.timestamp)?.let { keyEvent ->
                        // 剪贴板历史搜索会话期间：物理直达按键不得透传给目标编辑器。
                        // 可打印字符进入查询（ACTION_DOWN 一次），退格修改查询，
                        // 回车/方向键吞掉；抬起事件与修饰键状态同步可安全丢弃。
                        if (ClipboardSearchController.isActive) {
                            if (keyEvent.action == KeyEvent.ACTION_DOWN) {
                                when (keyEvent.keyCode) {
                                    KeyEvent.KEYCODE_DEL, KeyEvent.KEYCODE_FORWARD_DEL ->
                                        ClipboardSearchController.onPhysicalBackspace()
                                    KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
                                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
                                    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> Unit
                                    else -> {
                                        val unicode = keyEvent.unicodeChar
                                        if (unicode > 0) {
                                            ClipboardSearchController.onPhysicalChar(unicode.toChar())
                                        }
                                    }
                                }
                            }
                            return@event
                        }
                        /**
                         * intercept the KeyEvent which would cause the default [android.text.method.QwertyKeyListener]
                         * to show a Gingerbread-style CharacterPickerDialog
                         */
                        if (keyEvent.unicodeChar == KeyCharacterMap.PICKER_DIALOG_INPUT.code) {
                            currentInputConnection?.sendKeyEvent(
                                KeyEvent(
                                    keyEvent.downTime, keyEvent.eventTime,
                                    keyEvent.action, keyEvent.keyCode,
                                    keyEvent.repeatCount, keyEvent.metaState, -1,
                                    keyEvent.scanCode, keyEvent.flags, keyEvent.source
                                )
                            )
                            return@event
                        }
                        currentInputConnection?.sendKeyEvent(keyEvent)
                        if (KeyEvent.isModifierKey(keyEvent.keyCode)) {
                            when (keyEvent.action) {
                                KeyEvent.ACTION_DOWN -> {
                                    // save current metaState when modifier key down
                                    lastMetaState = keyEvent.metaState
                                }
                                KeyEvent.ACTION_UP -> {
                                    // only clear metaState that would be missing when this modifier key up
                                    currentInputConnection?.clearMetaKeyStates(lastMetaState xor keyEvent.metaState)
                                    lastMetaState = keyEvent.metaState
                                }
                            }
                        }
                        return@event
                    }
                    // simulate key event
                    val keyCode = it.sym.keyCode
                    if (keyCode != KeyEvent.KEYCODE_UNKNOWN) {
                        // recognized keyCode
                        val eventTime = SystemClock.uptimeMillis()
                        if (it.up) {
                            sendUpKeyEvent(eventTime, keyCode, it.states.metaState)
                        } else {
                            sendDownKeyEvent(eventTime, keyCode, it.states.metaState)
                        }
                    } else {
                        // no matching keyCode, commit character once on key down
                        if (!it.up && it.unicode > 0) {
                            commitText(Character.toString(it.unicode))
                        } else {
                            Timber.w("Unhandled Fcitx KeyEvent: $it")
                        }
                    }
                }
            }
            is FcitxEvent.ClientPreeditEvent -> {
                // client preedit 与 panel preedit 是同一输入区的两部分，各自事件只带
                // 自己那一半，必须分别缓存后合并再喂给退格保护，否则 Android 上
                // （Rime 配置为 PreeditMode::No，client preedit 恒空）会把"正在输入"
                // 误判成"删空"。
                backspaceGuardClientPreeditNotEmpty = event.data.isNotEmpty()
                feedBackspaceGuardComposingState()
                if (!ClipboardSearchController.onPreeditChanged(event.data.toString())) {
                    updateComposingText(event.data)
                }
            }
            is FcitxEvent.InputPanelEvent -> {
                backspaceGuardPanelPreeditNotEmpty = event.data.preedit.isNotEmpty()
                feedBackspaceGuardComposingState()
            }
            is FcitxEvent.DeleteSurroundingEvent -> {
                // 搜索会话期间绝不触碰目标编辑器的文本。
                if (!ClipboardSearchController.isActive) {
                    val (before, after) = event.data
                    handleDeleteSurrounding(before, after)
                }
            }
            is FcitxEvent.IMChangeEvent -> {
                // Rime schema/ascii changes keep the same Android IME subtype.
                // Update space key label in "Always" floating mode
                inputView?.updateSpaceLabelOnFloatingMode()
                if (inputDeviceManager.evaluateOnInputMethodActivate()) {
                    updateStatusIcon(event.data)
                }
            }
            is FcitxEvent.SwitchInputMethodEvent -> {
                val (reason) = event.data
                if (reason != FcitxEvent.SwitchInputMethodEvent.Reason.CapabilityChanged &&
                    reason != FcitxEvent.SwitchInputMethodEvent.Reason.Other
                ) {
                    if (inputDeviceManager.evaluateOnInputMethodSwitch()) {
                        // show inputView for [CandidatesView] when input method switched by user
                        forceShowSelf()
                    }
                }
            }
            else -> {}
        }
    }

    private fun handleDeleteSurrounding(before: Int, after: Int) {
        val ic = currentInputConnection ?: return
        if (jsAppInputConnection == null && before > 0) {
            selection.predictOffset(-before)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            ic.deleteSurroundingTextInCodePoints(before, after)
        } else {
            ic.deleteSurroundingText(before, after)
        }
    }

    private fun handleBackspaceKey() {
        // 退格保护：到达这里说明引擎没有消费这次退格。
        // - 有码可删时 Rime 会 accept，根本走不到这里；
        // - "删空之后紧接着的这次"由 guard 吞掉（桌面 Lua 吃掉的那一次）；
        // - 其余情况（无码普通删除）放行。
        when (backspaceBoundaryGuard.onBackspace()) {
            BackspaceBoundaryGuard.Decision.Consume -> {
                Timber.d("handleBackspaceKey: consumed at composing boundary")
                return
            }
            BackspaceBoundaryGuard.Decision.PassThrough -> {}
        }
        handleBackspaceDirectly()
    }

    fun handleBackspaceDirectly() {
        if (jsAppInputConnection != null) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL); return }
        val ic = currentInputConnection ?: return
        val editorInfo = currentInputEditorInfo
        val isTypeNull = editorInfo.inputType and InputType.TYPE_MASK_CLASS == InputType.TYPE_NULL
        val lastSelection = selection.latest
        val hasSelection = lastSelection.isNotEmpty()
        if (hasSelection) {
            selection.predict(lastSelection.start)
        } else if (lastSelection.start > 0) {
            selection.predictOffset(-1)
        }
        // In practice nobody (apart from ourselves) would set `privateImeOptions` to our
        // `DeleteSurroundingFlag`, leading to a behavior of simulating backspace key pressing
        // in almost every EditText.
        if (editorInfo.privateImeOptions != DeleteSurroundingFlag || isTypeNull) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            return
        }
        if (!hasSelection) {
            if (lastSelection.start <= 0) {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                return
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                ic.deleteSurroundingTextInCodePoints(1, 0)
            } else {
                ic.deleteSurroundingText(1, 0)
            }
        } else {
            ic.commitText("", 0)
        }
    }

    private fun handleReturnKey() {
        if (jsAppInputConnection != null) { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER); return }
        val ic = currentInputConnection ?: run {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            return
        }
        val editorInfo = currentInputEditorInfo
        val inputType = editorInfo.inputType
        val imeOptions = editorInfo.imeOptions
        if (inputType and InputType.TYPE_MASK_CLASS == InputType.TYPE_NULL ||
            imeOptions.hasFlag(EditorInfo.IME_FLAG_NO_ENTER_ACTION)
        ) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            return
        }
        val actionId = editorInfo.actionId
        if (editorInfo.actionLabel?.isNotEmpty() == true && actionId != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(actionId)
            return
        }
        when (val action = imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_UNSPECIFIED,
            EditorInfo.IME_ACTION_NONE -> sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
            else -> ic.performEditorAction(action)
        }
    }

    private fun handleArrowKey(keyCode: Int) {
        if (jsAppInputConnection != null) { sendDownUpKeyEvents(keyCode); return }
        val ic = currentInputConnection ?: run {
            sendDownUpKeyEvents(keyCode)
            return
        }
        val editorInfo = currentInputEditorInfo
        val type = editorInfo.inputType and InputType.TYPE_MASK_CLASS
        val variation = editorInfo.inputType and InputType.TYPE_MASK_VARIATION
        if (type == InputType.TYPE_NULL ||
            type == InputType.TYPE_CLASS_TEXT && variation == InputType.TYPE_TEXT_VARIATION_URI
        ) {
            sendDownUpKeyEvents(keyCode)
            return
        }
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                // 水平移动光标不走 DPAD 键事件：文本边界处的 DPAD_LEFT/RIGHT 会被部分编辑框
                // （微信/QQ 聊天输入框等）交给焦点导航，把焦点移出输入框（表现为光标跑到
                // app 内其他控件上）。改用 setSelection：它不会触发焦点导航，越界目标也会被
                // BaseInputConnection 安全忽略（光标停在边界不动）。
                val (start, end) = selection.latest
                if (start < 0 || end < 0) {
                    // 编辑器尚未上报光标位置，无法计算目标，退回键事件
                    sendDownUpKeyEvents(keyCode)
                    return
                }
                // 有选区时折叠到选区边界，无选区时移动一格
                val offset = if (start == end) 1 else 0
                val target =
                    if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) start - offset else end + offset
                if (target >= 0) {
                    // predict 让同一次手势内的连续按键立即读到最新预测位置，
                    // 否则 onUpdateSelection 回报前会重复计算同一目标导致丢步
                    selection.predict(target)
                    ic.setSelection(target, target)
                }
                // target < 0：光标已在文本最前端，保持不动
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                // 偏移 0 一定在第一行：此时 DPAD_UP 会被编辑框交给焦点导航导致失焦，直接跳过。
                // 以编辑器的真实文本为准（跟踪值可能在快速连击时滞后）。
                if (ic.getTextBeforeCursor(1, 0)?.isEmpty() == true) return
                sendDownUpKeyEvents(keyCode)
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                // 文本末尾一定在最后一行：此时 DPAD_DOWN 同样会逃逸编辑框，跳过
                if (ic.getTextAfterCursor(1, 0)?.isEmpty() == true) return
                sendDownUpKeyEvents(keyCode)
            }
        }
    }

    fun commitText(text: String, cursor: Int = -1) {
        dispatchCommitText(text, cursor)
    }

    // A true InputConnection return value acknowledges the request, not that a
    // remote editor displayed it. Never replay uncertain commits into a new
    // connection: the old editor might already have sent the same text.
    private enum class CommitRequestResult { SEARCH, NO_CONNECTION, REQUEST_ACCEPTED, REQUEST_REJECTED }

    private fun dispatchCommitText(text: String, cursor: Int): CommitRequestResult {
        jsAppInputConnection?.let {
            return if (it.commitText(text, 1)) CommitRequestResult.REQUEST_ACCEPTED else CommitRequestResult.REQUEST_REJECTED
        }
        // 剪贴板历史搜索会话期间：所有提交都进入查询，不写入目标编辑器。
        if (ClipboardSearchController.onCommitText(text)) return CommitRequestResult.SEARCH
        val ic = currentInputConnection ?: return CommitRequestResult.NO_CONNECTION
        var accepted = false
        // when composing text equals commit content, finish composing text as-is
        if (composing.isNotEmpty() && composingText.toString() == text) {
            val c = if (cursor == -1) text.length else cursor
            val target = composing.start + c
            resetComposingState()
            ic.withBatchEdit {
                if (selection.current.start != target) {
                    selection.predict(target)
                    ic.setSelection(target, target)
                }
                accepted = ic.finishComposingText()
            }
            return if (accepted) CommitRequestResult.REQUEST_ACCEPTED else CommitRequestResult.REQUEST_REJECTED
        }
        // committed text should replace composing (if any), replace selected range (if any),
        // or simply prepend before cursor
        val start = if (composing.isEmpty()) selection.latest.start else composing.start
        resetComposingState()
        if (cursor == -1) {
            selection.predict(start + text.length)
            accepted = ic.commitText(text, 1)
        } else {
            val target = start + cursor
            selection.predict(target)
            ic.withBatchEdit {
                accepted = commitText(text, 1)
                setSelection(target, target)
            }
        }
        return if (accepted) CommitRequestResult.REQUEST_ACCEPTED else CommitRequestResult.REQUEST_REJECTED
    }

    fun setVoiceComposingText(text: String) {
        val ic = currentInputConnection ?: return
        if (text.isBlank()) return
        val start = if (composing.isEmpty()) selection.latest.start else composing.start
        val formatted = FormattedText(
            arrayOf(text),
            intArrayOf(TextFormatFlag.Underline.flag),
            text.length,
        )
        composing.update(start, start + text.length)
        composingText = formatted
        selection.predict(composing.end)
        ic.setComposingText(formatted.toSpannedString(highlightColor), 1)
        android.util.Log.i(
            "FcitxVoiceInput",
            "voice composing set len=${text.length} range=$composing",
        )
    }

    fun clearVoiceComposingText() {
        val ic = currentInputConnection ?: return
        if (composing.isEmpty()) return
        resetComposingState()
        ic.setComposingText("", 1)
    }

    fun commitVoiceText(text: String) {
        val ic = currentInputConnection ?: return
        if (text.isBlank()) return
        android.util.Log.i(
            "FcitxVoiceInput",
            "voice commit len=${text.length} composing=${composing.isNotEmpty()} same=${composingText.toString() == text}",
        )
        if (composing.isNotEmpty() && composingText.toString() == text) {
            selection.predict(composing.start + text.length)
            resetComposingState()
            ic.finishComposingText()
        } else {
            clearVoiceComposingText()
            commitText(text)
        }
    }

    /**
     * Paste [text] into the editor: as rich content when it is a URI we can stage, else as
     * plain text.
     *
     * Suspend, with staging on Dispatchers.IO: stageForCommit copies the *entire* file, and
     * it used to run on the IME main thread — pasting a large image from the clipboard
     * manager froze the keyboard for the duration of the copy.
     */
    suspend fun commitClipboardEntry(text: String): Boolean {
        val staged = withContext(Dispatchers.IO) {
            ClipboardUriStore.stageForCommit(this@FcitxInputMethodService, text)
        }
        return if (staged != null && commitStagedUriContent(staged)) {
            true
        } else {
            commitText(text)
            false
        }
    }

    private fun commitStagedUriContent(staged: ClipboardSharedContent): Boolean {
        val editorInfo = currentInputEditorInfo ?: return false
        val inputConnection = currentInputConnection ?: return false
        val packageName = editorInfo.packageName
        if (!packageName.isNullOrEmpty()) {
            grantUriPermission(packageName, staged.uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val description = ClipDescription(staged.uri.lastPathSegment ?: "clipboard", arrayOf(staged.mimeType))
        return InputConnectionCompat.commitContent(
            inputConnection,
            editorInfo,
            InputContentInfoCompat(staged.uri, description, null),
            InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION,
            null
        )
    }

    private fun sendDownKeyEvent(eventTime: Long, keyEventCode: Int, metaState: Int = 0) {
        val ic = currentInputConnection ?: return
        val scanCode = getCachedScancode(keyEventCode)
        ic.sendKeyEvent(
            KeyEvent(
                eventTime,
                eventTime,
                KeyEvent.ACTION_DOWN,
                keyEventCode,
                0,
                metaState,
                KeyCharacterMap.VIRTUAL_KEYBOARD,
                scanCode,
                KeyEvent.FLAG_SOFT_KEYBOARD or KeyEvent.FLAG_KEEP_TOUCH_MODE
            )
        )
    }

    private fun sendUpKeyEvent(eventTime: Long, keyEventCode: Int, metaState: Int = 0) {
        val ic = currentInputConnection ?: return
        val scanCode = getCachedScancode(keyEventCode)
        ic.sendKeyEvent(
            KeyEvent(
                eventTime,
                SystemClock.uptimeMillis(),
                KeyEvent.ACTION_UP,
                keyEventCode,
                0,
                metaState,
                KeyCharacterMap.VIRTUAL_KEYBOARD,
                scanCode,
                KeyEvent.FLAG_SOFT_KEYBOARD or KeyEvent.FLAG_KEEP_TOUCH_MODE
            )
        )
    }

    private fun getCachedScancode(keyCode: Int): Int {
        val uncached = Int.MIN_VALUE
        val cached = cachedScancodes.get(keyCode, uncached)
        if (cached != uncached) return cached
        return ScancodeMapping.keyCodeToScancode(keyCode).also {
            cachedScancodes.put(keyCode, it)
        }
    }

    fun deleteSelection() {
        if (jsAppInputConnection != null) {
            (jsAppInputConnection as? JsAppInputConnection)?.deleteSelection()
            return
        }
        val lastSelection = selection.latest
        if (lastSelection.isEmpty()) return
        selection.predict(lastSelection.start)
        currentInputConnection?.commitText("", 1)
    }

    fun sendCombinationKeyEvents(
        keyEventCode: Int,
        alt: Boolean = false,
        ctrl: Boolean = false,
        shift: Boolean = false
    ) {
        var metaState = 0
        if (alt) metaState = KeyEvent.META_ALT_ON or KeyEvent.META_ALT_LEFT_ON
        if (ctrl) metaState = metaState or KeyEvent.META_CTRL_ON or KeyEvent.META_CTRL_LEFT_ON
        if (shift) metaState = metaState or KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON
        val eventTime = SystemClock.uptimeMillis()
        if (alt) sendDownKeyEvent(eventTime, KeyEvent.KEYCODE_ALT_LEFT)
        if (ctrl) sendDownKeyEvent(eventTime, KeyEvent.KEYCODE_CTRL_LEFT)
        if (shift) sendDownKeyEvent(eventTime, KeyEvent.KEYCODE_SHIFT_LEFT)
        sendDownKeyEvent(eventTime, keyEventCode, metaState)
        sendUpKeyEvent(eventTime, keyEventCode, metaState)
        if (shift) sendUpKeyEvent(eventTime, KeyEvent.KEYCODE_SHIFT_LEFT)
        if (ctrl) sendUpKeyEvent(eventTime, KeyEvent.KEYCODE_CTRL_LEFT)
        if (alt) sendUpKeyEvent(eventTime, KeyEvent.KEYCODE_ALT_LEFT)
    }

    fun applySelectionOffset(offsetStart: Int, offsetEnd: Int = 0) {
        if (jsAppInputConnection != null) {
            (jsAppInputConnection as? JsAppInputConnection)?.offsetSelection(offsetStart, offsetEnd)
            return
        }
        val lastSelection = selection.latest
        currentInputConnection?.also {
            val start = max(lastSelection.start + offsetStart, 0)
            val end = max(lastSelection.end + offsetEnd, 0)
            if (start > end) return
            selection.predict(start, end)
            it.setSelection(start, end)
        }
    }

    fun cancelSelection() {
        if (jsAppInputConnection != null) {
            (jsAppInputConnection as? JsAppInputConnection)?.cancelSelection()
            return
        }
        val lastSelection = selection.latest
        if (lastSelection.isEmpty()) return
        val end = lastSelection.end
        selection.predict(end)
        currentInputConnection?.setSelection(end, end)
    }

    private lateinit var lastKnownConfig: Configuration

    override fun onConfigurationChanged(newConfig: Configuration) {
        /**
         * skip keyboard|keyboardHidden changes, because we have [inputDeviceManager]
         * skip uiMode (system light/dark mode) changes, because we have [onThemeChangeListener]
         * to replace InputView(s) when needed
         * [android.inputmethodservice.InputMethodService.onConfigurationChanged] would call
         * resetStateForNewConfiguration() which calls initViews() causes InputView(s) to be replaced again
         * https://android.googlesource.com/platform/frameworks/base/+/refs/tags/android-15.0.0_r36/core/java/android/inputmethodservice/InputMethodService.java#1984
         */
        val f = ActivityInfo.CONFIG_KEYBOARD or
                ActivityInfo.CONFIG_KEYBOARD_HIDDEN or
                ActivityInfo.CONFIG_UI_MODE
        val diff = lastKnownConfig.diff(newConfig)
        Timber.d("onConfigurationChanged diff=$diff")
        val hasMeaningfulDiff = diff and f != diff
        if (hasMeaningfulDiff) {
            postFcitxJob { reset() }
        } else {
            Timber.d("onConfigurationChanged: skip reset for keyboard/uiMode-only diff=$diff")
        }
        /**
         * perform `super.onConfigurationChanged` only when `newConfig` diff fall outside "skipped" flags
         * we have to calculate the mask ourselves because nobody knows how `handledConfigChanges` works
         * https://android.googlesource.com/platform/frameworks/base/+/refs/tags/android-15.0.0_r36/core/java/android/inputmethodservice/InputMethodService.java#1876
         */
        if (hasMeaningfulDiff) {
            super.onConfigurationChanged(newConfig)
        }
        lastKnownConfig = newConfig
    }

    override fun onWindowShown() {
        super.onWindowShown()
        highlightColor =
            styledColorOrDefault(android.R.attr.colorAccent, DefaultHighlightColor).alpha(0.4f)
        InputFeedbacks.syncSystemPrefs()
        applyPendingThemeIfPossible()
    }

    override fun onCreateInputView(): View? {
        val startedAt = SystemClock.elapsedRealtime()
        android.util.Log.i("FcitxColdStart", "service.onCreateInputView begin")
        replaceInputViews(ThemeManager.activeTheme)
        android.util.Log.i(
            "FcitxColdStart",
            "service.onCreateInputView duration=${SystemClock.elapsedRealtime() - startedAt}ms"
        )
        // We will call `setInputView` by ourselves. This is fine.
        return null
    }

    override fun setInputView(view: View) {
        super.setInputView(view)
        // input method layout has not changed in 11 years:
        // https://android.googlesource.com/platform/frameworks/base/+/ae3349e1c34f7aceddc526cd11d9ac44951e97b6/core/res/res/layout/input_method.xml
        // expand inputArea to fullscreen
        contentView.findViewById<FrameLayout>(android.R.id.inputArea)
            .updateLayoutParams<ViewGroup.LayoutParams> {
                height = ViewGroup.LayoutParams.MATCH_PARENT
            }
        /**
         * expand InputView to fullscreen, since [android.inputmethodservice.InputMethodService.setInputView]
         * would set InputView's height to [ViewGroup.LayoutParams.WRAP_CONTENT]
         */
        view.updateLayoutParams<ViewGroup.LayoutParams> {
            height = ViewGroup.LayoutParams.MATCH_PARENT
        }
    }

    override fun onConfigureWindow(win: Window, isFullscreen: Boolean, isCandidatesOnly: Boolean) {
        win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }

    override fun onEvaluateFullscreenMode(): Boolean {
        // Always return false to prevent "Extract View" mode which hides the app.
        // We handle full screen window size manually via onConfigureWindow.
        return false 
    }

    override fun onComputeInsets(outInsets: Insets) {
        val inputView = this.inputView
        if (inputView?.isFloating == true && !inputView.isPhysicalCandidateBarMode) {
            // Floating mode: allow app to be full screen (insets.contentTopInsets = screen height)
            // But we need to handle touches.
             outInsets.contentTopInsets = inputView.height
             outInsets.visibleTopInsets = inputView.height
             
             outInsets.touchableInsets = Insets.TOUCHABLE_INSETS_REGION
             inputView.getFloatingKeyboardRegion(outInsets.touchableRegion)
             return
        }

        if (inputView?.isPhysicalCandidateBarMode == true) {
            val location = IntArray(2)
            inputView.keyboardView.getLocationInWindow(location)
            val top = location[1]

            outInsets.touchableInsets = Insets.TOUCHABLE_INSETS_REGION
            inputView.getDockedKeyboardRegion(outInsets.touchableRegion)

            if (top > 0) {
                outInsets.contentTopInsets = top
                outInsets.visibleTopInsets = top
            } else {
                val h = decorView.height
                outInsets.contentTopInsets = h
                outInsets.visibleTopInsets = h
            }
            return
        }

        if (inputDeviceManager.isVirtualKeyboard) {
            val location = IntArray(2)
            inputView?.keyboardView?.getLocationInWindow(location)
            val top = location[1]
            
            // In fixed mode, use TOUCHABLE_INSETS_REGION to explicitly define touchable area
            // to avoid any ambiguity about full screen blocking.
            outInsets.touchableInsets = Insets.TOUCHABLE_INSETS_REGION
            inputView?.getDockedKeyboardRegion(outInsets.touchableRegion)
            
            // Also set contentTopInsets to where the keyboard starts
            if (top > 0) {
                 outInsets.contentTopInsets = top
                 outInsets.visibleTopInsets = top
            } else {
                 // Fallback
                 val h = decorView.height
                 outInsets.contentTopInsets = h
                 outInsets.visibleTopInsets = h
            }
        } else {
            val n = decorView.findViewById<View>(android.R.id.navigationBarBackground)?.height ?: 0
            val h = decorView.height - n
            outInsets.apply {
                contentTopInsets = h
                visibleTopInsets = h
                touchableInsets = Insets.TOUCHABLE_INSETS_VISIBLE
            }
        }
    }

    // always show InputView since we delegate CandidatesView's visibility to it
    @SuppressLint("MissingSuperCall")
    override fun onEvaluateInputViewShown() = true

    fun superEvaluateInputViewShown() = super.onEvaluateInputViewShown()

    fun toggleOneHandKeyboard() {
        inputView?.toggleOneHandMode()
    }

    fun isOneHandKeyboardEnabled(): Boolean {
        return inputView?.isOneHanded == true
    }

    // override fun onEvaluateFullscreenMode() = false // Removed duplicate

    private fun forwardKeyEvent(event: KeyEvent, preserveModifierState: Boolean = false): Boolean {
        // reason to use a self increment index rather than timestamp:
        // KeyUp and KeyDown events actually can happen on the same time
        val timestamp = cachedKeyEventIndex++
        val forwardedEvent = if (simulatedCapsLockOn && !event.isCapsLockOn) {
            KeyEvent(
                event.downTime,
                event.eventTime,
                event.action,
                event.keyCode,
                event.repeatCount,
                event.metaState or KeyEvent.META_CAPS_LOCK_ON,
                event.deviceId,
                event.scanCode,
                event.flags,
                event.source
            )
        } else {
            event
        }
        cachedKeyEvents.put(timestamp, forwardedEvent)
        val sym = KeySym.fromKeyEvent(forwardedEvent)
        Timber.v("forwardKeyEvent: keyCode=%d scanCode=%d action=%d unicodeChar=%d sym=%s",
            forwardedEvent.keyCode, forwardedEvent.scanCode, forwardedEvent.action, forwardedEvent.unicodeChar, sym)
        if (sym != null) {
            var states = if (preserveModifierState) {
                keyStatesFromEventRaw(forwardedEvent)
            } else {
                KeyStates.fromKeyEvent(forwardedEvent)
            }
            if (simulatedCapsLockOn && !states.has(KeyState.CapsLock)) {
                states = KeyStates(states.states or KeyState.CapsLock.state)
            }
            val adjustedSym = adjustAlphabetSymForCaps(sym, states)
            val up = forwardedEvent.action == KeyEvent.ACTION_UP
            postFcitxKeyJob {
                sendKey(adjustedSym, states, forwardedEvent.scanCode, up, timestamp)
            }
            return true
        }
        Timber.v("Skipped KeyEvent: $forwardedEvent")
        return false
    }

    private fun keyStatesFromEventRaw(event: KeyEvent): KeyStates {
        var states = KeyState.NoState.state
        if (event.isAltPressed) states = states or KeyState.Alt.state
        if (event.isCtrlPressed) states = states or KeyState.Ctrl.state
        if (event.isShiftPressed) states = states or KeyState.Shift.state
        if (event.isCapsLockOn) states = states or KeyState.CapsLock.state
        if (event.isNumLockOn) states = states or KeyState.NumLock.state
        if (event.isMetaPressed) states = states or KeyState.Meta.state
        return KeyStates(states)
    }

    private fun adjustAlphabetSymForCaps(sym: KeySym, states: KeyStates): KeySym {
        val code = sym.sym
        if (code !in 'a'.code..'z'.code && code !in 'A'.code..'Z'.code) return sym
        val shouldUpper = states.capsLock.xor(states.shift)
        val adjusted = if (shouldUpper) {
            code.toChar().uppercaseChar().code
        } else {
            code.toChar().lowercaseChar().code
        }
        return KeySym(adjusted)
    }

    /**
     * Send simulated KeyEvent (for macros)
     * Route through the physical-keyboard path so Rime can recognize it correctly
     */
    private var simulatedCapsLockOn = false
    private var simulatedNumLockOn = false
    private var simulatedCapsLockPressed = false
    private var simulatedNumLockPressed = false
    private var simulatedShiftPressedCount = 0
    private var simulatedCtrlPressedCount = 0
    private var simulatedAltPressedCount = 0
    private var simulatedMetaPressedCount = 0
    private var simulatedFunctionPressedCount = 0
    private var simulatedAltRightPressedCount = 0
    private var simulatedCapsLockPressedFromMacro = false
    private var simulatedCapsLockOnByMacroTap = false
    private var virtualShiftLockOn = false

    public fun isSimulatedCapsLockOn(): Boolean = simulatedCapsLockOn
    public fun isSimulatedCapsLockOnByMacroTap(): Boolean = simulatedCapsLockOnByMacroTap
    public fun isVirtualShiftLockOn(): Boolean = virtualShiftLockOn

    public fun setVirtualCapsLockState(enabled: Boolean) {
        if (simulatedCapsLockOn == enabled) return
        simulatedCapsLockOn = enabled
        simulatedCapsLockPressed = false
        simulatedCapsLockPressedFromMacro = false
        simulatedCapsLockOnByMacroTap = false
        TextKeyboard.refreshCapsPresentationOnAll()
    }

    public fun setVirtualShiftLockState(enabled: Boolean) {
        if (virtualShiftLockOn == enabled) return
        virtualShiftLockOn = enabled
        TextKeyboard.refreshCapsPresentationOnAll()
    }

    private fun onHardwareTypingModeEnter(event: KeyEvent) {
        if (event.keyCode == KeyEvent.KEYCODE_CAPS_LOCK) return
        if (event.unicodeChar == 0) return
        TextKeyboard.clearCapsStateOnAll()
        setVirtualShiftLockState(false)
        setVirtualCapsLockState(event.isCapsLockOn)
    }

    /**
     * Track modifier hold state for simulated key events (shared by the keyboard macro path
     * [sendSimulatedKeyEvent] and the custom-button path [sendSimulatedKeyEventOrFallback]) so
     * key taps/shortcuts carry the correct metaState (e.g. Ctrl+A is not just a plain "a").
     */
    private fun updateSimulatedModifierCount(keyCode: Int, action: Int) {
        when (action) {
            KeyEvent.ACTION_DOWN -> when (keyCode) {
                KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> simulatedShiftPressedCount += 1
                KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> simulatedCtrlPressedCount += 1
                KeyEvent.KEYCODE_ALT_LEFT -> simulatedAltPressedCount += 1
                KeyEvent.KEYCODE_ALT_RIGHT -> {
                    simulatedAltPressedCount += 1
                    simulatedAltRightPressedCount += 1
                }
                KeyEvent.KEYCODE_META_LEFT, KeyEvent.KEYCODE_META_RIGHT -> simulatedMetaPressedCount += 1
                KeyEvent.KEYCODE_FUNCTION -> simulatedFunctionPressedCount += 1
            }
            KeyEvent.ACTION_UP -> when (keyCode) {
                KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT ->
                    simulatedShiftPressedCount = (simulatedShiftPressedCount - 1).coerceAtLeast(0)
                KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT ->
                    simulatedCtrlPressedCount = (simulatedCtrlPressedCount - 1).coerceAtLeast(0)
                KeyEvent.KEYCODE_ALT_LEFT ->
                    simulatedAltPressedCount = (simulatedAltPressedCount - 1).coerceAtLeast(0)
                KeyEvent.KEYCODE_ALT_RIGHT -> {
                    simulatedAltPressedCount = (simulatedAltPressedCount - 1).coerceAtLeast(0)
                    simulatedAltRightPressedCount = (simulatedAltRightPressedCount - 1).coerceAtLeast(0)
                }
                KeyEvent.KEYCODE_META_LEFT, KeyEvent.KEYCODE_META_RIGHT ->
                    simulatedMetaPressedCount = (simulatedMetaPressedCount - 1).coerceAtLeast(0)
                KeyEvent.KEYCODE_FUNCTION ->
                    simulatedFunctionPressedCount = (simulatedFunctionPressedCount - 1).coerceAtLeast(0)
            }
        }
    }

    private fun simulatedMetaState(keyCode: Int): Int {
        var metaState = 0
        if (simulatedCapsLockOn) metaState = metaState or KeyEvent.META_CAPS_LOCK_ON
        // Num lock is always treated as ON for numpad keys from the simulated keyboard,
        // so that Android KeyCharacterMap produces the correct digit/symbol unicode
        // characters instead of converting them to navigation keys.
        if (simulatedNumLockOn || keyCode in NUMPAD_KEYCODE_RANGE) {
            metaState = metaState or KeyEvent.META_NUM_LOCK_ON
        }
        if (simulatedShiftPressedCount > 0) metaState = metaState or KeyEvent.META_SHIFT_ON
        if (simulatedCtrlPressedCount > 0) metaState = metaState or KeyEvent.META_CTRL_ON
        if (simulatedAltPressedCount > 0) metaState = metaState or KeyEvent.META_ALT_ON
        if (simulatedMetaPressedCount > 0) metaState = metaState or KeyEvent.META_META_ON
        if (simulatedFunctionPressedCount > 0) metaState = metaState or KeyEvent.META_FUNCTION_ON
        if (simulatedAltRightPressedCount > 0) metaState = metaState or KeyEvent.META_ALT_RIGHT_ON
        return metaState
    }

    /**
     * Send a simulated key event directly to the current input connection (custom buttons on the
     * Kawaii bar / status area). Like [sendSimulatedKeyEvent], it tracks modifier hold state so
     * shortcuts and modifier-composed macros carry the correct metaState to the app.
     */
    public fun sendSimulatedKeyEventOrFallback(keyCode: Int, isDown: Boolean) {
        val action = if (isDown) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP
        updateSimulatedModifierCount(keyCode, action)
        val eventTime = SystemClock.uptimeMillis()
        val scanCode = getCachedScancode(keyCode)
        currentInputConnection?.sendKeyEvent(
            KeyEvent(
                eventTime,
                eventTime,
                action,
                keyCode,
                0,
                simulatedMetaState(keyCode),
                KeyCharacterMap.VIRTUAL_KEYBOARD,
                scanCode,
                KeyEvent.FLAG_SOFT_KEYBOARD or KeyEvent.FLAG_KEEP_TOUCH_MODE
            )
        )
    }

    public fun sendSimulatedKeyEvent(keyCode: Int, scanCode: Int, action: Int, fromMacro: Boolean = false) {
        val eventTime = SystemClock.uptimeMillis()
        if (action == KeyEvent.ACTION_DOWN) {
            when (keyCode) {
                KeyEvent.KEYCODE_CAPS_LOCK -> {
                    simulatedCapsLockPressed = true
                    simulatedCapsLockPressedFromMacro = fromMacro
                }
                KeyEvent.KEYCODE_NUM_LOCK -> simulatedNumLockPressed = true
            }
            updateSimulatedModifierCount(keyCode, action)
        } else if (action == KeyEvent.ACTION_UP) {
            updateSimulatedModifierCount(keyCode, action)
        }
        val metaState = simulatedMetaState(keyCode)
        // Use InputDevice.SOURCE_KEYBOARD so the system uses the physical keyboard KeyCharacterMap
        // This makes function keys (F1-F12) return unicodeChar = 0 and follow the keyCodeToSym path
        val event = KeyEvent(
            eventTime, // downTime
            eventTime, // eventTime
            action,
            keyCode,
            0, // repeatCount
            metaState,
            0, // deviceId
            scanCode,
            KeyEvent.FLAG_FROM_SYSTEM, // flags: mark as coming from system hardware
            InputDevice.SOURCE_KEYBOARD // source: physical keyboard
        )
        Timber.v("sendSimulatedKeyEvent: keyCode=%d scanCode=%d action=%d unicodeChar=%d",
            keyCode, scanCode, action, event.unicodeChar)
        forwardKeyEvent(event, preserveModifierState = true)
        if (fromMacro) {
            inputView?.clearKawaiiBarFocusState()
            inputView?.post { inputView?.clearKawaiiBarFocusState() }
        }

        if (action == KeyEvent.ACTION_UP) {
            when (keyCode) {
                KeyEvent.KEYCODE_CAPS_LOCK -> {
                    val old = simulatedCapsLockOn
                    if (simulatedCapsLockPressed) {
                        simulatedCapsLockOn = !simulatedCapsLockOn
                        simulatedCapsLockOnByMacroTap =
                            simulatedCapsLockOn && simulatedCapsLockPressedFromMacro
                    }
                    simulatedCapsLockPressed = false
                    simulatedCapsLockPressedFromMacro = false
                    if (old != simulatedCapsLockOn) {
                        TextKeyboard.refreshCapsPresentationOnAll()
                    }
                }
                KeyEvent.KEYCODE_NUM_LOCK -> {
                    if (simulatedNumLockPressed) {
                        simulatedNumLockOn = !simulatedNumLockOn
                    }
                    simulatedNumLockPressed = false
                }
            }
        }
    }

    /** Send UP only within its original editor; a stale connection may have been reused. */
    internal fun releaseMacroKey(
        keyCode: Int,
        scanCode: Int,
        editor: EditorSessionTracker.Token,
        cancelled: Boolean
    ) {
        val current = editor.isCurrent()
        if (cancelled || !current) {
            // An interrupted lock-key tap must not latch Caps/Num Lock on cleanup.
            if (keyCode == KeyEvent.KEYCODE_CAPS_LOCK) {
                simulatedCapsLockPressed = false
                simulatedCapsLockPressedFromMacro = false
            } else if (keyCode == KeyEvent.KEYCODE_NUM_LOCK) simulatedNumLockPressed = false
        }
        if (current) {
            sendSimulatedKeyEvent(keyCode, scanCode, KeyEvent.ACTION_UP, fromMacro = true)
        } else {
            updateSimulatedModifierCount(keyCode, KeyEvent.ACTION_UP)
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (dispatchDialogKeyEvent(event)) return true
        if (keyCode == KeyEvent.KEYCODE_CAPS_LOCK) {
            simulatedCapsLockPressed = true
            simulatedCapsLockPressedFromMacro = false
        }
        // A real hardware character is input demand even for TYPE_NULL terminals.
        // Promote before capturing the key, while keeping silent focus cheap.
        if (event.unicodeChar != 0 && FcitxDaemon.requireInputSession()) {
            postFcitxSessionJob(inputSessionGeneration) { focus(true) }
        }
        onHardwareTypingModeEnter(event)
        // request to show floating CandidatesView when pressing physical keyboard
        if (inputDeviceManager.evaluateOnKeyDown(event)) {
            postFcitxJob {
                focus(true)
            }
            forceShowSelf()
        }
        return forwardKeyEvent(event) || super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (dispatchDialogKeyEvent(event)) return true
        if (keyCode == KeyEvent.KEYCODE_CAPS_LOCK) {
            val old = simulatedCapsLockOn
            simulatedCapsLockOn = event.isCapsLockOn
            simulatedCapsLockPressed = false
            simulatedCapsLockPressedFromMacro = false
            simulatedCapsLockOnByMacroTap = false
            if (old != simulatedCapsLockOn) {
                TextKeyboard.refreshCapsPresentationOnAll()
            }
        }
        return forwardKeyEvent(event) || super.onKeyUp(keyCode, event)
    }

    public fun sendSimulatedCapsLockTapFromMacro() {
        val keyCode = KeyEvent.KEYCODE_CAPS_LOCK
        val scanCode = run {
            try {
                getCachedScancode(keyCode).takeIf { it != 0 } ?: 0
            } catch (e: Exception) {
                Timber.w("keyCodeToScancode failed for keyCode=$keyCode: ${e.message}")
                0
            }
        }
        sendSimulatedKeyEvent(keyCode, scanCode, KeyEvent.ACTION_DOWN, fromMacro = true)
        sendSimulatedKeyEvent(keyCode, scanCode, KeyEvent.ACTION_UP, fromMacro = true)
    }

    /**
     * Serializes [sendStandaloneShiftTap] so a fast double tap produces two separate taps
     * instead of a nested down-down-up-up sequence (which the engine would see as one).
     */
    private var standaloneShiftTapJob: Job? = null

    /**
     * Send one standalone Shift tap (press, short hold, release).
     *
     * This is what the language key does: instead of switching input method itself, it hands a
     * lone Shift to the engine and lets the engine decide. For Rime that is
     * `ascii_composer/switch_key`, i.e. the Chinese/Latin (`ascii_mode`) toggle configured in
     * the user's `default.custom.yaml`.
     *
     * Two details are load-bearing:
     * - it goes through [sendSimulatedKeyEvent], never [sendSimulatedKeyEventOrFallback]: the
     *   latter only reaches the application's InputConnection, so fcitx would never see the key;
     * - the key is held for [STANDALONE_MODIFIER_HOLD_MS], comfortably inside librime's 500ms
     *   `toggle_duration_limit`, so the release still counts as a standalone modifier tap.
     */
    fun sendStandaloneShiftTap() {
        val keyCode = KeyEvent.KEYCODE_SHIFT_LEFT
        val scanCode = getCachedScancode(keyCode)
        val previous = standaloneShiftTapJob
        standaloneShiftTapJob = lifecycleScope.launch {
            previous?.join()
            sendSimulatedKeyEvent(keyCode, scanCode, KeyEvent.ACTION_DOWN)
            try {
                delay(STANDALONE_MODIFIER_HOLD_MS)
            } finally {
                // Never leave Shift held: the modifier hold state is shared with macros and
                // shortcuts, so a missing release would silently add Shift to later keys.
                sendSimulatedKeyEvent(keyCode, scanCode, KeyEvent.ACTION_UP)
            }
        }
    }

    // Added in API level 14, deprecated in 29
    // it's needed because editors still use it even on API 36
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onViewClicked(focusChanged: Boolean) {
        super.onViewClicked(focusChanged)
        inputDeviceManager.evaluateOnViewClicked(this)
    }

    @RequiresApi(34)
    override fun onUpdateEditorToolType(toolType: Int) {
        super.onUpdateEditorToolType(toolType)
        inputDeviceManager.evaluateOnUpdateEditorToolType(toolType, this)
    }

    private var firstBindInput = true

    override fun onBindInput() {
        resetCandidatePagingModeCache()
        onBackspaceGuardSessionChanged()
        val uid = currentInputBinding.uid
        val pkgName = pkgNameCache.forUid(uid)
        val bindingGeneration = ++inputBindingGeneration
        Timber.d("onBindInput: uid=$uid pkg=$pkgName")
        postFcitxBindingJob(bindingGeneration) {
            // ensure InputContext has been created before focusing it
            activate(uid, pkgName)
        }
        if (firstBindInput) {
            firstBindInput = false
            // only use input method from subtype for the first `onBindInput`, because
            // 1. fcitx has `ShareInputState` option, thus reading input method from subtype
            //    everytime would ruin `ShareInputState=Program`
            // 2. im from subtype should be read once, when user changes input method from other
            //    app to a subtype of ours via system input method picker (on 34+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val subtype = inputMethodManager.currentInputMethodSubtype ?: return
                val im = SubtypeManager.inputMethodOf(subtype)
                postFcitxJob {
                    activateIme(im)
                }
            }
        }
    }

    override fun onCurrentInputMethodSubtypeChanged(newSubtype: InputMethodSubtype) {
        super.onCurrentInputMethodSubtypeChanged(newSubtype)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val im = SubtypeManager.inputMethodOf(newSubtype)
            Timber.d("onCurrentInputMethodSubtypeChanged: im=$im")
            postFcitxJob {
                activateIme(im)
            }
        }
    }

    /**
     * 开关剪贴板历史搜索会话。关闭时重置引擎，避免搜索期间的 composing
     * 状态残留到目标编辑器。
     */
    fun startClipboardSearch() {
        statisticsStore?.endSession()
        ClipboardSearchController.start()
        onBackspaceGuardSessionChanged()
        postFcitxJob { reset() }
    }

    fun stopClipboardSearch() {
        statisticsStore?.endSession()
        ClipboardSearchController.stop()
        onBackspaceGuardSessionChanged()
        postFcitxJob { reset() }
    }

    override fun onStartInput(attribute: EditorInfo, restarting: Boolean) {
        statisticsStore?.endSession()
        jsAppDismiss?.invoke()
        android.util.Log.i("FcitxColdStart", "service.onStartInput restarting=$restarting")
        if (editorSession.start(EditorSessionTracker.Editor(attribute.packageName, attribute.fieldId,
                attribute.inputType, attribute.imeOptions), restarting)) {
            endEditorWork()
        }
        val engineGeneration = FcitxDaemon.invalidateInputSession()
        isInInputLifecycleCriticalPhase = true
        onBackspaceGuardSessionChanged()
        try {
            val inputSessionGeneration = ++this.inputSessionGeneration
            MainService.startSyncService(this, "ime-start-input", imeSyncActive = true)
            selection.resetTo(attribute.initialSelStart, attribute.initialSelEnd)
            resetComposingState()
            val flags = CapabilityFlags.fromEditorInfo(attribute)
            capabilityFlags = flags
            inputDeviceManager.notifyOnStartInput(attribute)
            Timber.d("onStartInput: initialSel=${selection.current}, restarting=$restarting")
            val isNullType = attribute.isTypeNull()
            FcitxDaemon.prepareInputSession(engineGeneration, attribute.packageName.orEmpty(), flags, !isNullType)
            android.util.Log.i("RimeLifecycle", "input_binding generation=$engineGeneration input_type=${attribute.inputType} ime_options=${attribute.imeOptions} needs_rime=${!isNullType} restarting=$restarting")
            postFcitxSessionJob(inputSessionGeneration) {
                startInputSession(engineGeneration, attribute.packageName.orEmpty())
                setCapFlags(flags)
                if (!isNullType) {
                    focus(true)
                }
            }
        } finally {
            contentView.post {
                isInInputLifecycleCriticalPhase = false
                applyPendingThemeIfPossible()
            }
        }
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        android.util.Log.i("FcitxColdStart", "service.onStartInputView restarting=$restarting")
        isInInputLifecycleCriticalPhase = true
        // Android may show a retained keyboard window for a non-editor too.
        // TYPE_NULL terminals are promoted by their first actual key/action.
        try {
            val inputSessionGeneration = this.inputSessionGeneration
            Timber.d("onStartInputView: restarting=$restarting")
            MainService.startSyncService(this, "ime-start-input-view", imeSyncActive = true)
            ensurePreferredVoiceInputProviderAvailable()
            postFcitxSessionJob(inputSessionGeneration) {
                focus(true)
                // Keep paged candidate mode enabled so candidate cursor/highlight is available.
                applyCandidatePagingModeIfNeeded(1)
            }
            if (inputDeviceManager.evaluateOnStartInputView(info, this) ||
                inputDeviceManager.isPhysicalCandidateBarMode
            ) {
                // startInput -> KeyboardWindow.checkAndApplyFontRefresh() consumes the font
                // refresh flag and rebuilds only the key rows. There used to be an extra
                // whole-tree replacement above this branch; it read the flag without clearing
                // it, so once a font had been changed *every* later focus event rebuilt
                // everything, and the replacement also ran inside the input-lifecycle critical
                // phase that canApplyPendingThemeNow() exists to keep InputView swaps out of.
                inputView?.startInput(info, capabilityFlags, restarting)
            } else {
                if (currentInputConnection?.monitorCursorAnchor() != true) {
                    if (!decorLocationUpdated) {
                        updateDecorLocation()
                    }
                    workaroundNullCursorAnchorInfo()
                }
                // anchor CandidatesView to bottom-left corner in case InputConnection does not
                // support monitoring CursorAnchorInfo
                candidatesView?.updateCursorAnchor(contentSize)
                // This path never calls startInput, so nothing consumes the font refresh flag
                // here. Queue a theme-style replacement instead of doing it inline: the finally
                // block below runs applyPendingThemeIfPossible() once the critical phase ends.
                if (org.fcitx.fcitx5.android.input.font.FontProviders.checkAndClearRefreshFlag()) {
                    pendingThemeUpdate = ThemeManager.activeTheme
                }
            }
        } finally {
            contentView.post {
                isInInputLifecycleCriticalPhase = false
                applyPendingThemeIfPossible()
            }
            updateStatusIcon()
        }
    }

    private fun ensurePreferredVoiceInputProviderAvailable() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !userManager.isUserUnlocked) return
        val keyboardPrefs = AppPrefs.getInstance().keyboard
        val voiceInputReachable =
            keyboardPrefs.showVoiceInputButton.getValue() ||
                keyboardPrefs.spaceKeyLongPressBehavior.getValue() == SpaceLongPressBehavior.VoiceInput ||
                keyboardPrefs.spaceKeyLongPressBehavior.getValue() == SpaceLongPressBehavior.VoiceInputHold
        if (!voiceInputReachable) return
        val preferredVoiceInput = keyboardPrefs.preferredVoiceInput.getValue()
        VoiceInputProviderManager.ensureProviderAvailable(this, preferredVoiceInput)
    }

    override fun onUpdateSelection(
        oldSelStart: Int,
        oldSelEnd: Int,
        newSelStart: Int,
        newSelEnd: Int,
        candidatesStart: Int,
        candidatesEnd: Int
    ) {
        if (jsAppInputConnection != null) return
        // onUpdateSelection can left behind when user types quickly enough, eg. long press backspace
        cursorUpdateIndex += 1
        Timber.d("onUpdateSelection: old=[$oldSelStart,$oldSelEnd] new=[$newSelStart,$newSelEnd] cand=[$candidatesStart,$candidatesEnd]")
        handleCursorUpdate(
            newSelStart,
            newSelEnd,
            candidatesStart,
            candidatesEnd,
            cursorUpdateIndex
        )
        inputView?.updateSelection(newSelStart, newSelEnd)
    }

    private val contentSize = floatArrayOf(0f, 0f)
    private val decorLocation = floatArrayOf(0f, 0f)
    private val decorLocationInt = intArrayOf(0, 0)
    private var decorLocationUpdated = false

    private fun updateDecorLocation() {
        contentSize[0] = contentView.width.toFloat()
        contentSize[1] = contentView.height.toFloat()
        decorView.getLocationOnScreen(decorLocationInt)
        decorLocation[0] = decorLocationInt[0].toFloat()
        decorLocation[1] = decorLocationInt[1].toFloat()
        // contentSize and decorLocation can be completely wrong,
        // when measuring right after the very first onStartInputView() of an IMS' lifecycle
        if (contentSize[0] > 0 && contentSize[1] > 0) {
            decorLocationUpdated = true
        }
    }

    private val anchorPosition = floatArrayOf(0f, 0f, 0f, 0f)

    private fun workaroundNullCursorAnchorInfo() {
        anchorPosition[0] = 0f
        anchorPosition[1] = contentSize[1]
        anchorPosition[2] = 0f
        anchorPosition[3] = contentSize[1]
        candidatesView?.updateCursorAnchor(anchorPosition, contentSize)
    }

    override fun onUpdateCursorAnchorInfo(info: CursorAnchorInfo) {
        val bounds = info.getCharacterBounds(0)
        if (bounds != null) {
            // anchor to start of composing span instead of insertion mark if available
            val horizontal =
                if (candidatesView?.layoutDirection == View.LAYOUT_DIRECTION_RTL) bounds.right else bounds.left
            anchorPosition[0] = horizontal
            anchorPosition[1] = bounds.bottom
            anchorPosition[2] = horizontal
            anchorPosition[3] = bounds.top
        } else {
            anchorPosition[0] = info.insertionMarkerHorizontal
            anchorPosition[1] = info.insertionMarkerBottom
            anchorPosition[2] = info.insertionMarkerHorizontal
            anchorPosition[3] = info.insertionMarkerTop
        }
        // avoid calling `decorView.getLocationOnScreen` repeatedly
        if (!decorLocationUpdated) {
            updateDecorLocation()
        }
        if (anchorPosition.any(Float::isNaN)) {
            // anchor candidates view to bottom-left corner in case CursorAnchorInfo is invalid
            candidatesView?.updateCursorAnchor(contentSize)
            return
        }
        // params of `Matrix.mapPoints` must be [x0, y0, x1, y1]
        info.matrix.mapPoints(anchorPosition)
        val (xOffset, yOffset) = decorLocation
        anchorPosition[0] -= xOffset
        anchorPosition[1] -= yOffset
        anchorPosition[2] -= xOffset
        anchorPosition[3] -= yOffset
        
        // In "Always" floating mode, avoid doing the normal cursor-anchor
        // positioning first and then immediately re-positioning again.
        val floatingMode = AppPrefs.getInstance().candidates.mode.getValue()
        if (floatingMode == FloatingCandidatesMode.Always) {
            updateCursorAnchorForFloatingCandidates()
        } else {
            candidatesView?.updateCursorAnchor(anchorPosition, contentSize)
        }
    }

    private fun handleCursorUpdate(
        newSelStart: Int,
        newSelEnd: Int,
        newComposingStart: Int,
        newComposingEnd: Int,
        updateIndex: Int
    ) {
        if (selection.consume(newSelStart, newSelEnd)) {
            // try restore composing range in case it was dropped by InputFilter
            // but only when prediction matches, since InputFilter can also change editor content
            // ref:
            // https://android.googlesource.com/platform/frameworks/base/+/refs/tags/android-15.0.0_r36/core/java/android/widget/Editor.java#2083
            // https://android.googlesource.com/platform/frameworks/base/+/refs/tags/android-15.0.0_r36/core/java/android/widget/TextView.java#7351
            if (newComposingStart == -1 && newComposingEnd == -1 && composing.isNotEmpty()) {
                currentInputConnection?.setComposingRegion(composing.start, composing.end)
            }
            return // do nothing if prediction matches
        } else {
            // cursor update can't match any prediction: it's treated as a user input
            selection.resetTo(newSelStart, newSelEnd)
        }
        // skip selection range update, we only care about selection cursor (zero width) here
        if (newSelStart != newSelEnd) return
        // do reset if composing is empty && input panel is not empty
        if (composing.isEmpty()) {
            postFcitxJob {
                if (!isEmpty()) {
                    Timber.d("handleCursorUpdate: reset")
                    reset()
                }
            }
            return
        }
        // check if cursor inside composing text
        if (composing.contains(newSelStart)) {
            if (ignoreSystemCursor) return
            // Android reports UTF-16 positions relative to the client preedit.
            val position = newSelStart - composing.start
            // move fcitx cursor when cursor position changed
            if (position != composingText.cursor) {
                // The backend maps displayed code points to raw Rime input bytes.
                val codePointPosition = composingText.codePointCountUntil(position)
                val expectedPreedit = composingText.toString()
                val expectedSession = FcitxDaemon.currentInputSession
                postFcitxJob {
                    if (updateIndex != cursorUpdateIndex) return@postFcitxJob
                    Timber.d("handleCursorUpdate: move fcitx cursor to $codePointPosition")
                    moveCursorIfCurrent(codePointPosition, expectedSession, expectedPreedit)
                }
            }
        } else {
            Timber.d("handleCursorUpdate: focus out/in")
            resetComposingState()
            // cursor outside composing range, finish composing as-is
            currentInputConnection?.finishComposingText()
            // `fcitx.reset()` here would commit preedit after new cursor position
            // since we have `ClientUnfocusCommit`, focus out and in would do the trick
            postFcitxJob {
                focusOutIn()
            }
        }
    }

    // because setComposingText(text, cursor) can only put cursor at end of composing,
    // sometimes onUpdateSelection would receive event with wrong cursor position.
    // those events need to be filtered.
    // because of https://android.googlesource.com/platform/frameworks/base.git/+/refs/tags/android-11.0.0_r45/core/java/android/view/inputmethod/BaseInputConnection.java#851
    // it's not possible to set cursor inside composing text
    private fun updateComposingText(text: FormattedText) {
        jsAppInputConnection?.let {
            (it as? JsAppInputConnection)?.updateComposition(text.toSpannedString(highlightColor), text.cursor)
            return
        }
        if (text.isEmpty() && composing.isEmpty() && composingText.isEmpty()) return
        val ic = currentInputConnection ?: return
        val lastSelection = selection.latest
        ic.beginBatchEdit()
        if (composingText.spanEquals(text)) {
            // composing text content is up-to-date
            // update cursor only when it's not empty AND cursor position is valid
            if (text.length > 0 && text.cursor >= 0) {
                val p = text.cursor + composing.start
                if (p != lastSelection.start) {
                    Timber.d("updateComposingText: set Android selection ($p, $p)")
                    ic.setSelection(p, p)
                    selection.predict(p)
                }
            }
        } else {
            // composing text content changed
            Timber.d("updateComposingText: len=${text.length} lastSelection=$lastSelection")
            if (text.isEmpty()) {
                if (composing.isEmpty()) {
                    // do not reset saved selection range when incoming composing
                    // and saved composing range are both empty:
                    // composing.start is invalid when it's empty.
                    selection.predict(lastSelection.start)
                } else {
                    // clear composing text, put cursor at start of original composing
                    selection.predict(composing.start)
                    composing.clear()
                }
                ic.setComposingText("", 1)
            } else {
                val start = if (composing.isEmpty()) lastSelection.start else composing.start
                composing.update(start, start + text.length)
                // skip cursor reposition when:
                // - preedit cursor is at the end
                // - cursor position is invalid
                if (text.cursor == text.length || text.cursor < 0) {
                    selection.predict(composing.end)
                    ic.setComposingText(text.toSpannedString(highlightColor), 1)
                } else {
                    val p = text.cursor + composing.start
                    selection.predict(p)
                    ic.setComposingText(text.toSpannedString(highlightColor), 1)
                    ic.setSelection(p, p)
                }
            }
            Timber.d("updateComposingText: composing=$composing")
        }
        composingText = text
        ic.endBatchEdit()
    }

    /**
     * Finish composing text and leave cursor position as-is.
     * Also updates internal composing state of [FcitxInputMethodService].
     */
    fun finishComposing() {
        jsAppInputConnection?.let { it.finishComposingText(); return }
        val ic = currentInputConnection ?: return
        if (composing.isEmpty()) return
        composing.clear()
        composingText = FormattedText.Empty
        ic.finishComposingText()
    }

    @SuppressLint("RestrictedApi")
    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreateInlineSuggestionsRequest(uiExtras: Bundle): InlineSuggestionsRequest? {
        // ignore inline suggestion when disabled by user || using physical keyboard with floating candidates view
        if (!inlineSuggestions || !inputDeviceManager.isVirtualKeyboard) return null
        val theme = ThemeManager.activeTheme
        val chipDrawable =
            if (theme.isDark) R.drawable.bkg_inline_suggestion_dark else R.drawable.bkg_inline_suggestion_light
        val chipBg = Icon.createWithResource(this, chipDrawable).setTint(theme.keyTextColor)
        val style = InlineSuggestionUi.newStyleBuilder()
            .setSingleIconChipStyle(
                ViewStyle.Builder()
                    .setBackgroundColor(Color.TRANSPARENT)
                    .setPadding(0, 0, 0, 0)
                    .build()
            )
            .setChipStyle(
                ViewStyle.Builder()
                    .setBackground(chipBg)
                    .setPadding(dp(10), 0, dp(10), 0)
                    .build()
            )
            .setTitleStyle(
                TextViewStyle.Builder()
                    .setLayoutMargin(dp(4), 0, dp(4), 0)
                    .setTextColor(theme.keyTextColor)
                    .setTextSize(14f)
                    .build()
            )
            .setSubtitleStyle(
                TextViewStyle.Builder()
                    .setTextColor(theme.altKeyTextColor)
                    .setTextSize(12f)
                    .build()
            )
            .setStartIconStyle(
                ImageViewStyle.Builder()
                    .setTintList(ColorStateList.valueOf(theme.altKeyTextColor))
                    .build()
            )
            .setEndIconStyle(
                ImageViewStyle.Builder()
                    .setTintList(ColorStateList.valueOf(theme.altKeyTextColor))
                    .build()
            )
            .build()
        val styleBundle = UiVersions.newStylesBuilder()
            .addStyle(style)
            .build()
        val spec = InlinePresentationSpec
            .Builder(Size(0, 0), Size(Int.MAX_VALUE, Int.MAX_VALUE))
            .setStyle(styleBundle)
            .build()
        return InlineSuggestionsRequest.Builder(listOf(spec))
            .setMaxSuggestionCount(InlineSuggestionsRequest.SUGGESTION_COUNT_UNLIMITED)
            .build()
    }

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onInlineSuggestionsResponse(response: InlineSuggestionsResponse): Boolean {
        if (!inlineSuggestions || !inputDeviceManager.isVirtualKeyboard) return false
        return inputView?.handleInlineSuggestions(response) == true
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        statisticsStore?.endSession()
        Timber.d("onFinishInputView: finishingInput=$finishingInput")
        macroInput.cancelAll()
        onBackspaceGuardSessionChanged()
        MainService.stopSyncService(this)
        if (VoiceInputProviderManager.isActive()) {
            VoiceInputProviderManager.stop(this)
        }
        decorLocationUpdated = false
        inputDeviceManager.onFinishInputView()
        currentInputConnection?.apply {
            finishComposingText()
            monitorCursorAnchor(false)
        }
        resetComposingState()
        val inputSessionGeneration = this.inputSessionGeneration
        postFcitxSessionJob(inputSessionGeneration) {
            focusOutIn()
        }
        hideStatusIcon()
        showingDialog?.dismiss()
    }

    override fun onFinishInput() {
        jsAppDismiss?.invoke()
        editorSession.end()
        endEditorWork()
        FcitxDaemon.invalidateInputSession()
        Timber.d("onFinishInput")
        onBackspaceGuardSessionChanged()
        MainService.stopSyncService(this)
        val inputSessionGeneration = this.inputSessionGeneration
        postFcitxSessionJob(inputSessionGeneration) {
            focus(false)
        }
        capabilityFlags = CapabilityFlags.DefaultFlags
    }

    override fun onUnbindInput() {
        jsAppDismiss?.invoke()
        editorSession.end()
        endEditorWork()
        FcitxDaemon.invalidateInputSession()
        cachedKeyEvents.evictAll()
        cachedKeyEventIndex = 0
        cursorUpdateIndex = 0
        resetCandidatePagingModeCache()
        onBackspaceGuardSessionChanged()
        // currentInputBinding can be null on some devices under some special Multi-screen mode
        val uid = currentInputBinding?.uid ?: return
        val bindingGeneration = inputBindingGeneration
        Timber.d("onUnbindInput: uid=$uid")
        postFcitxBindingJob(bindingGeneration) {
            deactivate(uid)
        }
    }

    override fun onDestroy() {
        jsAppDismiss?.invoke()
        editorSession.end()
        endEditorWork()
        showingDialog?.dismiss()
        unregisterDialogBackHandler?.invoke()
        unregisterDialogBackHandler = null
        FcitxDaemon.invalidateInputSession()
        MainService.stopSyncService(this)
        recreateInputViewPrefs.forEach {
            it.unregisterOnChangeListener(recreateInputViewListener)
        }
        prefs.candidates.unregisterOnChangeListener(recreateCandidatesViewListener)
        prefs.candidates.mode.unregisterOnChangeListener(onFloatingModeChangeListener)
        ThemeManager.removeOnChangedListener(onThemeChangeListener)
        runCatching { unregisterReceiver(voiceInputCommitReceiver) }
        super.onDestroy()
        // Fcitx might be used in super.onDestroy()
        FcitxDaemon.disconnect(javaClass.name)
    }

    internal var jsAppInputConnection: android.view.inputmethod.InputConnection? = null
        set(value) {
            if (field !== value) statisticsStore?.endSession()
            field = value
        }
    internal var jsAppDismiss: (() -> Unit)? = null
    internal val applicationInputConnection get() = super.getCurrentInputConnection()
    override fun getCurrentInputConnection(): android.view.inputmethod.InputConnection? =
        jsAppInputConnection ?: super.getCurrentInputConnection()

    internal fun resetJsAppEditorState() {
        resetComposingState()
        val extracted = applicationInputConnection?.getExtractedText(android.view.inputmethod.ExtractedTextRequest(), 0)
        if (extracted != null) selection.resetTo(extracted.startOffset + extracted.selectionStart,
            extracted.startOffset + extracted.selectionEnd)
        postFcitxSessionJob(inputSessionGeneration) { reset() }
    }

    private var showingDialog: Dialog? = null
    private var unregisterDialogBackHandler: (() -> Unit)? = null

    // Selection menus keep the editor's window focus. Deliver keys through the
    // IME so Back and keyboard navigation still belong to the open menu.
    private fun dispatchDialogKeyEvent(event: KeyEvent): Boolean =
        showingDialog?.takeIf { it.isShowing }?.dispatchKeyEvent(event) == true

    fun showDialog(dialog: Dialog) {
        // Menu data is resolved asynchronously; the editor may have gone away.
        if (!decorView.isShown || !decorView.isAttachedToWindow) return
        unregisterDialogBackHandler?.invoke()
        unregisterDialogBackHandler = null
        showingDialog?.dismiss()
        // AlertController adds ALT_FOCUSABLE_IM while installing its content.
        // Finish that first so it cannot overwrite our final window policy.
        dialog.create()
        dialog.window?.also {
            it.attributes.apply {
                token = decorView.windowToken
                type = WindowManager.LayoutParams.TYPE_APPLICATION_ATTACHED_DIALOG
            }
            // A focusable attached dialog makes web password editors lose
            // focus, hide the IME and immediately restart input. These menus
            // contain selections, not editors: touch must not take that focus.
            // NOT_FOCUSABLE alone stays above the IME; combining it with
            // ALT_FOCUSABLE_IM would instead place the menu behind the IME.
            it.clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM)
            it.addFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_DIM_BEHIND or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH)
            it.setDimAmount(styledFloat(android.R.attr.backgroundDimAmount))
        }
        dialog.setOnDismissListener {
            if (showingDialog === dialog) {
                showingDialog = null
                unregisterDialogBackHandler?.invoke()
                unregisterDialogBackHandler = null
            }
        }
        dialog.show()
        showingDialog = dialog
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Predictive Back bypasses onKeyDown/onKeyUp when enabled by the
            // settings UI. Consume it on the IME window while a menu is open.
            val dispatcher = window.window!!.onBackInvokedDispatcher
            val callback = android.window.OnBackInvokedCallback {
                if (showingDialog === dialog) dialog.cancel()
            }
            dispatcher.registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_OVERLAY, callback)
            unregisterDialogBackHandler = { dispatcher.unregisterOnBackInvokedCallback(callback) }
        }
    }

    @Suppress("ConstPropertyName")
    companion object {
        const val DefaultHighlightColor = 0x66008577 // material_deep_teal_500 with alpha 0.4
        const val DeleteSurroundingFlag = "org.fcitx.fcitx5.android.DELETE_SURROUNDING"
    }
}
