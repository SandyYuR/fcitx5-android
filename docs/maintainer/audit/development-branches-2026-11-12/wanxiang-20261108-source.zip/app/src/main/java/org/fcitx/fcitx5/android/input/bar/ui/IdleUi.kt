/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2025 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.input.bar.ui

import android.content.Context
import android.graphics.drawable.Drawable
import android.transition.Slide
import android.transition.TransitionManager
import android.transition.TransitionSet
import android.view.View
import android.view.Gravity
import android.view.animation.AlphaAnimation
import android.view.animation.AnimationSet
import android.view.animation.TranslateAnimation
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ViewAnimator
import androidx.annotation.DrawableRes
import androidx.core.view.updateLayoutParams
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.data.prefs.AppPrefs
import org.fcitx.fcitx5.android.data.theme.Theme
import org.fcitx.fcitx5.android.input.bar.KawaiiBarComponent
import org.fcitx.fcitx5.android.input.bar.ui.idle.ButtonsBarUi
import org.fcitx.fcitx5.android.input.bar.ui.idle.ClipboardSuggestionUi
import org.fcitx.fcitx5.android.input.bar.ui.idle.InlineSuggestionsUi
import org.fcitx.fcitx5.android.input.bar.ui.idle.NumberRow
import org.fcitx.fcitx5.android.input.config.ButtonIconFile
import org.fcitx.fcitx5.android.input.config.ButtonsLayoutConfig
import org.fcitx.fcitx5.android.input.config.ConfigurableButton
import org.fcitx.fcitx5.android.data.theme.IconThemeManager
import org.fcitx.fcitx5.android.input.keyboard.CommonKeyActionListener
import org.fcitx.fcitx5.android.input.popup.PopupComponent
import splitties.dimensions.dp
import splitties.views.dsl.constraintlayout.after
import splitties.views.dsl.constraintlayout.before
import splitties.views.dsl.constraintlayout.centerVertically
import splitties.views.dsl.constraintlayout.constraintLayout
import splitties.views.dsl.constraintlayout.endOfParent
import splitties.views.dsl.constraintlayout.lParams
import splitties.views.dsl.constraintlayout.matchConstraints
import splitties.views.dsl.constraintlayout.startOfParent
import splitties.views.dsl.core.Ui
import splitties.views.dsl.core.add
import splitties.views.dsl.core.horizontalLayout
import splitties.views.dsl.core.lParams
import splitties.views.dsl.core.frameLayout
import splitties.views.dsl.core.matchParent
import splitties.views.dsl.core.textView
import splitties.views.dsl.core.wrapContent
import splitties.views.imageResource
import timber.log.Timber
import kotlin.math.roundToInt
import kotlin.math.sqrt

class IdleUi(
    override val ctx: Context,
    private val theme: Theme,
    private val popup: PopupComponent,
    private val commonKeyActionListener: CommonKeyActionListener,
    private val buttonsConfig: List<ConfigurableButton> = ButtonsLayoutConfig.default().kawaiiBarButtons,
    private var toolbarToggleConfig: ConfigurableButton = ConfigurableButton("toolbar_toggle"),
    private var hideKeyboardConfig: ConfigurableButton = ConfigurableButton("hide_keyboard")
) : Ui {

    enum class State {
        Toolbar, Clipboard, NumberRow, InlineSuggestion, Search
    }

    var currentState = State.Toolbar
        private set

    private val disableAnimation by AppPrefs.getInstance().advanced.disableAnimation

    private var inPrivate = false

    private val translateDirection by lazy {
        if (ctx.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_LTR) 1f else -1f
    }

    private val hasCustomMenuIcon get() = toolbarToggleConfig.icon != null || !toolbarToggleConfig.text.isNullOrEmpty()
    private val menuButtonRotation = 0f

    /**
     * 「返回键盘」模式：符号面板显示时为 `true`。
     *
     * 此时工具栏内容完全不变（仍是主键盘那套按钮），只把最左侧按钮的图标换成返回箭头；
     * 点击行为由 `KawaiiBarComponent` 按当前窗口判定。
     */
    private var backToKeyboardMode = false

    @DrawableRes
    private val defaultMenuIcon = R.drawable.ic_baseline_more_horiz_24
    @DrawableRes
    private val defaultHideKeyboardIcon = R.drawable.ic_baseline_arrow_drop_down_24

    val menuButton = ToolButton(ctx, R.drawable.ic_baseline_more_horiz_24, theme).apply {
        iconRotation = menuButtonRotation
        applySystemButtonConfig(this, toolbarToggleConfig, defaultMenuIcon)
        if (toolbarToggleConfig.label.isNullOrEmpty()) {
            contentDescription = ctx.getString(R.string.status_area)
        }
    }

    val hideKeyboardButton = ToolButton(ctx, R.drawable.ic_baseline_arrow_drop_down_24, theme).apply {
        applySystemButtonConfig(this, hideKeyboardConfig, defaultHideKeyboardIcon)
        contentDescription = hideKeyboardConfig.label ?: ctx.getString(R.string.hide_keyboard)
    }

    val buttonsUi = ButtonsBarUi(ctx, theme, buttonsConfig)

    val clipboardUi = ClipboardSuggestionUi(ctx, theme)

    val numberRow = NumberRow(ctx, theme).apply {
        visibility = View.GONE
    }

    val inlineSuggestionsBar = InlineSuggestionsUi(ctx)

    val searchUi = ClipboardSearchUi(ctx, theme)

    private val voiceStatusText: TextView = textView {
        text = "Recording"
        textSize = 14f
        setTextColor(theme.keyTextColor)
        isSingleLine = true
    }

    private val voiceBars = List(12) {
        View(ctx).apply {
            setBackgroundColor(theme.keyTextColor)
            alpha = 0.35f
        }
    }

    private var voiceWavePhase = 0
    private var lastVoiceLevelAt = 0L

    val voiceInputFinishButton = ToolButton(ctx, R.drawable.ic_baseline_stop_24, theme).apply {
        contentDescription = ctx.getString(R.string.voice_input_finish)
    }

    private val voiceStatusBar = horizontalLayout {
        gravity = Gravity.CENTER_VERTICAL
        visibility = View.GONE
        setPadding(dp(8), 0, dp(8), 0)
        add(voiceStatusText, lParams(0, wrapContent, weight = 1f))
        voiceBars.forEach { bar ->
            add(bar, LinearLayout.LayoutParams(dp(3), dp(8)).apply {
                marginStart = dp(3)
            })
        }
        // The configurable microphone lives in animator, which is hidden while recording.
        // Keep the session's finish control inside the visible voice status strip instead.
        add(voiceInputFinishButton, lParams(KawaiiBarComponent.resolveHeightPx(ctx), matchParent))
    }

    private val voiceWaveTicker = object : Runnable {
        override fun run() {
            if (voiceStatusBar.visibility != View.VISIBLE) return
            val hasRecentLevel = System.currentTimeMillis() - lastVoiceLevelAt < 500L
            if (!hasRecentLevel) {
                updateVoiceBars(-1f)
            }
            voiceStatusBar.postDelayed(this, 120L)
        }
    }

    private val animator = ViewAnimator(ctx).apply {
        add(buttonsUi.root, lParams(matchParent, matchParent))
        add(clipboardUi.root, lParams(matchParent, matchParent))
        add(inlineSuggestionsBar.root, lParams(matchParent, matchParent))
        add(searchUi.root, lParams(matchParent, matchParent))
    }

    /** 工具栏搜索框：显示已提交查询与下划线 preedit，搜索会话专用。 */
    fun updateSearchQuery(committed: String, preedit: String) {
        searchUi.updateQuery(committed, preedit)
    }

    private val inAnimation by lazy {
        AnimationSet(true).apply {
            duration = 200L
            addAnimation(AlphaAnimation(0f, 1f))
            // 2 stands for Animation.RELATIVE_TO_PARENT
            addAnimation(TranslateAnimation(2, -0.3f * translateDirection, 2, 0f, 0, 0f, 0, 0f))
        }
    }

    private val outAnimation by lazy {
        AnimationSet(true).apply {
            duration = 200L
            addAnimation(AlphaAnimation(1f, 0f))
            addAnimation(TranslateAnimation(2, 0f, 2, -0.3f * translateDirection, 0, 0f, 0, 0f))
        }
    }

    private val idleBody = constraintLayout {
        val size = KawaiiBarComponent.resolveHeightPx(ctx)
        add(menuButton, lParams(size, size) {
            startOfParent()
            centerVertically()
        })
        add(hideKeyboardButton, lParams(size, size) {
            endOfParent()
            centerVertically()
        })
        add(animator, lParams(matchConstraints, matchParent) {
            after(menuButton)
            before(hideKeyboardButton)
            centerVertically()
        })
        add(voiceStatusBar, lParams(matchConstraints, matchParent) {
            after(menuButton)
            before(hideKeyboardButton)
            centerVertically()
        })
    }

    override val root = frameLayout {
        add(idleBody, lParams(matchParent, matchParent))
        add(numberRow, lParams(matchParent, matchParent))
    }

    /**
     * 应用「工具栏大小」缩放。
     *
     * 固定按钮（状态区、隐藏键盘）的边长在这里显式更新：它们在 [idleBody] 里是按
     * 构造时的 40dp 写进 ConstraintLayout.LayoutParams 的，工具栏变高后若不动，
     * 点击热区会小于视觉上的栏高。图标缩放由 [ToolButton.applyToolbarScale] 负责。
     *
     * 调用方：[KawaiiBarComponent.refreshButtonsLayout]（设置变化时）与
     * [KawaiiBarComponent.view] 的首次构建，因此这里是唯一的尺寸来源。
     */
    fun applyToolbarScale() {
        val scale = KawaiiBarComponent.resolveScale()
        val size = KawaiiBarComponent.resolveHeightPx(ctx)
        // 固定按钮是正方形（边长 = 栏高），所以图标上限跟着栏高走：
        // 栏调高它们才有空间长大，栏压矮时又被自动收住。
        val slotDp = KawaiiBarComponent.resolveHeightDp()
        listOf(menuButton, hideKeyboardButton).forEach { button ->
            button.updateLayoutParams<androidx.constraintlayout.widget.ConstraintLayout.LayoutParams> {
                width = size
                height = size
            }
            button.applyToolbarScale(scale, slotDp)
        }
        voiceInputFinishButton.updateLayoutParams<LinearLayout.LayoutParams> { width = size }
        voiceInputFinishButton.applyToolbarScale(scale, slotDp)
        // 下滑隐藏键盘的手势阈值按栏高算；改了栏高却不改阈值，用户会滑不动（或一碰就触发）。
        hideKeyboardButton.swipeThresholdY = size.toFloat()
        buttonsUi.refreshLayout()
    }

    init {
        // Keep the center strip on the initial Toolbar page: updateState() only runs on an
        // actual state transition, so without this sync a freshly created bar that never
        // transitions (no clipboard hint, no password field, no number row) keeps showing
        // the animator's default child while the fixed left/right buttons stay visible —
        // exactly the intermittent "center toolbar missing" report.
        applyCenterVisibility()
    }

    fun clearTransientPressState() {
        menuButton.clearTransientPressState()
        hideKeyboardButton.clearTransientPressState()
        voiceInputFinishButton.clearTransientPressState()
        buttonsUi.clearTransientPressState()
    }

    fun privateMode(activate: Boolean = true) {
        if (activate == inPrivate) return
        inPrivate = activate
        updateMenuButtonIcon()
        updateMenuButtonContentDescription()
        updateMenuButtonRotation(instant = true)
    }

    private fun systemSlotFromButtonId(buttonId: String): String? = when (buttonId) {
        "toolbar_toggle" -> "system.toolbar_toggle"
        "hide_keyboard" -> "system.hide_keyboard"
        else -> buttonId.takeIf { it.startsWith("system.") }
    }

    private fun applyIconThemeToSystemButton(button: ToolButton, slotOrButtonId: String): Boolean {
        val slot = systemSlotFromButtonId(slotOrButtonId) ?: return false
        val iconInfo = IconThemeManager.resolveIconDrawableInfo(slot)
        if (iconInfo != null) {
            button.setIconFromDrawable(iconInfo.drawable, tintWithTheme = iconInfo.tintWithTheme)
            return true
        }
        val textValue = IconThemeManager.resolveIcon(slot)
        if (textValue != null) {
            button.setText(textValue)
            return true
        }
        return false
    }

    private fun applyConfiguredSystemButton(button: ToolButton, config: ConfigurableButton): Boolean {
        if (!config.text.isNullOrEmpty()) {
            button.setText(config.text)
            return true
        }
        val icon = config.icon ?: return false
        if (icon.startsWith("file:")) {
            val drawable = ButtonIconFile.loadDrawable(icon) ?: return false
            button.setIconFromDrawable(drawable, tintWithTheme = ButtonIconFile.shouldTintIcon(icon))
            return true
        }
        val resId = ctx.resources.getIdentifier(icon, "drawable", ctx.packageName)
        if (resId != 0) {
            button.setIcon(resId)
            return true
        }
        return false
    }

    private fun applySystemButtonConfig(
        button: ToolButton,
        config: ConfigurableButton,
        @DrawableRes defaultIcon: Int,
        slotOverride: String? = null
    ) {
        val fromConfig = applyConfiguredSystemButton(button, config)
        val fromTheme = if (!fromConfig) applyIconThemeToSystemButton(button, slotOverride ?: config.id) else false
        if (!fromConfig && !fromTheme) {
            button.setIcon(defaultIcon)
        }
        if (!config.label.isNullOrEmpty()) {
            button.contentDescription = config.label
        }
    }

    fun reloadSystemButtonIcons() {
        val toolbarIcon = toolbarToggleConfig.icon
        if (toolbarIcon != null && toolbarIcon.startsWith("file:")) {
            updateMenuButtonIcon()
        }
        val hideIcon = hideKeyboardConfig.icon
        if (hideIcon != null && hideIcon.startsWith("file:")) {
            refreshHideKeyboardButtonIcon()
        }
    }

    /** Refresh all toolbar and system button icons (called when icon theme changes). */
    fun refreshAllIcons() {
        // Re-apply icon theme to system buttons
        updateMenuButtonIcon()
        refreshHideKeyboardButtonIcon()
        // Re-resolve every center button's icon from the current icon theme
        buttonsUi.reloadIcons()
    }

    fun updateSystemButtonConfigs(
        newToolbarToggleConfig: ConfigurableButton,
        newHideKeyboardConfig: ConfigurableButton
    ) {
        toolbarToggleConfig = newToolbarToggleConfig
        hideKeyboardConfig = newHideKeyboardConfig
        applySystemButtonConfig(menuButton, toolbarToggleConfig, defaultMenuIcon)
        refreshHideKeyboardButtonIcon()
        updateMenuButtonIcon()
        updateMenuButtonContentDescription()
    }

    private fun updateMenuButtonIcon() {
        when {
            currentState == State.Search || currentState == State.Clipboard ->
                menuButton.setIcon(R.drawable.ic_baseline_arrow_back_24)
            // 符号面板占据键盘时：工具栏整体保持主键盘的样子，只把最左按钮换成返回箭头
            backToKeyboardMode ->
                menuButton.setIcon(R.drawable.ic_baseline_arrow_back_24)
            inPrivate && !hasCustomMenuIcon -> {
                menuButton.setIcon(R.drawable.ic_view_private)
            }
            else -> applySystemButtonConfig(menuButton, toolbarToggleConfig, defaultMenuIcon)
        }
    }

    private fun updateMenuButtonContentDescription() {
        if (backToKeyboardMode) {
            menuButton.contentDescription = ctx.getString(R.string.back_to_keyboard)
            return
        }
        if (!toolbarToggleConfig.label.isNullOrEmpty()) return
        menuButton.contentDescription = when {
            currentState == State.Search || currentState == State.Clipboard -> ctx.getString(R.string.return_to_toolbar)
            inPrivate -> ctx.getString(R.string.private_mode)
            else -> ctx.getString(R.string.status_area)
        }
    }

    /**
     * 进入 / 退出「返回键盘」模式。
     *
     * 符号面板（[PickerWindow]）不是扩展窗口，它借用主键盘那套工具栏；按用户要求，
     * 工具栏内容一概不变，只把最左侧按钮从「状态区」换成返回箭头。点击行为在
     * `KawaiiBarComponent` 里按当前窗口判定。
     */
    fun setBackToKeyboardMode(active: Boolean) {
        if (backToKeyboardMode == active) return
        backToKeyboardMode = active
        updateMenuButtonIcon()
        updateMenuButtonContentDescription()
    }

    private fun updateMenuButtonRotation(instant: Boolean = false) {
        val targetRotation = menuButtonRotation
        menuButton.apply {
            if (targetRotation == iconRotation) return
            iconAnimate().cancel()
            if (!instant && !disableAnimation) {
                iconAnimate().setDuration(200L).rotation(targetRotation)
            } else {
                iconRotation = targetRotation
            }
        }
    }

    private fun refreshHideKeyboardButtonIcon() {
        applySystemButtonConfig(hideKeyboardButton, hideKeyboardConfig, defaultHideKeyboardIcon)
    }

    fun showVoiceStatus(label: String = "Recording") {
        voiceStatusText.text = label
        voiceStatusBar.visibility = View.VISIBLE
        applyCenterVisibility()
        startVoiceWave()
    }

    fun updateVoiceLevel(rms: Int) {
        if (voiceStatusBar.visibility != View.VISIBLE) return
        lastVoiceLevelAt = System.currentTimeMillis()
        val normalized = sqrt((rms / 3500f).coerceIn(0f, 1f))
        updateVoiceBars(normalized)
    }

    private fun updateVoiceBars(normalized: Float) {
        val animated = normalized < 0f
        val active = if (animated) {
            voiceWavePhase = (voiceWavePhase + 1) % voiceBars.size
            voiceBars.size
        } else {
            (normalized * voiceBars.size).roundToInt().coerceIn(1, voiceBars.size)
        }
        voiceBars.forEachIndexed { index, bar ->
            val waveDistance = kotlin.math.abs(index - voiceWavePhase).let {
                minOf(it, voiceBars.size - it)
            }
            val animatedHeight = ctx.dp(5 + (4 - waveDistance.coerceAtMost(4)) * 4)
            val levelHeight = ctx.dp(5 + ((index % 4) + 1) * 4)
            val targetHeight = when {
                animated -> animatedHeight
                index < active -> levelHeight
                else -> ctx.dp(5)
            }
            bar.layoutParams = bar.layoutParams.apply { this.height = targetHeight }
            bar.alpha = when {
                animated -> if (waveDistance <= 3) 0.9f else 0.3f
                index < active -> 0.95f
                else -> 0.25f
            }
        }
    }

    fun hideVoiceStatus() {
        if (voiceStatusBar.visibility == View.GONE) return
        stopVoiceWave()
        voiceStatusBar.visibility = View.GONE
        if (currentState == State.NumberRow) {
            numberRow.keyActionListener = commonKeyActionListener.listener
            numberRow.popupActionListener = popup.listener
        }
        applyCenterVisibility()
    }

    private fun displayContentForState(state: State) {
        when (state) {
            State.Toolbar -> animator.displayedChild = 0
            State.Clipboard -> animator.displayedChild = 1
            State.NumberRow -> {}
            State.InlineSuggestion -> animator.displayedChild = 2
            State.Search -> animator.displayedChild = 3
        }
    }

    /**
     * Single owner of the center strip's contents.
     *
     * The strip shows exactly one of the voice status, the number row, or the page selected by
     * [currentState]. Deriving all three views' visibility in one place keeps every path — voice
     * status, password number row, clipboard/search pages, extended windows — from leaving the
     * strip on a page that draws nothing while the fixed edge buttons stay visible.
     */
    private fun applyCenterVisibility() {
        displayContentForState(currentState)
        if (voiceStatusBar.visibility == View.VISIBLE) {
            animator.visibility = View.GONE
            idleBody.visibility = View.VISIBLE
            numberRow.visibility = View.GONE
            return
        }
        voiceStatusBar.visibility = View.GONE
        animator.visibility = View.VISIBLE
        if (currentState == State.NumberRow) {
            idleBody.visibility = View.GONE
            numberRow.visibility = View.VISIBLE
        } else {
            idleBody.visibility = View.VISIBLE
            numberRow.visibility = View.GONE
        }
    }

    private fun startVoiceWave() {
        voiceStatusBar.removeCallbacks(voiceWaveTicker)
        voiceStatusBar.post(voiceWaveTicker)
    }

    private fun stopVoiceWave() {
        voiceStatusBar.removeCallbacks(voiceWaveTicker)
        lastVoiceLevelAt = 0L
    }

    private fun clearAnimation() {
        animator.inAnimation = null
        animator.outAnimation = null
    }

    private fun setAnimation() {
        animator.inAnimation = inAnimation
        animator.outAnimation = outAnimation
    }

    private fun enableSlideTransition(inTarget: View, outTarget: View, inGravity: Int, outGravity: Int) {
        val slideIn = Slide(inGravity).apply { duration = 200L }
        val slideOut = Slide(outGravity).apply { duration = 200L }
        slideIn.addTarget(inTarget)
        slideOut.addTarget(outTarget)
        val set = TransitionSet().apply {
            ordering = TransitionSet.ORDERING_TOGETHER
            addTransition(slideIn)
            addTransition(slideOut)
        }
        TransitionManager.beginDelayedTransition(root, set)
    }

    fun updateState(state: State, fromUser: Boolean = false) {
        Timber.d("Switch idle ui to $state")
        if (voiceStatusBar.visibility == View.VISIBLE) {
            // The voice status owns the strip while it is visible; applyCenterVisibility()
            // restores the page for this state as soon as the voice status is hidden.
            currentState = state
            applyCenterVisibility()
            updateMenuButtonIcon()
            updateMenuButtonContentDescription()
            updateMenuButtonRotation(instant = !fromUser)
            return
        }
        if (
            !fromUser ||
            disableAnimation ||
            (state == State.InlineSuggestion || currentState == State.InlineSuggestion) ||
            (state == State.NumberRow || currentState == State.NumberRow)
        ) {
            clearAnimation()
        } else {
            setAnimation()
        }
        // Publish the target page before the slide transition is captured, so the transition
        // only animates the number row sliding in/out.
        displayContentForState(state)
        if (state == State.NumberRow) {
            numberRow.keyActionListener = commonKeyActionListener.listener
            numberRow.popupActionListener = popup.listener
            if (fromUser && !disableAnimation) {
                enableSlideTransition(numberRow, idleBody, Gravity.END, Gravity.START)
            }
        } else if (currentState == State.NumberRow) {
            if (fromUser && !disableAnimation) {
                enableSlideTransition(idleBody, numberRow, Gravity.START, Gravity.END)
            }
            numberRow.keyActionListener = null
            numberRow.popupActionListener = null
            popup.dismissAll()
        }
        currentState = state
        applyCenterVisibility()
        updateMenuButtonIcon()
        updateMenuButtonContentDescription()
        updateMenuButtonRotation(instant = !fromUser)
    }
}
