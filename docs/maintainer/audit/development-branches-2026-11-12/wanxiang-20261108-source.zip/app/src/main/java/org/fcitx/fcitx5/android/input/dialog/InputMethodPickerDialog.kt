/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2023 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.input.dialog

import androidx.appcompat.app.AlertDialog
import android.content.Context
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import org.fcitx.fcitx5.android.R
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.fcitx.fcitx5.android.data.prefs.SettingsUiPreferences
import org.fcitx.fcitx5.android.core.FcitxAPI
import org.fcitx.fcitx5.android.input.FcitxInputMethodService
import org.fcitx.fcitx5.android.utils.InputMethodUtil
import splitties.dimensions.dp
import splitties.views.dsl.core.matchParent
import splitties.views.dsl.core.wrapContent
import splitties.views.dsl.recyclerview.recyclerView
import splitties.views.recyclerview.verticalLayoutManager
import splitties.views.topPadding

object InputMethodPickerDialog {
    suspend fun build(
        fcitx: FcitxAPI,
        service: FcitxInputMethodService,
        context: Context
    ): AlertDialog {
        val entries = InputMethodData.resolve(fcitx, service)
        val enabledIM = fcitx.inputMethodEntryCached.uniqueName
        val enabledIndex = entries.indexOfFirst { it.uniqueName == enabledIM }
        val dividerIndex = entries.indexOfFirst { it.ime }
        lateinit var dialog: AlertDialog
        val themed = SettingsUiPreferences.themedContext(context, SettingsUiPreferences.read(context))
        val builder = MaterialAlertDialogBuilder(themed)
        dialog = builder
            .setTitle(R.string.choose_input_method)
            .setView(builder.context.recyclerView {
                layoutParams = ViewGroup.LayoutParams(matchParent, wrapContent)
                // add some padding because AlertDialog's `titleDividerNoCustom` won't show up...
                // but why?
                // https://android.googlesource.com/platform/frameworks/base.git/+/refs/tags/android-11.0.0_r48/core/res/res/layout/alert_dialog_title_material.xml#58
                topPadding = dp(4) // android.R.dimen.dialog_title_divider_material
                setPadding(dp(30), dp(0), dp(30), dp(4))
                layoutManager = verticalLayoutManager()
                adapter = InputMethodListAdapter(entries, enabledIndex) {
                    if (it.ime) {
                        val imeId = it.imeId ?: return@InputMethodListAdapter
                        val subtype = it.subtype
                        if (subtype != null) {
                            InputMethodUtil.switchInputMethod(service, imeId, subtype)
                        } else {
                            service.switchInputMethod(imeId)
                        }
                    } else {
                        service.lifecycleScope.launch { fcitx.activateIme(it.uniqueName) }
                    }
                    dialog.dismiss()
                }
                // Some themes may leave dividerHorizontal unresolved. Resolve it from the
                // dialog's own theme, and let TypedArray return null when no drawable is set.
                val divider = builder.context.obtainStyledAttributes(
                    intArrayOf(android.R.attr.dividerHorizontal)
                ).let { attributes ->
                    try {
                        attributes.getDrawable(0)
                    } finally {
                        attributes.recycle()
                    }
                }
                divider?.let {
                    addItemDecoration(SingleDividerDecoration(it, dividerIndex))
                }
            })
            .create()
        return dialog
    }
}
