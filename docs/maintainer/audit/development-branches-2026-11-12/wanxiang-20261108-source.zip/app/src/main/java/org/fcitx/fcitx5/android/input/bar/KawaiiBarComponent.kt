/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2025 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.input.bar

import android.content.Context
import android.graphics.Color
import android.os.Build
import android.util.Log
import android.util.Size
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InlineSuggestion
import android.view.inputmethod.InlineSuggestionsResponse
import android.view.inputmethod.InputMethodSubtype
import android.widget.FrameLayout
import android.widget.Toast
import android.widget.ViewAnimator
import android.widget.inline.InlineContentView
import androidx.annotation.Keep
import androidx.annotation.RequiresApi
import androidx.lifecycle.lifecycleScope
import java.io.File
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.core.CapabilityFlag
import org.fcitx.fcitx5.android.core.CapabilityFlags
import org.fcitx.fcitx5.android.core.FcitxEvent.CandidateListEvent
import org.fcitx.fcitx5.android.core.InputMethodEntry
import org.fcitx.fcitx5.android.data.clipboard.ClipboardManager
import org.fcitx.fcitx5.android.data.clipboard.ClipboardCategory
import org.fcitx.fcitx5.android.data.clipboard.db.ClipboardEntry
import org.fcitx.fcitx5.android.data.prefs.AppPrefs
import org.fcitx.fcitx5.android.data.prefs.ManagedPreference
import org.fcitx.fcitx5.android.data.theme.ThemeManager
import org.fcitx.fcitx5.android.input.bar.ExpandButtonStateMachine.State.ClickToAttachWindow
import org.fcitx.fcitx5.android.input.bar.ExpandButtonStateMachine.State.ClickToDetachWindow
import org.fcitx.fcitx5.android.input.bar.ExpandButtonStateMachine.State.Hidden
import org.fcitx.fcitx5.android.input.bar.KawaiiBarStateMachine.BooleanKey.CandidateEmpty
import org.fcitx.fcitx5.android.input.bar.KawaiiBarStateMachine.BooleanKey.PreeditEmpty
import org.fcitx.fcitx5.android.input.bar.KawaiiBarStateMachine.TransitionEvent.CandidatesUpdated
import org.fcitx.fcitx5.android.input.bar.KawaiiBarStateMachine.TransitionEvent.ExtendedWindowAttached
import org.fcitx.fcitx5.android.input.bar.KawaiiBarStateMachine.TransitionEvent.PreeditUpdated
import org.fcitx.fcitx5.android.input.action.ButtonAction
import org.fcitx.fcitx5.android.input.action.executeMacroSteps
import org.fcitx.fcitx5.android.input.bar.KawaiiBarStateMachine.TransitionEvent.WindowDetached
import org.fcitx.fcitx5.android.input.bar.ui.CandidateUi
import org.fcitx.fcitx5.android.input.bar.ui.IdleUi
import org.fcitx.fcitx5.android.input.bar.ui.TitleUi
import org.fcitx.fcitx5.android.input.voice.VoiceInputProviderManager
import org.fcitx.fcitx5.android.input.dialog.VoiceInputPickerDialog
import org.fcitx.fcitx5.android.input.config.ButtonIconFile
import org.fcitx.fcitx5.android.input.config.ButtonsLayoutConfig
import org.fcitx.fcitx5.android.input.config.ConfigProviders
import org.fcitx.fcitx5.android.input.config.ConfigurableButton
import org.fcitx.fcitx5.android.input.config.displayedKawaiiBarButtons
import org.fcitx.fcitx5.android.input.bar.ui.ToolButton
import org.fcitx.fcitx5.android.data.theme.IconThemeManager
import org.fcitx.fcitx5.android.input.broadcast.InputBroadcastReceiver
import org.fcitx.fcitx5.android.input.candidates.expanded.ExpandedCandidateStyle
import org.fcitx.fcitx5.android.input.candidates.expanded.window.FlexboxExpandedCandidateWindow
import org.fcitx.fcitx5.android.input.candidates.expanded.window.GridExpandedCandidateWindow
import org.fcitx.fcitx5.android.input.candidates.floating.FloatingCandidatesMode
import org.fcitx.fcitx5.android.input.candidates.horizontal.HorizontalCandidateComponent
import org.fcitx.fcitx5.android.input.clipboard.ClipboardSearchController
import org.fcitx.fcitx5.android.input.clipboard.ClipboardWindow
import org.fcitx.fcitx5.android.input.dependency.UniqueViewComponent
import org.fcitx.fcitx5.android.input.dependency.context
import org.fcitx.fcitx5.android.input.dependency.fcitx
import org.fcitx.fcitx5.android.input.dependency.inputMethodService
import org.fcitx.fcitx5.android.input.dependency.theme
import org.fcitx.fcitx5.android.input.editing.TextEditingWindow
import org.fcitx.fcitx5.android.input.keyboard.CommonKeyActionListener
import org.fcitx.fcitx5.android.input.keyboard.CustomGestureView
import org.fcitx.fcitx5.android.input.keyboard.KeyboardWindow
import org.fcitx.fcitx5.android.input.picker.PickerWindow
import org.fcitx.fcitx5.android.input.popup.PopupComponent
import org.fcitx.fcitx5.android.input.status.StatusAreaWindow
import org.fcitx.fcitx5.android.input.wm.InputWindow
import org.fcitx.fcitx5.android.input.wm.InputWindowManager
import org.fcitx.fcitx5.android.utils.AppUtil
import org.fcitx.fcitx5.android.utils.loadThumbnailBitmap
import org.fcitx.fcitx5.android.core.SubtypeManager
import org.fcitx.fcitx5.android.daemon.launchOnReady
import org.fcitx.fcitx5.android.utils.InputMethodUtil
import org.mechdancer.dependency.DynamicScope
import org.mechdancer.dependency.manager.must
import splitties.bitflags.hasFlag
import splitties.dimensions.dp
import splitties.resources.drawable
import splitties.views.backgroundColor
import splitties.views.dsl.core.add
import splitties.views.dsl.core.lParams
import splitties.views.dsl.core.matchParent
import java.util.concurrent.Executor
import kotlin.coroutines.resume
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.min

private const val VOICE_INPUT_TAG = "FcitxVoiceInput"

class KawaiiBarComponent : UniqueViewComponent<KawaiiBarComponent, FrameLayout>(KawaiiBarComponent::class),
    InputBroadcastReceiver {

    private val context by manager.context()
    private val theme by manager.theme()
    private val service by manager.inputMethodService()
    private val fcitx by manager.fcitx()
    private val windowManager: InputWindowManager by manager.must()
    private val horizontalCandidate: HorizontalCandidateComponent by manager.must()
    private val commonKeyActionListener: CommonKeyActionListener by manager.must()
    private val popup: PopupComponent by manager.must()

    var onFloatingToggleListener: (() -> Unit)? = null

    fun setFloatingState(isFloating: Boolean) {
        idleUi.buttonsUi.setFloatingState(isFloating)
    }

    fun setOneHandKeyboardState(isOneHanded: Boolean) {
        idleUi.buttonsUi.setOneHandKeyboardState(isOneHanded)
    }

    /**
     * 重新应用「工具栏大小」并按新尺寸重排。
     *
     * 三个页面（Idle / Candidate / Title）都要走：它们各自持有按尺寸算好的固定值
     * （按钮边长、候选项字号、标题字号），只 requestLayout 不会把这些值重算。
     * 设置页改完「工具栏大小」和键盘尺寸变化都会走到这里。
     */
    fun refreshButtonsLayout() {
        applyToolbarScaleToPages()
        view.requestLayout()
    }

    /**
     * Macro-simulated key events can move focus out of touch mode. Clear any
     * stale focus from toolbar descendants before Android renders a focus highlight.
     */
    fun clearFocusState() {
        view.clearFocus()
        idleUi.root.clearFocus()
        idleUi.buttonsUi.root.clearFocus()
    }

    private val prefs = AppPrefs.getInstance()

    private val clipboardSuggestion = prefs.clipboard.clipboardSuggestion
    private val clipboardItemTimeout = prefs.clipboard.clipboardItemTimeout
    private val clipboardMaskSensitive by prefs.clipboard.clipboardMaskSensitive
    private val expandedCandidateStyle by prefs.keyboard.expandedCandidateStyle
    private val toolbarNumRowOnPassword by prefs.keyboard.toolbarNumRowOnPassword
    private val showVoiceInputButton by prefs.keyboard.showVoiceInputButton
    private val preferredVoiceInput by prefs.keyboard.preferredVoiceInput

    private var clipboardTimeoutJob: Job? = null

    private var isClipboardFresh: Boolean = false
    private var isInlineSuggestionPresent: Boolean = false
    private var isPasswordField: Boolean = false
    private var isKeyboardLayoutNumber: Boolean = false

    private enum class NumberRowState { Auto, ForceShow, ForceHide }

    private var numberRowState = NumberRowState.Auto

    @Keep
    private val onClipboardUpdateListener =
        ClipboardManager.OnClipboardUpdateListener {
            if (!clipboardSuggestion.getValue()) return@OnClipboardUpdateListener
            service.lifecycleScope.launch {
                if (it.text.isEmpty()) {
                    isClipboardFresh = false
                } else {
                    val isImage = it.type.startsWith("image/")
                    if (isImage) {
                        idleUi.clipboardUi.text.visibility = View.GONE
                        idleUi.clipboardUi.preview.visibility = View.VISIBLE
                        val bitmap = it.loadThumbnailBitmap(context)
                        if (bitmap != null) {
                            idleUi.clipboardUi.preview.setImageBitmap(bitmap)
                        } else {
                            context.drawable(R.drawable.ic_baseline_image_24)?.apply {
                                setTint(theme.altKeyTextColor)
                            }?.let {
                                idleUi.clipboardUi.preview.setImageDrawable(it)
                            }
                        }
                    } else {
                        idleUi.clipboardUi.preview.visibility = View.GONE
                        idleUi.clipboardUi.text.visibility = View.VISIBLE
                        idleUi.clipboardUi.text.text = if (it.sensitive && clipboardMaskSensitive) {
                            ClipboardEntry.BULLET.repeat(min(42, it.text.length))
                        } else {
                            it.text.take(42)
                        }
                    }
                    isClipboardFresh = true
                    launchClipboardTimeoutJob()
                }
                evalIdleUiState()
            }
        }

    @Keep
    private val onClipboardSuggestionUpdateListener =
        ManagedPreference.OnChangeListener<Boolean> { _, it ->
            if (!it) {
                isClipboardFresh = false
                evalIdleUiState()
                clipboardTimeoutJob?.cancel()
                clipboardTimeoutJob = null
            }
        }

    @Keep
    private val onClipboardTimeoutUpdateListener =
        ManagedPreference.OnChangeListener<Int> { _, _ ->
            when (idleUi.currentState) {
                IdleUi.State.Clipboard -> {
                    // renew timeout when clipboard suggestion is present
                    launchClipboardTimeoutJob()
                }
                else -> {}
            }
        }

    @Keep
    private val onIconThemeChangeListener =
        IconThemeManager.OnIconThemeChangeListener { _idleUi?.refreshAllIcons() }

    private fun launchClipboardTimeoutJob() {
        clipboardTimeoutJob?.cancel()
        val timeout = clipboardItemTimeout.getValue() * 1000L
        // never transition to ClipboardTimedOut state when timeout is disabled (<= 0)
        if (timeout <= 0L) return
        clipboardTimeoutJob = service.lifecycleScope.launch {
            delay(timeout)
            isClipboardFresh = false
            clipboardTimeoutJob = null
            evalIdleUiState()
        }
    }

    private fun evalIdleUiState(fromUser: Boolean = false) {
        val passwordMode = resolvePasswordToolbarMode(
            isPasswordField = isPasswordField,
            showNumberRow = toolbarNumRowOnPassword,
            isNumberLayout = isKeyboardLayoutNumber,
            numberRowDismissed = numberRowState == NumberRowState.ForceHide
        )
        val content = resolveIdleToolbarContent(
            searchActive = ClipboardSearchController.isActive,
            clipboardFresh = isClipboardFresh,
            inlineSuggestionPresent = isInlineSuggestionPresent,
            forceNumberRow = numberRowState == NumberRowState.ForceShow &&
                isPasswordField && toolbarNumRowOnPassword && !isKeyboardLayoutNumber,
            passwordMode = passwordMode
        )
        val newState = when (content) {
            IdleToolbarContent.Search -> IdleUi.State.Search
            IdleToolbarContent.Clipboard -> IdleUi.State.Clipboard
            IdleToolbarContent.InlineSuggestion -> IdleUi.State.InlineSuggestion
            IdleToolbarContent.NumberRow -> IdleUi.State.NumberRow
            IdleToolbarContent.Toolbar -> IdleUi.State.Toolbar
        }
        if (newState == idleUi.currentState) return
        idleUi.updateState(newState, fromUser)
    }

    /** 剪贴板搜索状态变化时调用：刷新工具栏状态并同步搜索框文本。 */
    fun onClipboardSearchChanged() {
        evalIdleUiState()
        idleUi.updateSearchQuery(
            ClipboardSearchController.committedText,
            ClipboardSearchController.preeditText
        )
    }

    private fun hideKeyboardAndExitAdjustingMode() {
        service.inputView?.exitAdjustingMode()
        service.requestHideSelf(0)
    }

    private val hideKeyboardCallback = View.OnClickListener {
        hideKeyboardAndExitAdjustingMode()
    }

    private val swipeDownExpandCallback = CustomGestureView.OnGestureListener { _, e ->
        if (e.type == CustomGestureView.GestureType.Up && e.totalY > 0) {
            hideKeyboardAndExitAdjustingMode()
            true
        } else false
    }

    // Combined gesture: determine primary direction by comparing totalX and totalY.
    // - If horizontal is dominant and left, show number row (when allowed).
    // - If vertical is dominant and down, hide keyboard.
    private val swipeHideKeyboardCallback = CustomGestureView.OnGestureListener { v, e ->
        require(v is ToolButton)
        val numberRowAvailable = isPasswordField && toolbarNumRowOnPassword && !isKeyboardLayoutNumber
        if (numberRowAvailable) {
            val dir = if (context.resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_LTR) 1 else -1
            // `e.x` and `e.y` are relative to the view's top-left corner
            val centerX = e.x - v.width / 2f
            val centerY = e.y - v.height / 2f

            val distance = hypot(centerX, centerY)
            // the button is ↓, so apply -90 degrees offset
            var angle = atan2(-centerX, centerY) * (180f / PI.toFloat())

            when (e.type) {
                CustomGestureView.GestureType.Move -> {
                    angle = if (angle in -45f..45f) {
                        angle.coerceIn(-10f, 10f)
                    } else abs(angle).coerceIn(90f - 10f, 90f + 10f) * dir
                    v.iconRotation = angle
                }
                CustomGestureView.GestureType.Up -> {
                    val handled = when (angle) {
                        in -45f..45f if distance > v.swipeThresholdY -> {
                            hideKeyboardAndExitAdjustingMode()
                            true
                        }
                        !in -45f..45f if distance > v.swipeThresholdX -> {
                            v.iconRotation = 90f * dir
                            numberRowState = NumberRowState.ForceShow
                            evalIdleUiState(fromUser = true)
                            true
                        }
                        else -> false
                    }
                    v.iconRotation = 0f
                    return@OnGestureListener handled
                }
                else -> {}
            }
        }

        if (e.type == CustomGestureView.GestureType.Up && abs(e.totalY) > abs(e.totalX) && e.totalY > 0) {
            hideKeyboardAndExitAdjustingMode()
            true
        } else false
    }

    private var voiceInputSubtype: Pair<String, InputMethodSubtype>? = null

    private val switchToVoiceInputCallback = View.OnClickListener {
        Log.i(
            VOICE_INPUT_TAG,
            "toolbar voice click preferred=$preferredVoiceInput " +
                "isProvider=${VoiceInputProviderManager.isProviderId(preferredVoiceInput)} " +
                "subtype=${voiceInputSubtype != null}"
        )
        if (VoiceInputProviderManager.isProviderId(preferredVoiceInput)) {
            if (VoiceInputProviderManager.isActive()) {
                idleUi.showVoiceStatus(service.getString(R.string.voice_status_recognizing))
            }
            VoiceInputProviderManager.toggle(
                service = service,
                id = preferredVoiceInput,
                onReady = { idleUi.showVoiceStatus(service.getString(R.string.voice_status_listening)) },
                onPartialResult = { /* recognized text goes to the input field, not the bar */ },
                onLevel = { rms -> idleUi.updateVoiceLevel(rms) },
                onStatus = { status -> idleUi.showVoiceStatus(status) },
                onFinished = { idleUi.hideVoiceStatus() },
                onError = { msg ->
                    idleUi.hideVoiceStatus()
                    Toast.makeText(service, msg, Toast.LENGTH_SHORT).show()
                },
            )
            return@OnClickListener
        }
        val (id, subtype) = voiceInputSubtype ?: run {
            showVoiceInputPicker()
            return@OnClickListener
        }
        InputMethodUtil.switchInputMethod(service, id, subtype)
    }

    private fun showVoiceInputPicker() {
        if (isPasswordField) return
        service.showDialog(VoiceInputPickerDialog.build(context) { _ ->
            if (VoiceInputProviderManager.isActive()) {
                VoiceInputProviderManager.stop(service)
                service.clearVoiceComposingText()
                idleUi.hideVoiceStatus()
            }
            refreshVoiceInputButton()
        })
    }

    internal fun onVoiceInputButtonAction() {
        switchToVoiceInputCallback.onClick(idleUi.buttonsUi.getButton("voice_input"))
    }

    internal fun onVoiceInputButtonLongPress() {
        showVoiceInputPicker()
    }

    // Load buttons config from file or use default. The Status Area is opened by IdleUi's
    // fixed left-side control, so legacy "more" entries are excluded from the button row.
    private fun loadButtonsConfig(): Triple<List<ConfigurableButton>, ConfigurableButton, ConfigurableButton> {
        val snapshot = ConfigProviders.readButtonsLayoutConfig<ButtonsLayoutConfig>()
        val config = snapshot?.value ?: ButtonsLayoutConfig.default()
        val configuredButtons = config.displayedKawaiiBarButtons()
        val buttonsWithoutPasswordVoice = if (isPasswordField) {
            configuredButtons.filterNot { it.id == "voice_input" }
        } else {
            configuredButtons
        }
        val buttons = if (
            showVoiceInputButton && !isPasswordField &&
            buttonsWithoutPasswordVoice.none { it.id == "voice_input" }
        ) {
            buttonsWithoutPasswordVoice + ConfigurableButton("voice_input")
        } else {
            buttonsWithoutPasswordVoice
        }

        // Update watched icon filenames for hot-reload
        val allButtons = buttons + listOf(config.toolbarToggleButton, config.hideKeyboardButton)
        val iconFileNames = allButtons
            .mapNotNull { it.icon }
            .filter { it.startsWith(ButtonIconFile.PREFIX) }
            .map { it.removePrefix(ButtonIconFile.PREFIX).substringAfterLast('/') }
            .toSet()
        ConfigProviders.setWatchedIconFileNames(iconFileNames)

        return Triple(buttons, config.toolbarToggleButton, config.hideKeyboardButton)
    }

    private var _idleUi: IdleUi? = null
    private var currentButtonsConfig: List<ConfigurableButton> = emptyList()
    private var currentToolbarToggleConfig: ConfigurableButton = ConfigurableButton("toolbar_toggle")
    private var currentHideKeyboardConfig: ConfigurableButton = ConfigurableButton("hide_keyboard")
    
    private val idleUi: IdleUi
        get() {
            if (_idleUi == null) {
                val (buttons, toolbarToggle, hideKeyboard) = loadButtonsConfig()
                currentButtonsConfig = buttons
                currentToolbarToggleConfig = toolbarToggle
                currentHideKeyboardConfig = hideKeyboard
                _idleUi = IdleUi(context, theme, popup, commonKeyActionListener, currentButtonsConfig,
                    currentToolbarToggleConfig, currentHideKeyboardConfig)
                setupIdleUiCallbacks(_idleUi!!)
            }
            return _idleUi!!
        }

    private fun setupIdleUiCallbacks(ui: IdleUi) {
        fun restoreVirtualKeyboardMode() {
            service.restoreVirtualKeyboardForKawaiiBarAction()
        }

        ui.menuButton.setOnClickListener {
            restoreVirtualKeyboardMode()
            // 符号面板显示时，最左侧按钮已换成返回箭头，点击即回到文字键盘。
            if (windowManager.currentWindowOrNull() is PickerWindow) {
                windowManager.attachWindow(KeyboardWindow)
                return@setOnClickListener
            }
            // 剪贴板历史搜索期间，最左侧返回箭头即搜索关闭按钮。
            if (idleUi.currentState == IdleUi.State.Search) {
                service.stopClipboardSearch()
                // 会话可能已经结束（如输入目标切换触发的自动结束）而没有刷新到工具栏，
                // 这里按当前会话状态兜底重算一次，保证返回箭头一定退出搜索页。
                evalIdleUiState()
                return@setOnClickListener
            }
            // When the clipboard hint is showing, the leftmost button dismisses it
            // instead of opening the status area.
            if (idleUi.currentState == IdleUi.State.Clipboard) {
                clipboardTimeoutJob?.cancel()
                clipboardTimeoutJob = null
                isClipboardFresh = false
                evalIdleUiState(fromUser = true)
                return@setOnClickListener
            }
            windowManager.attachWindow(StatusAreaWindow())
        }
        ui.hideKeyboardButton.apply {
            setOnClickListener {
                restoreVirtualKeyboardMode()
                hideKeyboardCallback.onClick(it)
            }
            swipeEnabled = true
            swipeThresholdY = dp(resolveHeightDp().toFloat())
            onGestureListener = swipeHideKeyboardCallback
        }
        ui.voiceInputFinishButton.setOnClickListener {
            if (VoiceInputProviderManager.isActive()) {
                ui.showVoiceStatus(service.getString(R.string.voice_status_recognizing))
                VoiceInputProviderManager.finish(service)
            } else {
                ui.hideVoiceStatus()
            }
        }
        ui.buttonsUi.apply {
            // Setup click listeners using ButtonAction
            ButtonAction.allConfigurableActions.forEach { action ->
                setOnClickListener(action.id, defaultActionClickListener(action))
            }

            setOnLongClickListener("ai_assistant") {
                org.fcitx.fcitx5.android.input.voice.js.JsApps.configure(service)
                true
            }
            setOnLongClickListener("voice_input") {
                restoreVirtualKeyboardMode()
                ButtonAction.fromId("voice_input")?.onLongPress(
                    context = context,
                    service = service,
                    fcitx = fcitx,
                    windowManager = windowManager,
                    view = it
                )
                true
            }
            
            setOnLongClickListener("theme_toggle") {
                restoreVirtualKeyboardMode()
                ButtonAction.fromId("theme_toggle")?.onLongPress(
                    context = context,
                    service = service,
                    fcitx = fcitx,
                    windowManager = windowManager,
                    view = ui.buttonsUi.root
                )
                true
            }

            setOnClickListener("floating_toggle") {
                restoreVirtualKeyboardMode()
                val action = ButtonAction.fromId("floating_toggle")
                if (onFloatingToggleListener != null) {
                    onFloatingToggleListener?.invoke()
                    updateButtonsState()
                } else {
                    action?.execute(
                        context = context,
                        service = service,
                        fcitx = fcitx,
                        windowManager = windowManager,
                        view = null,
                        onActionComplete = { updateButtonsState() }
                    )
                }
            }

            setOnLongClickListener("floating_toggle") {
                restoreVirtualKeyboardMode()
                ButtonAction.fromId("floating_toggle")?.onLongPress(
                    context = context,
                    service = service,
                    fcitx = fcitx,
                    windowManager = windowManager,
                    view = ui.buttonsUi.root
                )
                true
            }

            // Keep language switch long-press behavior aligned with keyboard globe key.
            setOnLongClickListener("language_switch") {
                restoreVirtualKeyboardMode()
                ButtonAction.fromId("language_switch")?.onLongPress(
                    context = context,
                    service = service,
                    fcitx = fcitx,
                    windowManager = windowManager,
                    view = ui.buttonsUi.root
                )
                true
            }

            // Setup click listeners for custom action buttons
            setupCustomActionListeners(ui)
        }
        ui.numberRow.onCollapseListener = {
            numberRowState = NumberRowState.ForceHide
            evalIdleUiState(fromUser = true)
        }
        ui.clipboardUi.suggestionView.apply {
            setOnClickListener {
                ClipboardManager.lastEntry?.let {
                    if (it.isUriEntry()) {
                        windowManager.attachWindow(ClipboardWindow(ClipboardCategory.Media))
                    } else {
                        service.commitText(it.text)
                    }
                }
                clipboardTimeoutJob?.cancel()
                clipboardTimeoutJob = null
                isClipboardFresh = false
                evalIdleUiState()
            }
            setOnLongClickListener {
                ClipboardManager.lastEntry?.let {
                    org.fcitx.fcitx5.android.input.clipboard.ClipboardEditor.open(service, it.id)
                }
                true
            }
        }
    }

    // Reload Kawaii Bar buttons config (called when config file changes)
    fun reloadButtonsConfig() {
        val (newButtons, newToolbarToggle, newHideKeyboard) = loadButtonsConfig()
        val buttonsChanged = newButtons != currentButtonsConfig
        val systemButtonsChanged = newToolbarToggle != currentToolbarToggleConfig ||
            newHideKeyboard != currentHideKeyboardConfig
        if (buttonsChanged || systemButtonsChanged) {
            cleanupOrphanedIconFiles(
                currentButtonsConfig, newButtons,
                currentToolbarToggleConfig, newToolbarToggle,
                currentHideKeyboardConfig, newHideKeyboard
            )
        }
        if (buttonsChanged) {
            currentButtonsConfig = newButtons
            _idleUi?.buttonsUi?.updateConfig(newButtons)
            _idleUi?.let { setupCustomActionListeners(it) }
            updateButtonsState()
        }
        if (systemButtonsChanged) {
            currentToolbarToggleConfig = newToolbarToggle
            currentHideKeyboardConfig = newHideKeyboard
            _idleUi?.updateSystemButtonConfigs(newToolbarToggle, newHideKeyboard)
        }
    }

    // Reload button icons from disk (called when icon files change on disk)
    fun reloadButtonIcons() {
        _idleUi?.buttonsUi?.reloadIcons()
        _idleUi?.reloadSystemButtonIcons()
    }

    private fun extractIconFileNames(buttons: List<ConfigurableButton>): Set<String> {
        return buttons
            .mapNotNull { it.icon }
            .filter { it.startsWith(ButtonIconFile.PREFIX) }
            .map { it.removePrefix(ButtonIconFile.PREFIX).substringAfterLast('/') }
            .toSet()
    }

    private fun getAllReferencedIconFileNames(): Set<String> {
        val snapshot = ConfigProviders.readButtonsLayoutConfig<ButtonsLayoutConfig>()
        if (snapshot == null) return emptySet()
        val config = snapshot.value
        val allButtons = config.displayedKawaiiBarButtons() + config.statusAreaButtons +
            listOf(config.toolbarToggleButton, config.hideKeyboardButton)
        return extractIconFileNames(allButtons)
    }

    private fun cleanupOrphanedIconFiles(
        oldKawaiiButtons: List<ConfigurableButton>,
        newKawaiiButtons: List<ConfigurableButton>,
        oldToolbarToggle: ConfigurableButton = ConfigurableButton("toolbar_toggle"),
        newToolbarToggle: ConfigurableButton = ConfigurableButton("toolbar_toggle"),
        oldHideKeyboard: ConfigurableButton = ConfigurableButton("hide_keyboard"),
        newHideKeyboard: ConfigurableButton = ConfigurableButton("hide_keyboard")
    ) {
        val oldIcons = extractIconFileNames(oldKawaiiButtons) +
            extractIconFileNames(listOf(oldToolbarToggle, oldHideKeyboard))
        val newLocalIcons = extractIconFileNames(newKawaiiButtons) +
            extractIconFileNames(listOf(newToolbarToggle, newHideKeyboard))
        // Icons that were in the old config but not in the new local config
        val removed = oldIcons - newLocalIcons
        if (removed.isEmpty()) return
        // But don't delete if still referenced by any button in the full config
        val allNewIcons = getAllReferencedIconFileNames()
        val orphaned = removed - allNewIcons
        if (orphaned.isEmpty()) return
        val extDir = context.getExternalFilesDir(null) ?: return
        val iconDir = File(extDir, ButtonIconFile.DIR)
        orphaned.forEach { filename ->
            val file = File(iconDir, filename)
            if (file.exists() && file.isFile) {
                try { file.delete() } catch (_: Exception) { }
            }
        }
    }

    /**
     * Click listener that runs [action]'s built-in behavior.
     *
     * Extracted so [setupCustomActionListeners] can restore it on a button whose macro was
     * removed.
     */
    private fun defaultActionClickListener(action: ButtonAction) = View.OnClickListener {
        service.restoreVirtualKeyboardForKawaiiBarAction()
        action.execute(
            context = context,
            service = service,
            fcitx = fcitx,
            windowManager = windowManager,
            view = null,
            onActionComplete = {
                // Refresh UI state after action completion
                when (action.id) {
                    "floating_toggle" -> evalIdleUiState()
                    "one_handed_keyboard", "theme_toggle" -> updateButtonsState()
                }
            }
        )
    }

    /**
     * Bind every configured button to either its macro or its default action.
     *
     * Iterating only the buttons that *have* macros was not enough: on reload the listener
     * installed for a macro that has since been deleted stayed in place, so the button kept
     * running the old macro (and a button converted from macro back to a built-in action did
     * nothing at all). Rebinding every button makes the config the single source of truth.
     */
    private fun setupCustomActionListeners(ui: IdleUi) {
        fun restoreVirtualKeyboardMode() {
            service.restoreVirtualKeyboardForKawaiiBarAction()
        }
        currentButtonsConfig.forEach { button ->
            val steps = button.macroSteps?.takeIf { it.isNotEmpty() }
            if (steps != null) {
                ui.buttonsUi.setOnClickListener(button.id) {
                    restoreVirtualKeyboardMode()
                    executeMacroSteps(steps, service, context)
                }
            } else {
                // Restore the built-in behavior, or clear the listener entirely for an id with
                // no known action (a leftover custom_N button whose macro was deleted).
                ui.buttonsUi.setOnClickListener(
                    button.id,
                    ButtonAction.fromId(button.id)?.let { defaultActionClickListener(it) }
                )
            }
        }
    }

    private val candidateUi by lazy {
        CandidateUi(context, theme, horizontalCandidate.view).apply {
            applyToolbarScale()
            expandButton.apply {
                swipeEnabled = true
                swipeThresholdY = dp(resolveHeightDp().toFloat())
                onGestureListener = swipeDownExpandCallback
            }
        }
    }

    private val titleUi by lazy {
        TitleUi(context, theme)
    }

    private val barStateMachine = KawaiiBarStateMachine.new {
        switchUiByState(it)
    }

    val expandButtonStateMachine = ExpandButtonStateMachine.new {
        when (it) {
            ClickToAttachWindow -> {
                setExpandButtonToAttach()
                setExpandButtonEnabled(true)
            }
            ClickToDetachWindow -> {
                setExpandButtonToDetach()
                setExpandButtonEnabled(true)
            }
            Hidden -> {
                setExpandButtonEnabled(false)
            }
        }
    }

    // set expand candidate button to create expand candidate
    private fun setExpandButtonToAttach() {
        candidateUi.expandButton.setOnClickListener {
            service.restoreVirtualKeyboardForKawaiiBarAction()
            windowManager.attachWindow(
                when (expandedCandidateStyle) {
                    ExpandedCandidateStyle.Grid -> GridExpandedCandidateWindow()
                    ExpandedCandidateStyle.Flexbox -> FlexboxExpandedCandidateWindow()
                }
            )
        }
        candidateUi.expandButton.setIcon(R.drawable.ic_baseline_expand_more_24)
        candidateUi.expandButton.contentDescription = context.getString(R.string.expand_candidates_list)
    }

    // set expand candidate button to close expand candidate
    private fun setExpandButtonToDetach() {
        candidateUi.expandButton.setOnClickListener {
            service.restoreVirtualKeyboardForKawaiiBarAction()
            windowManager.attachWindow(KeyboardWindow)
        }
        candidateUi.expandButton.setIcon(R.drawable.ic_baseline_expand_less_24)
        candidateUi.expandButton.contentDescription = context.getString(R.string.hide_candidates_list)
    }

    // should be used with setExpandButtonToAttach or setExpandButtonToDetach
    private fun setExpandButtonEnabled(enabled: Boolean) {
        candidateUi.expandButton.visibility = if (enabled) View.VISIBLE else View.INVISIBLE
    }

    private fun switchUiByState(state: KawaiiBarStateMachine.State) {
        val index = state.ordinal
        if (view.displayedChild == index) return
        if (
            view.displayedChild == KawaiiBarStateMachine.State.Idle.ordinal &&
            state == KawaiiBarStateMachine.State.Title
        ) {
            // An extended window replaces IdleUi immediately. End its unbounded button
            // ripples before the title bar is drawn in the same region.
            idleUi.clearTransientPressState()
        }
        val new = view.getChildAt(index)
        if (new != titleUi.root) {
            titleUi.setReturnButtonOnClickListener { }
            titleUi.setTitle("")
            titleUi.removeExtension()
        }
        view.displayedChild = index
    }

    override val view by lazy {
        ViewAnimator(context).apply {
            isFocusable = false
            isFocusableInTouchMode = false
            descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
            backgroundColor =
                if (ThemeManager.prefs.keyBorder.getValue()) Color.TRANSPARENT
                else theme.barColor
            add(idleUi.root, lParams(matchParent, matchParent))
            add(candidateUi.root, lParams(matchParent, matchParent))
            add(titleUi.root, lParams(matchParent, matchParent))
            // 三个页面各自持有按尺寸算好的固定值，构建完成后按当前偏好统一重放一次，
            // 保证「工具栏大小」在第一次显示时就生效（而不是等设置页动过才生效）。
            //
            // 这里**不能**调 [refreshButtonsLayout]：它内部会读 `view`，而 `view` 的 lazy
            // 初始化此刻还没返回（同一线程可重入），会无限递归。直接操作用 `this`。
            applyToolbarScaleToPages()
            requestLayout()
        }
    }

    /** 让三个页面各自重放一次「工具栏大小」缩放（不触碰 [view] 本身）。 */
    private fun applyToolbarScaleToPages() {
        idleUi.applyToolbarScale()
        candidateUi.applyToolbarScale()
        titleUi.applyToolbarScale()
        // 展开候选列表 / 下滑隐藏键盘的手势阈值都按栏高算，跟着一起更新。
        val height = resolveHeightPx(context).toFloat()
        candidateUi.expandButton.swipeThresholdY = height
        idleUi.hideKeyboardButton.swipeThresholdY = height
    }

    override fun onScopeSetupFinished(scope: DynamicScope) {
        ClipboardManager.lastEntry?.let {
            val now = System.currentTimeMillis()
            val clipboardTimeout = clipboardItemTimeout.getValue() * 1000L
            if (now - it.timestamp < clipboardTimeout) {
                onClipboardUpdateListener.onUpdate(it)
            }
        }
        ClipboardManager.addOnUpdateListener(onClipboardUpdateListener)
        clipboardSuggestion.registerOnChangeListener(onClipboardSuggestionUpdateListener)
        clipboardItemTimeout.registerOnChangeListener(onClipboardTimeoutUpdateListener)
        // Installed under this component's identity so teardown can release exactly these
        // callbacks (see VoiceInputProviderManager.releaseUiCallbacks). They capture idleUi
        // and the service, so leaving them installed after detach pinned the whole InputView
        // tree and made the *new* keyboard show no voice feedback at all.
        VoiceInputProviderManager.setUiCallbacks(
            owner = this,
            floatingCommit = { text ->
                Log.i(VOICE_INPUT_TAG, "floating commit reflected in kawaii bar len=${text.length}")
                idleUi.showVoiceStatus(service.getString(R.string.voice_status_committed))
                idleUi.hideVoiceStatus()
            },
            // Shared callbacks for both kawaii bar button and space long-press.
            status = { s -> idleUi.showVoiceStatus(s) },
            ready = { idleUi.showVoiceStatus(service.getString(R.string.voice_status_listening)) },
            level = { rms -> idleUi.updateVoiceLevel(rms) },
            finished = { idleUi.hideVoiceStatus() },
            error = { msg ->
                idleUi.hideVoiceStatus()
                android.widget.Toast.makeText(service, msg, android.widget.Toast.LENGTH_SHORT).show()
            },
            // Keep the keyboard on the layout the user was looking at across a voice session.
            sessionStarted = { service.inputView?.onVoiceInputStarted() },
            sessionEnded = { service.inputView?.onVoiceInputFinished() }
        )
        IconThemeManager.addOnChangedListener(onIconThemeChangeListener)
    }

    /**
     * Release everything [onScopeSetupFinished] registered on process-scoped singletons.
     *
     * Called from [InputView.onDetachedFromWindow]. Without it the voice callbacks, the
     * clipboard listener and the icon-theme listener all kept this component (and therefore
     * the entire InputView tree and the IMS) alive for the life of the process, once per
     * recreation.
     */
    fun onScopeTeardown() {
        VoiceInputProviderManager.releaseUiCallbacks(this)
        ClipboardManager.removeOnUpdateListener(onClipboardUpdateListener)
        clipboardSuggestion.unregisterOnChangeListener(onClipboardSuggestionUpdateListener)
        clipboardItemTimeout.unregisterOnChangeListener(onClipboardTimeoutUpdateListener)
        IconThemeManager.removeOnChangedListener(onIconThemeChangeListener)
    }

    override fun onStartInput(info: EditorInfo, capFlags: CapabilityFlags, restarting: Boolean) {
        // 输入目标变化同时意味着搜索上下文丢失：非重启时结束搜索，避免按键继续被搜索吞掉。
        if (!restarting && ClipboardSearchController.isActive) {
            service.stopClipboardSearch()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            idleUi.privateMode(info.imeOptions.hasFlag(EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING))
        }
        isPasswordField = capFlags.has(CapabilityFlag.Password)
        isInlineSuggestionPresent = false
        numberRowState = NumberRowState.Auto
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            idleUi.inlineSuggestionsBar.clear()
        }
        refreshVoiceInputButton()
        evalIdleUiState()
    }

    override fun onImeUpdate(ime: InputMethodEntry) {
        refreshVoiceInputButton()
    }

    private fun refreshVoiceInputButton() {
        voiceInputSubtype = InputMethodUtil.findVoiceSubtype(preferredVoiceInput)
        reloadButtonsConfig()
    }

    override fun onPreeditEmptyStateUpdate(empty: Boolean) {
        barStateMachine.push(PreeditUpdated, PreeditEmpty to empty)
    }

    override fun onCandidateUpdate(data: CandidateListEvent.Data) {
        // When using "Always" floating mode, don't show candidates in Kawaii Bar
        val floatingMode = AppPrefs.getInstance().candidates.mode.getValue()
        val useFloatingAlways =
            floatingMode == FloatingCandidatesMode.Always && !service.inputDeviceManager.isPhysicalCandidateBarMode

        if (useFloatingAlways) {
            // Force stay in Idle state when using floating candidates
            barStateMachine.push(CandidatesUpdated, CandidateEmpty to true)
        } else {
            barStateMachine.push(CandidatesUpdated, CandidateEmpty to data.candidates.isEmpty())
        }
    }

    override fun onWindowAttached(window: InputWindow) {
        // 符号面板借用主键盘那一套工具栏：整条栏的形态与按钮都不变，只把最左侧按钮
        // 换成「返回键盘」箭头（见 IdleUi.setBackToKeyboardMode）。
        //
        // 这里在 when 之前统一设置：窗口切换的次序是「先 detach 旧、再 attach 新」，
        // 因此本行执行后该状态一定是最新的，面板之间互切也不会闪回。
        idleUi.setBackToKeyboardMode(window is PickerWindow)
        when (window) {
            is InputWindow.ExtendedInputWindow<*> -> {
                titleUi.setTitle(window.title)
                window.onCreateBarExtension()?.let { titleUi.addExtension(it, window.showTitle) }
                titleUi.setReturnButtonOnClickListener {
                    windowManager.attachWindow(KeyboardWindow)
                }
                barStateMachine.push(ExtendedWindowAttached)
            }
            else -> {}
        }
        service.inputView?.requestBlurRefresh()
    }

    override fun onWindowDetached(window: InputWindow) {
        barStateMachine.push(WindowDetached)
        service.inputView?.requestBlurRefresh()
    }

    private val suggestionSize by lazy {
        Size(ViewGroup.LayoutParams.WRAP_CONTENT, resolveHeightPx(context))
    }

    private val directExecutor by lazy {
        Executor { it.run() }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    fun handleInlineSuggestions(response: InlineSuggestionsResponse): Boolean {
        val suggestions = response.inlineSuggestions
        if (suggestions.isEmpty()) {
            isInlineSuggestionPresent = false
            evalIdleUiState()
            idleUi.inlineSuggestionsBar.clear()
            return true
        }
        var pinned: InlineSuggestion? = null
        val scrollable = mutableListOf<InlineSuggestion>()
        var extraPinnedCount = 0
        suggestions.forEach {
            if (it.info.isPinned) {
                if (pinned == null) {
                    pinned = it
                } else {
                    scrollable.add(extraPinnedCount++, it)
                }
            } else {
                scrollable.add(it)
            }
        }
        service.lifecycleScope.launch {
            idleUi.inlineSuggestionsBar.setPinnedView(
                pinned?.let { inflateInlineContentView(it) }
            )
        }
        service.lifecycleScope.launch {
            val views = scrollable.map { s ->
                service.lifecycleScope.async {
                    inflateInlineContentView(s)
                }
            }.awaitAll()
            idleUi.inlineSuggestionsBar.setScrollableViews(views)
        }
        isInlineSuggestionPresent = true
        evalIdleUiState()
        return true
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private suspend fun inflateInlineContentView(suggestion: InlineSuggestion): InlineContentView? {
        return suspendCancellableCoroutine { c ->
            // callback view might be null
            suggestion.inflate(context, suggestionSize, directExecutor) { v ->
                c.resume(v)
            }
        }
    }

    companion object {
        /**
         * 工具栏的**基准**（100%）高度，即历史上写死的 40dp。
         *
         * 实际高度由「工具栏大小」偏好决定，必须用 [resolveHeightPx] / [resolveScale] 取，
         * 不要再直接把本常量当布局尺寸用——那样「工具栏大小」设置会失效。
         */
        const val HEIGHT = ToolbarMetrics.BASE_HEIGHT_DP

        /** 「工具栏大小」百分比（80..200）。 */
        fun toolbarHeightPercent(): Int =
            AppPrefs.getInstance().keyboard.toolbarHeightPercent.getValue()

        /** 当前工具栏缩放系数（0.8f..2.0f）。 */
        fun resolveScale(): Float = ToolbarMetrics.scale(toolbarHeightPercent())

        /** 按「工具栏大小」换算出的实际工具栏高度（dp）。 */
        fun resolveHeightDp(): Int = ToolbarMetrics.heightDp(toolbarHeightPercent())

        /** 按「工具栏大小」换算出的实际工具栏高度（像素）。 */
        fun resolveHeightPx(context: Context): Int = context.dp(resolveHeightDp())
    }

    private fun updateButtonsState() {
        _idleUi?.buttonsUi?.updateButtonsState(service)
    }

    fun onKeyboardLayoutSwitched(isNumber: Boolean) {
        isKeyboardLayoutNumber = isNumber
        evalIdleUiState()
    }

}
