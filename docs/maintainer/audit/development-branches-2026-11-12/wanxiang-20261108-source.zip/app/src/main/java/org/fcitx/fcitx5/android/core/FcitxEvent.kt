/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2023 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.core

sealed class FcitxEvent<T>(open val data: T) {

    internal var inputSession: Long = 0
    internal var candidateActionContext: CandidateActionContext? = null
    // Monotonic producer time for commit delivery diagnostics; excluded from equality.
    internal var commitProducedNanos: Long = 0

    // Opt-in diagnostics only. Kept outside data-class equality and never logged with text.
    internal var diagnosticSequence: Long = 0
    internal var diagnosticEmittedNanos: Long = 0

    abstract val eventType: EventType

    data class CandidateListEvent(override val data: Data) :
        FcitxEvent<CandidateListEvent.Data>(data) {

        override val eventType = EventType.Candidate

        data class Data(val total: Int = -1, val candidates: Array<CandidateWord> = emptyArray()) {

            override fun toString(): String =
                "total=$total, candidates=[${candidates.joinToString(limit = 5)}]"

            override fun equals(other: Any?): Boolean {
                if (this === other) return true
                if (javaClass != other?.javaClass) return false

                other as Data

                if (total != other.total) return false
                if (!candidates.contentEquals(other.candidates)) return false

                return true
            }

            override fun hashCode(): Int {
                var result = total
                result = 31 * result + candidates.contentHashCode()
                return result
            }
        }
    }

    data class CommitStringEvent(override val data: Data) :
        FcitxEvent<CommitStringEvent.Data>(data) {

        override val eventType = EventType.Commit

        internal var statistics: InputOperationStatistics? = null

        data class Data(val text: String, val cursor: Int)
    }

    /** Counts admitted DOWN operations; never forwarded to Android as another key. */
    internal data class StatisticsKeyEvent(val statistics: InputOperationStatistics, val sym: Int) :
        FcitxEvent<Unit>(Unit) {
        override val eventType = EventType.StatisticsKey
    }

    /** Optional metrics travel together while intermediate presentation frames may still merge. */
    internal data class StatisticsKeysEvent(
        val keys: List<StatisticsKeyEvent>,
        val epoch: Long,
        val dropped: Long = 0
    ) : FcitxEvent<Unit>(Unit) {
        override val eventType = EventType.StatisticsKeys
    }

    data class ClientPreeditEvent(override val data: FormattedText) :
        FcitxEvent<FormattedText>(data) {

        override val eventType = EventType.ClientPreedit

        override fun toString(): String = "ClientPreeditEvent('$data', ${data.cursor})"
    }

    data class InputPanelEvent(override val data: Data) : FcitxEvent<InputPanelEvent.Data>(data) {

        override val eventType = EventType.InputPanel

        data class Data(
            val preedit: FormattedText,
            val auxUp: FormattedText,
            val auxDown: FormattedText,
            val tabs: Array<CandidateAction>,
            val auxBarActions: Array<AuxBarAction> = emptyArray(),
            val statusHintId: Long = 0
        ) {
            constructor() : this(
                FormattedText.Empty,
                FormattedText.Empty,
                FormattedText.Empty,
                emptyArray()
            )

            override fun equals(other: Any?): Boolean {
                if (this === other) return true
                if (javaClass != other?.javaClass) return false

                other as Data

                if (preedit != other.preedit) return false
                if (auxUp != other.auxUp) return false
                if (auxDown != other.auxDown) return false
                if (!tabs.contentEquals(other.tabs)) return false
                if (!auxBarActions.contentEquals(other.auxBarActions)) return false
                if (statusHintId != other.statusHintId) return false

                return true
            }

            override fun hashCode(): Int {
                var result = preedit.hashCode()
                result = 31 * result + auxUp.hashCode()
                result = 31 * result + auxDown.hashCode()
                result = 31 * result + tabs.contentHashCode()
                result = 31 * result + auxBarActions.contentHashCode()
                result = 31 * result + statusHintId.hashCode()
                return result
            }
        }
    }

    data class ReadyEvent(override val data: Unit = Unit) : FcitxEvent<Unit>(data) {

        override val eventType = EventType.Ready

        override fun toString(): String = "ReadyEvent"
    }

    data class KeyEvent(override val data: Data) : FcitxEvent<KeyEvent.Data>(data) {

        override val eventType = EventType.Key

        data class Data(
            val sym: KeySym,
            val states: KeyStates,
            val unicode: Int,
            val up: Boolean,
            val timestamp: Int
        )
    }

    data class IMChangeEvent(override val data: InputMethodEntry) :
        FcitxEvent<InputMethodEntry>(data) {
        override val eventType: EventType
            get() = EventType.Change
    }

    data class StatusAreaEvent(override val data: Data) : FcitxEvent<StatusAreaEvent.Data>(data) {

        override val eventType = EventType.StatusArea

        data class Data(val actions: Array<Action>, val im: InputMethodEntry) {
            override fun equals(other: Any?): Boolean {
                if (this === other) return true
                if (javaClass != other?.javaClass) return false

                other as Data

                if (!actions.contentEquals(other.actions)) return false
                if (im != other.im) return false

                return true
            }

            override fun hashCode(): Int {
                var result = actions.contentHashCode()
                result = 31 * result + im.hashCode()
                return result
            }
        }
    }

    data class DeleteSurroundingEvent(override val data: Data) :
        FcitxEvent<DeleteSurroundingEvent.Data>(data) {

        override val eventType = EventType.DeleteSurrounding

        data class Data(val before: Int, val after: Int)
    }

    data class PagedCandidateEvent(override val data: Data) :
        FcitxEvent<PagedCandidateEvent.Data>(data) {

        override val eventType = EventType.PagedCandidate

        enum class LayoutHint {
            NotSet, Vertical, Horizontal
        }

        data class Data(
            val candidates: Array<CandidateWord>,
            val cursorIndex: Int,
            val layoutHint: LayoutHint,
            val hasPrev: Boolean,
            val hasNext: Boolean
        ) {
            companion object {
                @Suppress("BooleanLiteralArgument")
                val Empty = Data(emptyArray(), -1, LayoutHint.NotSet, false, false)
            }

            override fun equals(other: Any?): Boolean {
                if (this === other) return true
                if (javaClass != other?.javaClass) return false

                other as Data

                if (!candidates.contentEquals(other.candidates)) return false
                if (cursorIndex != other.cursorIndex) return false
                if (layoutHint != other.layoutHint) return false
                if (hasPrev != other.hasPrev) return false
                if (hasNext != other.hasNext) return false

                return true
            }

            override fun hashCode(): Int {
                var result = candidates.contentHashCode()
                result = 31 * result + cursorIndex
                result = 31 * result + layoutHint.hashCode()
                result = 31 * result + hasPrev.hashCode()
                result = 31 * result + hasNext.hashCode()
                return result
            }
        }
    }

    data class SwitchInputMethodEvent(override val data: Data) :
        FcitxEvent<SwitchInputMethodEvent.Data>(data) {

        override val eventType: EventType
            get() = EventType.SwitchInputMethod

        /**
         * The reason why input method is switched to another.
         *
         * translated from
         * [fcitx/event.h](https://github.com/fcitx/fcitx5/blob/5.1.16/src/lib/fcitx/event.h#L41)
         */
        enum class Reason {
            Trigger, Deactivate, AltTrigger, Activate, Enumerate, GroupChange, CapabilityChanged, Other
        }

        data class Data(val reason: Reason, val oldInputMethod: String)
    }

    enum class EventType {
        Candidate,
        Commit,
        ClientPreedit,
        InputPanel,
        Ready,
        Key,
        Change,
        StatusArea,
        DeleteSurrounding,
        PagedCandidate,
        SwitchInputMethod,
        StatisticsKey,
        StatisticsKeys
    }
}
