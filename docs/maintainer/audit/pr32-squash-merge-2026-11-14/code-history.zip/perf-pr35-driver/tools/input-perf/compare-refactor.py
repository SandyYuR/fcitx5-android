#!/usr/bin/env python3
"""Compare two pinned Direct products on a disposable Actions emulator."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import statistics
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
FIXTURE_SHA = '333e0a0c8c9beb8a942bd56d3f9c55f1c9123836635a4663744e23f21228404f'
MODEL_SHA = '769854c83f6c914a05a1e1abb67c31c00f1ae622a41878e05957bcdee3dbda9a'
LABELS = ('before', 'after')
FRONTEND = 'app/src/androidTest/java/org/fcitx/fcitx5/android/core/DirectRimeFrontendTest.kt'
HOST_FILES = ('tools/candidate-perf/host/BenchHost.java',
              'tools/candidate-perf/host/BenchControl.java',
              'tools/candidate-perf/host/AndroidManifest.xml', 'tools/screen-perf/build-host.sh')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def preflight(args):
    products = json.loads((args.apks / 'products.json').read_text())
    require(set(products['sources']) == set(LABELS), 'Expected exactly two Direct products')
    require(all(re.fullmatch(r'[0-9a-f]{40}', sha) for sha in products['sources'].values()),
            'Product sources must be full commit SHAs')
    require(products['sources']['before'] != products['sources']['after'], 'Product commits must differ')
    expected_files = {label + suffix for label in LABELS for suffix in ('.apk', '-tests.apk')} | {'host.apk'}
    require(set(products['files']) == expected_files, 'Unexpected product file manifest')
    for name, sha in products['files'].items():
        require(digest(args.apks / name) == sha, 'Product checksum changed: ' + name)
    require(products['harness_sha256'] == digest(ROOT / 'tools/candidate-perf/CandidateTapTest.kt'),
            'Candidate instrumentation differs from the build')
    require(products['frontend_harness_sha256'] == digest(ROOT / FRONTEND), 'Backend instrumentation differs from the build')
    require(products['host_source_sha256'] == {name: digest(ROOT / name) for name in HOST_FILES},
            'Editor host source differs from the build')
    require(products['driver_sha256'] == {name: digest(ROOT / name) for name in
            ('tools/candidate-perf/run.py', 'tools/input-perf/compare-refactor.py')},
            'Measurement driver differs from the build')
    require(set(products['packages']) == set(LABELS), 'Missing product package names')
    # This runner is intentionally limited to the existing Debug application ID.
    require(set(products['packages'].values()) == {'org.fcitx.fcitx5.android.fx.rime.debug'},
            'Unexpected benchmark package')
    fixture = json.loads(args.fixture_manifest.read_text())
    require(fixture['fixture_sha256'] == FIXTURE_SHA and digest(args.fixture) == FIXTURE_SHA,
            'The benchmark requires the original frozen fixture')
    require(fixture['model']['digest'] == 'sha256:' + MODEL_SHA, 'Unexpected model source')
    require(fixture['base']['digest'] == 'sha256:ddebf0372a2a3d9d8f7a5017704b2afd7397a961c32be490a91e49ec3ee90999',
            'Unexpected Wanxiang base source')
    return products, fixture


def adb(*parts, check=True, timeout=900):
    return subprocess.run(['adb', '-s', 'emulator-5554', *map(str, parts)],
                          check=check, capture_output=True, text=True, timeout=timeout)


def backend_sample(args, product, output, source):
    # Installed by the immediately preceding candidate sample. All resets occur
    # outside timing and apply only to the disposable Actions benchmark app.
    package = product
    adb('shell', 'am', 'force-stop', package)
    adb('shell', 'pm', 'clear', package)
    adb('shell', 'run-as', package, 'mkdir', '-p', 'files')
    adb('push', args.fixture, '/data/local/tmp/refactor-fixture.zip')
    adb('shell', f"cat /data/local/tmp/refactor-fixture.zip | run-as {package} sh -c 'cat > files/refactor-fixture.zip'")
    adb('logcat', '-c')
    run = adb('shell', 'am', 'instrument', '-w', '-r', '-e', 'class',
              'org.fcitx.fcitx5.android.core.DirectRimeFrontendTest#replayPerformanceWorkload',
              '-e', 'fixtureArchive', 'refactor-fixture.zip', '-e', 'waitMs', '240000',
              package + '.test/androidx.test.runner.AndroidJUnitRunner', check=False)
    (output / 'backend-instrumentation.txt').write_text(run.stdout + run.stderr)
    (output / 'backend-logcat.txt').write_text(adb('logcat', '-d', '-v', 'threadtime').stdout)
    require(run.returncode == 0 and 'OK (1 test)' in run.stdout, 'Backend instrumentation failed')
    result = json.loads(adb('shell', 'run-as', package, 'cat', 'files/direct-rime-replay.json').stdout)
    save(output / 'backend.json', result)
    require(result['harness_commit'] == source and result['model_mapped'] is True, 'Backend product or model mismatch')
    require(result['words'] == 100 and len(result['commits']) == 100 and result['keys'] > 100,
            'Incomplete backend workload')
    for key in ('p50_ms', 'p95_ms', 'p99_ms'):
        require(type(result[key]) in (int, float) and math.isfinite(result[key]) and result[key] > 0,
                'Invalid backend timing: ' + key)
    require(result['p50_ms'] <= result['p95_ms'] <= result['p99_ms'], 'Backend quantiles are reversed')
    return result


def candidate_measurements(raw, source):
    ime, editor = raw['ime'], raw['editor']
    require(ime['commit'] == source and ime['model_mapped'] is True and ime['fcitx_core_mapped'] is False,
            'Wrong candidate product or native model')
    require(len(ime['rounds']) == len(editor['commits']) == 6 and editor['text'] == '你' * 6,
            'Expected exactly six candidate commits')
    values = []
    for index, row in enumerate(ime['rounds']):
        require(row['round'] == index + 1, 'Candidate rounds are unordered')
        touch = row['select']
        up = touch['dispatch_up_ns']
        expected = '你' * (index + 1)
        ic = editor['commits'][index]['at_ns']
        edit = next(e['at_ns'] for e in editor['edits'] if e['text'] == expected)
        draw = next(e['at_ns'] for e in editor['draws'] if e['text'] == expected)
        require(editor['commits'][index]['text'] == '你', 'Candidate commit text changed')
        require(0 < touch['inject_up_ns'] <= up <= ic <= edit <= draw,
                'Candidate clocks violate causal order')
        require(up <= touch['dispatch_return_ns'] and up <= row['commit_collected_ns'],
                'IME callbacks violate causal order')
        require(0 < row['n']['dispatch_up_ns'] <= row['preedit_collected_ns'], 'Invalid preedit timestamp')
        values.append({'round': index + 1,
                       'input_connection_ms': (ic - up) / 1e6,
                       'editor_change_ms': (edit - up) / 1e6,
                       'editor_draw_ms': (draw - up) / 1e6,
                       'commit_collector_ms': (row['commit_collected_ns'] - up) / 1e6,
                       'touch_handler_ms': (touch['dispatch_return_ns'] - up) / 1e6,
                       'input_injection_ms': (up - touch['inject_up_ns']) / 1e6,
                       'preedit_collector_ms': (row['preedit_collected_ns'] - row['n']['dispatch_up_ns']) / 1e6})
    return values


def describe(values):
    ordered = sorted(values)
    return {'n': len(values), 'median': statistics.median(values), 'min': ordered[0], 'max': ordered[-1],
            'p95_nearest_rank': ordered[math.ceil(len(ordered) * .95) - 1]}


def summaries(samples, blocks):
    per_product = {}
    for label in LABELS:
        chosen = [s for s in samples if s['label'] == label]
        ui = {}
        for metric in chosen[0]['candidate'][0]:
            if metric == 'round':
                continue
            ui[metric] = {
                'first': describe([s['candidate'][0][metric] for s in chosen]),
                'steady': describe([row[metric] for s in chosen for row in s['candidate'][1:]]),
                'steady_process_medians': describe([
                    statistics.median(row[metric] for row in s['candidate'][1:]) for s in chosen])}
        backend = {metric: describe([s['backend'][metric] for s in chosen])
                   for metric in ('p50_ms', 'p95_ms', 'p99_ms', 'entry_identity_changes',
                                  'art_objects_allocated', 'art_bytes_allocated')
                   if all(s['backend'][metric] is not None for s in chosen)}
        per_product[label] = {'candidate': ui, 'backend_per_process': backend}
    paired = []
    for block in range(blocks):
        selected = [s for s in samples if s['block'] == block + 1]
        require(len(selected) == 4, 'An ABBA block must have four complete samples')
        by_label = {label: [s for s in selected if s['label'] == label] for label in LABELS}
        require(all(len(v) == 2 for v in by_label.values()), 'An ABBA block must balance both products')
        record = {'block': block + 1, 'delta_after_minus_before_ms': {}}
        for metric in ('input_connection_ms', 'editor_draw_ms', 'preedit_collector_ms'):
            for phase in ('first', 'steady'):
                medians = {}
                for label in LABELS:
                    values = [s['candidate'][0][metric] for s in by_label[label]] if phase == 'first' else [
                        statistics.median(row[metric] for row in s['candidate'][1:]) for s in by_label[label]]
                    medians[label] = statistics.median(values)
                record['delta_after_minus_before_ms'][metric + '_' + phase] = medians['after'] - medians['before']
        for metric in ('p50_ms', 'p95_ms', 'p99_ms'):
            record['delta_after_minus_before_ms']['backend_' + metric] = (
                statistics.median(s['backend'][metric] for s in by_label['after']) -
                statistics.median(s['backend'][metric] for s in by_label['before']))
        paired.append(record)
    return {'products': per_product, 'paired_blocks': paired}


def run(args):
    products, fixture = preflight(args)
    if args.verify_only:
        print('PRODUCTS_AND_FIXTURE_VERIFIED')
        return
    require(os.environ.get('GITHUB_ACTIONS') == 'true', 'Run only in the disposable GitHub Actions VM')
    require(adb('get-serialno').stdout.strip() == 'emulator-5554', 'Unexpected emulator')
    require(adb('emu', 'avd', 'name').stdout.strip().splitlines()[0] == 'test', 'Unexpected Actions AVD')
    require(not args.output.exists() or not any(args.output.iterdir()), 'Output must be empty; retain earlier evidence')
    args.output.mkdir(parents=True, exist_ok=True)
    os.environ['ANDROID_SERIAL'] = 'emulator-5554'  # Existing child driver inherits the explicit target.
    # Reverse replica reverses every predeclared block on a separate host VM.
    plan = [['before', 'after', 'after', 'before'] if (b + (args.replica == 'reverse')) % 2 == 0 else
            ['after', 'before', 'before', 'after'] for b in range(args.blocks)]
    save(args.output / 'plan.json', {'sources': products['sources'], 'blocks': plan, 'replica': args.replica,
         'fixture_sha256': FIXTURE_SHA, 'traced': False, 'build_type': 'Debug', 'abi': 'x86_64',
         'reset': 'Fresh app profile and process per sample; preparation excluded from timing',
         'limits': 'View.onDraw is a CPU callback; neither frame presentation nor physical device latency'})
    save(args.output / 'products.json', products)
    save(args.output / 'fixture.manifest.json', fixture)
    for name, command in (('device-properties.txt', ('shell', 'getprop')),
                          ('device-cpu.txt', ('shell', 'cat', '/proc/cpuinfo'))):
        (args.output / name).write_text(adb(*command).stdout)
    samples = []
    reference_commits = None
    try:
        for block, labels in enumerate(plan, 1):
            for position, label in enumerate(labels, 1):
                name = f'b{block:02}-p{position:02}-{label}'
                output = args.output / name
                output.mkdir()
                # Expose only the selected product to the unchanged candidate driver.
                apks = output / 'selected-apks'
                apks.mkdir()
                for suffix in ('.apk', '-tests.apk', '-commit.txt'):
                    target = apks / (label + suffix)
                    if suffix == '-commit.txt':
                        target.write_text(products['sources'][label] + '\n')
                    else:
                        try:
                            os.link(args.apks / (label + suffix), target)
                        except OSError:
                            shutil.copyfile(args.apks / (label + suffix), target)
                print('MEASURING ' + name, flush=True)
                with (output / 'candidate-driver.log').open('w') as log:
                    subprocess.run([sys.executable, str(ROOT / 'tools/candidate-perf/run.py'),
                        '--apks', str(apks), '--fixture', str(args.fixture), '--host', str(args.apks / 'host.apk'),
                        '--output', str(output / 'candidate'), '--trials', '1'],
                        stdout=log, stderr=subprocess.STDOUT, check=True, timeout=1200)
                raw = json.loads((output / 'candidate/comparison.json').read_text())[label][0]
                candidate = candidate_measurements(raw, products['sources'][label])
                backend = backend_sample(args, products['packages'][label], output, products['sources'][label])
                workload = (backend['keys'], backend['commits'])
                if reference_commits is None:
                    reference_commits = workload
                require(workload == reference_commits, 'Backend key count or commit sequence changed between products')
                sample = {'block': block, 'position': position, 'label': label,
                          'source': products['sources'][label], 'candidate': candidate, 'backend': backend}
                save(output / 'sample.json', sample)
                samples.append(sample)
                save(args.output / 'samples.json', samples)
                # Product APKs are retained once in the build artifact, not duplicated in every sample.
                for apk in apks.glob('*.apk'):
                    apk.unlink()
        require(len(samples) == args.blocks * 4, 'Study is incomplete')
        result = {'replica': args.replica, 'sources': products['sources'], 'completed_samples': len(samples),
                  'selection_count': len(samples) * 6, 'backend_words': len(samples) * 100,
                  'statistics': summaries(samples, args.blocks)}
        save(args.output / 'summary.json', result)
        print('PERFORMANCE_COMPARISON_COMPLETE', flush=True)
    except BaseException as error:
        save(args.output / 'failure.json', {'error': str(error), 'completed_samples': len(samples)})
        raise


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    for name in ('apks', 'fixture', 'fixture-manifest', 'output'):
        result.add_argument('--' + name, type=Path, required=True)
    result.add_argument('--blocks', type=int, choices=range(1, 7), default=3)
    result.add_argument('--replica', choices=('forward', 'reverse'), default='forward')
    result.add_argument('--verify-only', action='store_true')
    return result


if __name__ == '__main__':
    run(parser().parse_args())
