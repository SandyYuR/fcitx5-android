#!/usr/bin/env bash
# Build exact Direct products; the common candidate probe is an androidTest-only overlay.
set -euo pipefail

repo_dir=$(git rev-parse --show-toplevel)
mode=build
if [ "${1:-}" = --finalize ]; then mode=finalize; shift; fi
output_dir=${1:?product output directory}
before_ref=${2:?exact default product commit}
after_ref=${3:?exact refactored product commit}
: "${RUNNER_TEMP:?Use the disposable Actions build workspace}"
for revision in "$before_ref" "$after_ref"; do
    [[ "$revision" =~ ^[0-9a-f]{40}$ ]] || { echo 'Products require full lowercase commit SHAs' >&2; exit 2; }
    if ! git -C "$repo_dir" cat-file -e "$revision^{commit}"; then
        git -C "$repo_dir" fetch --no-recurse-submodules --no-tags origin "$revision"
    fi
    [ "$(git -C "$repo_dir" rev-parse "$revision^{commit}")" = "$revision" ]
done
[ "$before_ref" != "$after_ref" ] || { echo 'Choose two distinct product commits' >&2; exit 2; }
mkdir -p "$output_dir"
output_dir=$(cd "$output_dir" && pwd)
if [ "$mode" = build ]; then
    [ -z "$(find "$output_dir" -mindepth 1 -maxdepth 1 -print -quit)" ] || { echo 'Product output must be empty; retain previous evidence' >&2; exit 2; }
else
    [ ! -e "$output_dir/products.json" ] || { echo 'Finalize accepts only the identified incomplete build' >&2; exit 2; }
    python3 - "$repo_dir" "$output_dir" "$before_ref" "$after_ref" <<'PYRECOVERY'
import hashlib, json, subprocess, sys
from pathlib import Path
root, output = map(Path, sys.argv[1:3])
record = json.loads((root / 'tools/input-perf/refactor-build-recovery.json').read_text())
if record['sources'] != dict(zip(('before', 'after'), sys.argv[3:5])):
    raise SystemExit('Recovery must retain the original two product commits')
for name, sha in record['files'].items():
    if hashlib.sha256((output / name).read_bytes()).hexdigest() != sha:
        raise SystemExit('Original build artifact bytes changed: ' + name)
subprocess.run(['git', '-C', str(root), 'diff', '--exit-code', record['build_driver_commit'], 'HEAD', '--',
    'tools/candidate-perf/CandidateTapTest.kt', 'tools/candidate-perf/run.py',
    'app/src/androidTest/java/org/fcitx/fcitx5/android/core/DirectRimeFrontendTest.kt',
    'tools/candidate-perf/host', 'tools/screen-perf/build-host.sh',
    'tools/input-perf/compare-refactor.py'], check=True)
print('ORIGINAL_BUILD_ARTIFACT_BYTES_AND_PROBES_VERIFIED')
PYRECOVERY
fi
export BUILD_ABI=x86_64

python3 - "$repo_dir" "$before_ref" "$after_ref" <<'PY'
import hashlib
from pathlib import Path
import subprocess
import sys

root, before, after = sys.argv[1:]
paths = ('native/rime-sdk.lock.json',
         'app/src/androidTest/java/org/fcitx/fcitx5/android/core/DirectRimeFrontendTest.kt')
for path in paths:
    contents = [subprocess.check_output(['git', '-C', root, 'show', ref + ':' + path])
                for ref in (before, after)]
    if contents[0] != contents[1] or contents[1] != (Path(root) / path).read_bytes():
        raise SystemExit('Products and driver must share identical SDK/frontend probe bytes: ' + path)
    print(path + ' sha256:' + hashlib.sha256(contents[0]).hexdigest())
subprocess.run(['git', '-C', root, 'diff', '--exit-code', before, after, '--',
                'direct-rime', 'native', 'build-logic', 'gradle', 'patches',
                'app/build.gradle.kts', 'build.gradle.kts', 'settings.gradle.kts',
                'gradle.properties', '.gitmodules'], check=True)
PY

if [ "$mode" = build ]; then
checkout_dir="$RUNNER_TEMP/refactor-product"
[ ! -e "$checkout_dir" ] || { echo "Refusing to reuse checkout: $checkout_dir" >&2; exit 2; }
git clone --shared --no-checkout "$repo_dir" "$checkout_dir"
for label in before after; do
    if [ "$label" = before ]; then revision=$before_ref; else revision=$after_ref; fi
    # The preceding product and all of its audit records are already saved.
    # One absolute build path avoids Debug ELF build-id differences from paths.
    if [ "$label" = after ]; then
        git -C "$checkout_dir" diff --exit-code
        git -C "$checkout_dir" diff --cached --exit-code
    fi
    git -C "$checkout_dir" checkout --detach "$revision"
    bash "$repo_dir/tools/prepare-native-inputs.sh" "$checkout_dir"
    target="$checkout_dir/app/src/androidTest/java/org/fcitx/fcitx5/android/core"
    mkdir -p "$target"
    cp "$repo_dir/tools/candidate-perf/CandidateTapTest.kt" "$target/CandidateTapTest.kt"
    cmp "$repo_dir/tools/candidate-perf/CandidateTapTest.kt" "$target/CandidateTapTest.kt"
    (
        cd "$checkout_dir"
        git diff --exit-code -- app/src/main direct-rime native build-logic gradle patches \
            app/build.gradle.kts build.gradle.kts settings.gradle.kts gradle.properties .gitmodules
        git submodule status > "$output_dir/$label-submodules.txt"
        sha256sum app/src/androidTest/java/org/fcitx/fcitx5/android/core/CandidateTapTest.kt \
            | awk '{print $1}' > "$output_dir/$label-harness-sha256.txt"
        sha256sum app/src/androidTest/java/org/fcitx/fcitx5/android/core/DirectRimeFrontendTest.kt \
            | awk '{print $1}' > "$output_dir/$label-frontend-harness-sha256.txt"
        ./gradlew --console=plain clean 2>&1 | tee "$output_dir/$label-clean.log"
        ./gradlew -PbuildABI=x86_64 -Pkotlin.compiler.execution.strategy=in-process \
            --max-workers=2 --console=plain :app:assembleFxDebug :app:assembleFxDebugAndroidTest \
            2>&1 | tee "$output_dir/$label-build.log"
        app_apks=(app/build/outputs/apk/fx/debug/*.apk)
        test_apks=(app/build/outputs/apk/androidTest/fx/debug/*.apk)
        [ "${#app_apks[@]}" -eq 1 ] && [ -f "${app_apks[0]}" ]
        [ "${#test_apks[@]}" -eq 1 ] && [ -f "${test_apks[0]}" ]
        cp "${app_apks[0]}" "$output_dir/$label.apk"
        cp "${test_apks[0]}" "$output_dir/$label-tests.apk"
        git rev-parse HEAD > "$output_dir/$label-commit.txt"
        python3 tools/verify-direct-rime-apk.py "$output_dir/$label.apk" > "$output_dir/$label-apk-audit.json"
        python3 tools/audit-direct-rime-link.py "$output_dir/$label.apk" \
            --build-root "$checkout_dir/app/.cxx" --prebuilt "$checkout_dir/native/rime-sdk" \
            > "$output_dir/$label-native-link-audit.json"
        ./gradlew --stop
    )
done

cmp "$output_dir/before-frontend-harness-sha256.txt" "$output_dir/after-frontend-harness-sha256.txt"
cmp "$output_dir/before-harness-sha256.txt" "$output_dir/after-harness-sha256.txt"
bash "$repo_dir/tools/screen-perf/build-host.sh" "$RUNNER_TEMP/refactor-host" "$repo_dir/tools/candidate-perf/host"
cp "$RUNNER_TEMP/refactor-host/host.apk" "$output_dir/host.apk"
fi

python3 - "$repo_dir" "$output_dir" "$before_ref" "$after_ref" "$mode" <<'PY'
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import zipfile

root, output = map(Path, sys.argv[1:3])
sources = dict(zip(('before', 'after'), sys.argv[3:5]))
mode = sys.argv[5]
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

sdk = Path(os.environ.get('ANDROID_HOME') or os.environ['ANDROID_SDK_ROOT'])
aapt = max((sdk / 'build-tools').glob('*/aapt2'),
           key=lambda p: [int(n) for n in re.findall(r'\d+', p.parent.name)])
signer = aapt.with_name('apksigner')
packages, certificates, native = {}, {}, {}
files = {label + suffix: digest(output / (label + suffix))
         for label in sources for suffix in ('.apk', '-tests.apk')}
files['host.apk'] = digest(output / 'host.apk')
for label, revision in sources.items():
    if (output / (label + '-commit.txt')).read_text().strip() != revision:
        raise SystemExit('Built checkout does not match pinned product: ' + label)
    for suffix in ('.apk', '-tests.apk'):
        apk = output / (label + suffix)
        package = subprocess.check_output([str(aapt), 'dump', 'packagename', str(apk)], text=True).strip()
        if not re.fullmatch(r'[a-zA-Z0-9_.]+', package):
            raise SystemExit('Unexpected product package')
        expected = 'org.fcitx.fcitx5.android.fx.rime.debug' + ('.test' if suffix == '-tests.apk' else '')
        if package != expected:
            raise SystemExit('Product package differs from the original Debug application ID: ' + package)
        if suffix == '.apk':
            packages[label] = package
        text = subprocess.check_output([str(signer), 'verify', '--print-certs', str(apk)], text=True)
        hashes = {value.lower() for value in re.findall(
            r'^(?:Signer #\d+|V[1-4](?:\.\d+)? Signer:) certificate SHA-256 digest: ([0-9a-fA-F]{64})\s*$',
            text, re.MULTILINE)}
        if len(hashes) != 1:
            raise SystemExit('Expected exactly one APK signer: ' + apk.name)
        certificates[apk.name] = hashes.pop()
    if certificates[label + '.apk'] != certificates[label + '-tests.apk']:
        raise SystemExit('Product and instrumentation signer differ: ' + label)
    with zipfile.ZipFile(output / (label + '.apk')) as archive:
        native[label] = {name: hashlib.sha256(archive.read(name)).hexdigest()
                         for name in archive.namelist() if name.startswith('lib/') and name.endswith('.so')}
    expected_libraries = {'lib/x86_64/libdirect-rime.so', 'lib/x86_64/libc++_shared.so', 'lib/x86_64/libquickjs.so'}
    if set(native[label]) != expected_libraries:
        raise SystemExit('Native library set differs from the three-library whitelist: ' + label)
    audit = json.loads((output / (label + '-native-link-audit.json')).read_text())
    if (len(audit) != 1 or audit[0]['abi'] != 'x86_64' or audit[0]['fcitx_cpp_symbols'] or
            audit[0]['apk_native_sha256'] != native[label]['lib/x86_64/libdirect-rime.so']):
        raise SystemExit('Link audit does not match packaged native bytes: ' + label)
    apk_audit = json.loads((output / (label + '-apk-audit.json')).read_text())
    if apk_audit['apk_sha256'] != files[label + '.apk'] or apk_audit['fcitx_dependencies']:
        raise SystemExit('APK audit does not match the original product bytes: ' + label)
if native['before'] != native['after']:
    (output / 'native-library-difference.json').write_text(json.dumps(native, indent=2) + '\n')
    raise SystemExit('Two Kotlin products must package identical native library bytes; inspect recorded difference')
if len(set(certificates.values())) != 1:
    raise SystemExit('Both products and instrumentation must use the same generated Debug signer')
host_paths = ('tools/candidate-perf/host/BenchHost.java',
              'tools/candidate-perf/host/BenchControl.java',
              'tools/candidate-perf/host/AndroidManifest.xml', 'tools/screen-perf/build-host.sh')
driver_paths = ('tools/input-perf/build-refactor-products.sh', 'tools/input-perf/compare-refactor.py',
                'tools/candidate-perf/run.py', '.github/workflows/rime-candidate-perf.yml')
manifest = {
    'schema_version': 1, 'build_type': 'Debug', 'abi': 'x86_64', 'input_diagnostics': False,
    'driver_commit': subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip(),
    'sources': sources, 'files': files, 'packages': packages, 'signer_sha256': certificates,
    'harness_sha256': digest(root / 'tools/candidate-perf/CandidateTapTest.kt'),
    'frontend_harness_sha256': digest(root / 'app/src/androidTest/java/org/fcitx/fcitx5/android/core/DirectRimeFrontendTest.kt'),
    'host_source_sha256': {path: digest(root / path) for path in host_paths},
    'driver_sha256': {path: digest(root / path) for path in
                      ('tools/candidate-perf/run.py', 'tools/input-perf/compare-refactor.py')},
    'driver_source_sha256': {path: digest(root / path) for path in driver_paths},
    'sdk_lock_sha256': digest(root / 'native/rime-sdk.lock.json'),
    'native_library_sha256': native['before'],
}
manifest['build_driver_commit'] = manifest['driver_commit']
if mode == 'finalize':
    recovery = json.loads((root / 'tools/input-perf/refactor-build-recovery.json').read_text())
    if any(files[name] != recovery['files'][name] for name in files):
        raise SystemExit('Finalize changed an original product or host APK')
    manifest['build_driver_commit'] = recovery['build_driver_commit']
    manifest['recovery'] = recovery
(output / 'products.json').write_text(json.dumps(manifest, indent=2) + '\n')
(output / 'harness-sha256.txt').write_text(manifest['harness_sha256'] + '\n')
(output / 'apk-sha256.txt').write_text(''.join(h + '  ' + name + '\n' for name, h in sorted(files.items())))
print(json.dumps(manifest, indent=2))
PY

# Compiler work must be finished before the independent measurement VMs start.
compiler_pids=$(jps -l | awk '$2 == "org.jetbrains.kotlin.daemon.KotlinCompileDaemon" {print $1}')
if [ -n "$compiler_pids" ]; then kill $compiler_pids; fi
