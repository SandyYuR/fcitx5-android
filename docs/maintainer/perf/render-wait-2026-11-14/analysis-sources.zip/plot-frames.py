from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
r=Path(__file__).resolve().parent
plt.rcParams.update({'font.size':10,'svg.fonttype':'none'})
fig, axes=plt.subplots(2,1,figsize=(11.5,6.4),sharex=True,layout='constrained')
for ax,label in zip(axes,['baseline','current']):
 data=json.loads((r/('recomputed-'+label)/'analysis.json').read_text())['rounds'][0]
 origin=data['anchors']['n']['inject_down_ns']
 for key,y,color in [('waits',2,'#d88031'),('frames',1,'#659bc2'),('syncs',0,'#70499b')]:
  for s in data[key]:
   left=(s['ts']-origin)/1e6
   ax.broken_barh([(left,s['ms'])],(y-.24,.48),facecolors=color,alpha=.9,edgecolors='white',linewidth=.5)
   if s['ms']>90 and left>=0:
    ax.text(left+s['ms']/2,y,f"{s['ms']:.1f} ms",ha='center',va='center',color='white',weight='bold',fontsize=9)
 injected=(data['anchors']['i']['inject_up_ns']-origin)/1e6
 received=(data['anchors']['i']['dispatch_up_ns']-origin)/1e6
 ax.axvspan(injected,received,color='#f0bcbd',alpha=.23)
 ax.axvline(injected,color='#be434a',ls='--',lw=1.5)
 ax.axvline(received,color='#26735a',lw=1.6)
 ax.text(received+2,2.40,f'i received: {received:.1f} ms',fontsize=9,color='#26735a')
 ax.set_yticks([0,1,2],['Render: sync encode/readback','Render: DrawFrames','Main: postAndWait'])
 ax.set_ylim(-.55,2.75);ax.set_xlim(0,370);ax.grid(axis='x',alpha=.22)
 ax.set_title(('Default 88a664d4' if label=='baseline' else 'Trial f02bbaec')+' — one diagnostic process',loc='left',weight='bold')
axes[-1].set_xlabel('Milliseconds since actual injection of the first n DOWN')
fig.legend(handles=[Line2D([0],[0],color='#be434a',ls='--',label='i actual injection UP'),Line2D([0],[0],color='#26735a',label='i window UP dispatch'),Patch(color='#f0bcbd',alpha=.4,label='Input waiting interval')],loc='outside upper center',ncol=3,frameon=False)
fig.savefig(r/'frame-timeline.svg');fig.savefig(r/'frame-timeline.png',dpi=160)
