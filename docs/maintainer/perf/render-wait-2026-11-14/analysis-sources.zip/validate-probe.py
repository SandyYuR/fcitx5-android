from pathlib import Path
import importlib.util,json,hashlib,sys,os
r=Path(__file__).resolve().parent
tools=Path(os.environ.get('INPUT_PERF_TOOLS','/workspace/fcitx5-android-pipeline/tools/input-perf'))
sys.path.insert(0,str(tools))
spec=importlib.util.spec_from_file_location('study',tools/'run-study.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[]
for seq in ['a','b']:
 d=r/('render-cache-'+seq)/'samples'
 assert json.loads((d/'probe-cleanup.json').read_text())['errors']==[]
 restoration=json.loads((d/'restoration.json').read_text());assert restoration['errors']==[] and restoration['remaining_owned_packages']==[] and restoration['remaining_diagnostic_packages']==[]
 for path in sorted(d.glob('*/current.json')):
  raw=json.loads(path.read_text());m.measurements(raw,'f02bbaec1c2820545382dab82b3e007e9f2735fe','external_process_input_manager_phase_v3')
  cache=json.loads((path.parent/'cache.json').read_text())
  assert all(cache[k]==[] for k in ['before','pre_replay','after_replay'])
  analysis=json.loads((r/'probe-analysis'/d.parent.name/path.parent.name/'analysis.json').read_text())
  assert analysis['loss']==[dict(name='config_write_into_file_no_flush',idx='[NULL]',severity='error',value='1')]
  assert not analysis['valid']
  assert all(t['complete'] for rd in analysis['rounds'] for i in rd['intervals'].values() for t in i['threads'].values())
  assert all(s['cpu']['complete'] for rd in analysis['rounds'] for s in rd['frames']+rd['syncs']+rd['waits'])
  first=raw['ime']['rounds'][0]
  rows.append(dict(vm=seq,sample=path.parent.name,source=raw['ime']['commit'],raw_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),correct_selections=len(raw['editor']['commits']),cache_files_before=0,cache_files_after=0,cache_intervention_effective=False,trace_strict_validation=False,trace_config_error=analysis['loss'],event_thread_coverage_complete=True,first_i_actual_down_to_window_up_ms=(first['i']['dispatch_up_ns']-first['i']['inject_down_ns'])/1e6,first_i_actual_up_to_window_up_ms=(first['i']['dispatch_up_ns']-first['i']['inject_up_ns'])/1e6))
assert len(rows)==8
result=dict(run_id=43508740045,product_rebuilt=False,driver='3c474d1d3e8aa1fdbb92983c6efcf8db5ec82b25',cache_contrast_valid=False,cache_contrast_reason='No inventoried HWUI shader disk cache file existed in either VM before or after any replay; no actual cache deletion or retention contrast.',trace_strict_passes=0,trace_strict_failures=8,trace_config_fix='a3c9bea6; locally tested only, not rerun on device',completed_processes=len(rows),correct_selections=sum(v['correct_selections'] for v in rows),device_restore_verified=True,samples=rows)
(r/'cache-probe-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='samples'},indent=2))
