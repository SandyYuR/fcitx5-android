"""Reproduce frame/backpressure evidence from one trace and its original raw JSON."""
import argparse
import csv
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess

p = argparse.ArgumentParser(description=__doc__)
for name in ('data', 'trace', 'processor', 'tools', 'output'):
    p.add_argument('--' + name, type=Path, required=True)
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location('associate', a.tools / 'associate-events.py')
associate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(associate)
raw = json.loads(a.data.read_text())
pid = int(raw['ime']['ime_pid'])


def query(name, sql):
    (a.output / (name + '.sql')).write_text(sql + '\n')
    r = subprocess.run([str(a.processor), 'query', '--no-agent', '--format', 'csv', str(a.trace), sql],
                       capture_output=True, text=True, check=True)
    (a.output / (name + '.csv')).write_text(r.stdout)
    return list(csv.DictReader(io.StringIO(r.stdout)))


process = query('process', f'SELECT upid,pid,name FROM process WHERE pid={pid}')
if len(process) != 1:
    raise ValueError('Ambiguous process identity')
upid = int(process[0]['upid'])
threads = query('threads', f'SELECT utid,tid,name FROM thread WHERE upid={upid}')
selected = {}
for label, match in [('main', lambda t: int(t['tid']) == pid),
                     ('render', lambda t: t['name'] == 'RenderThread'),
                     ('owner', lambda t: t['name'] == 'rime-main')]:
    found = [t for t in threads if match(t)]
    if len(found) != 1:
        raise ValueError('Ambiguous ' + label)
    selected[label] = int(found[0]['utid'])
bounds = query('bounds', 'SELECT * FROM trace_bounds')[0]
loss = query('loss', "SELECT name,idx,severity,value FROM stats WHERE value>0 AND (severity IN ('error','data_loss') OR name GLOB '*lost*' OR name GLOB '*drop*')")
sched = [tuple(int(r[k]) for k in ('ts', 'dur', 'utid')) for r in query('sched',
         f'SELECT s.ts,s.dur,s.utid FROM sched s JOIN thread t USING(utid) WHERE t.upid={upid} AND s.dur>0 ORDER BY s.ts')]
states = [tuple(int(r[k]) for k in ('ts', 'dur', 'utid')) + (r['state'],) for r in query('states',
          f'SELECT s.ts,s.dur,s.utid,s.state FROM thread_state s JOIN thread t USING(utid) WHERE t.upid={upid} AND s.dur>0 ORDER BY s.ts')]
slices = query('slices', f'''SELECT s.id,s.ts,s.dur,s.name,s.parent_id,s.depth,t.utid,t.tid,t.name AS thread
 FROM slice s JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON t.utid=tt.utid
 WHERE t.upid={upid} AND s.dur>0 AND (t.utid={selected['render']} OR
 (t.utid={selected['main']} AND (s.name GLOB 'Choreographer*' OR s.name IN
 ('postAndWait','DrawFrame','syncAndDrawFrame','layout','measure','RV OnLayout','RV OnMeasure'))))
 ORDER BY s.ts,s.dur DESC''')
for s in slices:
    for k in ('id', 'ts', 'dur', 'parent_id', 'depth', 'utid', 'tid'):
        s[k] = int(s[k]) if s[k] not in ('[NULL]', '', None) else None
    s['end_ns'] = s['ts'] + s['dur']
    s['ms'] = s['dur'] / 1e6
    s['cpu'] = associate.interval_evidence(s['ts'], s['end_ns'], s['utid'], sched, states)


def overlap(s, start, end):
    return max(0, min(s['end_ns'], end) - max(s['ts'], start)) / 1e6


rounds = []
for index, r in enumerate(raw['ime']['rounds']):
    start, end = r['n']['inject_down_ns'], r['select']['inject_down_ns']
    if not int(bounds['start_ts']) <= start < end <= int(bounds['end_ts']):
        raise ValueError('Invalid first-word boundaries')
    used = [s for s in slices if overlap(s, start, end) > 0]
    frames = [s for s in used if s['name'].startswith('DrawFrames ')]
    syncs = [s for s in used if s['name'] == 'rcCreateSyncKHR encode']
    waits = [s for s in used if s['name'] == 'postAndWait']
    intervals = {}
    for label, left, right in (
        ('i_actual_down_to_window_up', r['i']['inject_down_ns'], r['i']['dispatch_up_ns']),
        ('i_actual_up_to_window_up', r['i']['inject_up_ns'], r['i']['dispatch_up_ns']),
        ('candidate_window_up_to_ic', r['select']['dispatch_up_ns'], raw['editor']['commits'][index]['at_ns']),
    ):
        if not int(bounds['start_ts']) <= left <= right <= int(bounds['end_ts']):
            raise ValueError('Invalid event interval')
        intervals[label] = dict(start_ns=left, end_ns=right, ms=(right-left)/1e6,
            threads={key: associate.interval_evidence(left, right, utid, sched, states) for key, utid in selected.items()},
            main_post_and_wait_ms=sum(overlap(s, left, right) for s in waits),
            render_sync_ms=sum(overlap(s, left, right) for s in syncs))
    rounds.append(dict(round=index+1, anchors=r, intervals=intervals, frames=frames, syncs=syncs, waits=waits,
        max_frame_ms=max((s['ms'] for s in frames), default=0), max_sync_ms=max((s['ms'] for s in syncs), default=0),
        shader_compiles=[s for s in used if s['name'] in ('shader_compile', 'cache_hit', 'cache_miss')],
        note='n actual DOWN to candidate DOWN window; frame durations are whole slices, not photon presentation times'))
result = dict(source=raw['ime']['commit'], process=process[0], selected_threads=selected,
    raw_sha256=hashlib.sha256(a.data.read_bytes()).hexdigest(), trace_sha256=hashlib.sha256(a.trace.read_bytes()).hexdigest(),
    bounds=bounds, loss=loss, rounds=rounds,
    all_syncs=[s for s in slices if s['name'] == 'rcCreateSyncKHR encode'],
    valid=not loss and all(t['complete'] for r in rounds for i in r['intervals'].values() for t in i['threads'].values())
        and all(s['cpu']['complete'] for r in rounds for s in r['frames'] + r['syncs'] + r['waits']))
(a.output / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(output=str(a.output), valid=result['valid'], first=result['rounds'][0]['max_sync_ms'])))
if not result['valid']:
    raise SystemExit('Trace coverage failed; raw evidence retained')
