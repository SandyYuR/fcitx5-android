SELECT upid,pid,name FROM process WHERE pid=2031
