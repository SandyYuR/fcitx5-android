SELECT s.ts,s.dur,s.utid FROM sched s JOIN thread t USING(utid) WHERE t.upid=124 AND s.dur>0 ORDER BY s.ts
