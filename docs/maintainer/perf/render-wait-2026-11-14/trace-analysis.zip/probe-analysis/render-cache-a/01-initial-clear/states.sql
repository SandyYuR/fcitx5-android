SELECT s.ts,s.dur,s.utid,s.state FROM thread_state s JOIN thread t USING(utid) WHERE t.upid=130 AND s.dur>0 ORDER BY s.ts
