SELECT utid,tid,name FROM thread WHERE upid=126
