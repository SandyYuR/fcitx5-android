SELECT upid,pid,name FROM process WHERE pid=3247
