SELECT s.id,s.ts,s.dur,s.name,s.parent_id,s.depth,t.utid,t.tid,t.name AS thread
 FROM slice s JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON t.utid=tt.utid
 WHERE t.upid=128 AND s.dur>0 AND (t.utid=408 OR
 (t.utid=205 AND (s.name GLOB 'Choreographer*' OR s.name IN
 ('postAndWait','DrawFrame','syncAndDrawFrame','layout','measure','RV OnLayout','RV OnMeasure'))))
 ORDER BY s.ts,s.dur DESC
