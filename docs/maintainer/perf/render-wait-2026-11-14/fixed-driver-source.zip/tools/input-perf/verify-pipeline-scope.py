#!/usr/bin/env python3
"""Freeze production scope independently of test overlays and source version metadata."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
plan = json.loads((root / 'tools/input-perf/pipeline-plan.json').read_text())
sources = plan['sources']
paths = ['app/src/main', 'app/src/fx', 'app/src/debug', 'app/src/release', 'direct-rime',
         'native', 'build-logic', 'gradle', 'app/build.gradle.kts', 'build.gradle.kts',
         'settings.gradle.kts', 'gradle.properties', 'prepare_personal_build.sh']
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])

changed = git('diff', '--name-only', sources['baseline'], sources['current'], '--', *paths).decode().splitlines()
if sorted(changed) != sorted(plan['production_files']):
    raise SystemExit('Unexpected production change: ' + repr(changed))
diff = git('diff', sources['baseline'], sources['current'], '--', *paths)
record = dict(sources=sources, compared_paths=paths, changed_paths=changed,
              diff_sha256=hashlib.sha256(diff).hexdigest(),
              native_engine_sdk_and_build_inputs_unchanged=True,
              generated_git_version_metadata_can_differ=True)
Path(sys.argv[1]).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
