#!/usr/bin/env python3
"""Require every full frontend and candidate pipeline oracle case on each exact product."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
from instrumentation_status import parse_status


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('apks', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--serial', required=True)
    parser.add_argument('--expected-avd-name', required=True)
    parser.add_argument('--allow-destructive-reset', action='store_true')
    args = parser.parse_args()
    if not args.allow_destructive_reset or not re.fullmatch(r'emulator-[0-9]+', args.serial):
        parser.error('Explicit disposable emulator authorization is required')
    if args.output.exists() and any(args.output.iterdir()):
        parser.error('Retain all previous evidence; output must be empty')
    args.output.mkdir(parents=True, exist_ok=True)
    root = Path(__file__).resolve().parents[2]
    plan = json.loads((root / 'tools/input-perf/pipeline-plan.json').read_text())
    products = json.loads((args.apks / 'products.json').read_text())
    if products['sources'] != plan['sources']:
        raise ValueError('Unexpected product source map')
    expected = set()
    for cls in plan['quality_classes']:
        source = root / 'app/src/androidTest/java' / (cls.replace('.', '/') + '.kt')
        names = re.findall(r'@Test\s+fun\s+(\w+)', source.read_text())
        if not names:
            raise ValueError('No source cases in ' + cls)
        expected.update((cls, name) for name in names if cls + '#' + name != plan['excluded_device_case'])

    def adb(*command, check=True, timeout=240):
        result = subprocess.run(['adb', '-s', args.serial, *command], text=True,
                                capture_output=True, timeout=timeout)
        if check and result.returncode:
            raise RuntimeError('ADB failed: ' + repr(command) + '\n' + result.stdout + result.stderr)
        return result

    if (adb('emu', 'avd', 'name').stdout.splitlines()[0].strip() != args.expected_avd_name or
            adb('shell', 'id', '-u').stdout.strip() != '0'):
        raise ValueError('This is not the declared rooted disposable AVD')
    for name, digest in products['apks'].items():
        if hashlib.sha256((args.apks / name).read_bytes()).hexdigest() != digest:
            raise ValueError('Product artifact checksum mismatch')
    package = products['packages']['baseline.apk']
    test_package = package + '.test'
    if not package.endswith('.debug') or any(products['packages'][label + '.apk'] != package for label in plan['sources']):
        raise ValueError('Unexpected or mixed product package identity')
    for name in (package, test_package):
        if adb('shell', 'pm', 'path', name, check=False).stdout.strip():
            raise ValueError('Refusing to adopt an already installed package')
    owned, results = set(), []
    try:
        for label, source in [('current', plan['sources']['current'])]:
            for suffix in ('.apk', '-tests.apk'):
                name = label + suffix
                adb('install', str(args.apks / name))
                owned.add(products['packages'][name])
            classes = ','.join(plan['quality_classes'])
            result = adb('shell', 'am', 'instrument', '-w', '-r', '-e', 'class', classes, '-e', 'notClass', plan['excluded_device_case'],
                         test_package + '/androidx.test.runner.AndroidJUnitRunner', check=False, timeout=1200)
            raw = result.stdout + result.stderr
            (args.output / (label + '-instrumentation.txt')).write_text(raw)
            (args.output / (label + '-logcat.txt')).write_text(adb('logcat', '-d', '-v', 'threadtime').stdout)
            if result.returncode:
                raise ValueError('Instrumentation process failed: ' + label)
            cases = parse_status(raw)
            suite = ET.Element('testsuite', name=label, tests=str(len(cases)),
                               failures=str(sum(c['status_code'] == -2 for c in cases)),
                               errors=str(sum(c['status_code'] not in (0, -2) for c in cases)), skipped='0')
            for case in cases:
                item = ET.SubElement(suite, 'testcase', classname=case['class'], name=case['test'])
                if case['status_code']:
                    ET.SubElement(item, 'failure' if case['status_code'] == -2 else 'error').text = case.get('stack', '')
            ET.ElementTree(suite).write(args.output / (label + '-junit.xml'), encoding='utf-8', xml_declaration=True)
            if (len(cases) != len(expected) or {(c['class'], c['test']) for c in cases} != expected or
                    any(c['status_code'] != 0 for c in cases)):
                raise ValueError('Missing, skipped or failing device case in ' + label)
            results.append(dict(label=label, source=source, cases=cases))
            for name in (test_package, package):
                adb('uninstall', name)
                owned.remove(name)
        (args.output / 'quality-summary.json').write_text(json.dumps(dict(status='pass',
            cases_per_product=len(expected), total_passes=len(expected) * len(results),
            failures_errors_skipped=0, results=results, products=products), indent=2) + '\n')
        print('Every declared device case passed for the exact current product')
    except Exception as error:
        (args.output / 'failure.json').write_text(json.dumps(dict(error=str(error), completed_products=results), indent=2) + '\n')
        raise
    finally:
        for name in (test_package, package):
            if name in owned:
                adb('uninstall', name, check=False)


if __name__ == '__main__':
    main()
