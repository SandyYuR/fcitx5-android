"""Validate the diagnostic's file/ownership boundary without contacting a device."""
import importlib.util
from pathlib import Path
from types import SimpleNamespace
import unittest

spec = importlib.util.spec_from_file_location('render_cache_probe', Path(__file__).with_name('run-render-cache-probe.py'))
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


class CacheProbeTest(unittest.TestCase):
    def test_streaming_trace_has_periodic_producer_flush(self):
        config = probe.owned.trace_config()
        self.assertIn('write_into_file: true', config)
        self.assertIn('file_write_period_ms: 1000', config)
        self.assertEqual(config.count('flush_period_ms:'), 1)
        self.assertIn('flush_period_ms: 1000', config)

    def test_inventory_rejects_truncation_duplicates_and_unexpected_paths(self):
        path = probe.CACHE_PATHS[0]
        entry = 'a' * 64 + '  ' + path + '\n123\n'
        self.assertEqual(probe.parse_cache(entry), [dict(path=path, sha256='a' * 64, bytes=123)])
        for broken in (entry.splitlines()[0], entry + entry, entry.replace(path, '/data/other/file'),
                       entry.replace('123', '-1'), entry.replace('a' * 64, 'x' * 64)):
            with self.subTest(broken=broken), self.assertRaises(ValueError):
                probe.parse_cache(broken)

    def test_removal_requires_acquired_package_ownership(self):
        device = probe.Device(SimpleNamespace(host=Path('/tmp/host.apk')), {})
        for active, owned in ((False, set()), (True, set()), (True, {probe.owned.HOST})):
            device.active = active
            device.initial = {'wakefulness': 'Awake'}
            device.owned = owned
            with self.subTest(active=active, owned=owned), self.assertRaises(ValueError):
                device.permit(probe.CACHE_COMMANDS[True])
        device.owned = {probe.PACKAGE}
        device.permit(probe.CACHE_COMMANDS[True])

    def test_only_fixed_shader_files_and_owned_injector_are_allowed(self):
        device = probe.Device(SimpleNamespace(host=Path('/tmp/host.apk')), {})
        device.active = True
        device.initial = {'wakefulness': 'Awake'}
        device.owned = {probe.PACKAGE}
        for command in (
            ('shell', 'run-as', probe.PACKAGE, 'rm', '-rf', 'cache'),
            ('shell', 'run-as', probe.PACKAGE, 'rm', 'files/userdb/LOCK'),
            ('shell', 'rm', '--', probe.DRIVER),
        ):
            with self.subTest(command=command), self.assertRaises(ValueError):
                device.permit(command)
        device.driver_owned = True
        device.permit(('shell', 'rm', '--', probe.DRIVER))
        with self.assertRaises(ValueError):
            device.permit(('shell', 'rm', '--', probe.DRIVER + '.other'))


if __name__ == '__main__':
    unittest.main()
