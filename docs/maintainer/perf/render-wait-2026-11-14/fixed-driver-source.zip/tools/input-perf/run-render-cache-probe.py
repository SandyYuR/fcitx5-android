#!/usr/bin/env python3
"""Diagnostic only: exact current APK, fresh processes, retained/removed shader files.

This is not a product comparison. Rime learning and other app/host caches persist
after the one fixture preparation. Only four explicitly named app-owned shader
files can be removed; neither app data nor databases are cleared between samples.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import shlex
import time
import uuid


ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('owned_render_probe', ROOT / 'run-isolated-study.py')
owned = importlib.util.module_from_spec(spec)
spec.loader.exec_module(owned)
# Reuse the ownership/restore machinery with this exact, already-built package.
owned.PACKAGE = PACKAGE = 'org.fcitx.fcitx5.android.fx.rime.debug'
owned.TEST_PACKAGE = TEST_PACKAGE = PACKAGE + '.test'
owned.PACKAGES = frozenset((PACKAGE, TEST_PACKAGE, owned.HOST))
owned.COMPONENT = PACKAGE + '/org.fcitx.fcitx5.android.input.FcitxInputMethodService'
PROTOCOL = 'external_process_input_manager_phase_v3'
SOURCE = 'f02bbaec1c2820545382dab82b3e007e9f2735fe'
MANIFEST_SHA = '9a929c82d6a9f2911fd32d3cf2cfb34cd1d9902703a85f5e9520e974fbf47c1b'
DRIVER = '/data/local/tmp/pr32-touch-driver.apk'
CACHE_PATHS = tuple(f'/data/{storage}/0/{PACKAGE}/cache/com.android.{kind}.shaders_cache'
                    for storage in ('user_de', 'user') for kind in ('skia', 'opengl'))


def cache_script(clear=False):
    paths = ' '.join(shlex.quote(path) for path in CACHE_PATHS)
    # Refuse links/directories and never recursively remove a cache directory.
    action = 'rm -- "$cache_file"' if clear else 'sha256sum "$cache_file"; wc -c < "$cache_file"'
    return (f'for cache_file in {paths}; do '
            'if [ -L "$cache_file" ]; then exit 72; fi; '
            'if [ -e "$cache_file" ] && [ ! -f "$cache_file" ]; then exit 73; fi; '
            f'if [ -f "$cache_file" ]; then {action}; fi; done')


CACHE_COMMANDS = {clear: ('shell', 'run-as', PACKAGE, 'sh', '-c', shlex.quote(cache_script(clear)))
                  for clear in (False, True)}


def parse_cache(text):
    lines = text.splitlines()
    if len(lines) % 2:
        raise ValueError('Incomplete shader cache inventory')
    records = []
    for index in range(0, len(lines), 2):
        match = re.fullmatch(r'([a-f0-9]{64})\s+(.+)', lines[index])
        if not match or match[2] not in CACHE_PATHS or not lines[index + 1].strip().isdigit():
            raise ValueError('Unexpected shader cache inventory')
        records.append(dict(path=match[2], sha256=match[1], bytes=int(lines[index + 1])))
    if len({item['path'] for item in records}) != len(records):
        raise ValueError('Duplicate shader cache entry')
    return records


class Device(owned.OwnedDevice):
    driver_owned = False

    def permit(self, parts):
        p = tuple(map(str, parts))
        if p in {('shell', 'test', '-e', DRIVER), ('shell', 'sha256sum', DRIVER)}:
            return
        if self.active and PACKAGE in self.owned:
            if p in CACHE_COMMANDS.values():
                return
            if p == ('push', str(self.args.host.resolve()), DRIVER) and self.driver_owned:
                return
            if p in {('shell', 'chmod', '444', DRIVER), ('shell', 'rm', '--', DRIVER)} and self.driver_owned:
                return
        super().permit(parts)

    def inventory(self):
        return parse_cache(self.call(*CACHE_COMMANDS[False]).stdout)

    def stop_product(self):
        self.call('shell', 'am', 'force-stop', PACKAGE)
        deadline = time.monotonic() + 10
        while self.call('shell', 'pidof', PACKAGE, check=False).stdout.strip():
            if time.monotonic() >= deadline:
                raise RuntimeError('Refuse cache mutation while product process is alive')
            time.sleep(0.05)


def preflight(args):
    if not args.allow_owned_test_apps or not re.fullmatch(r'emulator-\d+', args.serial):
        raise ValueError('Explicit authorization and emulator serial required')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+', args.expected_avd_name):
        raise ValueError('Exact AVD name required')
    if args.output.exists() and any(args.output.iterdir()):
        raise ValueError('Preserve previous evidence; output must be empty')
    if owned.digest(args.apks / 'products.json') != MANIFEST_SHA:
        raise ValueError('Only the exact previously verified product manifest is accepted')
    products = json.loads((args.apks / 'products.json').read_text())
    if (products['sources']['current'] != SOURCE or products['protocol'] != PROTOCOL or
            products['harness_sha256'] != owned.digest(ROOT / 'CadenceCandidateTapTest.kt')):
        raise ValueError('Product/probe identity changed')
    for name, digest in products['apks'].items():
        if owned.digest(args.apks / name) != digest:
            raise ValueError('APK hash mismatch: ' + name)
    if owned.digest(args.host) != products['host_sha256']:
        raise ValueError('Host APK hash mismatch')
    fixture = json.loads(args.fixture_manifest.read_text())
    if fixture['fixture_sha256'] != owned.FIXTURE_SHA256 or owned.digest(args.fixture) != owned.FIXTURE_SHA256:
        raise ValueError('Fixture identity changed')
    installs = {str((args.apks / name).resolve()): dict(package=products['packages'][name], sha256=products['apks'][name])
                for name in ('current.apk', 'current-tests.apk')}
    if {item['package'] for item in installs.values()} != {PACKAGE, TEST_PACKAGE}:
        raise ValueError('Unexpected APK packages')
    installs[str(args.host.resolve())] = dict(package=owned.HOST, sha256=products['host_sha256'])
    # The pinned hashes reuse the signed APK identity and successful 56-case QA;
    # the workflow additionally verifies those exact QA records before this job.
    return products, fixture, installs


def run(args):
    products, fixture, installs = preflight(args)
    device = Device(args, installs)
    device.initialize()
    trace = None
    samples = []
    conditions = (['initial-clear', 'keep', 'clear', 'keep'] if args.sequence == 'a'
                  else ['initial-clear', 'clear', 'keep', 'clear'])
    plan = dict(diagnostic_only=True, source=SOURCE, conditions=conditions, protocol=PROTOCOL,
                cache_paths=CACHE_PATHS, traced=True, fixture_sha256=owned.FIXTURE_SHA256,
                script_sha256=owned.digest(Path(__file__)), fresh_process_each_sample=True,
                fixture_prepared_once=True, learning_and_other_caches='retained; not a performance ranking',
                primary='RenderThread sync durations and their overlap with main postAndWait',
                no_product_rebuild=True, no_warmup_typing=True)
    owned.save(args.output / 'plan.json', plan)
    owned.save(args.output / 'products.json', products)
    owned.save(args.output / 'fixture.manifest.json', fixture)
    error = None
    cleanup_errors = []
    try:
        device.wake_for_study()
        if device.call('shell', 'test', '-e', DRIVER, check=False).returncode != 1:
            raise RuntimeError('Driver path must be absent before this run owns it')
        device.call('shell', 'setprop', owned.PROPERTY, 'true')
        device.call('shell', 'settings', 'put', 'secure', 'show_ime_with_hard_keyboard', '1')
        device.call('shell', 'settings', 'put', 'system', 'screen_off_timeout', '1800000')
        (args.output / 'device-properties.txt').write_text(device.call('shell', 'getprop').stdout)
        for path in (args.host, args.apks / 'current.apk', args.apks / 'current-tests.apk'):
            device.install(path)
        device.driver_owned = True
        device.call('push', str(args.host.resolve()), DRIVER)
        device.call('shell', 'chmod', '444', DRIVER)
        if device.call('shell', 'sha256sum', DRIVER).stdout.split()[0] != products['host_sha256']:
            raise RuntimeError('Device shell injector hash differs')
        device.call('shell', 'run-as', PACKAGE, 'mkdir', '-p', 'files')
        with args.fixture.open('rb') as stream:
            device.call('exec-in', 'run-as', PACKAGE, 'sh', '-c', 'cat > files/candidate-fixture.zip', stdin=stream, timeout=180)
        device.instrument('prepare', SOURCE, args.output / 'prepare')
        for position, condition in enumerate(conditions, 1):
            output = args.output / f'{position:02d}-{condition}'
            output.mkdir()
            prefix = output / 'current'
            device.call('shell', 'am', 'force-stop', owned.HOST)
            device.call('shell', 'pm', 'clear', owned.HOST)
            device.stop_product()
            before = device.inventory()
            if condition != 'keep':
                device.call(*CACHE_COMMANDS[True])
            pre_replay = device.inventory()
            if condition != 'keep' and pre_replay:
                raise RuntimeError('Shader cache removal did not complete')
            if condition == 'keep' and pre_replay != before:
                raise RuntimeError('Stopped-process shader cache unexpectedly changed')
            cache = dict(before=before, pre_replay=pre_replay,
                         removal_had_nonempty_target=any(item['bytes'] > 0 for item in before) if condition != 'keep' else None)
            owned.save(output / 'cache.json', cache)
            remote = '/data/misc/perfetto-traces/pr32-isolated-' + uuid.uuid4().hex + '.perfetto-trace'
            device.trace_paths.add(remote)
            config = owned.trace_config()
            (output / 'trace-config.txt').write_text(config)
            pid = device.call('shell', 'perfetto', '--background-wait', '--txt', '-c', '-', '-o', remote, input=config).stdout.strip()
            if not re.fullmatch(r'\d+', pid):
                raise RuntimeError('Perfetto did not return a PID')
            device.trace_pids.add(pid)
            trace = (pid, remote, prefix.with_suffix('.perfetto-trace'))
            device.instrument('replay', SOURCE, prefix)
            ime = device.call('shell', 'run-as', PACKAGE, 'cat', 'files/candidate-taps.json').stdout
            device.call('shell', 'am', 'broadcast', '-n', owned.HOST + '/.BenchControl', '--es', 'command', 'dump')
            editor = device.call('shell', 'run-as', owned.HOST, 'cat', 'files/candidate-editor.json').stdout
            raw = dict(ime=json.loads(ime), editor=json.loads(editor))
            owned.save(prefix.with_suffix('.json'), raw)
            sample = dict(position=position, condition=condition, source=SOURCE,
                          raw=str(prefix.with_suffix('.json').relative_to(args.output)),
                          measurements=owned.study_module().measurements(raw, SOURCE, PROTOCOL))
            samples.append(sample)
            owned.save(args.output / 'samples.json', samples)
            owned.retain_trace(device, *trace)
            trace = None
            cache['after_replay'] = device.inventory()
            owned.save(output / 'cache.json', cache)
            print(json.dumps(dict(condition=condition, completed=len(samples), cache=cache)), flush=True)
    except BaseException as caught:
        error = caught
        owned.save(args.output / 'failure.json', dict(error=repr(caught), completed=len(samples)))
        device.retain_failed_raw()
    finally:
        if trace:
            try:
                owned.retain_trace(device, *trace)
            except BaseException as caught:
                cleanup_errors.append(dict(action='retain trace', error=repr(caught)))
        if device.driver_owned:
            try:
                device.call('shell', 'rm', '--', DRIVER)
                if device.call('shell', 'test', '-e', DRIVER, check=False).returncode != 1:
                    raise RuntimeError('Owned injector file remains')
            except BaseException as caught:
                cleanup_errors.append(dict(action='remove owned injector', error=repr(caught)))
        cleanup_errors.extend(device.cleanup())
        owned.save(args.output / 'probe-cleanup.json', dict(errors=cleanup_errors))
    if error or cleanup_errors:
        raise RuntimeError(f'Probe failed: {error!r}; cleanup errors: {cleanup_errors!r}') from error
    owned.save(args.output / 'summary.json', dict(plan=plan, completed_samples=len(samples), selection_count=6 * len(samples)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ('apks', 'fixture', 'fixture-manifest', 'host', 'output'):
        parser.add_argument('--' + option, type=Path, required=True)
    parser.add_argument('--serial', required=True)
    parser.add_argument('--expected-avd-name', required=True)
    parser.add_argument('--allow-owned-test-apps', action='store_true')
    parser.add_argument('--sequence', choices=['a', 'b'], required=True)
    run(parser.parse_args())
