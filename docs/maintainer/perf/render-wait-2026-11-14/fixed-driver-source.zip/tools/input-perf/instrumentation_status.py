"""Raw AndroidJUnitRunner status parser, shared by isolated quality checks."""
def parse_status(text):
    """Parse AndroidJUnitRunner raw status packets, including stack continuations."""
    events, packet, last_key = [], {}, None
    for line in text.splitlines():
        if line.startswith('INSTRUMENTATION_STATUS: '):
            field = line.removeprefix('INSTRUMENTATION_STATUS: ')
            key, sep, value = field.partition('=')
            if sep:
                packet[key], last_key = value, key
        elif line.startswith('INSTRUMENTATION_STATUS_CODE: '):
            code = int(line.removeprefix('INSTRUMENTATION_STATUS_CODE: '))
            if code != 1 and packet.get('test') and packet.get('class'):
                events.append(dict(packet, status_code=code))
            packet, last_key = {}, None
        elif line.startswith('INSTRUMENTATION_'):
            last_key = None
        elif last_key:
            packet[last_key] += '\n' + line
    if 'INSTRUMENTATION_CODE: -1' not in text or 'INSTRUMENTATION_FAILED:' in text:
        raise ValueError('The instrumentation process did not finish normally')
    if not events:
        raise ValueError('No executed test case results')
    return events
