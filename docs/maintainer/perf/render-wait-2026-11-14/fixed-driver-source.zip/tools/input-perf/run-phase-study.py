#!/usr/bin/env python3
"""Independent-process injector, two fixed key gaps, and verified comment paths.

Temporary diagnostic study on the explicitly named disposable Actions AVD only.
Each condition retains its own plan, raw samples and summary. No pooling across gaps.
"""
import argparse
import json
import os
from pathlib import Path
import random
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('apks', 'fixture', 'fixture-manifest', 'host', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--serial', required=True)
    parser.add_argument('--expected-avd-name', required=True)
    parser.add_argument('--allow-destructive-reset', action='store_true')
    parser.add_argument('--mode', choices=['pilot', 'formal'], required=True)
    parser.add_argument('--order', required=True)
    parser.add_argument('--seed', type=int, required=True)
    parser.add_argument('--blocks', type=int, required=True)
    parser.add_argument('--profile', action='store_true')
    parser.add_argument('--gap-set', choices=['all', '100', '300'], default='all')
    parser.add_argument('--comment-set', choices=['visible', 'all'], default='visible')
    args = parser.parse_args()
    if not args.allow_destructive_reset or (args.profile and args.mode != 'pilot'):
        parser.error('Explicit disposable AVD authorization is required; trace is pilot only')
    if args.output.exists() and any(args.output.iterdir()):
        parser.error('Preserve all previous results: output must be empty')
    gaps = [100, 300] if args.gap_set == 'all' else [int(args.gap_set)]
    comment_modes = ['visible'] if args.comment_set == 'visible' else ['visible', 'hidden']
    conditions = [(gap, comments) for gap in gaps for comments in comment_modes]
    random.Random(args.seed).shuffle(conditions)
    args.output.mkdir(parents=True, exist_ok=True)
    plan = dict(seed=args.seed, conditions=conditions, order=args.order, mode=args.mode,
                blocks=args.blocks, profile=args.profile, gap_set=args.gap_set, comment_set=args.comment_set, injector='independent shell app_process',
                hypothesis='Whole input-chain review: defer gesture-only splitting and remove duplicate candidate delivery',
                primary='First actual i injection DOWN to window UP; paired products within condition',
                control='Pinned products with identical SDK, fixture, host, test overlay and shell driver')
    (args.output / 'phase-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    for index, (gap, comments) in enumerate(conditions):
        output = args.output / f'gap-{gap}-{comments}'
        command = [sys.executable, str(Path(__file__).with_name('run-study.py'))]
        for name in ('apks', 'fixture', 'fixture_manifest', 'host', 'serial', 'expected_avd_name', 'mode', 'order', 'blocks'):
            command.extend(['--' + name.replace('_', '-'), str(getattr(args, name))])
        command.extend(['--output', str(output), '--seed', str(args.seed + index), '--allow-destructive-reset'])
        if args.profile:
            command.append('--profile')
        environment = dict(os.environ, PR32_PHASE_GAP_MS=str(gap), PR32_PHASE_COMMENTS=comments)
        print(json.dumps({'condition': output.name, 'traced': args.profile}), flush=True)
        subprocess.run(command, env=environment, check=True, timeout=2400)


if __name__ == '__main__':
    main()
