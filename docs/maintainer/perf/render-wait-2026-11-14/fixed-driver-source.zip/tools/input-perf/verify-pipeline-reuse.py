#!/usr/bin/env python3
"""Resume pre-sampling checkout failure with exact run 43408540911 products/QA."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

products_dir, quality_dir = map(Path, sys.argv[1:])
root = Path(__file__).resolve().parents[2]
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(products_dir / 'products.json') == '9a929c82d6a9f2911fd32d3cf2cfb34cd1d9902703a85f5e9520e974fbf47c1b'
assert digest(quality_dir / 'quality-summary.json') == '6b615d0a3d1ec2f527626a9fb4ca5d645861a410968dc59c18bc52e5b4e672ec'
products = json.loads((products_dir / 'products.json').read_text())
quality = json.loads((quality_dir / 'quality-summary.json').read_text())
plan = json.loads((root / 'tools/input-perf/pipeline-plan.json').read_text())
assert products['sources'] == plan['sources'] and quality['products'] == products
assert products['driver_commit'] == 'b070c2b7b0d9a3ca446e444204408f11717dbe2f'
assert json.loads((products_dir / 'pipeline-plan.json').read_text()) == plan
for label, source in plan['sources'].items():
    subprocess.run(['git', '-C', str(root), 'cat-file', '-e', source + '^{commit}'], check=True)
    assert (products_dir / (label + '-commit.txt')).read_text().strip() == source
for name, sha in products['apks'].items():
    assert digest(products_dir / name) == sha, name
assert digest(products_dir / 'host.apk') == products['host_sha256']
expected = set()
for cls, sha in products['contract_classes_sha256'].items():
    path = 'app/src/androidTest/java/' + cls.replace('.', '/') + '.kt'
    source = subprocess.check_output(['git', '-C', str(root), 'show', plan['sources']['current'] + ':' + path])
    assert hashlib.sha256(source).hexdigest() == sha
    expected.update(cls + '#' + name for name in re.findall(r'@Test\s+fun\s+(\w+)', source.decode())
                    if cls + '#' + name != plan['excluded_device_case'])
assert quality['status'] == 'pass' and quality['failures_errors_skipped'] == 0
assert quality['total_passes'] == len(expected) == 56 and len(quality['results']) == 1
row = quality['results'][0]
assert row['label'] == 'current' and row['source'] == plan['sources']['current']
assert len(row['cases']) == 56 and all(c['status_code'] == 0 for c in row['cases'])
assert {c['class'] + '#' + c['test'] for c in row['cases']} == expected
cases = list(ET.parse(quality_dir / 'current-junit.xml').getroot().iter('testcase'))
assert len(cases) == 56 and not any(child.tag in ('failure', 'error', 'skipped') for c in cases for child in c)
assert {c.attrib['classname'] + '#' + c.attrib['name'] for c in cases} == expected
print('Reused exact four APKs and host from run 43408540911; all 56 device cases verified; no product rebuilt')
