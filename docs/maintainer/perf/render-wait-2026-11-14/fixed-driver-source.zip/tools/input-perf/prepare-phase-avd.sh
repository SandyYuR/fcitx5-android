#!/usr/bin/env bash
# Device setup only; invoke as one emulator-runner script command.
set -euo pipefail
serial=${1:?explicit disposable emulator serial required}
[[ "$serial" =~ ^emulator-[0-9]+$ ]] || { echo 'Expected an explicit test emulator serial' >&2; exit 2; }
for attempt in 1 2 3 4 5; do
    timeout 30 adb -s "$serial" wait-for-device
    if adb -s "$serial" root; then break; fi
    sleep 1
done
timeout 30 adb -s "$serial" wait-for-device
actual_uid=$(adb -s "$serial" shell id -u | tr -d '\r')
[[ "$actual_uid" = 0 ]] || { echo "Test AVD did not become root: $actual_uid" >&2; exit 1; }
