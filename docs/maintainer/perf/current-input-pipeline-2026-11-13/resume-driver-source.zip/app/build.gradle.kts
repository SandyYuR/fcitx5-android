import org.gradle.api.tasks.testing.Test

plugins {
    id("org.fcitx.fcitx5.android.app-convention")
    id("org.fcitx.fcitx5.android.native-app-convention")
    id("org.fcitx.fcitx5.android.build-metadata")
    id("org.fcitx.fcitx5.android.data-descriptor")
    alias(libs.plugins.kotlin.parcelize)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
}

val packageBase = "org.fcitx.fcitx5.android"
val flavorFx = "fx"
val imeSettingsActivity = "$packageBase.ui.main.MainActivity"
val inputDiagnostics = providers.gradleProperty("inputDiagnostics").orNull == "true"

android {
    namespace = packageBase

    defaultConfig {
        applicationId = "org.fcitx.fcitx5.android.fx.rime"
        buildConfigField("boolean", "INPUT_DIAGNOSTICS", inputDiagnostics.toString())
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        manifestPlaceholders["appLabel"] = "@string/direct_rime_app_name"
        resValue("string", "ime_settings_activity", imeSettingsActivity)

        @Suppress("UnstableApiUsage")
        externalNativeBuild {
            cmake {
                arguments("-DINPUT_DIAGNOSTICS=${if (inputDiagnostics) "ON" else "OFF"}")
                targets("direct-rime")
            }
        }
    }

    flavorDimensions += "brand"
    productFlavors {
        create(flavorFx) {
            dimension = "brand"
            buildConfigField("boolean", "IS_FX_BUILD", "true")
        }
    }

    buildFeatures {
        viewBinding = true
        resValues = true
        prefab = false
    }
    externalNativeBuild.cmake.path = file("../direct-rime/src/main/cpp/CMakeLists.txt")

    buildTypes {
        release {
            resValue("mipmap", "app_icon", "@mipmap/ic_launcher")
            resValue("mipmap", "app_icon_round", "@mipmap/ic_launcher_round")
            resValue("string", "app_name", "中州鹅")
            proguardFile("proguard-rules.pro")
        }
        debug {
            resValue("mipmap", "app_icon", "@mipmap/ic_launcher_debug")
            resValue("mipmap", "app_icon_round", "@mipmap/ic_launcher_round_debug")
            resValue("string", "app_name", "中州鹅")
        }
    }


    sourceSets.getByName("main").kotlin.srcDir("../direct-rime/src/engine/java")
    sourceSets.getByName("androidTest").assets.srcDir("../direct-rime/src/main/assets")

    androidResources {
        @Suppress("UnstableApiUsage")
        generateLocaleConfig = true
    }

    testOptions {
        unitTests {
            isIncludeAndroidResources = true
            // Let JVM unit tests exercise code that logs via android.util.Log: the stubbed
            // android.jar otherwise throws "Stub!" on every call. Framework layout
            // regressions use Robolectric; parser and validator tests use the stubs.
            isReturnDefaultValues = true
        }
    }
}

tasks.withType<Test>().configureEach {
    // Robolectric retains framework resource tables for each SDK sandbox.
    // Give the serial worker enough heap to load another Android resource
    // archive near the end of the full suite.
    maxHeapSize = "1536m"
    maxParallelForks = 1
}

run {
    val directAssets = layout.buildDirectory.dir("generated/direct-assets")
    val prepareDirectRimeAssets = tasks.register<Sync>("prepareDirectRimeAssets") {
        dependsOn(rootProject.tasks.named("prepareRimeSdk"))
        into(directAssets)
        from("src/main/assets") { exclude("usr/**", "descriptor.json") }
        into("usr/share/rime-data") {
            from(rootProject.file("native/rime-data"))
            from(rootProject.file("native/rime-prelude")) { include("key_bindings.yaml", "punctuation.yaml", "symbols.yaml") }
        }
        into("usr/share/opencc") { from(rootProject.file("native/rime-sdk/opencc/data")) }
    }
    android.sourceSets.getByName("main").assets.setSrcDirs(listOf(directAssets))
    tasks.named<DataDescriptorPlugin.DataDescriptorTask>("generateDataDescriptor") {
        dependsOn(prepareDirectRimeAssets)
        inputDir.set(directAssets)
        outputFile.set(directAssets.map { it.file("descriptor.json") })
    }
}

generateDataDescriptor {
    // rime-data ships its own copy of opencc data; link it to the shared one
    symlinks.put("usr/share/rime-data/opencc", "usr/share/opencc")
    // 内置布局/主题/图标主题/符号面板数据只随 APK 分发、由 BundledPresets 在运行时解包到
    // 外部存储，不参与 dataDir 资源同步（避免占用 data 目录且保持清单驱动）。
    // 符号 catalog 由 SymbolCatalogs 直接从 assets 读取，不落盘到 data 目录。
    excludes.addAll(
        listOf(
            "clearurls", // Host-only catalog/licenses; read from APK, never copied to Rime data.
            "bundled",
            "bundled/keyboard_layouts",
            "bundled/keyboard_layouts/PopupPreset.json",
            "bundled/themes",
            "bundled/icon_themes",
            "bundled/symbols",
            "bundled/symbols/symbols.json",
            "bundled/symbols/emoji.json",
            "bundled/symbols/kaomoji.json"
        )
    )
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    ksp(project(":codegen"))
    implementation(project(":lib:common"))
    implementation(libs.kotlinx.coroutines)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.autofill)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.coordinatorlayout)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.viewmodel)
    implementation(libs.androidx.lifecycle.livedata)
    implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.lifecycle.service)
    implementation(libs.androidx.navigation.fragment)
    implementation(libs.androidx.navigation.ui)
    implementation(libs.androidx.paging)
    implementation(libs.androidx.preference)
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation(libs.androidx.recyclerview)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // 2.12 requires API 24; keep this app's API 23 support.
    implementation("androidx.work:work-runtime-ktx:2.11.2")
    ksp(libs.androidx.room.compiler)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    implementation(libs.androidx.room.paging)
    implementation(libs.androidx.startup)
    implementation("androidx.profileinstaller:profileinstaller:1.4.1")
    implementation(libs.androidx.tracing.ktx)
    // 1.6.0+ snapshots child transitions before resuming them, avoiding mutation crashes.
    implementation(libs.androidx.transition)
    implementation(libs.androidx.viewpager2)
    implementation(libs.material)
    // Fragment 1.7+ is required for seekable predictive-back fragment animators.
    implementation(libs.androidx.fragment)
    implementation(libs.arrow.core)
    implementation(libs.arrow.functions)
    implementation(libs.imagecropper)
    implementation(libs.flexbox)
    implementation(libs.dependency)
    implementation(libs.timber)
    implementation(libs.splitties.bitflags)
    implementation(libs.splitties.dimensions)
    implementation(libs.splitties.resources)
    implementation(libs.splitties.views.dsl)
    implementation(libs.splitties.views.dsl.appcompat)
    implementation(libs.splitties.views.dsl.constraintlayout)
    implementation(libs.splitties.views.dsl.coordinatorlayout)
    implementation(libs.splitties.views.dsl.recyclerview)
    implementation(libs.splitties.views.recyclerview)
    implementation(libs.aboutlibraries.core)
    implementation(libs.zxing.core)
    implementation(libs.zxing.embedded)
    implementation(libs.xz)
    implementation("org.apache.commons:commons-compress:1.27.1")
    implementation("org.yaml:snakeyaml:2.7")
    implementation(libs.androidsvg)
    implementation(libs.quickjs.kt)
    testImplementation(libs.junit)
    testImplementation("org.robolectric:robolectric:4.17")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
    testImplementation("com.squareup.okhttp3:okhttp-tls:4.12.0")
    testImplementation("androidx.work:work-testing:2.11.2")
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(libs.androidx.test.rules)
    androidTestImplementation(libs.androidx.lifecycle.testing)
    androidTestImplementation(libs.junit)
}

configurations {
    all {
        // remove unwanted splitties libraries...
        exclude(group = "com.louiscad.splitties", module = "splitties-appctx")
        exclude(group = "com.louiscad.splitties", module = "splitties-systemservices")
    }
}

// Android 变体的 QuickJS 只带 .so，桌面 JVM 单测加载不了它（见 JsVoiceBridgeContractTest）。
// 只在**单元测试**的配置上换成带桌面原生库的 jvm 变体：APK 仍然打包 android 变体，
// 生产依赖与打出来的包都不受影响。
configurations.matching {
    it.name.endsWith("UnitTestRuntimeClasspath") || it.name.endsWith("UnitTestCompileClasspath")
}.configureEach {
    resolutionStrategy.dependencySubstitution {
        substitute(module("io.github.dokar3:quickjs-kt"))
            .using(module("io.github.dokar3:quickjs-kt-jvm:" + libs.versions.quickjs.kt.get()))
    }
}
