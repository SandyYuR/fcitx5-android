/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2024 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.input.candidates.expanded

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.drawable.Drawable
import android.view.Gravity
import androidx.constraintlayout.widget.ConstraintLayout
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.data.theme.Theme
import org.fcitx.fcitx5.android.data.theme.ThemeManager
import org.fcitx.fcitx5.android.input.keyboard.BackspaceKey
import org.fcitx.fcitx5.android.input.keyboard.BaseKeyboard
import org.fcitx.fcitx5.android.input.keyboard.ImageKeyView
import org.fcitx.fcitx5.android.input.keyboard.ImageLayoutSwitchKey
import org.fcitx.fcitx5.android.input.keyboard.KeyDef
import org.fcitx.fcitx5.android.input.keyboard.ReturnKey
import org.fcitx.fcitx5.android.utils.setVerticalScrollbarThumbColor
import org.fcitx.fcitx5.android.utils.singleSideBorderDrawable
import splitties.dimensions.dp
import splitties.views.backgroundColor
import splitties.views.dsl.constraintlayout.above
import splitties.views.dsl.constraintlayout.bottomOfParent
import splitties.views.dsl.constraintlayout.centerHorizontally
import splitties.views.dsl.constraintlayout.constraintLayout
import splitties.views.dsl.constraintlayout.lParams
import splitties.views.dsl.constraintlayout.leftOfParent
import splitties.views.dsl.constraintlayout.leftToRightOf
import splitties.views.dsl.constraintlayout.rightOfParent
import splitties.views.dsl.constraintlayout.rightToLeftOf
import splitties.views.dsl.constraintlayout.topOfParent
import splitties.views.dsl.core.add
import splitties.views.dsl.core.matchParent
import splitties.views.dsl.core.wrapContent
import splitties.views.dsl.recyclerview.recyclerView
import splitties.views.imageResource

@SuppressLint("ViewConstructor")
class ExpandedCandidateLayout(context: Context, theme: Theme) : ConstraintLayout(context) {

    class Keyboard(context: Context, theme: Theme) : BaseKeyboard(context, theme, { Layout }, { null }) {
        override fun currentLayoutSignature(): String = "ExpandedCandidate"

        companion object {
            const val UpBtnLabel = "U"
            const val DownBtnLabel = "D"

            const val UpBtnId = 0xff55
            const val DownBtnId = 0xff56

            val Layout: List<List<KeyDef>> = listOf(
                listOf(
                    ImageLayoutSwitchKey(
                        R.drawable.ic_baseline_arrow_upward_24,
                        to = UpBtnLabel,
                        percentWidth = 1f,
                        variant = KeyDef.Appearance.Variant.Alternative,
                        viewId = UpBtnId,
                        iconSlot = "keys.pageup"
                    )
                ),
                listOf(
                    ImageLayoutSwitchKey(
                        R.drawable.ic_baseline_arrow_downward_24,
                        to = DownBtnLabel,
                        percentWidth = 1f,
                        variant = KeyDef.Appearance.Variant.Alternative,
                        viewId = DownBtnId,
                        iconSlot = "keys.pagedown"
                    )
                ),
                listOf(BackspaceKey(percentWidth = 1f, KeyDef.Appearance.Variant.Alternative)),
                listOf(ReturnKey(percentWidth = 1f))
            )
        }

        val pageUpBtn: ImageKeyView? by lazy { findKeyViewById<ImageKeyView>(UpBtnId) }
        val pageDnBtn: ImageKeyView? by lazy { findKeyViewById<ImageKeyView>(DownBtnId) }
        val backspace: ImageKeyView? by lazy { findKeyViewById<ImageKeyView>(R.id.button_backspace) }
        val `return`: ImageKeyView? by lazy { findKeyViewById<ImageKeyView>(R.id.button_return) }

        override fun onReturnDrawableUpdate(returnDrawable: Int) {
            `return`?.img?.imageResource = returnDrawable
        }

        override fun onReturnDrawableOverride(drawable: Drawable?) {
            if (drawable != null) {
                `return`?.img?.setImageDrawable(drawable)
            }
        }
    }

    private val keyBorder by ThemeManager.prefs.keyBorder
    private val keyVerticalMargin by ThemeManager.prefs.keyVerticalMargin
    private val keyVerticalMarginLandscape by ThemeManager.prefs.keyVerticalMarginLandscape

    val recyclerView = recyclerView {
        // disable item cross-fade animation
        itemAnimator = null
        isVerticalScrollBarEnabled = false
    }

    val tabsContainer = constraintLayout()

    val scrollableTabs = recyclerView {
        itemAnimator = null
        // always show scrollbar
        isScrollbarFadingEnabled = false
        scrollBarSize = dp(1)
        setVerticalScrollbarThumbColor(theme.candidateTextColor)
    }

    val pinnedTabs = recyclerView {
        itemAnimator = null
        // prevent scrolling in pinned tabs at bottom
        overScrollMode = OVER_SCROLL_NEVER
        isNestedScrollingEnabled = false
        isVerticalScrollBarEnabled = false
    }

    var pageUpBtn: ImageKeyView? = null
    var pageDnBtn: ImageKeyView? = null

    val embeddedKeyboard = Keyboard(context, theme).also {
        pageUpBtn = it.pageUpBtn
        pageDnBtn = it.pageDnBtn
    }

    init {
        id = R.id.expanded_candidate_view

        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val inset = dp(if (landscape) keyVerticalMarginLandscape else keyVerticalMargin)
        tabsContainer.background =
            singleSideBorderDrawable(dp(1), theme.dividerColor, Gravity.RIGHT, inset)
        if (!keyBorder) {
            backgroundColor = theme.barColor
            embeddedKeyboard.background =
                singleSideBorderDrawable(dp(1), theme.dividerColor, Gravity.LEFT, inset)
        }

        add(tabsContainer, lParams {
            matchConstraintPercentWidth = 0.15f
            topOfParent()
            leftOfParent()
            bottomOfParent()
        })
        tabsContainer.apply {
            add(scrollableTabs, lParams(matchParent, 0) {
                topOfParent()
                centerHorizontally()
                above(pinnedTabs)
            })
            add(pinnedTabs, lParams(matchParent, wrapContent) {
                bottomOfParent()
                centerHorizontally()
            })
        }
        add(recyclerView, lParams {
            topOfParent()
            leftToRightOf(tabsContainer)
            rightToLeftOf(embeddedKeyboard)
            bottomOfParent()
        })
        add(embeddedKeyboard, lParams {
            matchConstraintPercentWidth = 0.15f
            topOfParent()
            leftToRightOf(recyclerView)
            rightOfParent()
            bottomOfParent()
        })
    }

    fun resetPosition() = resetPosition(0)

    /**
     * 回到列表中的 [position]。
     *
     * 滚动目标必须与 adapter 的 `offset`（= 已绑定数据的全局起点）一致，
     * 否则 `idx = position + offset` 会指向别的候选，点击/长按就会选错词。
     */
    fun resetPosition(position: Int) {
        recyclerView.scrollToPosition(position)
    }
}
