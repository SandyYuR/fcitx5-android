/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2025 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.ui.main

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.viewModels
import androidx.annotation.Keep
import androidx.lifecycle.Lifecycle
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import org.fcitx.fcitx5.android.BuildConfig
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.data.prefs.AppPrefs
import org.fcitx.fcitx5.android.data.theme.ThemeManager
import org.fcitx.fcitx5.android.databinding.ActivityMainBinding
import org.fcitx.fcitx5.android.ui.common.SettingsUiActivity
import org.fcitx.fcitx5.android.ui.main.settings.SettingsRoute
import org.fcitx.fcitx5.android.ui.setup.SetupActivity
import org.fcitx.fcitx5.android.utils.navigateWithAnim
import org.fcitx.fcitx5.android.utils.parcelable
import org.fcitx.fcitx5.android.utils.startActivity

class MainActivity : SettingsUiActivity() {

    private val viewModel: MainViewModel by viewModels()

    private lateinit var navController: NavController
    private lateinit var shareReceiveManager: ShareReceiveManager
    private val refreshKeyboardColors = Runnable {
        if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) refreshKeyboardPalette()
    }
    @Keep
    private val onKeyboardThemeChanged = ThemeManager.OnThemeChangeListener {
        // Leave the current preference/theme click callback before restoring the activity.
        window.decorView.removeCallbacks(refreshKeyboardColors)
        window.decorView.post(refreshKeyboardColors)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        navController = binding.navHostFragment.getFragment<NavHostFragment>().navController
        navController.graph = SettingsRoute.createGraph(navController)
        shareReceiveManager = ShareReceiveManager(this) { message, action ->
            Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).apply {
                action?.let { callback ->
                    setAction(R.string.edit) { callback() }
                }
            }.show()
        }
        processIntent(intent, savedInstanceState)
        checkNotificationPermission()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        processIntent(intent, null)
    }

    override fun onResume() {
        super.onResume()
        ThemeManager.addOnChangedListener(onKeyboardThemeChanged)
        window.decorView.post(refreshKeyboardColors)
    }

    override fun onPause() {
        ThemeManager.removeOnChangedListener(onKeyboardThemeChanged)
        window.decorView.removeCallbacks(refreshKeyboardColors)
        super.onPause()
    }

    override fun onSupportNavigateUp(): Boolean {
        // prevent navigate up when child fragment has enabled `OnBackPressedCallback`
        if (onBackPressedDispatcher.hasEnabledCallbacks()) {
            onBackPressedDispatcher.onBackPressed()
            return true
        }
        // "minimize" the activity if we can't go back
        return navController.navigateUp() || super.onSupportNavigateUp() || moveTaskToBack(false)
    }

    private fun processIntent(intent: Intent?, savedInstanceState: Bundle? = null) {
        val action = intent?.action ?: return
        when (action) {
            Intent.ACTION_MAIN -> if (SetupActivity.shouldShowUp()) {
                startActivity<SetupActivity>()
            }
            Intent.ACTION_RUN -> {
                // Restored navigation owns its destination. Only a fresh launch or a new
                // Intent should replay the shortcut that originally opened this activity.
                if (savedInstanceState != null) return
                val route = intent.parcelable<SettingsRoute>(EXTRA_SETTINGS_ROUTE) ?: return
                navController.popBackStack(SettingsRoute.Index, false)
                navController.navigateWithAnim(route)
            }
            Intent.ACTION_SEND, Intent.ACTION_SEND_MULTIPLE -> {
                shareReceiveManager.handle(intent, savedInstanceState)
            }
        }
    }

    private var needNotifications by AppPrefs.getInstance().internal.needNotifications

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                needNotifications = true
                return
            }
            // do not ask again if user denied the request
            if (!needNotifications) return
            // always show a dialog to explain why we need notification permission,
            // regardless of `shouldShowRequestPermissionRationale(...)`
            MaterialAlertDialogBuilder(this)
                .setIconAttribute(android.R.attr.alertDialogIcon)
                .setTitle(R.string.notification_permission_title)
                .setMessage(R.string.notification_permission_message)
                .setNegativeButton(R.string.i_do_not_need_it) { _, _ ->
                    // do not ask again if user denied the request
                    needNotifications = false
                }
                .setPositiveButton(R.string.grant_permission) { _, _ ->
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
                }
                .show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 0) return
        // do not ask again if user denied the request
        needNotifications = grantResults.getOrNull(0) == PackageManager.PERMISSION_GRANTED
    }

    override fun onStop() {
        // Persist non-Rime state without triggering Rime user-data synchronization.
        viewModel.fcitx.runIfReady {
            saveNonRimeState()
        }
        super.onStop()
    }

    companion object {
        const val EXTRA_SETTINGS_ROUTE = "${BuildConfig.APPLICATION_ID}.EXTRA_SETTINGS_ROUTE"
    }

}
