/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2023 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.input.status

import androidx.annotation.DrawableRes
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.core.Action
import org.fcitx.fcitx5.android.input.action.ButtonAction
import org.fcitx.fcitx5.android.input.keyboard.MacroStep

sealed class StatusAreaEntry(
    val label: String,
    @DrawableRes
    val icon: Int,
    val active: Boolean,
    val displayText: String? = null,
    val customIcon: String? = null
) {
    /**
     * Status Area entry backed by a ButtonAction
     */
    class ActionEntry(
        val buttonAction: ButtonAction,
        label: String,
        icon: Int,
        active: Boolean = false,
        displayText: String? = null,
        customIcon: String? = null
    ) : StatusAreaEntry(label, icon, active, displayText, customIcon)

    class Android(label: String, icon: Int, val type: Type, active: Boolean = false) :
        StatusAreaEntry(label, icon, active) {
        enum class Type {
            InputMethod,
            ReloadConfig,
            Keyboard,
            ThemeList,
            OneHandKeyboard
        }
    }

    class Fcitx(val action: Action, label: String, icon: Int, active: Boolean) :
        StatusAreaEntry(label, icon, active)

    class CustomEntry(
        val buttonId: String,
        val macroSteps: List<MacroStep>,
        label: String,
        icon: Int,
        active: Boolean = false,
        displayText: String? = null,
        customIcon: String? = null
    ) : StatusAreaEntry(label, icon, active, displayText, customIcon)

    companion object {
        private fun drawableFromIconName(icon: String) = when (icon) {
            // androidkeyboard
            "tools-check-spelling" -> R.drawable.ic_baseline_spellcheck_24
            // fcitx5-chinese-addons
            "fcitx-fullwidth-active" -> R.drawable.ic_fcitx_status_fullwidth_active
            "fcitx-fullwidth-inactive" -> R.drawable.ic_fcitx_status_fullwidth_inactive
            "fcitx-remind-active" -> R.drawable.ic_fcitx_status_prediction_active
            "fcitx-remind-inactive" -> R.drawable.ic_fcitx_status_prediction_inactive
            // fcitx5-unikey
            "document-edit" -> R.drawable.ic_baseline_edit_24
            "character-set" -> R.drawable.ic_baseline_text_format_24
            "edit-find" -> R.drawable.ic_baseline_search_24
            // fallback
            "" -> 0
            else -> {
                if (icon.endsWith("-inactive")) {
                    R.drawable.ic_baseline_code_off_24
                } else {
                    R.drawable.ic_baseline_code_24
                }
            }
        }

        fun fromAction(it: Action): Fcitx {
            val active = it.icon.endsWith("-active") || it.isChecked
            return Fcitx(it, it.shortText, drawableFromIconName(it.icon), active)
        }
    }
}
