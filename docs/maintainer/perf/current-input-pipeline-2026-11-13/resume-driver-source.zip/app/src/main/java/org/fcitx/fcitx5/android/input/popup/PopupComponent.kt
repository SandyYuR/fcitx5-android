/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2026 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.input.popup

import android.graphics.Rect
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.fcitx.fcitx5.android.data.BundledPresets
import org.fcitx.fcitx5.android.data.theme.ThemeManager
import org.fcitx.fcitx5.android.input.dependency.context
import org.fcitx.fcitx5.android.input.dependency.inputMethodService
import org.fcitx.fcitx5.android.input.dependency.theme
import org.fcitx.fcitx5.android.input.keyboard.KeyAction
import org.fcitx.fcitx5.android.input.keyboard.KeyDef
import org.mechdancer.dependency.Dependent
import org.fcitx.fcitx5.android.input.dependency.InputUniqueComponent
import org.mechdancer.dependency.manager.ManagedHandler
import org.mechdancer.dependency.manager.managedHandler
import splitties.dimensions.dp
import splitties.views.dsl.core.add
import splitties.views.dsl.core.frameLayout
import splitties.views.dsl.core.lParams
import java.util.LinkedList

class PopupComponent :
    InputUniqueComponent<PopupComponent>(PopupComponent::class), Dependent, ManagedHandler by managedHandler() {

    init {
        org.fcitx.fcitx5.android.input.config.ConfigProviders.addPopupPresetListener {
            invalidatePopupPresetCache()
        }
    }

    private val service by manager.inputMethodService()
    private val context by manager.context()
    private val theme by manager.theme()

    private val showingEntryUi = HashMap<Int, PopupEntryUi>()
    private val dismissJobs = HashMap<Int, Job>()
    private val freeEntryUi = LinkedList<PopupEntryUi>()

    private val showingContainerUi = HashMap<Int, PopupContainerUi>()

    private val keyBottomMargin by lazy {
        context.dp(ThemeManager.prefs.keyVerticalMargin.getValue())
    }
    private val popupWidth by lazy {
        context.dp(38)
    }
    private val popupHeight by lazy {
        context.dp(116)
    }
    private val popupKeyHeight by lazy {
        context.dp(48)
    }
    private val popupRadius by lazy {
        context.dp(ThemeManager.prefs.keyRadius.getValue()).toFloat()
    }
    private val hideThreshold = 100L

    private val rootLocation = intArrayOf(0, 0)
    private val rootBounds: Rect = Rect()

    companion object {
        private var lastModified = 0L
        private var cachedPopupPreset: Map<String, Array<String>>? = null
        private var cachedBundledPreset: Map<String, Array<String>>? = null

        @Synchronized
        private fun invalidatePopupPresetCache() {
            cachedPopupPreset = null
            lastModified = 0L
        }

        @Synchronized
        private fun bundledPopupPreset(): Map<String, Array<String>>? {
            cachedBundledPreset?.let { return it }
            val preset = BundledPresets.readBundledPopupPreset() ?: return null
            return preset.mapValues { it.value.toTypedArray() }.also { cachedBundledPreset = it }
        }

        /**
         * 弹出候选定义：用户配置（config/PopupPreset.json）优先，缺失时回退到
         * 内置的 bundled/keyboard_layouts/PopupPreset.json（不落盘，避免覆盖用户编辑入口）。
         */
        val popupPresetJson: Map<String, Array<String>>?
            @Synchronized
            get() {
                // Compare the file stamp *before* reading: readPopupPreset() re-reads and
                // re-parses the whole preset on every call, and this getter runs on long-press
                // of every key. Skipping the read when the stamp is unchanged is what makes
                // the cache actually save the work.
                val file = org.fcitx.fcitx5.android.input.config.ConfigProviders.provider
                    .popupPresetFile()
                if (cachedPopupPreset != null && file != null && file.exists() &&
                    file.lastModified() == lastModified
                ) {
                    return cachedPopupPreset
                }
                val snapshot = org.fcitx.fcitx5.android.input.config.ConfigProviders.readPopupPreset<Map<String, List<String>>>()
                if (snapshot == null) {
                    // 用户未自定义时使用内置默认弹出定义
                    return bundledPopupPreset()
                }
                if (cachedPopupPreset == null || snapshot.lastModified != lastModified) {
                    lastModified = snapshot.lastModified
                    cachedPopupPreset = snapshot.value.mapValues { it.value.toTypedArray() }
                }
                return cachedPopupPreset
            }
    }

    val root by lazy {
        context.frameLayout {
            // we want (0, 0) at top left
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isClickable = false
            isFocusable = false

            addOnLayoutChangeListener { v, left, top, right, bottom, _, _, _, _ ->
                val (x, y) = rootLocation.also { v.getLocationInWindow(it) }
                val width = right - left
                val height = bottom - top
                rootBounds.set(x, y, x + width, y + height)
            }
        }
    }

    private fun showPopup(viewId: Int, content: String, bounds: Rect) {
        showingEntryUi[viewId]?.apply {
            dismissJobs[viewId]?.also {
                dismissJobs.remove(viewId)?.cancel()
            }
            lastShowTime = System.currentTimeMillis()
            setText(content)
            return
        }
        val popup = (freeEntryUi.poll()
            ?: PopupEntryUi(context, theme, popupKeyHeight, popupRadius)).apply {
            lastShowTime = System.currentTimeMillis()
            setText(content)
        }
        popup.root.layoutParams = FrameLayout.LayoutParams(popupWidth, popupHeight).apply {
            // align popup bottom with key border bottom [^1]
            topMargin = bounds.bottom - popupHeight - keyBottomMargin
            leftMargin = (bounds.left + bounds.right - popupWidth) / 2
        }
        // make sure that popup.root does not have parent view before adding it under root container
        // it's wired that on some devices it would have a parent view despite it was newly created
        // or just polled from freeEntryUi
        if (popup.root.parent == null) {
            root.addView(popup.root)
        } else if (popup.root.parent !== root) {
            (popup.root.parent as? ViewGroup)?.removeView(popup.root)
            root.addView(popup.root)
        }
        showingEntryUi[viewId] = popup
    }

    private fun updatePopup(viewId: Int, content: String) {
        showingEntryUi[viewId]?.setText(content)
    }

    private fun showKeyboard(viewId: Int, keyboard: KeyDef.Popup.Keyboard, bounds: Rect) {
        val keys: Array<String>
        val labels: Array<String>
        when (keyboard) {
            is KeyDef.Popup.Keyboard.Preset -> {
                // Allow overriding via popupPresetJson, with EmojiModifier skin-tone fallback.
                val preset = popupPresetJson?.get(keyboard.label)
                    ?: PopupPreset[keyboard.label]
                    ?: EmojiModifier.produceSkinTones(keyboard.label, EmojiModifier.SkinTone.Default)
                    ?: return
                keys = preset
                labels = keys
            }
            is KeyDef.Popup.Keyboard.Explicit -> {
                keys = keyboard.items
                labels = keyboard.items
            }
        }
        if (keys.isEmpty()) {
            dismissPopup(viewId)
            return
        }
        // clear popup preview text         OR create empty popup preview
        showingEntryUi[viewId]?.setText("") ?: showPopup(viewId, "", bounds)
        val keyboardUi = PopupKeyboardUi(
            context,
            theme,
            rootBounds,
            bounds,
            { dismissPopup(viewId) },
            popupRadius,
            popupWidth,
            popupKeyHeight,
            // position popup keyboard higher, because of [^1]
            popupHeight + keyBottomMargin,
            keys,
            labels
        )
        showPopupContainer(viewId, keyboardUi)
    }

    private fun showLongPressKeyboard(viewId: Int, keyboard: KeyDef.Popup.LongPressKeyboard, bounds: Rect) {
        // Get base candidates from PopupPreset using baseLabel
        val baseKeys = popupPresetJson?.get(keyboard.baseLabel)
            ?: PopupPreset[keyboard.baseLabel]
            ?: EmojiModifier.produceSkinTones(keyboard.baseLabel, EmojiModifier.SkinTone.Default)
            ?: emptyArray()

        // Prepend the longPress macro as the first candidate
        val keys = arrayOf(keyboard.displayLabel) + baseKeys
        
        if (keys.isEmpty()) {
            dismissPopup(viewId)
            return
        }

        // clear popup preview text OR create empty popup preview
        showingEntryUi[viewId]?.setText("") ?: showPopup(viewId, "", bounds)
        reallyShowLongPressKeyboard(viewId, keyboard, keys, bounds)
    }

    private fun reallyShowLongPressKeyboard(viewId: Int, keyboard: KeyDef.Popup.LongPressKeyboard, keys: Array<String>, bounds: Rect) {
        // Create a special keyboard UI that can execute the longPress macro when first item is selected
        val keyboardUi = LongPressPopupKeyboardUi(
            context,
            theme,
            rootBounds,
            bounds,
            { dismissPopup(viewId) },
            popupRadius,
            popupWidth,
            popupKeyHeight,
            // position popup keyboard higher, because of [^1]
            popupHeight + keyBottomMargin,
            keys,
            keys,
            keyboard.action
        )
        showPopupContainer(viewId, keyboardUi)
    }

    private fun showMenu(viewId: Int, menu: KeyDef.Popup.Menu, bounds: Rect) {
        if (menu.items.isEmpty()) {
            dismissPopup(viewId)
            return
        }
        showingEntryUi[viewId]?.let {
            dismissPopupEntry(viewId, it)
        }
        val menuUi = PopupMenuUi(
            context,
            theme,
            rootBounds,
            bounds,
            { dismissPopup(viewId) },
            menu.items,
        )
        showPopupContainer(viewId, menuUi)
    }

    private fun showPopupContainer(viewId: Int, ui: PopupContainerUi) {
        root.apply {
            add(ui.root, lParams {
                leftMargin = ui.triggerBounds.left + ui.offsetX - rootBounds.left
                topMargin = ui.triggerBounds.top + ui.offsetY - rootBounds.top
            })
        }
        showingContainerUi[viewId] = ui
    }

    private fun changeFocus(viewId: Int, x: Float, y: Float): Boolean {
        return showingContainerUi[viewId]?.changeFocus(x, y) ?: false
    }

    private fun triggerFocused(viewId: Int): KeyAction? {
        return showingContainerUi[viewId]?.onTrigger()
    }

    private fun dismissPopup(viewId: Int) {
        dismissPopupContainer(viewId)
        showingEntryUi[viewId]?.also {
            val timeLeft = it.lastShowTime + hideThreshold - System.currentTimeMillis()
            if (timeLeft <= 0L) {
                dismissPopupEntry(viewId, it)
            } else {
                // Cancel any pending dismiss for this key first: overwriting the map entry
                // left the previous coroutine running, and it removed the *new* entry after
                // its own delay, so a later popup for the same key was dismissed early.
                dismissJobs.remove(viewId)?.cancel()
                dismissJobs[viewId] = service.lifecycleScope.launch {
                    delay(timeLeft)
                    dismissPopupEntry(viewId, it)
                    dismissJobs.remove(viewId)
                }
            }
        }
    }

    private fun dismissPopupContainer(viewId: Int) {
        showingContainerUi[viewId]?.also {
            showingContainerUi.remove(viewId)
            root.removeView(it.root)
        }
    }

    private fun dismissPopupEntry(viewId: Int, popup: PopupEntryUi) {
        showingEntryUi.remove(viewId)
        root.removeView(popup.root)
        freeEntryUi.add(popup)
    }

    /**
     * Dismiss every popup except the one belonging to [exceptViewId], if given.
     *
     * The exception is needed for multi-touch: pressing a second key must not tear down the
     * popup keyboard of a key still held under another finger, because its pending selection
     * is lost and nothing is committed when that finger lifts.
     */
    fun dismissAll(exceptViewId: Int? = null) {
        // Snapshot the ids first: the loops below remove from the same maps.
        dismissJobs.keys.filterTo(mutableListOf()) { it != exceptViewId }.forEach { viewId ->
            dismissJobs.remove(viewId)?.cancel()
        }
        showingContainerUi.keys.filterTo(mutableListOf()) { it != exceptViewId }.forEach { viewId ->
            showingContainerUi.remove(viewId)?.let { root.removeView(it.root) }
        }
        showingEntryUi.keys.filterTo(mutableListOf()) { it != exceptViewId }.forEach { viewId ->
            showingEntryUi.remove(viewId)?.let { entry ->
                root.removeView(entry.root)
                freeEntryUi.add(entry)
            }
        }
    }

    val listener = PopupActionListener { action ->
        with(action) {
            when (this) {
                is PopupAction.ChangeFocusAction -> outResult = changeFocus(viewId, x, y)
                is PopupAction.DismissAction -> dismissPopup(viewId)
                is PopupAction.DismissAllAction -> dismissAll(exceptViewId)
                is PopupAction.PreviewAction -> showPopup(viewId, content, bounds)
                is PopupAction.PreviewUpdateAction -> updatePopup(viewId, content)
                is PopupAction.ShowKeyboardAction -> showKeyboard(viewId, keyboard, bounds)
                is PopupAction.ShowLongPressKeyboardAction -> showLongPressKeyboard(viewId, keyboard, bounds)
                is PopupAction.ShowMenuAction -> showMenu(viewId, menu, bounds)
                is PopupAction.TriggerAction -> outAction = triggerFocused(viewId)
            }
        }
    }
}
