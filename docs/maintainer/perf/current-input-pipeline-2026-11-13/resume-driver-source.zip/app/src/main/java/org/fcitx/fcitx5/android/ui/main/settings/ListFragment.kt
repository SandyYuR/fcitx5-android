/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2025 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.ui.main.settings

import com.google.android.material.dialog.MaterialAlertDialogBuilder

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import org.fcitx.fcitx5.android.core.Key
import org.fcitx.fcitx5.android.core.RawConfig
import org.fcitx.fcitx5.android.ui.common.BaseDynamicListUi
import org.fcitx.fcitx5.android.ui.common.DynamicListUi
import org.fcitx.fcitx5.android.ui.main.EditDeleteMenuProvider
import org.fcitx.fcitx5.android.ui.main.settingsPageToolbar
import org.fcitx.fcitx5.android.ui.main.MainViewModel
import org.fcitx.fcitx5.android.ui.main.MainViewModel.ButtonMode
import org.fcitx.fcitx5.android.ui.main.withSettingsPage
import org.fcitx.fcitx5.android.utils.config.ConfigDescriptor
import org.fcitx.fcitx5.android.utils.config.ConfigType
import org.fcitx.fcitx5.android.utils.lazyRoute

class ListFragment : Fragment() {

    val args by lazyRoute<SettingsRoute.ListConfig>(
        SettingsRoute.ListConfig.Params.TypeMap
    )

    private val descriptor: ConfigDescriptor<*, *> by lazy {
        args.desc
    }

    private val cfg: RawConfig by lazy {
        args.cfg
    }

    private val viewModel: MainViewModel by activityViewModels()

    private var uiInitialized = false

    private val ui: BaseDynamicListUi<*> by lazy {
        val ctx = requireContext()
        when (descriptor) {
            is ConfigDescriptor.ConfigEnumList -> {
                val d = descriptor as ConfigDescriptor.ConfigEnumList
                val available = d.entries.toSet()
                ctx.DynamicListUi(
                    BaseDynamicListUi.Mode.ChooseOne {
                        (available - entries.toSet()).toTypedArray()
                    },
                    initialEntries = cfg.subItems?.map { it.value } ?: listOf(),
                    enableOrder = true,
                    show = { d.entriesI18n?.get(d.entries.indexOf(it)) ?: it }
                )
            }
            is ConfigDescriptor.ConfigList -> {
                val ty = descriptor.ty as ConfigType.TyList
                when (ty.subtype) {
                    // does a list of booleans make sense?
                    ConfigType.TyBool -> {
                        ctx.DynamicListUi(
                            BaseDynamicListUi.Mode.ChooseOne { arrayOf(true, false) },
                            initialEntries = cfg.subItems?.map { it.value.toBoolean() } ?: listOf(),
                            enableOrder = true,
                            show = { it.toString() }
                        )
                    }
                    ConfigType.TyInt -> {
                        ctx.DynamicListUi(
                            BaseDynamicListUi.Mode.FreeAdd(
                                hint = "integer",
                                converter = { it.toInt() },
                                validator = { it.toIntOrNull() != null }
                            ),
                            initialEntries = cfg.subItems?.map { it.value.toInt() } ?: listOf(),
                            enableOrder = true,
                            show = { it.toString() }
                        )
                    }
                    ConfigType.TyString -> {
                        ctx.DynamicListUi(
                            BaseDynamicListUi.Mode.FreeAddString(),
                            initialEntries = cfg.subItems?.map { it.value } ?: listOf(),
                            enableOrder = true,
                            show = { it }
                        )
                    }
                    ConfigType.TyKey -> {
                        object : BaseDynamicListUi<Key>(
                            ctx,
                            Mode.FreeAdd(
                                hint = "",
                                converter = { Key.parse(it) }
                            ),
                            initialEntries = cfg.subItems?.map { Key.parse(it.value) } ?: listOf(),
                            enableOrder = true
                        ) {
                            override fun showEntry(x: Key) = x.localizedString
                            override fun showEditDialog(
                                title: String,
                                entry: Key?,
                                block: (Key) -> Unit
                            ) {
                                val ui = KeyPreferenceUi(ctx).apply { setKey(entry ?: Key.None) }
                                MaterialAlertDialogBuilder(requireContext())
                                    .setTitle(title)
                                    .setView(ui.root)
                                    .setPositiveButton(android.R.string.ok) { _, _ ->
                                        val newKey = ui.lastKey
                                        if (newKey.sym == Key.None.sym) {
                                            entry?.let { removeItem(indexItem(it)) }
                                        } else {
                                            block(ui.lastKey)
                                        }
                                    }
                                    .setNegativeButton(android.R.string.cancel, null)
                                    .show()
                            }
                        }.apply {
                            addTouchCallback()
                        }
                    }
                    ConfigType.TyEnum -> error("Impossible!")
                    else -> throw IllegalArgumentException("List of ${ConfigType.pretty(ty.subtype)} is unsupported")
                }
            }
            else -> throw IllegalArgumentException("$descriptor is not a list-like descriptor")
        }.also {
            it.setViewModel(viewModel)
            uiInitialized = true
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = withSettingsPage(ui.root)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.toolbarButton.value =
            if (ui.entries.isNotEmpty()) ButtonMode.EDIT else ButtonMode.NONE
        val menuHost = settingsPageToolbar()
        menuHost.addMenuProvider(
            EditDeleteMenuProvider(
                buttonMode = viewModel.toolbarButton,
                editButtonAction = { ui.enterMultiSelect(requireActivity().onBackPressedDispatcher) },
                deleteButtonAction = { ui.deleteSelected(); ui.exitMultiSelect() },
                menuHost = menuHost,
                context = requireContext(),
                lifecycleOwner = viewLifecycleOwner,
            ),
            viewLifecycleOwner,
            Lifecycle.State.STARTED
        )
    }

    override fun onStop() {
        if (uiInitialized) {
            ui.exitMultiSelect()
        }
        super.onStop()
    }

    override fun onDestroy() {
        val items = Array(ui.entries.size) { RawConfig("$it", ui.entries[it]!!.toString()) }
        parentFragmentManager.setFragmentResult(
            descriptor.name,
            Bundle().apply { putParcelableArray(descriptor.name, items) }
        )
        super.onDestroy()
    }

    companion object {
        val supportedSubtypes = listOf(
            ConfigType.TyEnum,
            ConfigType.TyString,
            ConfigType.TyInt,
            ConfigType.TyBool,
            ConfigType.TyKey
        )
    }

}
