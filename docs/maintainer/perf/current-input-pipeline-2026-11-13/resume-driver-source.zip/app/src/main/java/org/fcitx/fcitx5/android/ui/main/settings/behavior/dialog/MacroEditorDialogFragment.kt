/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2026 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.ui.main.settings.behavior.dialog

import org.fcitx.fcitx5.android.ui.common.MaterialSpinner
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.dialog.MaterialAlertDialogBuilder

import android.content.res.ColorStateList
import android.content.res.Configuration
import android.content.Intent
import android.content.DialogInterface
import android.app.Dialog
import android.os.Bundle
import android.view.WindowManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.shape.MaterialShapeDrawable
import com.google.android.material.shape.ShapeAppearanceModel
import org.fcitx.fcitx5.android.ui.main.settings.behavior.editor.EditorUi
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.input.keyboard.KeyAction
import org.fcitx.fcitx5.android.input.keyboard.KeyRef
import org.fcitx.fcitx5.android.input.keyboard.MacroStep
import org.fcitx.fcitx5.android.input.picker.PickerWindow
import org.fcitx.fcitx5.android.utils.serializable
import org.fcitx.fcitx5.android.ui.main.settings.behavior.FlowLayout
import splitties.dimensions.dp
import org.fcitx.fcitx5.android.utils.settingsColor
import org.fcitx.fcitx5.android.utils.allowImeInput

/**
 * Macro editor shown as a Material dialog over the current editor page.
 */
class MacroEditorDialogFragment : DialogFragment() {

    @kotlinx.serialization.Serializable
    data class MacroStepData(
        var type: String = "tap",
        var keys: MutableList<KeyData> = mutableListOf(),
        var text: String = ""
    )

    @kotlinx.serialization.Serializable
    data class KeyData(
        var keyType: String = "fcitx",
        var code: String = ""
    )

    private val titleView by lazy {
        TextView(requireContext()).apply {
            setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleLarge)
            setTextColor(requireContext().settingsColor(com.google.android.material.R.attr.colorOnSurface))
            setPadding(requireContext().dp(24), requireContext().dp(20), requireContext().dp(24), requireContext().dp(12))
        }
    }

    private val stepsRecyclerView by lazy {
        RecyclerView(requireContext()).apply {
            layoutManager = LinearLayoutManager(requireContext())
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f)
            setPadding(0, requireContext().dp(4), 0, requireContext().dp(4))
            clipToPadding = false
        }
    }

    private val addStepButton by lazy {
        EditorUi.button(requireContext(), R.string.macro_editor_add_step, tonal = true) { addNewStep() }
    }

    private val confirmButton by lazy {
        EditorUi.button(requireContext(), R.string.macro_editor_confirm, tonal = true) { saveAndFinish() }
    }

    private val footer by lazy {
        LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(requireContext().dp(16), requireContext().dp(4), requireContext().dp(16), requireContext().dp(12))
            addView(EditorUi.button(requireContext(), R.string.macro_editor_cancel) { cancelEditor() })
            addView(confirmButton, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
                marginStart = requireContext().dp(8)
            })
        }
    }

    private val container by lazy {
        LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
        }
    }

    private val steps = mutableListOf<MacroStepData>()
    @kotlinx.serialization.Serializable
    private data class Draft(val baseline: List<MacroStepData>, val steps: List<MacroStepData>)
    private val draftState by lazy {
        org.fcitx.fcitx5.android.ui.main.settings.behavior.data.EditorDraftState(requireContext(), "macro")
    }
    private var availableLayoutTargets: List<String> = emptyList()
    private lateinit var stepsAdapter: StepsAdapter

    // Save original data for comparison
    private var originalSteps: List<Map<*, *>>? = null
    private var hasChanges = false
    private var resultSent = false

    private fun normalizeLayerMode(raw: String?): String {
        return when (raw?.lowercase()) {
            "osl" -> "osl"
            "back" -> "back"
            else -> "to"
        }
    }

    private fun ensureLayerMode(step: MacroStepData) {
        if (step.type != "layer") return
        val normalized = normalizeLayerMode(step.keys.firstOrNull()?.code)
        step.keys.clear()
        step.keys.add(KeyData(keyType = "fcitx", code = normalized))
    }

    private fun parseKeyData(keyMap: Map<*, *>): KeyData {
        val androidValue = keyMap["android"]
        val androidCode = when (androidValue) {
            is Number -> androidValue.toString()
            is String -> androidValue.takeIf { it.isNotBlank() }
            else -> null
        }
        if (androidCode != null) {
            return KeyData(keyType = "android", code = androidCode)
        }

        val fcitxValue = keyMap["fcitx"]?.toString().orEmpty()
        return KeyData(
            keyType = "fcitx",
            code = fcitxValue
        )
    }

    companion object {
        const val TAG = "macro_editor"
        const val RESULT_REQUEST_KEY = "macro_editor_result"
        const val RESULT_DATA = "result_data"
        const val RESULT_CODE = "result_code"

        const val EXTRA_MACRO_STEPS = "macro_steps"
        const val EXTRA_EVENT_TYPE = "event_type"
        const val EXTRA_MACRO_RESULT = "macro_result"
        const val EXTRA_LAYOUT_TARGETS = "layout_targets"
        const val EXTRA_MACRO_STEPS_JSON = "macro_steps_json"
        const val EXTRA_MACRO_RESULT_JSON = "macro_result_json"

        /**
         * Opaque token identifying what the caller is editing (a button id, a key position…),
         * echoed back verbatim in the result Intent.
         *
         * This lets a caller apply the result after being recreated, instead of relying on a
         * callback field that dies with the old instance.
         */
        const val EXTRA_TARGET_TOKEN = "target_token"

        fun newInstance(intent: Intent) = MacroEditorDialogFragment().apply {
            arguments = Bundle().apply { intent.extras?.let { putAll(it) } }
        }

        /**
         * Convert [MacroStep] list to [ArrayList] of [Map] for use as Intent extra.
         */
        fun toStepsExtra(steps: List<MacroStep>): ArrayList<Map<String, Any?>> {
            val result = ArrayList<Map<String, Any?>>()
            for (step in steps) {
                result.add(when (step) {
                    is MacroStep.Tap -> mapOf("type" to "tap", "keys" to step.keys.map { it.toMap() })
                    is MacroStep.Down -> mapOf("type" to "down", "keys" to step.keys.map { it.toMap() })
                    is MacroStep.Up -> mapOf("type" to "up", "keys" to step.keys.map { it.toMap() })
                    is MacroStep.Text -> mapOf("type" to "text", "text" to step.text)
                    is MacroStep.Edit -> mapOf("type" to "edit", "action" to step.action)
                    is MacroStep.AppAction -> mapOf("type" to "app", "id" to step.id)
                    is MacroStep.Shortcut -> mapOf(
                        "type" to "shortcut",
                        "modifiers" to step.modifiers.map { it.toMap() },
                        "key" to step.key.toMap()
                    )
                    is MacroStep.LayerSwitch -> mapOf("type" to "layer", "mode" to step.mode.name, "target" to step.target)
                })
            }
            return result
        }

        /**
         * Convert result from Intent extra back to [MacroStep] list.
         */
        @Suppress("UNCHECKED_CAST")
        fun fromStepsExtra(data: ArrayList<Map<*, *>>?): List<MacroStep> {
            if (data == null) return emptyList()
            return data.mapNotNull { map ->
                val m = map as Map<String, Any?>
                when (val type = m["type"] as? String) {
                    "tap" -> MacroStep.Tap((m["keys"] as? List<Map<*,*>>).toKeyRefs())
                    "down" -> MacroStep.Down((m["keys"] as? List<Map<*,*>>).toKeyRefs())
                    "up" -> MacroStep.Up((m["keys"] as? List<Map<*,*>>).toKeyRefs())
                    "text" -> MacroStep.Text(m["text"] as? String ?: "")
                    "edit" -> MacroStep.Edit(m["action"] as? String ?: "paste")
                    "app" -> MacroStep.AppAction(m["id"] as? String ?: "theme")
                    "shortcut" -> {
                        val mods = (m["modifiers"] as? List<Map<*,*>>).toKeyRefs()
                        val key = (m["key"] as? Map<*,*>)?.toKeyRef() ?: return@mapNotNull null
                        MacroStep.Shortcut(mods, key)
                    }
                    "layer" -> {
                        val mode = when ((m["mode"] as? String)?.uppercase()) {
                            "TO" -> KeyAction.LayerSwitchMode.TO
                            "OSL" -> KeyAction.LayerSwitchMode.OSL
                            "BACK" -> KeyAction.LayerSwitchMode.BACK
                            else -> return@mapNotNull null
                        }
                        MacroStep.LayerSwitch(mode, m["target"] as? String ?: "")
                    }
                    else -> null
                }
            }
        }

        private fun KeyRef.toMap(): Map<String, String> = when (this) {
            is KeyRef.Fcitx -> mapOf("fcitx" to code)
            is KeyRef.Android -> mapOf("android" to code.toString())
        }

        private fun List<Map<*, *>>?.toKeyRefs(): List<KeyRef> =
            this?.mapNotNull { it.toKeyRef() } ?: emptyList()

        private fun Map<*, *>.toKeyRef(): KeyRef? {
            (this["fcitx"] as? String)?.let { return KeyRef.Fcitx(it) }
            (this["android"] as? String)?.let { return KeyRef.Android(it.toIntOrNull() ?: return null) }
            return null
        }

        val STEP_TYPES = arrayOf("tap", "shortcut", "edit", "app", "layer", "down", "up", "text")
        val KEY_TYPES = arrayOf("fcitx", "android")

        /**
         * App actions offered by the "app" step picker, in display order.
         *
         * Single source of truth: the picker derives each row's label from its id through
         * getAppActionLabel instead of keeping a second array of labels. The two arrays this
         * replaces had drifted apart when actions were removed (ids deleted, labels kept), so
         * every row past the removal point selected the wrong id — picking "switch keyboard
         * definition profile" stored `edit_fontset` — and the trailing rows had no id at all.
         *
         * Every id here must be executable by `CustomActionExecutor`: a [ButtonAction] id, a
         * `ROUTE_MAP` entry, or one of its explicit special cases.
         */
        val APP_ACTION_IDS = arrayOf(
            "theme",
            "icon_theme",
            "virtual_keyboard",
            "more",
            "browse_user_data_dir",
            "clipboard",
            "cursor_move",
            "floating_toggle",
            "language_switch",
            "switch_input_method",
            "rime_schema_menu",
            "reload_config",
            "one_handed_keyboard",
            "input_method_options",
            "undo",
            "redo",
            "settings_global_options",
            "settings_candidates_window",
            "settings_clipboard",
            "settings_symbol",
            "settings_advanced",
            "settings_developer",
            "settings_about",
            "settings_license",
            "edit_text_keyboard_layout",
            "text_keyboard_layout_file_select",
            "edit_fontset",
            "edit_buttons",
            "split_keyboard_calibration",
            "web_editor_bridge"
        )

        /**
         * Check if it's a modifier key
         * Includes Ctrl, Alt, Shift, Meta, Super, Hyper, and Mode_switch
         */
        fun isModifierKey(code: String): Boolean {
            return code in arrayOf(
                "Ctrl_L", "Ctrl_R",
                "Alt_L", "Alt_R",
                "Shift_L", "Shift_R",
                "Meta_L", "Meta_R",
                "Super_L", "Super_R",
                "Hyper_L", "Hyper_R",
                "Mode_switch",
                "ISO_Level3_Shift",
                "ISO_Level5_Shift"
            )
        }

        /**
         * Symbol key friendly name mapping (key name -> symbol character)
         */
        val SYMBOL_KEY_MAP = mapOf(
            // Canonical fcitx/X11 symbol key names (lowercase)
            "exclam" to "!",
            "at" to "@",
            "numbersign" to "#",
            "dollar" to "$",
            "percent" to "%",
            "asciicircum" to "^",
            "ampersand" to "&",
            "asterisk" to "*",
            "parenleft" to "(",
            "parenright" to ")",
            "minus" to "-",
            "underscore" to "_",
            "equal" to "=",
            "plus" to "+",
            "bracketleft" to "[",
            "braceleft" to "{",
            "bracketright" to "]",
            "braceright" to "}",
            "backslash" to "\\",
            "bar" to "|",
            "semicolon" to ";",
            "colon" to ":",
            "apostrophe" to "'",
            "quotedbl" to "\"",
            "grave" to "`",
            "asciitilde" to "~",
            "comma" to ",",
            "less" to "<",
            "period" to ".",
            "greater" to ">",
            "slash" to "/",
            "question" to "?",
            // Legacy aliases kept for compatibility with existing macros
            "Exclam" to "!",
            "At" to "@",
            "Numbersign" to "#",
            "Dollar" to "$",
            "Percent" to "%",
            "Minus" to "-",
            "Equal" to "=",
            "Bracket_L" to "[",
            "Bracket_R" to "]",
            "Backslash" to "\\",
            "Semicolon" to ";",
            "Colon" to ":",
            "Apostrophe" to "'",
            "Quotedbl" to "\"",
            "Grave" to "`",
            "Tilde" to "~",
            "Asciitilde" to "~",
            "Comma" to ",",
            "Period" to ".",
            "Slash" to "/",
            "Bar" to "|",
            "Question" to "?",
            "Multiply" to "*",
            "Add" to "+",
            "Subtract" to "-",
            "Divide" to "÷",
            "Separator" to ",",
            // Numpad symbols
            "KP_Multiply" to "*",
            "KP_Add" to "+",
            "KP_Subtract" to "-",
            "KP_Divide" to "÷",
            "KP_Decimal" to ".",
            "KP_Equal" to "=",
            "KP_Separator" to ","
        )

        // Case-insensitive lookup for symbol display: build a lowercase-key map
        private val SYMBOL_KEY_MAP_LOWER: Map<String, String> = SYMBOL_KEY_MAP.entries.associate { (k, v) -> k.lowercase() to v }

        // Normalize legacy/non-canonical key names for consistent UI display.
        private val FCITX_KEY_DISPLAY_NAME_ALIAS = mapOf(
            "bracket_l" to "bracketleft",
            "bracket_r" to "bracketright",
            "multiply" to "asterisk",
            "add" to "plus",
            "subtract" to "minus",
            "tilde" to "asciitilde"
        )

        /**
         * Get display name for Fcitx key with symbol hint (case-insensitive)
         */
        fun getFcitxKeyDisplayName(keyName: String): String {
            val lower = keyName.lowercase()
            val normalizedName = FCITX_KEY_DISPLAY_NAME_ALIAS[lower] ?: lower
            val symbol = SYMBOL_KEY_MAP_LOWER[normalizedName] ?: SYMBOL_KEY_MAP_LOWER[lower]
            val displayName = normalizedName.replaceFirstChar {
                if (it.isLowerCase()) it.titlecase() else it.toString()
            }
            return symbol?.let { "$displayName ($it)" } ?: keyName
        }

        // Fcitx virtual key names
        // These key names are passed to Fcitx sendKey API
        // Reference: https://github.com/fcitx/fcitx5/blob/master/src/lib/fcitx-utils/keysym.h
        val FCITX_KEYS = arrayOf(
            // Letter keys (A-Z) - placed first for easy access
            "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
            "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
            // Number keys (0-9)
            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
            // Modifier keys
            "Ctrl_L", "Ctrl_R", "Shift_L", "Shift_R", "Alt_L", "Alt_R",
            "Meta_L", "Meta_R", "Super_L", "Super_R", "Hyper_L", "Hyper_R",
            // Basic keys
            "Enter", "Tab", "Escape", "Space", "Delete", "BackSpace",
            "Home", "End", "Page_Up", "Page_Down",
            "Left", "Right", "Up", "Down",
            "Insert", "Menu", "Print", "Scroll_Lock", "Pause",
            "Caps_Lock", "Num_Lock",
            // Symbol keys (main 104-key area, includes shifted and unshifted symbols)
            "grave", "asciitilde",
            "minus", "underscore", "equal", "plus",
            "bracketleft", "braceleft", "bracketright", "braceright",
            "backslash", "bar",
            "semicolon", "colon", "apostrophe", "quotedbl",
            "comma", "less", "period", "greater", "slash", "question",
            "exclam", "at", "numbersign", "dollar", "percent", "asciicircum", "ampersand", "asterisk",
            "parenleft", "parenright",
            // Extra aliases/symbol keys for compatibility
            "Bracket_L", "Bracket_R", "Multiply", "Add", "Subtract", "Divide", "Separator",
            // Numpad keys
            "KP_0", "KP_1", "KP_2", "KP_3", "KP_4", "KP_5", "KP_6", "KP_7", "KP_8", "KP_9",
            "KP_Enter", "KP_Space", "KP_Tab", "KP_Equal", "KP_Multiply", "KP_Add",
            "KP_Subtract", "KP_Divide", "KP_Decimal", "KP_Separator",
            // Function keys (moved after numpad since they're less commonly used)
            "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12",
            "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24",
            "F25", "F26", "F27", "F28", "F29", "F30", "F31", "F32", "F33", "F34", "F35",
            // Multimedia keys
            "AudioMute", "AudioLowerVolume", "AudioRaiseVolume",
            "AudioPlay", "AudioStop", "AudioPrev", "AudioNext",
            "AudioRewind", "AudioForward", "AudioRepeat",
            "HomePage", "Mail", "Search", "WWW", "Favorites",
            "Calculator", "Calendar", "Contacts", "Memo", "Todo",
            // Power management keys removed to avoid accidental assignment by users
            // Other special keys
            "Back", "Forward", "Refresh", "Reload", "Stop",
            "ZoomIn", "ZoomOut",
            // Fcitx clipboard keys (requires Fcitx configuration support)
            "XF86Copy", "XF86Cut", "XF86Paste", "XF86Select",
            "XF86Undo", "XF86Redo", "XF86Find",
            // Other function keys
            "Execute", "Help", "Setup", "Options", "Info",
            "Time", "Market", "Go", "Off", "Shop"
        )

        // Android key codes (commonly used)
        val ANDROID_KEYS = arrayOf(
            // Basic keys
            "4", "66", "67", "68", "61", "63",
            // Navigation keys
            "19", "20", "21", "22", "23", "56",
            // Page control
            "58", "59", "26", "27", "3", "122", "123",
            // Function keys
            "60", "62", "70", "71", "72", "73", "74", "75", "76", "77",
            // Media keys
            "85", "86", "87", "88", "89", "90", "91", "126", "127", "128", "129", "130", "131",
            // Volume keys
            "24", "25", "164",
            // Brightness keys
            "224", "225",
            // Other
            "57", "64", "65", "69", "78", "79", "80", "81", "82", "83", "84", "93", "94", "95", "96", "97", "98", "99", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "132", "133", "134", "135", "136", "137", "138", "139", "140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150", "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161", "162", "163", "165", "166", "167", "168", "169", "170", "171", "172", "173", "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184", "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195", "196", "197", "198", "199", "200", "201", "202", "203", "204", "205", "206", "207", "208", "209", "210", "211", "212", "213", "214", "215", "216", "217", "218", "219", "220", "221", "222", "223", "226", "227", "228", "229", "230", "231", "232", "233", "234", "235", "236", "237", "238", "239", "240", "241", "242", "243", "244", "245", "246", "247", "248", "249", "250", "251", "252", "253", "254", "255"
        )

        // Android key code friendly name mapping
        val ANDROID_KEY_NAMES = mapOf(
            // Basic keys
            "4" to "Back",
            "66" to "Enter",
            "67" to "Del",
            "68" to "Forward Del",
            "61" to "Delete",
            "63" to "Insert",
            // Navigation keys
            "19" to "DPad Up",
            "20" to "DPad Down",
            "21" to "DPad Left",
            "22" to "DPad Right",
            "23" to "DPad Center",
            "56" to "Tab",
            // Page control
            "58" to "Page Up",
            "59" to "Page Down",
            "26" to "Home",
            "27" to "End",
            "3" to "Home (2)",
            "122" to "Move Home",
            "123" to "Move End",
            // Function keys
            "60" to "Escape",
            "62" to "Period",
            "70" to "Scroll Lock",
            "71" to "Print Screen",
            "72" to "Pause",
            "73" to "Menu",
            "74" to "Help",
            "75" to "Left Bracket",
            "76" to "Right Bracket",
            "77" to "Backslash",
            // Media keys
            "85" to "Play/Pause",
            "86" to "Stop",
            "87" to "Next",
            "88" to "Previous",
            "89" to "Rewind",
            "90" to "Fast Forward",
            "91" to "Eject",
            "126" to "Play",
            "127" to "Pause (2)",
            "128" to "Close",
            "129" to "Eject (2)",
            "130" to "Next (2)",
            "131" to "Previous (2)",
            // Volume keys
            "24" to "Volume Up",
            "25" to "Volume Down",
            "164" to "Mute",
            // Brightness keys
            "224" to "Brightness Up",
            "225" to "Brightness Down",
            // Other
            "57" to "Space",
            "64" to "Open Bracket",
            "65" to "Close Bracket",
            "69" to "Apostrophe",
            "78" to "Slash",
            "79" to "At",
            "80" to "Envelop",
            "81" to "Plus",
            "82" to "Search",
            "83" to "Media Top Menu",
            "84" to "Sleep",
            "93" to "Semicolon",
            "94" to "Equals",
            "95" to "Comma",
            "96" to "Minus",
            "97" to "Period (2)",
            "98" to "Alt Left",
            "99" to "Alt Right",
            "100" to "Shift Left",
            "101" to "Shift Right",
            "102" to "Tab (2)",
            "103" to "Space (2)",
            "104" to "Sym",
            "105" to "Explorer",
            "106" to "Envelope",
            "107" to "Call",
            "108" to "End Call",
            "109" to "Headset Hook",
            "110" to "Camera",
            "111" to "Focus",
            "112" to "Home (3)",
            "113" to "Back (2)",
            "114" to "Volume Up (2)",
            "115" to "Volume Down (2)",
            "116" to "Mute (2)",
            "117" to "Mic Mute",
            "118" to "Volume Up (3)",
            "119" to "Volume Down (3)",
            "120" to "Power",
            "121" to "Power (2)",
            "132" to "Function",
            "133" to "Caps Lock",
            "134" to "Num Lock",
            "135" to "Scroll Lock (2)",
            "136" to "Meta Left",
            "137" to "Meta Right",
            "138" to "SysRq",
            "139" to "Break",
            "140" to "Move Home (2)",
            "141" to "Move End (2)",
            "142" to "Insert (2)",
            "143" to "Forward Del (2)",
            "144" to "Num Lock (2)",
            "145" to "Numpad 0",
            "146" to "Numpad 1",
            "147" to "Numpad 2",
            "148" to "Numpad 3",
            "149" to "Numpad 4",
            "150" to "Numpad 5",
            "151" to "Numpad 6",
            "152" to "Numpad 7",
            "153" to "Numpad 8",
            "154" to "Numpad 9",
            "155" to "Numpad Divide",
            "156" to "Numpad Multiply",
            "157" to "Numpad Subtract",
            "158" to "Numpad Add",
            "159" to "Numpad Dot",
            "160" to "Numpad Comma",
            "161" to "Numpad Enter",
            "162" to "Numpad Equals",
            "163" to "Numpad Left Paren",
            "165" to "Info",
            "166" to "Channel Up",
            "167" to "Channel Down",
            "168" to "Zoom In",
            "169" to "Zoom Out",
            "170" to "TV",
            "171" to "Window",
            "172" to "Guide",
            "173" to "DVR",
            "174" to "Bookmark",
            "175" to "Captions",
            "176" to "Settings",
            "177" to "TV Power",
            "178" to "TV Input",
            "179" to "STB Power",
            "180" to "STB Input",
            "181" to "AVR Power",
            "182" to "AVR Input",
            "183" to "Prog Red",
            "184" to "Prog Green",
            "185" to "Prog Yellow",
            "186" to "Prog Blue",
            "187" to "App Switch",
            "188" to "Button 1",
            "189" to "Button 2",
            "190" to "Button 3",
            "191" to "Button 4",
            "192" to "Button 5",
            "193" to "Button 6",
            "194" to "Button 7",
            "195" to "Button 8",
            "196" to "Button 9",
            "197" to "Button 10",
            "198" to "Button 11",
            "199" to "Button 12",
            "200" to "Button 13",
            "201" to "Button 14",
            "202" to "Button 15",
            "203" to "Button 16",
            "204" to "Language Switch",
            "205" to "Manner Mode",
            "206" to "3D Mode",
            "207" to "Contacts",
            "208" to "Calendar",
            "209" to "Music",
            "210" to "Calculator",
            "211" to "Zenkaku Hankaku",
            "212" to "Eisu",
            "213" to "Muhenkan",
            "214" to "Henkan",
            "215" to "Katakana Hiragana",
            "216" to "Yen",
            "217" to "Ro",
            "218" to "Kana",
            "219" to "Assist",
            "220" to "Brightness Down (2)",
            "221" to "Brightness Up (2)",
            "222" to "Media Audio Track",
            "223" to "Media Sleep",
            "226" to "Wake Up",
            "227" to "Pairing",
            "228" to "Media Top Menu (2)",
            "229" to "11",
            "230" to "12",
            "231" to "Last Channel",
            "232" to "TV Data Service",
            "233" to "Voice Assist",
            "234" to "TV Radio Service",
            "235" to "TV Teletext",
            "236" to "TV Number Entry",
            "237" to "TV Terrestrial Analog",
            "238" to "TV Terrestrial Digital",
            "239" to "TV Satellite",
            "240" to "TV Satellite BS",
            "241" to "TV Satellite CS",
            "242" to "TV Satellite Service",
            "243" to "TV Network",
            "244" to "TV Antenna Cable",
            "245" to "TV Input HDMI 1",
            "246" to "TV Input HDMI 2",
            "247" to "TV Input HDMI 3",
            "248" to "TV Input HDMI 4",
            "249" to "TV Input Composite 1",
            "250" to "TV Input Composite 2",
            "251" to "TV Input Component 1",
            "252" to "TV Input Component 2",
            "253" to "TV Input VGA 1",
            "254" to "TV Audio Description",
            "255" to "TV Audio Description Mix Up"
        )
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        container.addView(titleView, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        container.addView(stepsRecyclerView)
        container.addView(addStepButton, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
            setMargins(requireContext().dp(16), requireContext().dp(8), requireContext().dp(16), requireContext().dp(4))
        })
        container.addView(footer, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        val editorDialog = MaterialAlertDialogBuilder(requireContext()).setView(container).create()
        editorDialog.setCanceledOnTouchOutside(false)
        editorDialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val eventType = requireArguments().getString(EXTRA_EVENT_TYPE)
            ?: getString(R.string.text_keyboard_layout_macro_tap_event)
        titleView.text = getString(R.string.macro_editor_title, eventType)

        // Receive macro data
        // 三个符号面板（Symbol / Emoji / Kaomoji）也是合法的切层目标：运行时由
        // KeyboardWindow.handleLayerSwitchAction 路由到对应窗口。它们不是布局里的层，
        // 不会出现在 EXTRA_LAYOUT_TARGETS 里，因此显式并入候选。
        // 放在这里（而不是各个调用方）是因为两个宏编辑入口
        // （ButtonsCustomizerActivity 与 KeyEditorActivity）都最终汇聚到本编辑弹框。
        availableLayoutTargets = buildList {
            addAll(requireArguments().getStringArrayList(EXTRA_LAYOUT_TARGETS)?.toList() ?: emptyList())
            addAll(PickerWindow.Key.layerTargetNames)
        }.distinct()
        val initialSteps = requireArguments().serializable<ArrayList<Map<*, *>>>(EXTRA_MACRO_STEPS)
        originalSteps = initialSteps
        if (originalSteps != null) {
            steps.clear()
            steps.addAll(originalSteps!!.map { parseStep(it) })
        } else {
            // Try JSON format if Map format is null (e.g. from new ButtonsCustomizerActivity)
            val json = requireArguments().getString(EXTRA_MACRO_STEPS_JSON)
            if (json != null) {
                try {
                    val macroList = macroJson.decodeFromString<List<MacroStep>>(json)
                    steps.clear()
                    steps.addAll(macroList.map { macroStepToData(it) })
                } catch (_: Exception) {
                    steps.add(MacroStepData())
                }
            } else {
                steps.add(MacroStepData())
            }
        }

        // Both Intent formats must compare against the same normalized, detached snapshot.
        originalSteps = snapshotSteps()
        draftState.read(savedInstanceState)?.let { payload ->
            runCatching { macroJson.decodeFromString<Draft>(payload) }.onSuccess { draft ->
                steps.clear(); steps.addAll(draft.baseline)
                originalSteps = snapshotSteps()
                steps.clear(); steps.addAll(draft.steps)
            }.onFailure { android.util.Log.w("MacroEditor", "Unable to restore editor draft") }
        }
        updateSaveButtonState()

        stepsAdapter = StepsAdapter()
        stepsRecyclerView.adapter = stepsAdapter

        return editorDialog
    }

    override fun onStart() {
        super.onStart()
        // AlertController scans before RecyclerView binds its editable rows, so it treats
        // this form as a picker and adds ALT_FOCUSABLE_IM. Clear it after installation;
        // text steps added or selected later must still be normal system IME targets.
        dialog?.allowImeInput()
        resizeDialog()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        resizeDialog()
    }

    override fun onCancel(dialog: DialogInterface) {
        sendResult(android.app.Activity.RESULT_CANCELED, null)
        super.onCancel(dialog)
    }

    private fun cancelEditor() {
        sendResult(android.app.Activity.RESULT_CANCELED, null)
        dismiss()
    }

    private fun sendResult(resultCode: Int, data: Intent?) {
        if (resultSent) return
        resultSent = true
        parentFragmentManager.setFragmentResult(RESULT_REQUEST_KEY, Bundle().apply {
            putInt(RESULT_CODE, resultCode)
            putParcelable(RESULT_DATA, data)
        })
    }

    private fun resizeDialog() {
        val configuration = requireContext().resources.configuration
        val width = (requireContext().dp(configuration.screenWidthDp) - requireContext().dp(32)).coerceAtMost(requireContext().dp(640))
        val height = (requireContext().dp(configuration.screenHeightDp) * 0.85f).toInt().coerceAtMost(requireContext().dp(720))
        dialog?.window?.setLayout(width, height)
        dialog?.window?.setGravity(Gravity.CENTER)
    }

    /**
     * Show a dialog containing a scrollable FlowLayout of chips.
     * Tapping a chip calls [onSelect] with its index and dismisses the dialog.
     */
    private fun showScrollableChipsDialog(
        title: String,
        items: List<String>,
        highlightIndex: Int = -1,
        onSelect: (Int) -> Unit
    ) {
        val chipsContainer = FlowLayout(requireContext()).apply {
            setPadding(requireContext().dp(12), requireContext().dp(8), requireContext().dp(12), requireContext().dp(8))
        }
        val primaryColor = requireContext().settingsColor(com.google.android.material.R.attr.colorPrimaryContainer)
        val onPrimaryContainerColor = requireContext().settingsColor(com.google.android.material.R.attr.colorOnPrimaryContainer)
        val buttonColor = requireContext().settingsColor(android.R.attr.colorButtonNormal)
        val borderColor = requireContext().settingsColor(android.R.attr.colorControlNormal)
        val scrollView = android.widget.ScrollView(requireContext()).apply {
            addView(chipsContainer)
        }
        val dialog = MaterialAlertDialogBuilder(requireContext())
            .setTitle(title)
            .setView(scrollView)
            .setNegativeButton(R.string.macro_editor_picker_cancel, null)
            .create()
        items.forEachIndexed { index, label ->
            val isHighlighted = index == highlightIndex
            val chip = TextView(requireContext()).apply {
                text = label
                textSize = 14f
                setPadding(requireContext().dp(12), requireContext().dp(8), requireContext().dp(12), requireContext().dp(8))
                gravity = Gravity.CENTER
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(if (isHighlighted) primaryColor else buttonColor)
                    setStroke(requireContext().dp(1), borderColor)
                    cornerRadius = requireContext().dp(4).toFloat()
                }
                setTextColor(if (isHighlighted) onPrimaryContainerColor else requireContext().settingsColor(android.R.attr.textColorPrimary))
                layoutParams = ViewGroup.MarginLayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
                    rightMargin = requireContext().dp(6)
                    bottomMargin = requireContext().dp(6)
                }
                setOnClickListener {
                    onSelect(index)
                    dialog.dismiss()
                }
            }
            chipsContainer.addView(chip)
        }
        dialog.show()
    }

    private val macroJson = kotlinx.serialization.json.Json { ignoreUnknownKeys = true; encodeDefaults = true }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        runCatching {
            val baseline = originalSteps.orEmpty().map(::parseStep)
            draftState.save(outState, macroJson.encodeToString(Draft(baseline, steps)))
        }.onFailure { draftState.retain(outState) }
    }

    override fun onDestroy() {
        if (resultSent || activity?.isFinishing == true) draftState.delete()
        super.onDestroy()
    }

    private fun parseStep(stepMap: Map<*, *>): MacroStepData {
        val type = stepMap["type"] as? String ?: "tap"
        var keys = (stepMap["keys"] as? List<*>)?.mapNotNull { keyMap ->
            (keyMap as? Map<*, *>)?.let { parseKeyData(it) }
        }?.toMutableList() ?: mutableListOf()
        val text = stepMap["text"] as? String ?: ""

        // Parse shortcut type: merge modifiers and key into keys list
        if (type == "shortcut") {
            val modifiers = (stepMap["modifiers"] as? List<*>)?.mapNotNull { modMap ->
                (modMap as? Map<*, *>)?.let { parseKeyData(it) }
            } ?: emptyList()

            val key = (stepMap["key"] as? Map<*, *>)?.let {
                parseKeyData(it)
            }

            // Merge modifiers and key into keys list
            keys = mutableListOf()
            keys.addAll(modifiers)
            key?.let { keys.add(it) }
        }

        // Parse edit type: store action as the code of the first key
        if (type == "edit") {
            val action = stepMap["action"] as? String ?: "copy"
            keys = mutableListOf(KeyData(keyType = "fcitx", code = action))
        }

        if (type == "app") {
            val actionId = stepMap["id"] as? String ?: "theme"
            keys = mutableListOf(KeyData(keyType = "fcitx", code = actionId))
        }

        if (type == "layer") {
            val target = stepMap["target"] as? String ?: ""
            val mode = normalizeLayerMode(stepMap["mode"] as? String)
            return MacroStepData(
                type = "layer",
                keys = mutableListOf(KeyData(keyType = "fcitx", code = mode)),
                text = target
            )
        }

        return MacroStepData(type = type, keys = keys, text = text)
    }

    private fun macroStepToData(step: MacroStep): MacroStepData = when (step) {
        is MacroStep.Tap -> MacroStepData("tap", keys = step.keys.map { keyRefToData(it) }.toMutableList())
        is MacroStep.Down -> MacroStepData("down", keys = step.keys.map { keyRefToData(it) }.toMutableList())
        is MacroStep.Up -> MacroStepData("up", keys = step.keys.map { keyRefToData(it) }.toMutableList())
        is MacroStep.Text -> MacroStepData("text", text = step.text)
        is MacroStep.Edit -> MacroStepData("edit", keys = mutableListOf(KeyData("fcitx", step.action)))
        is MacroStep.AppAction -> MacroStepData("app", keys = mutableListOf(KeyData("fcitx", step.id)))
        is MacroStep.Shortcut -> {
            val keys = mutableListOf<KeyData>()
            keys.addAll(step.modifiers.map { keyRefToData(it) })
            keys.add(keyRefToData(step.key))
            MacroStepData("shortcut", keys = keys)
        }
        is MacroStep.LayerSwitch -> MacroStepData("layer", keys = mutableListOf(KeyData("fcitx", step.mode.name)), text = step.target)
    }

    private fun keyRefToData(ref: KeyRef): KeyData = when (ref) {
        is KeyRef.Fcitx -> KeyData("fcitx", ref.code)
        is KeyRef.Android -> KeyData("android", ref.code.toString())
    }


    private fun addNewStep() {
        // Validate existing steps
        steps.forEachIndexed { index, step ->
            when (step.type) {
                "text" -> {
                    if (step.text.isBlank()) {
                        Toast.makeText(requireContext(), getString(R.string.macro_editor_step_text_empty), Toast.LENGTH_SHORT).show()
                        return
                    }
                }
                "tap", "down", "up" -> {
                    if (step.keys.isEmpty()) {
                        Toast.makeText(requireContext(), getString(R.string.macro_editor_step_keys_empty, index + 1), Toast.LENGTH_SHORT).show()
                        return
                    }
                }
                "shortcut" -> {
                    val modifiers = step.keys.filter { isModifierKey(it.code) }
                    val nonModifiers = step.keys.filter { !isModifierKey(it.code) }
                    if (modifiers.isEmpty()) {
                        Toast.makeText(requireContext(), getString(R.string.macro_editor_step_shortcut_modifiers_empty, index + 1), Toast.LENGTH_SHORT).show()
                        return
                    }
                    if (nonModifiers.size != 1) {
                        Toast.makeText(requireContext(), getString(R.string.macro_editor_step_shortcut_multiple_keys, index + 1), Toast.LENGTH_SHORT).show()
                        return
                    }
                }
                "edit" -> {
                    if (step.keys.isEmpty()) {
                        Toast.makeText(requireContext(), getString(R.string.macro_editor_step_edit_action_required, index + 1), Toast.LENGTH_SHORT).show()
                        return
                    }
                }
                "app" -> {
                    if (step.keys.isEmpty()) {
                        Toast.makeText(requireContext(), getString(R.string.macro_editor_step_app_action_required, index + 1), Toast.LENGTH_SHORT).show()
                        return
                    }
                }
                "layer" -> {
                    if (normalizeLayerMode(step.keys.firstOrNull()?.code) != "back" && step.text.isBlank()) {
                        Toast.makeText(requireContext(), getString(R.string.macro_editor_step_layer_target_required, index + 1), Toast.LENGTH_SHORT).show()
                        return
                    }
                    // availableLayoutTargets is only a picker suggestion set, not a hard
                    // whitelist: layer targets are resolved at runtime (bare sub-layer
                    // labels and cross-layout keys are valid) and a custom button is not
                    // bound to a single layout profile, so a snapshot-based whitelist is
                    // inherently incomplete. Do not reject a non-blank target here.
                }
            }
        }

        steps.add(MacroStepData())
        stepsAdapter.notifyItemInserted(steps.size - 1)
        stepsRecyclerView.scrollToPosition(steps.size - 1)
        updateSaveButtonState()
    }

    private fun saveAndFinish() {
        // Validate data
        steps.forEachIndexed { index, step ->
            if (step.type == "text" && step.text.isBlank()) {
                Toast.makeText(requireContext(), getString(R.string.macro_editor_step_text_empty), Toast.LENGTH_SHORT).show()
                return
            }
            if (step.type in listOf("tap", "down", "up") && step.keys.isEmpty()) {
                Toast.makeText(requireContext(), getString(R.string.macro_editor_step_keys_empty, index + 1), Toast.LENGTH_SHORT).show()
                return
            }
            if (step.type == "shortcut") {
                val modifiers = step.keys.filter { isModifierKey(it.code) }
                val nonModifiers = step.keys.filter { !isModifierKey(it.code) }
                if (modifiers.isEmpty()) {
                    Toast.makeText(requireContext(), getString(R.string.macro_editor_step_shortcut_modifiers_empty, index + 1), Toast.LENGTH_SHORT).show()
                    return
                }
                if (nonModifiers.size != 1) {
                    Toast.makeText(requireContext(), getString(R.string.macro_editor_step_shortcut_multiple_keys, index + 1), Toast.LENGTH_SHORT).show()
                    return
                }
            }
            if (step.type == "app" && step.keys.isEmpty()) {
                Toast.makeText(requireContext(), getString(R.string.macro_editor_step_app_action_required, index + 1), Toast.LENGTH_SHORT).show()
                return
            }
            if (step.type == "layer" && normalizeLayerMode(step.keys.firstOrNull()?.code) != "back" && step.text.isBlank()) {
                Toast.makeText(requireContext(), getString(R.string.macro_editor_step_layer_target_required, index + 1), Toast.LENGTH_SHORT).show()
                return
            }
        }

        // Validate that each key has matching down and up events
        val keyEventCounts = mutableMapOf<Pair<String, String>, Pair<Int, Int>>() // (keyType, code) -> (downCount, upCount)
        steps.forEach { step ->
            when (step.type) {
                "tap" -> {
                    step.keys.forEach { key ->
                        val keyId = Pair(key.keyType, key.code)
                        val (down, up) = keyEventCounts.getOrDefault(keyId, Pair(0, 0))
                        keyEventCounts[keyId] = Pair(down + 1, up + 1)
                    }
                }
                "down" -> {
                    step.keys.forEach { key ->
                        val keyId = Pair(key.keyType, key.code)
                        val (down, up) = keyEventCounts.getOrDefault(keyId, Pair(0, 0))
                        keyEventCounts[keyId] = Pair(down + 1, up)
                    }
                }
                "up" -> {
                    step.keys.forEach { key ->
                        val keyId = Pair(key.keyType, key.code)
                        val (down, up) = keyEventCounts.getOrDefault(keyId, Pair(0, 0))
                        keyEventCounts[keyId] = Pair(down, up + 1)
                    }
                }
                "shortcut" -> {
                    val modifiers = step.keys.filter { isModifierKey(it.code) }
                    val nonModifiers = step.keys.filter { !isModifierKey(it.code) }
                    // Modifiers: down at start, up at end
                    modifiers.forEach { key ->
                        val keyId = Pair(key.keyType, key.code)
                        val (down, up) = keyEventCounts.getOrDefault(keyId, Pair(0, 0))
                        keyEventCounts[keyId] = Pair(down + 1, up + 1)
                    }
                    // Key: tap (down + up)
                    nonModifiers.firstOrNull()?.let { key ->
                        val keyId = Pair(key.keyType, key.code)
                        val (down, up) = keyEventCounts.getOrDefault(keyId, Pair(0, 0))
                        keyEventCounts[keyId] = Pair(down + 1, up + 1)
                    }
                }
                // "text", "edit" and "app" do not involve key events
            }
        }
        // Check for unmatched down/up events
        val unmatchedKeys = keyEventCounts.filter { (_, counts) -> counts.first != counts.second }
        if (unmatchedKeys.isNotEmpty()) {
            val keyNames = unmatchedKeys.keys.joinToString(", ") { (type, code) -> "$type:$code" }
            Toast.makeText(requireContext(), getString(R.string.macro_editor_key_event_unmatched, keyNames), Toast.LENGTH_SHORT).show()
            return
        }

        // Convert to Map format
        val result = steps.map { step ->
            buildMap {
                put("type", step.type)
                if (step.type in listOf("tap", "down", "up", "shortcut")) {
                    if (step.type == "shortcut") {
                        // Separate modifiers and key for shortcut type
                        val modifiers = step.keys.filter { isModifierKey(it.code) }
                        val nonModifiers = step.keys.filter { !isModifierKey(it.code) }
                        put("modifiers", modifiers.map { mapOf(it.keyType to it.code) })
                        nonModifiers.firstOrNull()?.let { put("key", mapOf(it.keyType to it.code)) }
                    } else {
                        put("keys", step.keys.map { key -> mapOf(key.keyType to key.code) })
                    }
                }
                if (step.type == "text") {
                    put("text", step.text)
                }
                if (step.type == "layer") {
                    put("type", "layer")
                    put("mode", normalizeLayerMode(step.keys.firstOrNull()?.code))
                    put("target", step.text)
                }
                if (step.type == "edit") {
                    // Get action from the code of the first key for edit type
                    put("action", step.keys.firstOrNull()?.code ?: "copy")
                }
                if (step.type == "app") {
                    put("id", step.keys.firstOrNull()?.code ?: "theme")
                }
            }
        }

        val data = android.content.Intent()
        data.putExtra(EXTRA_MACRO_RESULT, ArrayList(result))
        // Also provide JSON format for reliable deserialization
        val macroSteps = fromStepsExtra(ArrayList(result))
        data.putExtra(EXTRA_MACRO_RESULT_JSON, macroJson.encodeToString(macroSteps))
        // Echo the caller's token so it can locate the edit target even if it was recreated.
        requireArguments().getString(EXTRA_TARGET_TOKEN)?.let { data.putExtra(EXTRA_TARGET_TOKEN, it) }
        sendResult(android.app.Activity.RESULT_OK, data)
        dismiss()
    }

    private fun snapshotSteps() = steps.map { step ->
        buildMap {
            put("type", step.type)
            if (step.type in listOf("tap", "down", "up", "shortcut")) {
                if (step.type == "shortcut") {
                    val modifiers = step.keys.filter { isModifierKey(it.code) }
                    val nonModifiers = step.keys.filter { !isModifierKey(it.code) }
                    put("modifiers", modifiers.map { mapOf(it.keyType to it.code) })
                    nonModifiers.firstOrNull()?.let { put("key", mapOf(it.keyType to it.code)) }
                } else {
                    put("keys", step.keys.map { key -> mapOf(key.keyType to key.code) })
                }
            }
            if (step.type == "text") {
                put("text", step.text)
            }
            if (step.type == "layer") {
                put("type", "layer")
                put("mode", normalizeLayerMode(step.keys.firstOrNull()?.code))
                put("target", step.text)
            }
            if (step.type == "edit") {
                put("action", step.keys.firstOrNull()?.code ?: "copy")
            }
            if (step.type == "app") {
                put("id", step.keys.firstOrNull()?.code ?: "theme")
            }
        }
    }

    /** Compare normalized values without sharing the editable keys or lists. */
    private fun isStepsChanged(): Boolean {
        val currentSteps = snapshotSteps()
        if (originalSteps == null) {
            // Original is empty, now has data
            return currentSteps.isNotEmpty() && !(currentSteps.size == 1 && currentSteps.first()["type"] == "tap" && (currentSteps.first()["keys"] as? List<*>)?.isEmpty() != false)
        }

        // Compare size
        if (currentSteps.size != originalSteps?.size) return true

        // Compare item by item
        for (i in currentSteps.indices) {
            val current = currentSteps[i]
            val original = originalSteps?.get(i)
            if (current != original) return true
        }

        return false
    }

    /**
     * Update save button enabled state
     */
    private fun updateSaveButtonState() {
        hasChanges = isStepsChanged()
        confirmButton.isEnabled = hasChanges
    }

    inner class StepsAdapter : RecyclerView.Adapter<StepViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StepViewHolder {
            return StepViewHolder(LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(requireContext().dp(12), requireContext().dp(12), requireContext().dp(12), requireContext().dp(12))
                background = MaterialShapeDrawable(ShapeAppearanceModel.builder()
                    .setAllCornerSizes(requireContext().dp(16).toFloat()).build()).apply {
                    fillColor = ColorStateList.valueOf(requireContext().settingsColor(com.google.android.material.R.attr.colorSurfaceBright))
                    setStroke(requireContext().dp(1).toFloat(), requireContext().settingsColor(com.google.android.material.R.attr.colorOutlineVariant))
                }
                layoutParams = RecyclerView.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                    setMargins(requireContext().dp(16), requireContext().dp(4), requireContext().dp(16), requireContext().dp(4))
                }
            })
        }

        override fun onBindViewHolder(holder: StepViewHolder, position: Int) {
            holder.bind(steps[position])
        }

        override fun getItemCount() = steps.size
    }

    inner class StepViewHolder(private val container: LinearLayout) : RecyclerView.ViewHolder(container) {
        private lateinit var keysFlow: FlowLayout
        private lateinit var typeSpinner: Spinner
        private lateinit var textEditContainer: LinearLayout
        private lateinit var deleteBtn: TextView

        fun bind(step: MacroStepData) {
            container.removeAllViews()
            if (step.type == "layer") {
                ensureLayerMode(step)
            }

            val contentRow = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
            }
            val typeRow = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            typeSpinner = MaterialSpinner(requireContext(), cornerRadiusDp = 12).apply {
                layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
            }
            val typeAdapter = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_spinner_item,
                arrayOf(
                    getString(R.string.macro_editor_step_type_tap),
                    getString(R.string.macro_editor_step_type_shortcut),
                    getString(R.string.macro_editor_step_type_edit),
                    getString(R.string.macro_editor_step_type_app),
                    getString(R.string.macro_editor_step_type_layer),
                    getString(R.string.macro_editor_step_type_down),
                    getString(R.string.macro_editor_step_type_up),
                    getString(R.string.macro_editor_step_type_text)
                )
            )
            typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            typeSpinner.adapter = typeAdapter
            typeSpinner.setSelection(STEP_TYPES.indexOf(step.type))
            typeRow.addView(typeSpinner)
            contentRow.addView(typeRow, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

            // Keep action values below the selector so long labels and key chips can wrap.
            val keysFlowContainer = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                    topMargin = requireContext().dp(8)
                }
            }

            keysFlow = FlowLayout(requireContext()).apply {
                setPadding(0, requireContext().dp(4), 0, requireContext().dp(4))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            keysFlowContainer.addView(keysFlow)
            contentRow.addView(keysFlowContainer)

            // Text input (text type) - placed inside keysFlowContainer
            textEditContainer = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                visibility = View.GONE  // hidden initially, controlled by updateVisibility
                setPadding(0, requireContext().dp(4), 0, requireContext().dp(4))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            val textEdit = TextInputEditText(requireContext()).apply {
                setText(step.text)
                hint = if (step.type == "layer") {
                    getString(R.string.macro_editor_layer_target_hint)
                } else {
                    null
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                setPadding(requireContext().dp(8), requireContext().dp(8), requireContext().dp(8), requireContext().dp(8))
                // Observe text changes and sync to step
                addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                    override fun afterTextChanged(s: android.text.Editable?) {
                        step.text = s?.toString() ?: ""
                        updateSaveButtonState()
                    }
                })
            }
            textEditContainer.addView(textEdit)
            keysFlowContainer.addView(textEditContainer)

            // Add contentRow to container (outermost layer)
            container.addView(contentRow)

            deleteBtn = EditorUi.icon(requireContext(),
                R.drawable.ic_baseline_delete_24, R.string.macro_editor_delete) {
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle(R.string.macro_editor_delete_step_title)
                    .setMessage(R.string.macro_editor_delete_step_message)
                    .setPositiveButton(R.string.macro_editor_delete) { _, _ ->
                        val removeIndex = steps.indexOfFirst { it === step }
                            .takeIf { it >= 0 }
                            ?: bindingAdapterPosition.takeIf { it != RecyclerView.NO_POSITION && it in steps.indices }
                            ?: return@setPositiveButton
                        steps.removeAt(removeIndex)
                        stepsAdapter.notifyItemRemoved(removeIndex)
                        updateSaveButtonState()
                    }
                    .setNegativeButton(R.string.macro_editor_cancel, null)
                    .show()
            }
            typeRow.addView(deleteBtn, LinearLayout.LayoutParams(requireContext().dp(48), requireContext().dp(48)).apply {
                marginStart = requireContext().dp(8)
                gravity = Gravity.CENTER_VERTICAL
            })

            // Update UI visibility
            val textEditDefaultKeyListener = textEdit.keyListener
            updateVisibility(step)
            configureTextEditorForType(step, textEdit, textEditDefaultKeyListener)

            // Render key chips
            renderKeys(step)

            // Type switch listener
            typeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                    val oldType = step.type
                    val newType = STEP_TYPES[pos]
                    val oldUsesText = oldType in listOf("text", "layer")
                    val newUsesText = newType in listOf("text", "layer")

                    // Check if type change would clear data
                    val willClearData = ((oldType == "edit" || oldType == "app") &&
                        newType != oldType && step.keys.isNotEmpty()) ||
                                        ((newType == "edit" || newType == "app") &&
                                            oldType != newType && step.keys.isNotEmpty()) ||
                                        (oldUsesText && !newUsesText && step.text.isNotEmpty()) ||
                                        (!oldUsesText && newUsesText && step.text.isNotEmpty())

                    if (willClearData) {
                        // Show confirmation dialog before clearing data
                        MaterialAlertDialogBuilder(requireContext())
                            .setTitle(R.string.macro_editor_type_change_title)
                            .setMessage(R.string.macro_editor_type_change_message)
                            .setPositiveButton(R.string.macro_editor_confirm) { _, _ ->
                                step.type = newType
                                // Clear old data when switching types
                                if ((oldType == "edit" || oldType == "app") && newType != oldType) {
                                    step.keys.clear()
                                }
                                if ((newType == "edit" || newType == "app") && oldType != newType) {
                                    step.keys.clear()
                                }
                                if (oldType == "text" && newType != "text") {
                                    step.text = ""
                                }
                                if (!oldUsesText && newUsesText) {
                                    step.keys.clear()
                                }
                                if (oldUsesText && !newUsesText) {
                                    step.text = ""
                                }
                                if (newType == "layer") {
                                    ensureLayerMode(step)
                                }
                                textEdit.hint = if (step.type == "layer") {
                                    getString(R.string.macro_editor_layer_target_hint)
                                } else {
                                    null
                                }
                                updateVisibility(step)
                                configureTextEditorForType(step, textEdit, textEditDefaultKeyListener)
                                renderKeys(step)
                                updateSaveButtonState()
                            }
                            .setNegativeButton(R.string.macro_editor_cancel) { _, _ ->
                                // Revert spinner to old type
                                typeSpinner.setSelection(STEP_TYPES.indexOf(oldType))
                            }
                            .setOnCancelListener {
                                // Revert spinner to old type when dialog is cancelled
                                typeSpinner.setSelection(STEP_TYPES.indexOf(oldType))
                            }
                            .show()
                    } else {
                        // No data will be cleared, proceed with type change
                        step.type = newType
                        if (newType == "layer") {
                            ensureLayerMode(step)
                        }
                        textEdit.hint = if (step.type == "layer") {
                            getString(R.string.macro_editor_layer_target_hint)
                        } else {
                            null
                        }
                        updateVisibility(step)
                        configureTextEditorForType(step, textEdit, textEditDefaultKeyListener)
                        renderKeys(step)
                        updateSaveButtonState()
                    }
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }

        private fun updateVisibility(step: MacroStepData) {
            // Only text type uses inline EditText. Layer uses compact chip + pickers.
            keysFlow.visibility = if (step.type == "text") View.GONE else View.VISIBLE
            textEditContainer.visibility = if (step.type == "text") View.VISIBLE else View.GONE
        }

        private fun configureTextEditorForType(
            step: MacroStepData,
            textEdit: EditText,
            defaultKeyListener: android.text.method.KeyListener?
        ) {
            if (step.type == "text") {
                textEdit.keyListener = defaultKeyListener
                textEdit.isFocusable = true
                textEdit.isFocusableInTouchMode = true
                textEdit.isCursorVisible = true
                textEdit.isLongClickable = true
                textEdit.setOnClickListener(null)
            } else {
                textEdit.keyListener = null
                textEdit.isFocusable = false
                textEdit.isFocusableInTouchMode = false
                textEdit.isCursorVisible = false
                textEdit.isLongClickable = false
                textEdit.setOnClickListener(null)
            }
        }


        private fun renderKeys(step: MacroStepData) {
            keysFlow.removeAllViews()
            step.keys.forEachIndexed { index, key ->
                val isShortcutType = step.type == "shortcut"
                val isEditType = step.type == "edit"
                val isAppType = step.type == "app"
                val isLayerType = step.type == "layer"
                val isModifier = isModifierKey(key.code)

                // Chip color: shortcut modifier keys use gray, target key uses primary; edit uses button normal
                val chipColor = when {
                    isShortcutType && isModifier -> requireContext().settingsColor(android.R.attr.colorButtonNormal)
                    isShortcutType && !isModifier -> requireContext().settingsColor(com.google.android.material.R.attr.colorPrimaryContainer)
                    isEditType -> requireContext().settingsColor(android.R.attr.colorButtonNormal)
                    else -> requireContext().settingsColor(android.R.attr.colorButtonNormal)
                }

                val keyChip = TextView(requireContext()).apply {
                    text = when {
                        isAppType -> getAppActionLabel(key.code)
                        isLayerType -> getLayerActionLabel(normalizeLayerMode(key.code), step.text)
                        key.keyType == "fcitx" -> getFcitxKeyDisplayName(key.code)
                        else -> key.code
                    }
                    textSize = 14f
                    setPadding(requireContext().dp(10), requireContext().dp(8), requireContext().dp(10), requireContext().dp(8))
                    gravity = Gravity.CENTER
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(chipColor)
                        setStroke(requireContext().dp(1), requireContext().settingsColor(android.R.attr.colorControlNormal))
                        cornerRadius = requireContext().dp(4).toFloat()
                    }
                    if (isShortcutType && !isModifier) {
                        setTextColor(requireContext().settingsColor(com.google.android.material.R.attr.colorOnPrimaryContainer))
                    }
                    layoutParams = ViewGroup.MarginLayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
                        rightMargin = requireContext().dp(6)
                        bottomMargin = requireContext().dp(4)
                        topMargin = requireContext().dp(4)
                    }
                    setOnClickListener {
                        if (isEditType) {
                            // Edit type: click to select action
                            showClipboardActionPicker { selectedAction ->
                                step.keys.clear()
                                step.keys.add(KeyData(keyType = "fcitx", code = selectedAction))
                                renderKeys(step)
                                updateSaveButtonState()
                            }
                        } else if (isAppType) {
                            showAppActionPicker { selectedAction ->
                                step.keys.clear()
                                step.keys.add(KeyData(keyType = "fcitx", code = selectedAction))
                                renderKeys(step)
                                updateSaveButtonState()
                            }
                        } else if (isLayerType) {
                            showLayerModeThenTargetPicker(
                                currentMode = normalizeLayerMode(key.code),
                                currentTarget = step.text
                            ) { selectedMode, selectedTarget ->
                                step.keys.clear()
                                step.keys.add(KeyData(keyType = "fcitx", code = selectedMode))
                                step.text = selectedTarget
                                renderKeys(step)
                                updateSaveButtonState()
                            }
                        } else {
                            // Other types: tap to edit
                            showEditKeyDialog(step, key, onSuccess = {
                                renderKeys(step)
                                updateSaveButtonState()
                            }, onCancel = {})
                        }
                    }
                }
                keysFlow.addView(keyChip)
            }

            // Add-key button - show add key for tap/shortcut/down/up; for edit show only [+]
            if (step.type in listOf("tap", "shortcut", "down", "up")) {
                val addKeyChip = TextView(requireContext()).apply {
                    text = "+"
                    textSize = 14f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setPadding(requireContext().dp(10), requireContext().dp(8), requireContext().dp(10), requireContext().dp(8))
                    gravity = Gravity.CENTER
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(requireContext().settingsColor(com.google.android.material.R.attr.colorPrimaryContainer))
                        setStroke(requireContext().dp(1), requireContext().settingsColor(android.R.attr.colorControlNormal))
                        cornerRadius = requireContext().dp(4).toFloat()
                    }
                    setTextColor(requireContext().settingsColor(com.google.android.material.R.attr.colorOnPrimaryContainer))
                    layoutParams = ViewGroup.MarginLayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
                        rightMargin = requireContext().dp(6)
                        bottomMargin = requireContext().dp(4)
                        topMargin = requireContext().dp(4)
                    }
                    setOnClickListener {
                        val newKey = KeyData()
                        showEditKeyDialog(step, newKey, onSuccess = {
                            // Check if the key already exists
                            val isDuplicate = step.keys.any {
                                it.keyType == newKey.keyType && it.code == newKey.code
                            }
                            if (isDuplicate) {
                                Toast.makeText(requireContext(), getString(R.string.macro_editor_key_duplicate, newKey.code), Toast.LENGTH_SHORT).show()
                            } else {
                                step.keys.add(newKey)
                                renderKeys(step)
                                updateSaveButtonState()
                            }
                        }, onCancel = {})
                    }
                }
                keysFlow.addView(addKeyChip)
            } else if ((step.type == "edit" || step.type == "app" || step.type == "layer") && step.keys.isEmpty()) {
                // Edit/App/Layer type: show [+] button when empty
                val addClipboardChip = TextView(requireContext()).apply {
                    text = "+"
                    textSize = 14f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setPadding(requireContext().dp(10), requireContext().dp(8), requireContext().dp(10), requireContext().dp(8))
                    gravity = Gravity.CENTER
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(requireContext().settingsColor(com.google.android.material.R.attr.colorPrimaryContainer))
                        setStroke(requireContext().dp(1), requireContext().settingsColor(android.R.attr.colorControlNormal))
                        cornerRadius = requireContext().dp(4).toFloat()
                    }
                    setTextColor(requireContext().settingsColor(com.google.android.material.R.attr.colorOnPrimaryContainer))
                    layoutParams = ViewGroup.MarginLayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
                        rightMargin = requireContext().dp(6)
                        bottomMargin = requireContext().dp(4)
                        topMargin = requireContext().dp(4)
                    }
                    setOnClickListener {
                        if (step.type == "edit") {
                            showClipboardActionPicker { selectedAction ->
                                step.keys.clear()
                                step.keys.add(KeyData(keyType = "fcitx", code = selectedAction))
                                renderKeys(step)
                                updateSaveButtonState()
                            }
                        } else if (step.type == "app") {
                            showAppActionPicker { selectedAction ->
                                step.keys.clear()
                                step.keys.add(KeyData(keyType = "fcitx", code = selectedAction))
                                renderKeys(step)
                                updateSaveButtonState()
                            }
                        } else {
                            showLayerModeThenTargetPicker(
                                currentMode = normalizeLayerMode(step.keys.firstOrNull()?.code),
                                currentTarget = step.text
                            ) { selectedMode, selectedTarget ->
                                step.keys.clear()
                                step.keys.add(KeyData(keyType = "fcitx", code = selectedMode))
                                step.text = selectedTarget
                                renderKeys(step)
                                updateSaveButtonState()
                            }
                        }
                    }
                }
                keysFlow.addView(addClipboardChip)
            }
            // When edit type already has an action: hide [+], tap chip to reselect
        }

        /**
         * Show edit action picker
         */
        private fun showClipboardActionPicker(onSelect: (String) -> Unit) {
            val actions = arrayOf("copy", "cut", "paste", "selectAll", "undo", "redo")
            val actionLabels = arrayOf(
                getString(R.string.macro_editor_action_copy),
                getString(R.string.macro_editor_action_cut),
                getString(R.string.macro_editor_action_paste),
                getString(R.string.macro_editor_action_select_all),
                getString(R.string.macro_editor_action_undo),
                getString(R.string.macro_editor_action_redo)
            )
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.macro_editor_picker_title)
                .setItems(actionLabels) { _, which ->
                    onSelect(actions[which])
                }
                .setNegativeButton(R.string.macro_editor_picker_cancel, null)
                .show()
        }

        private fun showAppActionPicker(onSelect: (String) -> Unit) {
            // Labels are derived from the ids, so row N always selects APP_ACTION_IDS[N].
            val actionLabels = APP_ACTION_IDS.map { getAppActionLabel(it) }.toTypedArray()
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.macro_editor_app_picker_title)
                .setItems(actionLabels) { _, which ->
                    onSelect(APP_ACTION_IDS[which])
                }
                .setNegativeButton(R.string.macro_editor_picker_cancel, null)
                .show()
        }

        private fun getAppActionLabel(actionId: String): String {
            return when (actionId) {
                "theme" -> getString(R.string.theme)
                "icon_theme" -> getString(R.string.icon_theme)
                "virtual_keyboard" -> getString(R.string.virtual_keyboard)
                "more" -> getString(R.string.macro_editor_app_action_more)
                "browse_user_data_dir" -> getString(R.string.browse_user_data_dir)
                "clipboard" -> getString(R.string.clipboard)
                "cursor_move" -> getString(R.string.text_editing)
                "floating_toggle" -> getString(R.string.floating_keyboard)
                "language_switch" -> getString(R.string.language_switch)
                "switch_input_method" -> getString(R.string.switch_input_method)
                "rime_schema_menu" -> getString(R.string.rime_schema_menu)
                "reload_config" -> getString(R.string.reload_config)
                "one_handed_keyboard" -> getString(R.string.one_handed_keyboard)
                "input_method_options" -> getString(R.string.input_method_options)
                "undo" -> getString(R.string.undo)
                "redo" -> getString(R.string.redo)
                "settings_global_options" -> getString(R.string.rime_settings)
                // no longer offered by the picker, but older macros may still carry it
                "settings_input_methods" -> getString(R.string.rime_settings)
                "settings_candidates_window" -> getString(R.string.candidates_window)
                "settings_clipboard" -> getString(R.string.clipboard)
                "settings_symbol" -> getString(R.string.emoji_and_symbols)
                "settings_advanced" -> getString(R.string.advanced)
                "settings_developer" -> getString(R.string.developer)
                "settings_about" -> getString(R.string.about)
                "settings_license" -> getString(R.string.license)
                "edit_text_keyboard_layout" -> getString(R.string.edit_text_keyboard_layout)
                "text_keyboard_layout_file_select" -> getString(R.string.text_keyboard_layout_file_select_title)
                "edit_fontset" -> getString(R.string.edit_fontset)
                "addon_list" -> getString(R.string.rime_settings)
                "table_input_methods" -> getString(R.string.macro_editor_table_input_methods)
                "pinyin_custom_phrase" -> getString(R.string.macro_editor_pinyin_custom_phrase)
                "pinyin_dict" -> getString(R.string.macro_editor_pinyin_dict)
                "edit_buttons" -> getString(R.string.edit_buttons)
                "split_keyboard_calibration" -> getString(R.string.split_keyboard_calibration_title)
                "web_editor_bridge" -> getString(R.string.web_editor_bridge_title)
                else -> actionId
            }
        }

        private fun showEditKeyDialog(step: MacroStepData, key: KeyData, onSuccess: () -> Unit, onCancel: () -> Unit) {
            // Chip selection is a draft until Confirm, including dismissal by Back/outside.
            val draft = key.copy()
            val dialogView = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(requireContext().dp(16), requireContext().dp(16), requireContext().dp(16), requireContext().dp(16))
            }

            // Key type selector - hidden from UI (fcitx only for public release)
            val keyTypeRow = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                visibility = View.GONE  // Hidden from UI
            }
            val keyTypeLabel = TextView(requireContext()).apply {
                text = getString(R.string.macro_editor_key_type_label)
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT).apply { weight = 1f }
            }
            keyTypeRow.addView(keyTypeLabel)

            val keyTypeEditSpinner = MaterialSpinner(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT).apply { weight = 1f }
            }
            val keyTypeEditAdapter = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_spinner_item,
                KEY_TYPES
            )
            keyTypeEditAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            keyTypeEditSpinner.adapter = keyTypeEditAdapter
            keyTypeEditSpinner.setSelection(KEY_TYPES.indexOf(key.keyType))
            keyTypeRow.addView(keyTypeEditSpinner)
            // Not adding keyTypeRow to dialogView - hidden from UI
            // dialogView.addView(keyTypeRow)

            // Key value selector - directly embedded chips list
            var currentKeyType = draft.keyType
            val keysList = if (currentKeyType == "fcitx") FCITX_KEYS else ANDROID_KEYS
            val displayList = if (currentKeyType == "fcitx") {
                keysList.map { getFcitxKeyDisplayName(it) }
            } else {
                keysList.map { ANDROID_KEY_NAMES[it] ?: it }
            }
            val primaryColor = requireContext().settingsColor(com.google.android.material.R.attr.colorPrimaryContainer)
            val onPrimaryContainerColor = requireContext().settingsColor(com.google.android.material.R.attr.colorOnPrimaryContainer)
            val buttonColor = requireContext().settingsColor(android.R.attr.colorButtonNormal)
            val borderColor = requireContext().settingsColor(android.R.attr.colorControlNormal)

            var highlightIndex = keysList.indexOfFirst { it.equals(draft.code, ignoreCase = true) }
                .takeIf { it >= 0 } ?: -1

            val chipsContainer = FlowLayout(requireContext()).apply {
                setPadding(requireContext().dp(12), requireContext().dp(8), requireContext().dp(12), requireContext().dp(8))
            }

            fun renderChips() {
                chipsContainer.removeAllViews()
                keysList.forEachIndexed { index, _ ->
                    val isHighlighted = index == highlightIndex
                    val chip = TextView(requireContext()).apply {
                        text = displayList[index]
                        textSize = 14f
                        setPadding(requireContext().dp(12), requireContext().dp(8), requireContext().dp(12), requireContext().dp(8))
                        gravity = Gravity.CENTER
                        background = android.graphics.drawable.GradientDrawable().apply {
                            setColor(if (isHighlighted) primaryColor else buttonColor)
                            setStroke(requireContext().dp(1), borderColor)
                            cornerRadius = requireContext().dp(4).toFloat()
                        }
                        setTextColor(if (isHighlighted) onPrimaryContainerColor else requireContext().settingsColor(android.R.attr.textColorPrimary))
                        layoutParams = ViewGroup.MarginLayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply {
                            rightMargin = requireContext().dp(6)
                            bottomMargin = requireContext().dp(6)
                        }
                        setOnClickListener {
                            draft.code = keysList[index]
                            highlightIndex = index
                            renderChips()
                        }
                    }
                    chipsContainer.addView(chip)
                }
            }
            renderChips()

            val scrollView = android.widget.ScrollView(requireContext()).apply {
                addView(chipsContainer)
            }
            dialogView.addView(scrollView)

            val dialog = MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.macro_editor_edit_key_title)
                .setView(dialogView)
                .setPositiveButton(R.string.macro_editor_confirm) { _, _ ->
                    key.code = draft.code
                    key.keyType = currentKeyType
                    onSuccess()
                }
                .setNegativeButton(R.string.macro_editor_cancel) { _, _ ->
                    onCancel()
                }
                .setNeutralButton(R.string.macro_editor_delete, null)
                .create()
            dialog.show()
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                // Imported macros may contain equal keys. Remove this occurrence only;
                // an unconfirmed new key does not belong to the step yet.
                val index = step.keys.indexOfFirst { it === key }
                if (index >= 0) {
                    step.keys.removeAt(index)
                    renderKeys(step)
                    updateSaveButtonState()
                }
                dialog.dismiss()
            }

            // Key type change listener - hidden spinner, no-op
            var isInitialKeyTypeSelection = true
            keyTypeEditSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                    if (isInitialKeyTypeSelection) {
                        isInitialKeyTypeSelection = false
                        return
                    }
                    currentKeyType = KEY_TYPES[pos]
                    // Key type spinner is hidden (GONE), chips are embedded directly in dialog
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }

        /**
         * Show modifier key selector
         */
        private fun showModifierPicker(currentModifiers: List<KeyData>, onSelect: (String) -> Unit) {
            val availableModifiers = arrayOf(
                "Ctrl_L", "Ctrl_R",
                "Alt_L", "Alt_R",
                "Shift_L", "Shift_R",
                "Meta_L", "Meta_R",
                "Super_L", "Super_R",
                "Hyper_L", "Hyper_R",
                "Mode_switch",
                "ISO_Level3_Shift",
                "ISO_Level5_Shift"
            )
                .filter { it !in currentModifiers.map { m -> m.code } }

            if (availableModifiers.isEmpty()) {
                Toast.makeText(requireContext(), R.string.macro_editor_all_modifiers_added, Toast.LENGTH_SHORT).show()
                return
            }

            showScrollableChipsDialog(
                title = getString(R.string.macro_editor_select_modifier_title),
                items = availableModifiers
            ) { index ->
                onSelect(availableModifiers[index])
            }
        }

        private fun showLayerTargetPicker(currentTarget: String, onSelect: (String) -> Unit) {
            val baseTargets = availableLayoutTargets.ifEmpty { emptyList() }
            val targets = buildList {
                if (currentTarget.isNotBlank()) add(currentTarget)
                baseTargets.forEach { if (it != currentTarget) add(it) }
            }.distinct()
            if (targets.isEmpty()) {
                Toast.makeText(requireContext(), R.string.macro_editor_layer_target_empty, Toast.LENGTH_SHORT).show()
                return
            }
            // 列表显示可读文本，选中后回传的仍是原始目标名（存进配置的就是它）。
            val labels = targets.map { layerTargetDisplayName(it) }
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.macro_editor_layer_target_picker_title)
                .setItems(labels.toTypedArray()) { _, which ->
                    onSelect(targets[which])
                }
                .setNegativeButton(R.string.macro_editor_cancel, null)
                .show()
        }

        /**
         * 把层目标名转成给用户看的文本。
         *
         * 符号面板的目标名是 [PickerWindow.Key] 的枚举名（`Symbol` / `Emoji` / `Kaomoji`）：
         * 写进配置、参与持久化的就是这个名字，**不能改**；但枚举名是英文，
         * 光看 `Kaomoji` 认不出是「颜文字面板」，所以显示时补一个中文提示。
         * 其余目标（真·布局层）原样返回。
         */
        private fun layerTargetDisplayName(target: String): String {
            val res = when (PickerWindow.Key.ofName(target)) {
                PickerWindow.Key.Symbol -> R.string.macro_editor_layer_target_symbol
                PickerWindow.Key.Emoji -> R.string.macro_editor_layer_target_emoji
                PickerWindow.Key.Kaomoji -> R.string.macro_editor_layer_target_kaomoji
                null -> null
            }
            return res?.let { getString(it) } ?: target
        }

        private fun showLayerModeThenTargetPicker(
            currentMode: String,
            currentTarget: String,
            onSelect: (mode: String, target: String) -> Unit
        ) {
            showLayerModePicker(currentMode) { mode ->
                if (mode == "back") {
                    onSelect(mode, "")
                } else {
                    showLayerTargetPicker(currentTarget) { target ->
                        onSelect(mode, target)
                    }
                }
            }
        }

        private fun getLayerModeLabel(mode: String): String {
            return when (normalizeLayerMode(mode)) {
                "osl" -> getString(R.string.macro_editor_step_type_osl)
                "back" -> getString(R.string.macro_editor_step_type_back)
                else -> getString(R.string.macro_editor_step_type_to)
            }
        }

        private fun getLayerActionLabel(mode: String, target: String): String {
            val modeLabel = getLayerModeLabel(mode)
            return if (normalizeLayerMode(mode) != "back" && target.isNotBlank()) {
                // 与目标选择列表用同一套显示文本，否则选完后面板目标又变回英文名，
                // 看起来像没生效。
                "$modeLabel -> ${layerTargetDisplayName(target)}"
            } else {
                modeLabel
            }
        }

        private fun showLayerModePicker(currentMode: String, onSelect: (String) -> Unit) {
            val modes = arrayOf("to", "osl", "back")
            val labels = arrayOf(
                getString(R.string.macro_editor_step_type_to),
                getString(R.string.macro_editor_step_type_osl),
                getString(R.string.macro_editor_step_type_back)
            )
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.macro_editor_layer_mode_picker_title)
                .setItems(labels) { _, which ->
                    onSelect(modes[which])
                }
                .setNegativeButton(R.string.macro_editor_cancel, null)
                .show()
        }
    }
}
