/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2023 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.ui.common

import android.annotation.SuppressLint
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import androidx.activity.OnBackPressedCallback
import androidx.activity.OnBackPressedDispatcher
import androidx.annotation.CallSuper
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import org.fcitx.fcitx5.android.ui.main.MainViewModel
import org.fcitx.fcitx5.android.ui.main.MainViewModel.ButtonMode
import java.util.Collections
import splitties.views.setPaddingDp

abstract class DynamicListAdapter<T>(
    initialEntries: List<T>,
    val enableAddAndDelete: Boolean = true,
    val enableOrder: Boolean = false,
    val initCheckBox: (CheckBox.(T) -> Unit) = { visibility = View.GONE },
    var initEditButton: (ImageButton.(T) -> Unit) = { visibility = View.GONE },
    var initSettingsButton: (ImageButton.(T) -> Unit) = { visibility = View.GONE }
) :
    RecyclerView.Adapter<DynamicListAdapter<T>.ViewHolder>() {

    private val _entries = initialEntries.toMutableList()

    val entries: List<T>
        get() = _entries

    var multiselect = false
        private set

    private val selected = mutableListOf<T>()

    private var listener: OnItemChangedListener<T>? = null

    fun removeItemChangedListener() {
        listener = null
    }

    fun addOnItemChangedListener(x: OnItemChangedListener<T>) {
        listener = listener?.let { OnItemChangedListener.merge(it, x) } ?: x
    }

    protected var itemTouchHelper: ItemTouchHelper? = null

    var removable: (T) -> Boolean = { true }

    private var onBackPressedCallback: OnBackPressedCallback? = null

    abstract fun showEntry(x: T): String

    /**
     * Optional secondary text shown below [showEntry] in a smaller style.
     * Return null to keep the subtitle hidden (default).
     */
    open fun showSubEntry(x: T): CharSequence? = null

    private var mainViewModel: MainViewModel? = null

    fun setViewModel(model: MainViewModel) {
        mainViewModel = model
    }

    inner class ViewHolder(entryUi: DynamicListEntryUi) : RecyclerView.ViewHolder(entryUi.root) {
        val multiselectCheckBox = entryUi.multiselectCheckBox
        val handleImage = entryUi.handleImage
        val checkBox = entryUi.checkBox
        val nameText = entryUi.nameText
        val subText = entryUi.subText
        val editButton = entryUi.editButton
        val settingsButton = entryUi.settingsButton
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(DynamicListEntryUi(parent.context))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = entries[position]
        with(holder) {
            handleImage.setOnLongClickListener {
                if (enableOrder && !multiselect && removable(item))
                    itemTouchHelper
                        ?.startDrag(this)
                        ?.run { true }
                        ?: false
                else false
            }
            nameText.text = showEntry(item)
            val subEntry = showSubEntry(item)
            nameText.setPaddingDp(0, if (subEntry.isNullOrEmpty()) 16 else 12, 0,
                if (subEntry.isNullOrEmpty()) 16 else 0)
            subText.visibility = if (subEntry.isNullOrEmpty()) View.GONE else View.VISIBLE
            subText.text = subEntry

            if (multiselect) {
                handleImage.visibility = View.GONE
                multiselectCheckBox.visibility = View.VISIBLE
                checkBox.visibility = View.GONE
                settingsButton.visibility = View.GONE
                editButton.visibility = View.GONE
            } else {
                handleImage.visibility = if (enableOrder) View.VISIBLE else View.GONE
                multiselectCheckBox.visibility = View.GONE
                checkBox.visibility = View.VISIBLE
                settingsButton.visibility = View.VISIBLE
                editButton.visibility = View.VISIBLE
                initCheckBox(checkBox, item)
                initSettingsButton(settingsButton, item)
                initEditButton(editButton, item)
            }

            multiselectCheckBox.isChecked = item in selected

            if (enableAddAndDelete && removable(item)) {
                multiselectCheckBox.setOnCheckedChangeListener { _, isChecked ->
                    select(item, isChecked)
                }
                nameText.setOnLongClickListener {
                    if (enableOrder) {
                        itemTouchHelper?.startDrag(holder)
                    }
                    true
                }
                nameText.setOnClickListener {
                    multiselectCheckBox.toggle()
                }
            } else {
                multiselectCheckBox.isEnabled = false
                multiselectCheckBox.setOnCheckedChangeListener(null)
                nameText.setOnClickListener(null)
            }
        }
    }

    override fun onViewRecycled(holder: DynamicListAdapter<T>.ViewHolder) {
        // reset view state and remove listeners once recycled
        holder.apply {
            multiselectCheckBox.setOnCheckedChangeListener(null)
            multiselectCheckBox.isEnabled = true
            multiselectCheckBox.isChecked = false
            checkBox.setOnCheckedChangeListener(null)
            checkBox.isEnabled = true
            checkBox.isChecked = false
            nameText.setOnClickListener(null)
            settingsButton.setOnClickListener(null)
            editButton.setOnClickListener(null)
        }
    }

    private fun select(item: T, shouldSelect: Boolean) {
        if (!enableAddAndDelete || !multiselect)
            return
        if (shouldSelect) {
            if (selected.indexOf(item) == -1) selected.add(item)
        } else {
            selected.remove(item)
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    @CallSuper
    open fun enterMultiSelect(onBackPressedDispatcher: OnBackPressedDispatcher) {
        mainViewModel?.let {
            if (multiselect)
                return
            onBackPressedCallback = object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    exitMultiSelect()
                }
            }
            onBackPressedDispatcher.addCallback(onBackPressedCallback!!)
            it.toolbarButton.value = ButtonMode.DELETE
            multiselect = true
            notifyDataSetChanged()
        }
    }


    internal fun deleteSelected() {
        if (!multiselect || selected.isEmpty())
            return
        val indexed = selected.mapNotNull { entry ->
            indexItem(entry).takeIf { it != -1 }?.let { it to entry }
        }.sortedByDescending { it.first }
        indexed.forEach { (index, _) ->
            _entries.removeAt(index)
            notifyItemRemoved(index)
        }
        listener?.onItemRemovedBatch(indexed)
    }

    @SuppressLint("NotifyDataSetChanged")
    @CallSuper
    open fun exitMultiSelect() {
        mainViewModel?.let {
            if (!multiselect)
                return
            onBackPressedCallback?.remove()
            multiselect = false
            selected.clear()
            notifyDataSetChanged()
            it.toolbarButton.value = if (entries.isNotEmpty()) ButtonMode.EDIT else ButtonMode.NONE
        }
    }

    override fun getItemCount(): Int = entries.size

    @CallSuper
    open fun addItem(idx: Int = _entries.size, item: T) {
        _entries.add(idx, item)
        notifyItemInserted(idx)
        listener?.onItemAdded(idx, item)
        mainViewModel?.toolbarButton?.value = ButtonMode.EDIT
    }

    @CallSuper
    open fun removeItem(idx: Int): T {
        val item = _entries.removeAt(idx)
        notifyItemRemoved(idx)
        listener?.onItemRemoved(idx, item)
        if (entries.isEmpty())
            mainViewModel?.toolbarButton?.value = ButtonMode.NONE
        return item
    }

    @CallSuper
    open fun swapItem(fromIdx: Int, toIdx: Int) {
        Collections.swap(_entries, fromIdx, toIdx)
        notifyItemMoved(fromIdx, toIdx)
        listener?.onItemSwapped(fromIdx, toIdx, _entries[toIdx])
    }

    @CallSuper
    open fun updateItem(idx: Int, item: T) {
        val old = _entries[idx]
        _entries[idx] = item
        notifyItemChanged(idx)
        listener?.onItemUpdated(idx, old, item)
    }

    fun indexItem(item: T): Int = _entries.indexOf(item)
}
