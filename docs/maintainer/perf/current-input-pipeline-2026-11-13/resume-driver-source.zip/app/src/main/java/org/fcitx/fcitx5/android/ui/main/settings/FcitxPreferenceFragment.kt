/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2026 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.ui.main.settings

import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.preference.isEmpty
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.core.FcitxAPI
import org.fcitx.fcitx5.android.core.RawConfig
import org.fcitx.fcitx5.android.daemon.FcitxConnection
import org.fcitx.fcitx5.android.ui.common.PaddingPreferenceFragment
import org.fcitx.fcitx5.android.ui.common.withLoadingDialog
import org.fcitx.fcitx5.android.ui.main.MainViewModel
import org.fcitx.fcitx5.android.ui.main.settings.search.scrollToPendingPreference
import org.fcitx.fcitx5.android.utils.addPreference

abstract class FcitxPreferenceFragment : PaddingPreferenceFragment() {
    abstract fun getPageTitle(): String
    abstract suspend fun obtainConfig(fcitx: FcitxAPI): RawConfig
    abstract suspend fun saveConfig(fcitx: FcitxAPI, newConfig: RawConfig)

    private lateinit var raw: RawConfig
    private var configLoaded = false

    private val supportedExternalProtocol = 2

    private val supervisorJob = SupervisorJob()
    private val scope = CoroutineScope(supervisorJob)
    private var pendingSaveCount = 0
    private var saveBackCallback: OnBackPressedCallback? = null

    private val viewModel: MainViewModel by activityViewModels()

    private val fcitx: FcitxConnection
        get() = viewModel.fcitx

    private fun save() {
        if (!configLoaded) return
        pendingSaveCount++
        saveBackCallback?.isEnabled = true
        // launch "saveConfig" job under supervisorJob scope
        scope.launch {
            try {
                fcitx.runOnReady {
                    saveConfig(this, raw["cfg"])
                }
            } finally {
                withContext(Dispatchers.Main.immediate) {
                    pendingSaveCount = (pendingSaveCount - 1).coerceAtLeast(0)
                    saveBackCallback?.isEnabled = pendingSaveCount > 0
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        saveBackCallback = object : OnBackPressedCallback(false) {
            // Intercept only while writes are active. At rest, NavController handles predictive back.
            override fun handleOnBackPressed() {
                lifecycleScope.withLoadingDialog(requireContext(), R.string.saving) {
                    // complete the parent job and wait all "saveConfig" jobs to finish
                    supervisorJob.complete()
                    supervisorJob.join()
                    scope.cancel()
                    findNavController().popBackStack()
                }
            }
        }.also { callback ->
            requireActivity().onBackPressedDispatcher.addCallback(this, callback)
        }
    }

    /**
     * **TLDR:**
     * Intentionally empty, since we need to create PreferenceScreen during onStart,
     * or it will crash when MainActivity relaunches.
     *
     * **Long version:**
     * When `MainActivity` relaunches, its `onCreate` get called, and somewhere in `super.onCreate`
     * decided to `restoreChildFragmentState` of `NavHostFragment`, thus recreate the child fragment.
     * If that fragment was derived from `FcitxPreferenceFragment`, it needs to call `obtainConfig`
     * which would need the route params, and in turn needs `NavGraph`.
     * But at this time it's still in `MainActivity`'s `super.onCreate`, the Activity did not have
     * chance to set up `NavGraph` on `navController`, so accessing `lazyRoute` would crash.
     *
     * That is to say, if we declare `app:navGraph` on `<FragmentContainerView />` in `activity_main.xml`,
     * the graph would have been initialized when `NavHostFragment` got inflated, and does not suffer
     * from this problem? But maintain navigation destinations in XML is too tedious ...
     */
    final override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // make sure to create preference only once since `onViewCreated` is also called on Fragment resume
        if (preferenceScreen?.isEmpty() == false) {
            // 列表已建好（例如从子页面返回）：直接消费待处理的滚动定位。
            scrollToPendingPreference(viewModel)
            return
        }
        val context = requireContext()
        lifecycleScope.withLoadingDialog(context) {
            raw = fcitx.runOnReady { obtainConfig(this) }
            val hasCfgDesc = raw.findByName("cfg") != null && raw.findByName("desc") != null
            val requiredExternalProtocol = maxRequiredExternalProtocol(raw)
            val protocolCompatible = requiredExternalProtocol <= supportedExternalProtocol
            configLoaded = hasCfgDesc && protocolCompatible
            preferenceScreen = if (configLoaded) {
                PreferenceScreenFactory.create(
                    preferenceManager, parentFragmentManager, raw, ::save
                ).apply {
                    if (isEmpty()) {
                        addPreference(R.string.no_config_options)
                    }
                }
            } else if (hasCfgDesc && !protocolCompatible) {
                preferenceManager.createPreferenceScreen(context).apply {
                    addPreference(
                        R.string.config_protocol_not_supported_title,
                        context.getString(
                            R.string.config_protocol_not_supported_summary,
                            requiredExternalProtocol,
                            supportedExternalProtocol
                        )
                    )
                }
            } else {
                preferenceManager.createPreferenceScreen(context).apply {
                    addPreference(R.string.direct_rime_config_unavailable)
                }
            }
            // 搜索跳转的滚动定位。本页的列表是**异步**建成的（要等引擎返回 `desc` 树），
            // 所以只能放在赋值 `preferenceScreen` 之后——若像其它页那样写在
            // `onViewCreated` 末尾，那时 `preferenceScreen` 还是空的，`findPreference`
            // 必然找不到目标项，表现为「跳对了页面但不滚动」且无日志。
            scrollToPendingPreference(viewModel)
        }
    }

    private fun maxRequiredExternalProtocol(raw: RawConfig): Int {
        val descRoot = raw.findByName("desc") ?: return 0
        var maxProtocol = 0

        fun updateFromUri(uriText: String) {
            if (!uriText.startsWith("fcitx://")) {
                return
            }
            val required = runCatching {
                val uri = Uri.parse(uriText)
                uri.getQueryParameter("app_proto")?.toIntOrNull()
                    ?: uri.getQueryParameter("min_app_proto")?.toIntOrNull()
                    ?: 0
            }.getOrDefault(0)
            if (required > maxProtocol) {
                maxProtocol = required
            }
        }

        fun walk(node: RawConfig) {
            node.findByName("External")?.value?.let(::updateFromUri)
            node.subItems?.forEach(::walk)
        }

        walk(descRoot)
        return maxProtocol
    }

}
