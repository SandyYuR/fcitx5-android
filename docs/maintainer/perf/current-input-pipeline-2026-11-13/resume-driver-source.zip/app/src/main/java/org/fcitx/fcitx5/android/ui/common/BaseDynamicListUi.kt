/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2021-2025 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.ui.common

import android.annotation.SuppressLint
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import androidx.activity.OnBackPressedDispatcher
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnAttach
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.ItemTouchHelper
import arrow.core.identity
import com.google.android.material.behavior.HideViewOnScrollBehavior
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.utils.onPositiveButtonClick
import org.fcitx.fcitx5.android.utils.str
import splitties.dimensions.dp
import splitties.resources.drawable
import org.fcitx.fcitx5.android.utils.settingsColorStateList
import org.fcitx.fcitx5.android.utils.settingsColor
import splitties.views.backgroundColor
import splitties.views.bottomPadding
import splitties.views.dsl.constraintlayout.bottomOfParent
import splitties.views.dsl.constraintlayout.constraintLayout
import splitties.views.dsl.constraintlayout.lParams
import splitties.views.dsl.constraintlayout.leftOfParent
import splitties.views.dsl.constraintlayout.rightOfParent
import splitties.views.dsl.constraintlayout.topOfParent
import splitties.views.dsl.coordinatorlayout.coordinatorLayout
import splitties.views.dsl.coordinatorlayout.defaultLParams
import splitties.views.dsl.core.Ui
import splitties.views.dsl.core.add
import com.google.android.material.textfield.TextInputEditText
import splitties.views.dsl.core.margin
import splitties.views.dsl.core.matchParent
import splitties.views.dsl.core.view
import splitties.views.dsl.core.wrapContent
import splitties.views.dsl.recyclerview.recyclerView
import splitties.views.gravityEndBottom
import splitties.views.imageDrawable
import splitties.views.recyclerview.verticalLayoutManager
import kotlin.math.min

abstract class BaseDynamicListUi<T>(
    override val ctx: Context,
    private val mode: Mode<T>,
    initialEntries: List<T>,
    enableOrder: Boolean = false,
    initCheckBox: (CheckBox.(T) -> Unit) = { visibility = View.GONE },
    initSettingsButton: (ImageButton.(T) -> Unit) = { visibility = View.GONE },
) : Ui,
    DynamicListAdapter<T>(
        initialEntries,
        enableAddAndDelete = mode !is Mode.Immutable,
        enableOrder,
        initCheckBox,
        initEditButton = {},
        initSettingsButton
    ) {

    protected var shouldShowFab = false

    protected val fab = view(::FloatingActionButton) {
        imageTintList = ctx.settingsColorStateList(com.google.android.material.R.attr.colorOnPrimaryContainer)
        imageDrawable = drawable(R.drawable.ic_baseline_plus_24)
    }

    sealed class Mode<T> {
        /**
         * Pick one from a list of [T]
         */
        data class ChooseOne<T>(val candidatesSource: BaseDynamicListUi<T>.() -> Array<T>) :
            Mode<T>()

        /**
         * Enter a string that can be converted into [T]
         */
        data class FreeAdd<T>(
            val hint: String,
            val converter: (String) -> T,
            val validator: (String) -> Boolean = { it.isNotBlank() }
        ) : Mode<T>()

        class Immutable<T> : Mode<T>()

        /**
         * Do nothing
         */
        class Custom<T> : Mode<T>()

        @Suppress("FunctionName")
        companion object {
            fun FreeAddString() = FreeAdd("", ::identity)
        }
    }

    /**
     * whether to show "undo" snackbar after item update
     */
    var enableUndo = true

    /**
     * suspend "undo" snackbar temporarily to prevent undo undo
     */
    private var suspendUndo = false

    init {
        initEditButton = when (mode) {
            is Mode.ChooseOne -> { _ -> visibility = View.GONE }
            is Mode.FreeAdd -> { entry ->
                visibility = View.VISIBLE
                setOnClickListener {
                    showEditDialog(ctx.getString(R.string.edit), entry) {
                        if (it != entry) updateItem(indexItem(entry), it)
                    }
                }
            }
            is Mode.Immutable -> { _ -> visibility = View.GONE }
            is Mode.Custom -> { _ -> visibility = View.GONE }
        }
        addOnItemChangedListener(object : OnItemChangedListener<T> {
            override fun onItemAdded(idx: Int, item: T) {
                updateFAB()
                showSnackbar(ctx.getString(R.string.added_x, showEntry(item))) {
                    removeItem(idx)
                }
            }

            override fun onItemRemoved(idx: Int, item: T) {
                updateFAB()
                showSnackbar(ctx.getString(R.string.removed_x, showEntry(item))) {
                    addItem(idx, item)
                }
            }

            override fun onItemUpdated(idx: Int, old: T, new: T) {
                updateFAB()
                if (mode is Mode.Immutable) return
                showSnackbar(ctx.getString(R.string.edited_x, showEntry(new))) {
                    updateItem(idx, old)
                }
            }

            override fun onItemRemovedBatch(indexed: List<Pair<Int, T>>) {
                updateFAB()
                showSnackbar(ctx.getString(R.string.removed_n_items, indexed.size)) {
                    indexed.sortedBy { it.first }.forEach {
                        addItem(it.first, it.second)
                    }
                }
            }
        })
    }

    private fun showSnackbar(text: String, action: () -> Unit) {
        if (suspendUndo) return
        val snackbar = Snackbar.make(root, text, Snackbar.LENGTH_SHORT)
        if (enableUndo) {
            snackbar.setAction(R.string.undo) {
                suspendUndo = true
                action.invoke()
                suspendUndo = false
            }
        }
        snackbar.show()
    }

    open fun updateFAB() {
        when (mode) {
            is Mode.ChooseOne -> {
                val candidatesSource = mode.candidatesSource(this)
                if (candidatesSource.isEmpty()) {
                    shouldShowFab = false
                    fab.hide()
                } else {
                    shouldShowFab = true
                    fab.show()
                    fab.setOnClickListener {
                        val items = candidatesSource.map { showEntry(it) }.toTypedArray()
                        MaterialAlertDialogBuilder(ctx)
                            .setTitle(R.string.add)
                            .setItems(items) { _, which -> addItem(item = candidatesSource[which]) }
                            .show()
                    }
                }
            }
            is Mode.FreeAdd -> {
                shouldShowFab = true
                fab.show()
                fab.setOnClickListener {
                    showEditDialog(ctx.getString(R.string.add)) { addItem(item = it) }
                }
            }
            is Mode.Immutable -> {
                shouldShowFab = false
                fab.hide()
            }
            is Mode.Custom -> {
            }
        }
    }

    override fun enterMultiSelect(onBackPressedDispatcher: OnBackPressedDispatcher) {
        if (shouldShowFab) {
            fab.hide()
        }
        super.enterMultiSelect(onBackPressedDispatcher)
    }

    override fun exitMultiSelect() {
        if (shouldShowFab) {
            fab.show()
        }
        super.exitMultiSelect()
    }

    open fun showEditDialog(
        title: String,
        entry: T? = null,
        block: (T) -> Unit
    ) {
        if (mode !is Mode.FreeAdd) return
        val editText = TextInputEditText(ctx).apply {
            id = android.view.View.generateViewId()
            hint = mode.hint
            if (entry != null) {
                setText(showEntry(entry))
            }
            addTextChangedListener { error = null }
        }
        val layout = constraintLayout {
            add(editText, lParams {
                height = wrapContent
                width = matchParent
                topOfParent()
                bottomOfParent()
                leftOfParent(dp(20))
                rightOfParent(dp(20))
            })
        }
        MaterialAlertDialogBuilder(ctx)
            .setTitle(title)
            .setView(layout)
            .setPositiveButton(android.R.string.ok, null)
            .setNegativeButton(android.R.string.cancel, null)
            .show()
            .onPositiveButtonClick {
                val str = editText.str
                if (mode.validator(str)) {
                    editText.error = null
                    block(mode.converter(str))
                    true
                } else {
                    editText.error = ctx.getString(R.string.invalid_value)
                    false
                }
            }
        editText.requestFocus()
    }

    protected val recyclerView = recyclerView {
        adapter = this@BaseDynamicListUi
        layoutManager = verticalLayoutManager()
        clipToPadding = false
    }

    fun addTouchCallback(
        touchCallback: DynamicListTouchCallback<T> = DynamicListTouchCallback(ctx, this)
    ) {
        itemTouchHelper = ItemTouchHelper(touchCallback).also {
            it.attachToRecyclerView(recyclerView)
        }
    }

    private fun updateViewMargin(insets: WindowInsetsCompat? = null) {
        val windowInsets = (insets ?: ViewCompat.getRootWindowInsets(root)) ?: return
        val navBars = windowInsets.getInsets(WindowInsetsCompat.Type.navigationBars())
        fab.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            bottomMargin = navBars.bottom + ctx.dp(16)
        }
        recyclerView.bottomPadding = navBars.bottom
    }

    override val root = coordinatorLayout {
        backgroundColor = settingsColor(com.google.android.material.R.attr.colorSurfaceContainer)
        add(recyclerView, defaultLParams {
            height = matchParent
            width = matchParent
        })
        add(fab, defaultLParams {
            gravity = gravityEndBottom
            margin = dp(16)
            behavior = object : HideViewOnScrollBehavior<FloatingActionButton>(EDGE_BOTTOM) {
                /**
                 * the `translationY` FAB needs to be shown above the snackbar
                 */
                var scrollInOffset = 0f

                @SuppressLint("RestrictedApi")
                override fun layoutDependsOn(
                    parent: CoordinatorLayout,
                    child: FloatingActionButton,
                    dependency: View
                ): Boolean {
                    return dependency is Snackbar.SnackbarLayout
                }

                override fun onDependentViewChanged(
                    parent: CoordinatorLayout,
                    child: FloatingActionButton,
                    dependency: View
                ): Boolean {
                    // make sure FAB is above snackbar and doesn't go below bottom inset (eg. navbar)
                    scrollInOffset = min(0f, dependency.translationY - dependency.height)
                    // [^1]: snackbar is invisible when it attached to parent
                    // update FAB position only when snackbar is visible
                    if (isScrolledIn && dependency.isVisible) {
                        // cancel pending animation to prevent translationY got overridden
                        // eg. when a new snackbar cancels previous snackbar, the canceled one would start
                        // an animation (as onDependentViewRemoved below) to update translationY constantly
                        child.animate().cancel()
                        child.translationY = scrollInOffset
                        return true
                    }
                    return false
                }

                override fun onDependentViewRemoved(
                    parent: CoordinatorLayout,
                    child: FloatingActionButton,
                    dependency: View
                ) {
                    // if the user dismiss the snackbar manually while FAB is visible,
                    // move the FAB back to its normal position
                    if (isScrolledIn) {
                        child.animate().translationY(0f)
                    }
                }
            }.apply {
                addOnScrollStateChangedListener { view, _ ->
                    // overwrite FAB's position when scrolling in while snackbar is visible
                    if (isScrolledIn && scrollInOffset < 0f) {
                        // need to post because `HideViewOnScrollBehavior#slideIn` starts animation
                        // after notifying all onScrollStateChangedListeners
                        ContextCompat.getMainExecutor(ctx).execute {
                            view.clearAnimation()
                            view.animate().translationY(scrollInOffset)
                        }
                    }
                }
            }
        })
        doOnAttach { updateViewMargin() }
        ViewCompat.setOnApplyWindowInsetsListener(this) { _, windowInsets ->
            updateViewMargin(windowInsets)
            windowInsets
        }
        updateFAB()
    }

}