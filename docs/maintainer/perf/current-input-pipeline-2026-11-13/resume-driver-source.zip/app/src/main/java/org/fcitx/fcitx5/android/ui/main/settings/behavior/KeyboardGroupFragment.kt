/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2025 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.ui.main.settings.behavior

import org.fcitx.fcitx5.android.utils.FileUtil
import org.fcitx.fcitx5.android.utils.copyBoundedTo

import com.google.android.material.dialog.MaterialAlertDialogBuilder

import android.content.Intent
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.preference.Preference
import androidx.preference.PreferenceScreen
import androidx.preference.ListPreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.data.prefs.AppPrefs
import org.fcitx.fcitx5.android.data.prefs.ManagedPreferenceFragment
import org.fcitx.fcitx5.android.data.prefs.ManagedPreferenceUi
import org.fcitx.fcitx5.android.input.config.ConfigProviders
import org.fcitx.fcitx5.android.input.config.UserConfigFiles
import org.fcitx.fcitx5.android.ui.main.MainViewModel
import org.fcitx.fcitx5.android.ui.main.settings.group.SettingsGroupAction
import org.fcitx.fcitx5.android.ui.main.settings.group.SettingsGroupSpecs
import org.fcitx.fcitx5.android.ui.main.settings.behavior.data.LayoutDataManager
import org.fcitx.fcitx5.android.ui.main.settings.behavior.webeditor.ImeWebEditorBridgeServer
import org.fcitx.fcitx5.android.ui.main.settings.voice.JsVoicePluginsActivity
import org.fcitx.fcitx5.android.utils.queryFileName
import org.fcitx.fcitx5.android.utils.toast

/**
 * Sub-fragment showing only the preferences belonging to one keyboard settings group.
 * Extends [ManagedPreferenceFragment] to inherit consistent lifecycle, visibility
 * evaluation and styling, then filters out items not belonging to the requested group.
 */
class KeyboardGroupFragment : ManagedPreferenceFragment(AppPrefs.getInstance().keyboard) {

    private val group: Int get() = arguments?.getInt("group", -1) ?: -1
    private val viewModel: MainViewModel by activityViewModels()

    private var textLayoutFileSelectPreference: Preference? = null
    private var webEditorBridgePreference: Preference? = null
    private var numericLayoutOverridePreference: Preference? = null
    private var customKeySoundPreference: Preference? = null

    private val customKeySoundLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        importKeySound(uri)
    }
    private data class LayoutLayerCache(
        val path: String?,
        val lastModified: Long,
        val layers: List<String>
    )
    private var layoutLayerCache: LayoutLayerCache? = null

    override fun onPreferenceUiCreated(screen: PreferenceScreen) {
        val groupKeys = KEYS_BY_GROUP[group] ?: emptySet()

        // Remove managed preferences not belonging to this group
        val toRemove = mutableListOf<Preference>()
        for (i in 0 until screen.preferenceCount) {
            val pref = screen.getPreference(i)
            if (pref.key.isNotEmpty() && pref.key !in groupKeys) {
                toRemove.add(pref)
            }
        }
        toRemove.forEach { screen.removePreference(it) }

        // Group 5 extras: keyboard definition tools
        if (group == GROUP_EDITORS) {
            val managerEntry = SettingsGroupSpecs.keyboardLayoutManager
            addTool(screen, "tool_text_layout_manager",
                managerEntry.title, buildCurrentTextLayoutFileSummary()
            ) { startActivity(Intent(requireContext(), (managerEntry.action as SettingsGroupAction.Launch).activityClass)) }

            addTool(screen, "tool_text_layout_editor",
                R.string.edit_text_keyboard_layout, ""
            ) { startActivity(Intent(requireContext(), TextKeyboardLayoutEditorActivity::class.java)) }

            textLayoutFileSelectPreference = addTool(screen, TEXT_LAYOUT_FILE_SELECT_PREF_KEY,
                R.string.text_keyboard_layout_file_select_title,
                buildCurrentTextLayoutFileSummary()
            ) { showSelectTextLayoutFileDialog() }

            numericLayoutOverridePreference = addTool(screen, "tool_numeric_layout_override",
                R.string.numeric_layout_override_title,
                buildNumericLayoutOverrideSummary()
            ) { showNumericLayoutOverrideDialog() }

            // 2026-09-29 由「外观」移来：它编辑的是**长按按键弹出的字符映射**，
            // 属于键盘的内容定义，与「布局编辑」同类；放在外观下与「主题/图标」
            // 并列会让外观的小字对不上内容。
            addTool(screen, "tool_popup_editor",
                R.string.edit_popup_preset, ""
            ) { startActivity(Intent(requireContext(), PopupEditorActivity::class.java)) }

            webEditorBridgePreference = addTool(screen, "tool_web_editor_bridge",
                R.string.web_editor_bridge_title, ""
            ) { toggleWebEditorBridge() }
        }

        // Group 2 extras: imported sound files used for all keys
        if (group == GROUP_FEEDBACK) {
            customKeySoundPreference = addTool(
                screen,
                AppPrefs.getInstance().keyboard.customKeySound.key,
                R.string.custom_key_sound,
                buildCustomKeySoundSummary()
            ) { showCustomKeySoundDialog() }
        }

        // Group 3 extras: edit buttons (toolbar customization)
        if (group == GROUP_TOOLBAR) {
            addTool(screen, "tool_edit_buttons",
                R.string.edit_buttons, R.string.edit_buttons_summary
            ) { startActivity(Intent(requireContext(), ButtonsCustomizerActivity::class.java)) }
        }

        // Group 6 extras: JS voice plugin manager.
        // 插件数量由用户决定（可以导入任意多个），所以分组页只留一条入口，图案与排序在管理页里，
        // 而不是像内置两家那样每条插件一行。
        if (group == GROUP_VOICE) {
            addTool(
                screen,
                "tool_js_voice_plugins",
                R.string.js_voice_plugins_title,
                R.string.js_voice_plugins_summary
            ) { startActivity(JsVoicePluginsActivity.intent(requireContext())) }
        }
    }

    override fun onResume() {
        super.onResume()
        if (group == GROUP_VOICE) {
            val preferred = AppPrefs.getInstance().keyboard.preferredVoiceInput
            findPreference<ListPreference>(preferred.key)?.let {
                ManagedPreferenceUi.VoiceInputList.refreshEntries(it)
                // Removing the selected plugin can also reset this setting on the manager page.
                it.value = preferred.getValue()
            }
        }
        if (group == GROUP_FEEDBACK) {
            customKeySoundPreference?.summary = buildCustomKeySoundSummary()
        }
        if (group == GROUP_EDITORS) {
            textLayoutFileSelectPreference?.summary = buildCurrentTextLayoutFileSummary()
            numericLayoutOverridePreference?.summary = buildNumericLayoutOverrideSummary()
            updateWebEditorBridgeStatus()
        }
    }

    // ---- helpers ----

    private fun addTool(
        screen: PreferenceScreen, key: String, titleRes: Int, summary: CharSequence,
        onClick: () -> Unit
    ): Preference = Preference(requireContext()).apply {
        this.key = key
        setTitle(titleRes)
        setSummary(summary)
        isSingleLineTitle = false
        isIconSpaceReserved = false
        setOnPreferenceClickListener { onClick(); true }
    }.also { screen.addPreference(it) }

    private fun addTool(
        screen: PreferenceScreen, key: String, titleRes: Int, summaryRes: Int,
        onClick: () -> Unit
    ): Preference = addTool(screen, key, titleRes, getString(summaryRes), onClick)

    private fun buildCustomKeySoundSummary(): String {
        val selected = AppPrefs.getInstance().keyboard.customKeySound.getValue()
        return selected.ifBlank { getString(R.string.custom_key_sound_system_default) }
    }

    private fun showCustomKeySoundDialog() {
        val files = UserConfigFiles.listKeySoundFiles()
        val items = listOf(getString(R.string.custom_key_sound_system_default)) + files
        val selected = AppPrefs.getInstance().keyboard.customKeySound.getValue()
        val checked = if (selected.isBlank()) 0 else (files.indexOf(selected) + 1).coerceAtLeast(0)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.custom_key_sound)
            .setSingleChoiceItems(items.toTypedArray(), checked) { dialog, which ->
                AppPrefs.getInstance().keyboard.customKeySound.setValue(
                    if (which == 0) "" else files[which - 1]
                )
                customKeySoundPreference?.summary = buildCustomKeySoundSummary()
                dialog.dismiss()
            }
            .setNeutralButton(R.string.custom_key_sound_import) { _, _ ->
                customKeySoundLauncher.launch(arrayOf("audio/*"))
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun importKeySound(uri: Uri) {
        val resolver = requireContext().contentResolver
        val sourceName = resolver.queryFileName(uri).orEmpty()
        val safeName = sourceName
            .replace(Regex("[^A-Za-z0-9._ -]"), "_")
            .trim()
        val target = UserConfigFiles.keySoundFile(safeName)
        if (target == null || safeName.isBlank()) {
            requireContext().toast(R.string.custom_key_sound_invalid)
            return
        }
        lifecycleScope.launch {
            val imported = withContext(Dispatchers.IO) {
                runCatching {
                    target.parentFile?.mkdirs()
                    resolver.openInputStream(uri)?.use { input ->
                        FileUtil.writeAtomically(target) { output -> input.copyBoundedTo(output, 16L * 1024 * 1024) }
                    } ?: error("Unable to open audio file")
                }.isSuccess
            }
            if (imported) {
                AppPrefs.getInstance().keyboard.customKeySound.setValue(target.name)
                customKeySoundPreference?.summary = buildCustomKeySoundSummary()
            } else {
                requireContext().toast(R.string.custom_key_sound_invalid)
            }
        }
    }

    private fun buildCurrentTextLayoutFileSummary() = getString(
        R.string.text_keyboard_layout_file_select_summary,
        displayProfile(currentTextLayoutProfile())
    )

    private fun currentTextLayoutProfile() =
        UserConfigFiles.normalizeTextKeyboardLayoutProfile(
            AppPrefs.getInstance().keyboard.textKeyboardLayoutProfile.getValue()
        ) ?: UserConfigFiles.DEFAULT_TEXT_KEYBOARD_LAYOUT_PROFILE

    private fun displayProfile(profile: String) =
        if (profile == UserConfigFiles.DEFAULT_TEXT_KEYBOARD_LAYOUT_PROFILE)
            getString(R.string.default_) else profile

    private fun buildNumericLayoutOverrideSummary(): String {
        val value = AppPrefs.getInstance().keyboard.numericLayoutOverride.getValue().trim()
        if (value.isEmpty()) return getString(R.string.numeric_layout_override_builtin)
        val available = value in collectLayoutLayerEntries()
        return if (available) value else getString(
            R.string.numeric_layout_override_unavailable,
            value
        )
    }

    /**
     * 列出当前启用的布局文件中的层：基础布局与 ime:submode 子布局。
     * 复用布局编辑器（LayoutDataManager.parseJsonText）的解析逻辑，与编辑页
     * 下拉框枚举的层完全一致。
     */
    private fun collectLayoutLayerEntries(): List<String> {
        val file = ConfigProviders.provider.textKeyboardLayoutFile() ?: return emptyList()
        val path = file.absolutePath
        val lastModified = file.takeIf { it.exists() }?.lastModified() ?: 0L
        layoutLayerCache?.takeIf {
            it.path == path && it.lastModified == lastModified
        }?.let { return it.layers }
        val text = runCatching { file.readText() }.getOrNull() ?: return emptyList()
        val parsed = runCatching {
            LayoutDataManager(requireContext()).parseJsonText(text, file.name, fallbackToDefault = false)
        }.getOrNull() ?: return emptyList()
        return parsed.keys.sorted().also {
            layoutLayerCache = LayoutLayerCache(path, lastModified, it)
        }
    }

    private fun showNumericLayoutOverrideDialog() {
        val builtin = getString(R.string.numeric_layout_override_builtin)
        val layers = collectLayoutLayerEntries()
        val items = listOf(builtin) + layers
        val current = AppPrefs.getInstance().keyboard.numericLayoutOverride.getValue().trim()
        val checked = if (current.isEmpty()) 0 else items.indexOf(current).coerceAtLeast(0)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.numeric_layout_override_title)
            .setSingleChoiceItems(items.toTypedArray(), checked) { dialog, which ->
                AppPrefs.getInstance().keyboard.numericLayoutOverride
                    .setValue(if (which == 0) "" else items[which])
                numericLayoutOverridePreference?.summary = buildNumericLayoutOverrideSummary()
                dialog.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .create()
            .show()
    }

    private fun showSelectTextLayoutFileDialog() {
        val profiles = UserConfigFiles.listTextKeyboardLayoutProfiles().toMutableList()
        val current = currentTextLayoutProfile()
        if (current !in profiles) profiles += current
        val sortedProfiles = profiles.distinct()
            .sortedWith(compareBy(
                { it != UserConfigFiles.DEFAULT_TEXT_KEYBOARD_LAYOUT_PROFILE }, { it }
            ))
        val labels = sortedProfiles.map { displayProfile(it) }.toTypedArray()
        val initial = sortedProfiles.indexOf(current).coerceAtLeast(0)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.text_keyboard_layout_file_select_title)
            .setSingleChoiceItems(labels, initial) { dialog, which ->
                val sel = sortedProfiles.getOrNull(which) ?: return@setSingleChoiceItems
                AppPrefs.getInstance().keyboard.textKeyboardLayoutProfile.setValue(sel)
                ConfigProviders.provider = ConfigProviders.provider
                textLayoutFileSelectPreference?.summary = buildCurrentTextLayoutFileSummary()
                numericLayoutOverridePreference?.summary = buildNumericLayoutOverrideSummary()
                dialog.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun toggleWebEditorBridge() {
        val session = ImeWebEditorBridgeServer.currentSession()
        if (session != null) {
            // Already running — show dialog with open/stop options
            showWebEditorBridgeDialog(session)
        } else {
            // Not running — start it
            val result = runCatching { ImeWebEditorBridgeServer.start() }
            result.onSuccess {
                showWebEditorBridgeDialog(it)
            }.onFailure {
                toast(it.localizedMessage ?: getString(R.string.web_editor_bridge_start_failed, ""))
            }
        }
    }

    private fun updateWebEditorBridgeStatus() {
        val session = ImeWebEditorBridgeServer.currentSession()
        webEditorBridgePreference?.summary = if (session != null) {
            getString(R.string.web_editor_bridge_running_status, session.host, session.port)
        } else {
            getString(R.string.web_editor_bridge_summary)
        }
    }

    private fun showWebEditorBridgeDialog(session: ImeWebEditorBridgeServer.Session) {
        val msg = getString(
            R.string.web_editor_bridge_running_message, session.editorUrl, session.apiBaseUrl) +
            "\n\n" + getString(R.string.web_editor_bridge_pairing_code, session.pairingCode)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.web_editor_bridge_title)
            .setMessage(msg)
            .setPositiveButton(R.string.web_editor_bridge_open) { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(session.editorUrl)))
            }
            .setNeutralButton(R.string.web_editor_bridge_stop) { _, _ ->
                ImeWebEditorBridgeServer.stop()
                updateWebEditorBridgeStatus()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
            .setOnDismissListener {
                updateWebEditorBridgeStatus()
            }
    }

    private fun toast(msg: String) {
        android.widget.Toast.makeText(requireContext(), msg, android.widget.Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val TEXT_LAYOUT_FILE_SELECT_PREF_KEY = "text_keyboard_layout_file_select"

        const val GROUP_LAYOUT = 0
        const val GROUP_BEHAVIOR = 1
        const val GROUP_FEEDBACK = 2
        const val GROUP_TOOLBAR = 3
        const val GROUP_EDITORS = 4

        /** 候选栏样式：从 [GROUP_TOOLBAR] 拆出，与「候选窗口」同属一族。 */
        const val GROUP_CANDIDATE = 5

        /** 语音输入：从 [GROUP_TOOLBAR] 拆出，语音是一种输入方式而非工具栏属性。 */
        const val GROUP_VOICE = 6

        val KEYS_BY_GROUP: Map<Int, Set<String>> = mapOf(
            GROUP_LAYOUT to setOf(
                "keyboard_height_percent", "keyboard_side_padding",
                "keyboard_bottom_padding", "expand_keypress_area",
            ),
            GROUP_BEHAVIOR to setOf(
                "popup_on_key_press", "keyboard_long_press_delay",
                "swipe_symbol_behavior", "keep_keyboard_letters_uppercase",
                "reset_keyboard_on_focus_change",
                "space_long_press_behavior", "space_key_label_mode",
                "space_swipe_move_cursor", "show_lang_switch_key",
            ),
            GROUP_FEEDBACK to setOf(
                "haptic_on_keypress", "haptic_on_keyup", "haptic_on_repeat",
                "button_vibration_press_milliseconds", "button_vibration_press_amplitude",
                "sound_on_keypress", "button_sound_volume", "custom_key_sound"
            ),
            // 工具栏只保留真正属于工具栏自身的项；候选栏样式与语音已各自成组。
            // 「工具栏大小」是工具栏自身尺寸，放这里才符合"工具栏的设置进工具栏组"的直觉。
            GROUP_TOOLBAR to setOf(
                "toolbar_height_percent",
                "inline_suggestions", "toolbar_num_row_on_password",
            ),
            GROUP_CANDIDATE to setOf(
                "horizontal_candidate_style", "horizontal_candidate_overflow_scroll",
                "highlight_first_candidate", "show_candidate_index_badge",
                "candidate_index_badge_position", "candidate_index_badge_content",
                "expanded_candidate_style",
                "expanded_candidate_grid_span_count_portrait",
            ),
            GROUP_VOICE to setOf(
                "show_voice_input_button", "preferred_voice_input",
            ),
            GROUP_EDITORS to emptySet(),
        )

        fun groupTitleRes(group: Int): Int = when (group) {
            GROUP_LAYOUT -> R.string.keyboard_category_layout
            GROUP_BEHAVIOR -> R.string.keyboard_category_behavior
            GROUP_FEEDBACK -> R.string.keyboard_category_feedback
            GROUP_TOOLBAR -> R.string.keyboard_category_toolbar
            GROUP_EDITORS -> R.string.keyboard_category_editors
            GROUP_CANDIDATE -> R.string.keyboard_category_candidate
            GROUP_VOICE -> R.string.keyboard_category_voice
            else -> throw IllegalArgumentException("Unknown group: $group")
        }
    }
}
