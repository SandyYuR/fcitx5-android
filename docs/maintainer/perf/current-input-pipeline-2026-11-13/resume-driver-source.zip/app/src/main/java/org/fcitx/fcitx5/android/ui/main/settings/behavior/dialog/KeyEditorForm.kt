/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2026 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.ui.main.settings.behavior.dialog

import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.fcitx.fcitx5.android.ui.main.settings.behavior.editor.EditorUi

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import kotlinx.serialization.json.JsonObject
import org.fcitx.fcitx5.android.R
import org.fcitx.fcitx5.android.data.prefs.AppPrefs
import org.fcitx.fcitx5.android.data.theme.SystemColorResourceId
import org.fcitx.fcitx5.android.data.theme.ThemeManager
import org.fcitx.fcitx5.android.data.theme.ThemeMonet
import org.fcitx.fcitx5.android.ui.main.settings.behavior.utils.LayoutJsonUtils
import org.fcitx.fcitx5.android.ui.main.settings.theme.SystemColorResourcePickerDialog
import org.fcitx.fcitx5.android.ui.main.settings.theme.ThemeColorEditorActivity
import org.fcitx.fcitx5.android.utils.DeviceUtil
import org.fcitx.fcitx5.android.utils.serializable
import splitties.dimensions.dp
import org.fcitx.fcitx5.android.utils.settingsColor
import splitties.views.backgroundColor
import splitties.views.dsl.core.wrapContent
import java.io.Serializable
import java.util.Arrays
import java.util.LinkedHashMap

/** The complete key form, shared by the canvas inspector and standalone editor. */
class KeyEditorForm(
    context: android.content.Context,
    private val intent: Intent,
    savedState: Bundle? = null,
    private val launchMacro: (Intent) -> Unit = {},
    private val launchColor: (ThemeColorEditorActivity.EditorInput) -> Unit = {},
    private val launchCompose: (Intent) -> Unit = {}
) : android.content.ContextWrapper(context) {
    var onChange: () -> Unit = {}
    private var building = true
    private var showValidationErrors = true
    val view: View get() = contentContainer
    val title: String get() = intent.getStringExtra(EXTRA_TITLE_OVERRIDE)
        ?: getString(if (keyIndex != null) R.string.edit else R.string.text_keyboard_layout_add_key)
    val subtitle: String? get() = currentSubModeLabel?.takeIf { isEditingSubModeLayout }
    val canDelete: Boolean get() = keyIndex != null || (composeOverrideEditorMode && hasInitialComposeOverride)


    private data class ThemeColorToken(
        val token: String,
        val resolver: (org.fcitx.fcitx5.android.data.theme.Theme) -> Int
    ) {
        val displayName: String
            get() = token.replace(Regex("([a-z])([A-Z])"), "$1 $2")
    }

    private data class EditableColorField(
        val customKey: String,
        val monetKey: String,
        val labelRes: Int,
        val themeColorGetter: (org.fcitx.fcitx5.android.data.theme.Theme) -> Int,
        val supportedTypes: Set<String>? = null
    )

    private val contentContainer by lazy {
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
    }

    private fun sectionHeading(label: Int) = TextView(this).apply {
        setText(label)
        setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleMedium)
        setTextColor(settingsColor(androidx.appcompat.R.attr.colorPrimary))
        setPadding(0, 0, 0, dp(12))
        androidx.core.view.ViewCompat.setAccessibilityHeading(this, true)
    }

    private fun organizeFields() {
        fun sectionFor(field: EditText?, section: Int) {
            var row: View = field ?: return
            while (row.parent is View && row.parent !== fieldsContainer) row = row.parent as View
            row.tag = section
        }
        listOf(alphabetWeightEdit, layoutSwitchWeightEdit, symbolWeightEdit, macroWeightEdit,
            simpleWeightEdit, placeholderWeightEdit).forEach { sectionFor(it, 2) }
        listOf(nonMacroSwipeLabelEdit, nonMacroSwipeUpLabelEdit, nonMacroSwipeDownLabelEdit,
            macroLongPressLabelEdit).forEach { sectionFor(it, 1) }
        val children = (0 until fieldsContainer.childCount).map(fieldsContainer::getChildAt)
        fieldsContainer.removeAllViews()
        val typeRow = typeSpinner.parent as View
        (typeRow.parent as? ViewGroup)?.removeView(typeRow)
        listOf(R.string.layout_editor_content, R.string.layout_editor_actions, R.string.layout_editor_appearance)
            .forEachIndexed { section, label ->
                val rows = children.filter { (it.tag as? Int ?: 0) == section }
                if (section != 0 && rows.isEmpty()) return@forEachIndexed
                val body = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(16), dp(16), dp(16), dp(16))
                    addView(sectionHeading(label))
                    if (section == 0) addView(typeRow)
                    rows.forEach { addView(it) }
                }
                fieldsContainer.addView(EditorUi.card(this, body), LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(12)
                })
            }
    }

    private val uiBuilder by lazy { KeyboardEditorUiBuilder(this) }

    private var rowIndex: Int = -1
    private var keyIndex: Int? = null
    private var isEditingSubModeLayout: Boolean = false
    private var currentSubModeLabel: String? = null
    private var hasMultiSubmodeSupport: Boolean = false
    private var lockTypeSelection: Boolean = false
    private var disableWeightEditing: Boolean = false
    private var composeOverrideEditorMode: Boolean = false
    private var hasInitialComposeOverride: Boolean = false
    private var availableLayoutTargets: List<String> = emptyList()
    private var independentColor: Boolean = false
    private var keyData: MutableMap<String, Any?> = mutableMapOf()
    private var keyColorOverrides: LinkedHashMap<String, Any?> = LinkedHashMap()
    private var inheritedBaseKeyColorData: MutableMap<String, Any?> = mutableMapOf()
    private var composeOverrideData: MutableMap<String, Any?>? = null

    private lateinit var typeSpinner: Spinner
    private lateinit var fieldsContainer: LinearLayout
    private var selectedType: String = "AlphabetKey"
    private var splitAfterCheckBox: android.widget.CheckBox? = null

    private var alphabetMainEdit: EditText? = null
    private var alphabetAltEdit: EditText? = null
    private var alphabetWeightEdit: EditText? = null
    private var alphabetDisplayTextSimpleEdit: EditText? = null
    private var alphabetDisplayTextModeSpecific = false
    private var alphabetDisplayTextSimpleValue = ""
    private val alphabetDisplayTextModeItems = mutableListOf<KeyboardEditorUiBuilder.DisplayTextItem>()
    private val alphabetDisplayTextRowBindings = mutableListOf<KeyboardEditorUiBuilder.DisplayTextRowBinding>()

    private var layoutSwitchLabelEdit: EditText? = null
    private var layoutSwitchTargetSpinner: Spinner? = null
    private var layoutSwitchWeightEdit: EditText? = null

    private var numPadLabelEdit: EditText? = null
    private var numPadSymSpinner: Spinner? = null

    private var symbolLabelEdit: EditText? = null
    private var symbolWeightEdit: EditText? = null

    private var macroLabelEdit: EditText? = null
    private var macroDisplayTextSimpleEdit: EditText? = null
    private var macroDisplayTextModeSpecific = false
    private var macroDisplayTextSimpleValue = ""
    private val macroDisplayTextModeItems = mutableListOf<KeyboardEditorUiBuilder.DisplayTextItem>()
    private val macroDisplayTextRowBindings = mutableListOf<KeyboardEditorUiBuilder.DisplayTextRowBinding>()
    private var macroLongPressLabelEdit: EditText? = null
    private var macroWeightEdit: EditText? = null

    private var simpleWeightEdit: EditText? = null
    private var nonMacroSwipeLabelEdit: EditText? = null
    private var nonMacroSwipeUpLabelEdit: EditText? = null
    private var nonMacroSwipeDownLabelEdit: EditText? = null

    // 空白占位键专用字段。
    private var placeholderMainEdit: EditText? = null
    private var placeholderAltEdit: EditText? = null
    private var placeholderWeightEdit: EditText? = null

    /**
     * 空白占位键是否使用自定义颜色。
     *
     * 关闭（默认）时这个键**连键底都不画**，只有文字可见；打开后才允许设置各种颜色并
     * 画出真实的键底。因此它同时决定了写进 JSON 的 `transparent` 字段（见
     * [buildDraftKeyData]）与颜色编辑区是否可用（见 [renderColorEditors]）。
     *
     * 不复用 [independentColor]：那个字段的语义是"合成态覆盖键是否自带配色"，只在
     * `composeOverrideEditorMode` 下有意义，普通键的颜色编辑区**始终**可用。两者叠在
     * 一起会让"占位键关掉自定义颜色"顺手把别的键型的颜色编辑也关掉。
     */
    private var placeholderCustomColor: Boolean = false

    private var macroTapStepsData: List<Any> = emptyList()
    private var macroSwipeUpStepsData: List<Any> = emptyList()
    private var macroSwipeDownStepsData: List<Any> = emptyList()
    private var macroLongPressStepsData: List<Any> = emptyList()
    private var nonMacroSwipeUpStepsData: List<Any> = emptyList()
    private var nonMacroSwipeDownStepsData: List<Any> = emptyList()
    private var nonMacroSwipeStepsData: List<Any> = emptyList()
    private var macroEditCallback: ((List<Any>) -> Unit)? = null

    /**
     * Which macro slot ("tap"/"swipe"/"longPress") the open macro editor is editing.
     *
     * [macroEditCallback] dies with this form instance, so the slot is also persisted:
     * a result that arrives after recreation is applied via [applyMacroStepsToSlot].
     */
    private var pendingMacroEventType: String? = null
    private var baselineKeySnapshot: String = ""
    private var lastPublishedSnapshot: String = ""
    private val editableColorFields = listOf(
        EditableColorField(
            customKey = "textColor",
            monetKey = "textColorMonet",
            labelRes = R.string.text_keyboard_layout_key_text_color,
            themeColorGetter = { it.keyTextColor }
        ),
        EditableColorField(
            customKey = "altTextColor",
            monetKey = "altTextColorMonet",
            labelRes = R.string.text_keyboard_layout_key_alt_text_color,
            themeColorGetter = { it.altKeyTextColor },
            supportedTypes = setOf("AlphabetKey", "MacroKey")
        ),
        EditableColorField(
            customKey = "backgroundColor",
            monetKey = "backgroundColorMonet",
            labelRes = R.string.text_keyboard_layout_key_background_color,
            themeColorGetter = { it.keyBackgroundColor }
        ),
        EditableColorField(
            customKey = "shadowColor",
            monetKey = "shadowColorMonet",
            labelRes = R.string.text_keyboard_layout_key_shadow_color,
            themeColorGetter = { it.keyShadowColor }
        )
    )

    private val themeColorTokens = listOf(
        ThemeColorToken("backgroundColor") { it.backgroundColor },
        ThemeColorToken("barColor") { it.barColor },
        ThemeColorToken("keyboardColor") { it.keyboardColor },
        ThemeColorToken("keyBackgroundColor") { it.keyBackgroundColor },
        ThemeColorToken("keyTextColor") { it.keyTextColor },
        ThemeColorToken("candidateTextColor") { it.candidateTextColor },
        ThemeColorToken("candidateLabelColor") { it.candidateLabelColor },
        ThemeColorToken("candidateCommentColor") { it.candidateCommentColor },
        ThemeColorToken("altKeyBackgroundColor") { it.altKeyBackgroundColor },
        ThemeColorToken("altKeyTextColor") { it.altKeyTextColor },
        ThemeColorToken("accentKeyBackgroundColor") { it.accentKeyBackgroundColor },
        ThemeColorToken("accentKeyTextColor") { it.accentKeyTextColor },
        ThemeColorToken("keyPressHighlightColor") { it.keyPressHighlightColor },
        ThemeColorToken("keyShadowColor") { it.keyShadowColor },
        ThemeColorToken("popupBackgroundColor") { it.popupBackgroundColor },
        ThemeColorToken("popupTextColor") { it.popupTextColor },
        ThemeColorToken("spaceBarColor") { it.spaceBarColor },
        ThemeColorToken("dividerColor") { it.dividerColor },
        ThemeColorToken("clipboardEntryColor") { it.clipboardEntryColor },
        ThemeColorToken("genericActiveBackgroundColor") { it.genericActiveBackgroundColor },
        ThemeColorToken("genericActiveForegroundColor") { it.genericActiveForegroundColor }
    )

    fun acceptMacroResult(result: androidx.activity.result.ActivityResult) {
        val callback = macroEditCallback
        val data = result.data
        val slot = data?.getStringExtra(MacroEditorDialogFragment.EXTRA_TARGET_TOKEN) ?: pendingMacroEventType
        macroEditCallback = null
        pendingMacroEventType = null
        if (result.resultCode != android.app.Activity.RESULT_OK) return
        data ?: return
        val steps = data.serializable<ArrayList<Map<*, *>>>(MacroEditorDialogFragment.EXTRA_MACRO_RESULT) ?: return
        val resolved = steps.map { it as Any }
        if (callback != null) callback(resolved) else if (slot != null) applyMacroStepsToSlot(slot, resolved)
    }

    fun acceptColorResult(result: ThemeColorEditorActivity.EditorResult?) {
        result ?: return
        val field = editableColorFields.firstOrNull { it.customKey == result.fieldName } ?: return
        persistCurrentDraft()
        setColorOverride(field, result.color, null)
        rebuildFields()
        updateActionButtonState()
    }

    fun acceptComposeResult(result: androidx.activity.result.ActivityResult) {
        val data = result.data ?: return
        if (result.resultCode != android.app.Activity.RESULT_OK) return
        val colors = LinkedHashMap(keyColorOverrides)
        persistCurrentDraft()
        restoreColorOverrides(colors)
        when (data.getStringExtra(EXTRA_RESULT_ACTION)) {
            RESULT_ACTION_SAVE -> {
                val returned = serializableExtraCompat<HashMap<String, Any?>>(data, EXTRA_RESULT_KEY_DATA)
                    ?.toMutableMap() ?: return
                returned.remove("weight")
                composeOverrideData = returned
            }
            RESULT_ACTION_DELETE -> composeOverrideData = null
        }
        rebuildFields()
        updateActionButtonState()
    }

    init {
        readIntentExtras()
        savedState?.let(::restoreDraftKeyData)
        buildForm()
        baselineKeySnapshot = savedState?.getString(STATE_BASELINE) ?: snapshotOf(buildDraftKeyData())
        lastPublishedSnapshot = snapshotOf(buildDraftKeyData())
        building = false
    }

    private fun readIntentExtras() {
        rowIndex = intent.getIntExtra(EXTRA_ROW_INDEX, -1)
        keyIndex = intent.takeIf { it.hasExtra(EXTRA_KEY_INDEX) }?.getIntExtra(EXTRA_KEY_INDEX, -1)?.takeIf { it >= 0 }
        isEditingSubModeLayout = intent.getBooleanExtra(EXTRA_IS_EDITING_SUBMODE_LAYOUT, false)
        currentSubModeLabel = intent.getStringExtra(EXTRA_CURRENT_SUBMODE_LABEL)
        hasMultiSubmodeSupport = intent.getBooleanExtra(EXTRA_HAS_MULTI_SUBMODE_SUPPORT, false)
        availableLayoutTargets = intent.getStringArrayListExtra(EXTRA_AVAILABLE_LAYOUT_TARGETS)?.toList() ?: emptyList()
        lockTypeSelection = intent.getBooleanExtra(EXTRA_LOCK_TYPE_SELECTION, false)
        disableWeightEditing = intent.getBooleanExtra(EXTRA_DISABLE_WEIGHT_EDITING, false)
        composeOverrideEditorMode = intent.getBooleanExtra(EXTRA_COMPOSE_OVERRIDE_EDITOR_MODE, false)
        hasInitialComposeOverride = intent.getBooleanExtra(EXTRA_HAS_INITIAL_COMPOSE_OVERRIDE, false)

        val received = serializableExtraCompat<HashMap<String, Any?>>(intent, EXTRA_KEY_DATA)
        keyData = received?.toMutableMap() ?: mutableMapOf()
        keyColorOverrides = extractColorOverrides(keyData)
        inheritedBaseKeyColorData = serializableExtraCompat<HashMap<String, Any?>>(intent, EXTRA_BASE_KEY_COLOR_DATA)
            ?.toMutableMap()
            ?: mutableMapOf()
        selectedType = intent.getStringExtra(EXTRA_FIXED_TYPE)
            ?: keyData["type"] as? String
            ?: "AlphabetKey"
        keyData["type"] = selectedType
        // 占位键的「自定义颜色」开关：显式写了 transparent=false 就是开着；此外只要这份
        // 键数据里**本来就有颜色取值**（手写 JSON 的情况，用户可能没写 transparent），
        // 也视为开着——否则那些颜色会被界面显示成"不可用"，用户一保存就被抹掉。
        placeholderCustomColor = keyData["transparent"] == false || keyColorOverrides.isNotEmpty()
        composeOverrideData = (keyData["composeOverride"] as? Map<*, *>)?.let { map ->
            map.entries.associate { (k, v) -> k.toString() to v }.toMutableMap()
        }
        if (composeOverrideEditorMode) {
            composeOverrideData = null
            keyData.remove("composeOverride")
            independentColor = keyData["independentColor"] as? Boolean ?: false
        }

    }

    private fun buildForm() {
        contentContainer.removeAllViews()
        typeSpinner = uiBuilder.setupTypeSpinner(contentContainer, keyData)
        if (lockTypeSelection) {
            typeSpinner.isEnabled = false
            typeSpinner.alpha = 0.6f
        }
        fieldsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        contentContainer.addView(fieldsContainer)

        if (!lockTypeSelection) {
            typeSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                    val newType = KeyboardEditorUiBuilder.KEY_TYPES[position]
                    if (newType == selectedType) return
                    persistCurrentDraft()
                    selectedType = newType
                    // 换成占位键时按这份键数据重推开关初值，否则它会带着上一个键型的状态
                    // （例如刚在字母键上配过颜色）进来，用户看到的是"我没开却已经开着"。
                    placeholderCustomColor =
                        keyData["transparent"] == false || keyColorOverrides.isNotEmpty()
                    rebuildFields()
                    updateActionButtonState()
                }

                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            }
        }

        rebuildFields()
    }

    private fun rebuildFields() {
        val wasBuilding = building
        building = true
        fieldsContainer.clearFocus()
        for (i in 0 until fieldsContainer.childCount) {
            fieldsContainer.getChildAt(i).clearFocus()
        }

        fieldsContainer.removeAllViews()
        splitAfterCheckBox = null
        alphabetMainEdit = null
        alphabetAltEdit = null
        alphabetWeightEdit = null
        alphabetDisplayTextSimpleEdit = null
        alphabetDisplayTextRowBindings.clear()
        layoutSwitchLabelEdit = null
        layoutSwitchTargetSpinner = null
        layoutSwitchWeightEdit = null
        numPadLabelEdit = null
        numPadSymSpinner = null
        symbolLabelEdit = null
        symbolWeightEdit = null
        macroLabelEdit = null
        macroDisplayTextSimpleEdit = null
        macroDisplayTextModeSpecific = false
        macroDisplayTextSimpleValue = ""
        macroDisplayTextModeItems.clear()
        macroDisplayTextRowBindings.clear()
        macroWeightEdit = null
        simpleWeightEdit = null
        nonMacroSwipeLabelEdit = null
        nonMacroSwipeUpLabelEdit = null
        nonMacroSwipeDownLabelEdit = null
        placeholderMainEdit = null
        placeholderAltEdit = null
        placeholderWeightEdit = null
        nonMacroSwipeStepsData = emptyList()
        nonMacroSwipeUpStepsData = emptyList()
        nonMacroSwipeDownStepsData = emptyList()
        macroSwipeUpStepsData = emptyList()
        macroSwipeDownStepsData = emptyList()

        initDisplayText(
            keyData,
            isEditingSubModeLayout,
            currentSubModeLabel
        ) { modeSpecific, simpleValue, items ->
            alphabetDisplayTextModeSpecific = modeSpecific
            alphabetDisplayTextSimpleValue = simpleValue
            alphabetDisplayTextModeItems.clear()
            alphabetDisplayTextModeItems.addAll(items)
        }

        initDisplayText(
            keyData,
            isEditingSubModeLayout,
            currentSubModeLabel,
            labelTextKey = "displayText"
        ) { modeSpecific, simpleValue, items ->
            macroDisplayTextModeSpecific = modeSpecific
            macroDisplayTextSimpleValue = simpleValue
            macroDisplayTextModeItems.clear()
            macroDisplayTextModeItems.addAll(items)
        }

        when (selectedType) {
            "AlphabetKey" -> {
                val mainEdit = uiBuilder.createEditField(
                    getString(R.string.text_keyboard_layout_key_main),
                    keyData["main"] as? String ?: ""
                )
                val altEdit = uiBuilder.createEditField(
                    getString(R.string.text_keyboard_layout_key_alt),
                    keyData["alt"] as? String ?: ""
                )
                fieldsContainer.addView(mainEdit.first)
                fieldsContainer.addView(altEdit.first)
                if (!disableWeightEditing) {
                    val weightEdit = uiBuilder.createEditField(
                        getString(R.string.text_keyboard_layout_key_weight),
                        (keyData["weight"] as? Number)?.toString() ?: ""
                    )
                    fieldsContainer.addView(weightEdit.first)
                    alphabetWeightEdit = weightEdit.second
                }

                val displayTextContainer = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                }
                fieldsContainer.addView(displayTextContainer)

                alphabetMainEdit = mainEdit.second
                alphabetAltEdit = altEdit.second

                uiBuilder.renderDisplayTextEditor(
                    displayTextContainer,
                    alphabetDisplayTextModeSpecific,
                    alphabetDisplayTextSimpleValue,
                    alphabetDisplayTextModeItems,
                    alphabetDisplayTextRowBindings,
                    isEditingSubModeLayout,
                    hasMultiSubmodeSupport
                ) { modeSpecific, simpleValue, items, bindings, simpleTextEdit ->
                    alphabetDisplayTextModeSpecific = modeSpecific
                    alphabetDisplayTextSimpleValue = simpleValue
                    alphabetDisplayTextModeItems.clear()
                    alphabetDisplayTextModeItems.addAll(items)
                    alphabetDisplayTextRowBindings.clear()
                    alphabetDisplayTextRowBindings.addAll(bindings)
                    alphabetDisplayTextSimpleEdit = simpleTextEdit ?: bindings.lastOrNull()?.valueEdit
                    updateActionButtonState()
                }
            }

            "LayoutSwitchKey" -> {
                val labelEdit = uiBuilder.createEditField(
                    getString(R.string.text_keyboard_layout_key_label),
                    keyData["label"] as? String ?: "?123"
                )
                layoutSwitchLabelEdit = labelEdit.second
                fieldsContainer.addView(labelEdit.first)
                layoutSwitchTargetSpinner = uiBuilder.createSwitchTargetSpinner(
                    fieldsContainer,
                    keyData["subLabel"] as? String ?: ""
                )
                layoutSwitchTargetSpinner?.onItemSelectedListener =
                    object : android.widget.AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(
                            parent: android.widget.AdapterView<*>?,
                            view: android.view.View?,
                            position: Int,
                            id: Long
                        ) {
                            updateActionButtonState()
                        }
                        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                    }
                if (!disableWeightEditing) {
                    val weightEdit = uiBuilder.createEditField(
                        getString(R.string.text_keyboard_layout_key_weight),
                        (keyData["weight"] as? Number)?.toString() ?: ""
                    )
                    fieldsContainer.addView(weightEdit.first)
                    layoutSwitchWeightEdit = weightEdit.second
                }

                addDirectionalSwipeLabelEditors(keyData)

                val (swipeUpMacroSteps, swipeDownMacroSteps) = directionalSwipeStepsOf(keyData)
                nonMacroSwipeUpStepsData = swipeUpMacroSteps
                nonMacroSwipeDownStepsData = swipeDownMacroSteps
                createMacroEditorButton(
                    title = getString(R.string.text_keyboard_layout_macro_swipe_up_event),
                    previewText = buildMacroPreview(swipeUpMacroSteps),
                    onClick = {
                        openMacroEditor(nonMacroSwipeUpStepsData, getString(R.string.text_keyboard_layout_macro_swipe_up_event), SLOT_SWIPE_UP) { newSteps ->
                            val draft = buildDraftKeyData()
                            nonMacroSwipeUpStepsData = newSteps
                            applyDirectionalSwipeDraft(draft, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
                            appendDirectionalSwipeLabels(draft)
                            keyData = draft
                            rebuildFields()
                            updateActionButtonState()
                        }
                    }
                ).forEach { fieldsContainer.addView(it) }
                createMacroEditorButton(
                    title = getString(R.string.text_keyboard_layout_macro_swipe_down_event),
                    previewText = buildMacroPreview(swipeDownMacroSteps),
                    onClick = {
                        openMacroEditor(nonMacroSwipeDownStepsData, getString(R.string.text_keyboard_layout_macro_swipe_down_event), SLOT_SWIPE_DOWN) { newSteps ->
                            val draft = buildDraftKeyData()
                            nonMacroSwipeDownStepsData = newSteps
                            applyDirectionalSwipeDraft(draft, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
                            appendDirectionalSwipeLabels(draft)
                            keyData = draft
                            rebuildFields()
                            updateActionButtonState()
                        }
                    }
                ).forEach { fieldsContainer.addView(it) }
            }

            "SymbolKey" -> {
                val labelEdit = uiBuilder.createEditField(
                    getString(R.string.text_keyboard_layout_key_label),
                    keyData["label"] as? String ?: "."
                )
                symbolLabelEdit = labelEdit.second
                fieldsContainer.addView(labelEdit.first)
                if (!disableWeightEditing) {
                    val weightEdit = uiBuilder.createEditField(
                        getString(R.string.text_keyboard_layout_key_weight),
                        (keyData["weight"] as? Number)?.toString() ?: ""
                    )
                    symbolWeightEdit = weightEdit.second
                    fieldsContainer.addView(weightEdit.first)
                }

                addDirectionalSwipeLabelEditors(keyData)

                val (swipeUpMacroSteps, swipeDownMacroSteps) = directionalSwipeStepsOf(keyData)
                nonMacroSwipeUpStepsData = swipeUpMacroSteps
                nonMacroSwipeDownStepsData = swipeDownMacroSteps
                createMacroEditorButton(
                    title = getString(R.string.text_keyboard_layout_macro_swipe_up_event),
                    previewText = buildMacroPreview(swipeUpMacroSteps),
                    onClick = {
                        openMacroEditor(nonMacroSwipeUpStepsData, getString(R.string.text_keyboard_layout_macro_swipe_up_event), SLOT_SWIPE_UP) { newSteps ->
                            val draft = buildDraftKeyData()
                            nonMacroSwipeUpStepsData = newSteps
                            applyDirectionalSwipeDraft(draft, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
                            appendDirectionalSwipeLabels(draft)
                            keyData = draft
                            rebuildFields()
                            updateActionButtonState()
                        }
                    }
                ).forEach { fieldsContainer.addView(it) }
                createMacroEditorButton(
                    title = getString(R.string.text_keyboard_layout_macro_swipe_down_event),
                    previewText = buildMacroPreview(swipeDownMacroSteps),
                    onClick = {
                        openMacroEditor(nonMacroSwipeDownStepsData, getString(R.string.text_keyboard_layout_macro_swipe_down_event), SLOT_SWIPE_DOWN) { newSteps ->
                            val draft = buildDraftKeyData()
                            nonMacroSwipeDownStepsData = newSteps
                            applyDirectionalSwipeDraft(draft, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
                            appendDirectionalSwipeLabels(draft)
                            keyData = draft
                            rebuildFields()
                            updateActionButtonState()
                        }
                    }
                ).forEach { fieldsContainer.addView(it) }
            }

            "MacroKey" -> {
                val labelEdit = uiBuilder.createEditField(
                    getString(R.string.text_keyboard_layout_key_label),
                    keyData["label"] as? String ?: ""
                )
                val longPressLabelEdit = uiBuilder.createEditField(
                    getString(R.string.text_keyboard_layout_longpress_label),
                    keyData["longPressLabel"] as? String ?: ""
                )
                (longPressLabelEdit.first.getChildAt(0) as com.google.android.material.textfield.TextInputLayout).placeholderText =
                    getString(R.string.text_keyboard_layout_longpress_label_fallback_hint)
                fieldsContainer.addView(labelEdit.first)
                addDirectionalSwipeLabelEditors(keyData)
                fieldsContainer.addView(longPressLabelEdit.first)
                if (!disableWeightEditing) {
                    val weightEdit = uiBuilder.createEditField(
                        getString(R.string.text_keyboard_layout_key_weight),
                        (keyData["weight"] as? Number)?.toString() ?: ""
                    )
                    fieldsContainer.addView(weightEdit.first)
                    macroWeightEdit = weightEdit.second
                }

                macroLabelEdit = labelEdit.second
                macroLongPressLabelEdit = longPressLabelEdit.second

                val labelTextContainer = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                }
                fieldsContainer.addView(labelTextContainer)

                uiBuilder.renderDisplayTextEditor(
                    labelTextContainer,
                    macroDisplayTextModeSpecific,
                    macroDisplayTextSimpleValue,
                    macroDisplayTextModeItems,
                    macroDisplayTextRowBindings,
                    isEditingSubModeLayout,
                    hasMultiSubmodeSupport = !isEditingSubModeLayout,
                    callback = { modeSpecific, simpleValue, items, bindings, simpleTextEdit ->
                        macroDisplayTextModeSpecific = modeSpecific
                        macroDisplayTextSimpleValue = simpleValue
                        macroDisplayTextModeItems.clear()
                        macroDisplayTextModeItems.addAll(items)
                        macroDisplayTextRowBindings.clear()
                        macroDisplayTextRowBindings.addAll(bindings)
                        macroDisplayTextSimpleEdit = simpleTextEdit
                        updateActionButtonState()
                    }
                )

                val tapAction = keyData["tap"] as? Map<*, *>
                val longPressAction = keyData["longPress"] as? Map<*, *>
                val (swipeUpMacroSteps, swipeDownMacroSteps) = directionalSwipeStepsOf(keyData)

                val tapMacroSteps = (tapAction?.get("macro") as? List<*>)?.filterNotNull() ?: emptyList()
                val longPressMacroSteps = (longPressAction?.get("macro") as? List<*>)?.filterNotNull() ?: emptyList()

                macroTapStepsData = tapMacroSteps
                macroSwipeUpStepsData = swipeUpMacroSteps
                macroSwipeDownStepsData = swipeDownMacroSteps
                macroLongPressStepsData = longPressMacroSteps

                createMacroEditorButton(
                    title = getString(R.string.text_keyboard_layout_macro_tap_event),
                    previewText = buildMacroPreview(tapMacroSteps),
                    onClick = {
                        openMacroEditor(macroTapStepsData, getString(R.string.text_keyboard_layout_macro_tap_event), SLOT_TAP) { newSteps ->
                            val draft = buildDraftKeyData()
                            macroTapStepsData = newSteps
                            draft["tap"] = mapOf("macro" to newSteps)
                            keyData = draft
                            rebuildFields()
                            updateActionButtonState()
                        }
                    }
                ).forEach { fieldsContainer.addView(it) }

                createMacroEditorButton(
                    title = getString(R.string.text_keyboard_layout_macro_swipe_up_event),
                    previewText = buildMacroPreview(swipeUpMacroSteps),
                    onClick = {
                        openMacroEditor(macroSwipeUpStepsData, getString(R.string.text_keyboard_layout_macro_swipe_up_event), SLOT_SWIPE_UP) { newSteps ->
                            val draft = buildDraftKeyData()
                            macroSwipeUpStepsData = newSteps
                            applyDirectionalSwipeDraft(draft, macroSwipeUpStepsData, macroSwipeDownStepsData)
                            keyData = draft
                            rebuildFields()
                            updateActionButtonState()
                        }
                    }
                ).forEach { fieldsContainer.addView(it) }

                createMacroEditorButton(
                    title = getString(R.string.text_keyboard_layout_macro_swipe_down_event),
                    previewText = buildMacroPreview(swipeDownMacroSteps),
                    onClick = {
                        openMacroEditor(macroSwipeDownStepsData, getString(R.string.text_keyboard_layout_macro_swipe_down_event), SLOT_SWIPE_DOWN) { newSteps ->
                            val draft = buildDraftKeyData()
                            macroSwipeDownStepsData = newSteps
                            applyDirectionalSwipeDraft(draft, macroSwipeUpStepsData, macroSwipeDownStepsData)
                            keyData = draft
                            rebuildFields()
                            updateActionButtonState()
                        }
                    }
                ).forEach { fieldsContainer.addView(it) }

                createMacroEditorButton(
                    title = getString(R.string.text_keyboard_layout_macro_longpress_event),
                    previewText = buildMacroPreview(longPressMacroSteps),
                    onClick = {
                        openMacroEditor(macroLongPressStepsData, getString(R.string.text_keyboard_layout_macro_longpress_event), SLOT_LONG_PRESS) { newSteps ->
                            val draft = buildDraftKeyData()
                            macroLongPressStepsData = newSteps
                            draft["longPress"] = mapOf("macro" to newSteps)
                            keyData = draft
                            rebuildFields()
                            updateActionButtonState()
                        }
                    }
                ).forEach { fieldsContainer.addView(it) }
            }

            "CapsKey", "ReturnKey", "BackspaceKey" -> {
                if (!disableWeightEditing) {
                    val weightEdit = uiBuilder.createEditField(
                        getString(R.string.text_keyboard_layout_key_weight),
                        (keyData["weight"] as? Number)?.toString() ?: ""
                    )
                    simpleWeightEdit = weightEdit.second
                    fieldsContainer.addView(weightEdit.first)
                }

                addDirectionalSwipeLabelEditors(keyData)

                val (swipeUpMacroSteps, swipeDownMacroSteps) = directionalSwipeStepsOf(keyData)
                nonMacroSwipeUpStepsData = swipeUpMacroSteps
                nonMacroSwipeDownStepsData = swipeDownMacroSteps
                createMacroEditorButton(
                    title = getString(R.string.text_keyboard_layout_macro_swipe_up_event),
                    previewText = buildMacroPreview(swipeUpMacroSteps),
                    onClick = {
                        openMacroEditor(nonMacroSwipeUpStepsData, getString(R.string.text_keyboard_layout_macro_swipe_up_event), SLOT_SWIPE_UP) { newSteps ->
                            val draft = buildDraftKeyData()
                            nonMacroSwipeUpStepsData = newSteps
                            applyDirectionalSwipeDraft(draft, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
                            appendDirectionalSwipeLabels(draft)
                            keyData = draft
                            rebuildFields()
                            updateActionButtonState()
                        }
                    }
                ).forEach { fieldsContainer.addView(it) }
                createMacroEditorButton(
                    title = getString(R.string.text_keyboard_layout_macro_swipe_down_event),
                    previewText = buildMacroPreview(swipeDownMacroSteps),
                    onClick = {
                        openMacroEditor(nonMacroSwipeDownStepsData, getString(R.string.text_keyboard_layout_macro_swipe_down_event), SLOT_SWIPE_DOWN) { newSteps ->
                            val draft = buildDraftKeyData()
                            nonMacroSwipeDownStepsData = newSteps
                            applyDirectionalSwipeDraft(draft, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
                            appendDirectionalSwipeLabels(draft)
                            keyData = draft
                            rebuildFields()
                            updateActionButtonState()
                        }
                    }
                ).forEach { fieldsContainer.addView(it) }
            }

            "CommaKey", "LanguageKey" -> {
                if (!disableWeightEditing) {
                    val weightEdit = uiBuilder.createEditField(
                        getString(R.string.text_keyboard_layout_key_weight),
                        (keyData["weight"] as? Number)?.toString() ?: ""
                    )
                    simpleWeightEdit = weightEdit.second
                    fieldsContainer.addView(weightEdit.first)
                }
            }

            "SpaceKey" -> {
                if (!disableWeightEditing) {
                    val weightEdit = uiBuilder.createEditField(
                        getString(R.string.text_keyboard_layout_key_weight),
                        (keyData["weight"] as? Number)?.toString() ?: ""
                    )
                    simpleWeightEdit = weightEdit.second
                    fieldsContainer.addView(weightEdit.first)
                }

                // 空格键的划动动作与「滑动空格键移动光标」开关互斥：开关开启时光标手势
                // 完全接管，这里的配置不生效。显式提示，避免用户以为配置丢了。
                fieldsContainer.addView(
                    uiBuilder.createNoticeField(
                        getString(R.string.text_keyboard_layout_space_swipe_hint)
                    )
                )

                val swipeLabelEdit = uiBuilder.createEditField(
                    getString(R.string.text_keyboard_layout_swipe_label),
                    keyData["swipeLabel"] as? String ?: ""
                )
                nonMacroSwipeLabelEdit = swipeLabelEdit.second
                fieldsContainer.addView(swipeLabelEdit.first)

                val swipeAction = keyData["swipe"] as? Map<*, *>
                val swipeMacroSteps = (swipeAction?.get("macro") as? List<*>)?.filterNotNull() ?: emptyList()
                nonMacroSwipeStepsData = swipeMacroSteps
                createMacroEditorButton(
                    title = getString(R.string.text_keyboard_layout_macro_swipe_event),
                    previewText = buildMacroPreview(swipeMacroSteps),
                    onClick = {
                        openMacroEditor(nonMacroSwipeStepsData, getString(R.string.text_keyboard_layout_macro_swipe_event), SLOT_SWIPE) { newSteps ->
                            val draft = buildDraftKeyData()
                            nonMacroSwipeStepsData = newSteps
                            if (newSteps.isNotEmpty()) {
                                draft["swipe"] = mapOf("macro" to newSteps)
                            } else {
                                draft.remove("swipe")
                            }
                            keyData = draft
                            rebuildFields()
                            updateActionButtonState()
                        }
                    }
                ).forEach { fieldsContainer.addView(it) }
            }

            "NumPadKey" -> {
                val labelEdit = uiBuilder.createEditField(
                    getString(R.string.text_keyboard_layout_key_label),
                    keyData["label"] as? String ?: "0"
                )
                numPadLabelEdit = labelEdit.second
                fieldsContainer.addView(labelEdit.first)
                val currentSym = when (val s = keyData["sym"]) {
                    is Number -> s.toInt()
                    is String -> LayoutJsonUtils.resolveKeysym(s) ?: 0
                    else -> 0
                }
                numPadSymSpinner = uiBuilder.createNumPadSymSpinner(fieldsContainer, currentSym)
                // Keep the displayed label in sync with the selected numpad symbol, unless the
                // user typed a custom label. Otherwise the preview would keep showing the old
                // label after switching the symbol.
                numPadSymSpinner?.onItemSelectedListener =
                    object : android.widget.AdapterView.OnItemSelectedListener {
                        private var selectedSym = currentSym
                        override fun onItemSelected(
                            parent: android.widget.AdapterView<*>?,
                            view: android.view.View?,
                            position: Int,
                            id: Long
                        ) {
                            val option = parent?.getItemAtPosition(position) as? KeyboardEditorUiBuilder.NumPadOption ?: return
                            if (option.sym == selectedSym) return
                            selectedSym = option.sym
                            val current = numPadLabelEdit?.text?.toString().orEmpty()
                            val synced = current.isEmpty() ||
                                KeyboardEditorUiBuilder.NUMPAD_OPTIONS.any { it.label == current }
                            if (synced) numPadLabelEdit?.setText(option.label)
                            updateActionButtonState()
                        }
                        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {
                            updateActionButtonState()
                        }
                    }
                if (!disableWeightEditing) {
                    val weightEdit = uiBuilder.createEditField(
                        getString(R.string.text_keyboard_layout_key_weight),
                        (keyData["weight"] as? Number)?.toString() ?: ""
                    )
                    simpleWeightEdit = weightEdit.second
                    fieldsContainer.addView(weightEdit.first)
                }
            }

            "MiniSpaceKey" -> {
                if (!disableWeightEditing) {
                    val weightEdit = uiBuilder.createEditField(
                        getString(R.string.text_keyboard_layout_key_weight),
                        (keyData["weight"] as? Number)?.toString() ?: ""
                    )
                    simpleWeightEdit = weightEdit.second
                    fieldsContainer.addView(weightEdit.first)
                }
            }

            "PlaceholderKey" -> {
                // 主/副字符**都可以留空**——留空 + 关闭自定义颜色就是"完全不可见"的占位，
                // 这也是默认形态，故不给任何兜底默认字符（见 LayoutJsonUtils 的写入分支）。
                val mainEdit = uiBuilder.createEditField(
                    getString(R.string.text_keyboard_layout_key_main),
                    keyData["main"] as? String ?: ""
                )
                val altEdit = uiBuilder.createEditField(
                    getString(R.string.text_keyboard_layout_key_alt),
                    keyData["alt"] as? String ?: ""
                )
                fieldsContainer.addView(mainEdit.first)
                fieldsContainer.addView(altEdit.first)
                placeholderMainEdit = mainEdit.second
                placeholderAltEdit = altEdit.second

                if (!disableWeightEditing) {
                    val weightEdit = uiBuilder.createEditField(
                        getString(R.string.text_keyboard_layout_key_weight),
                        (keyData["weight"] as? Number)?.toString() ?: ""
                    )
                    fieldsContainer.addView(weightEdit.first)
                    placeholderWeightEdit = weightEdit.second
                }

                // 自定义颜色开关要放在颜色编辑区**之前**：它决定下面那几行是否可用
                // （见 renderColorEditors），放在后面会让人先看到一堆灰掉的项。
                val appearanceStart = fieldsContainer.childCount
                renderPlaceholderCustomColorToggle()
                for (i in appearanceStart until fieldsContainer.childCount) fieldsContainer.getChildAt(i).tag = 2
                fieldsContainer.addView(
                    uiBuilder.createNoticeField(
                        getString(R.string.text_keyboard_layout_key_type_placeholder_helper)
                    )
                )
            }
        }

        if (!composeOverrideEditorMode) {
            val appearanceStart = fieldsContainer.childCount
            splitAfterCheckBox = uiBuilder.createSplitBoundaryCheckbox(
                fieldsContainer, keyData["splitAfter"] == true
            ).apply {
                setOnCheckedChangeListener { _, _ -> updateActionButtonState() }
            }
            for (i in appearanceStart until fieldsContainer.childCount) fieldsContainer.getChildAt(i).tag = 2
            // 空白占位键不显示「合成态按键」入口：它不可点击，永远进不了合成态，
            // 那个入口只会误导用户去配一个永远不会生效的东西。
            val start = fieldsContainer.childCount
            if (selectedType != "PlaceholderKey") renderComposeOverrideEditorEntry()
            for (i in start until fieldsContainer.childCount) fieldsContainer.getChildAt(i).tag = 1
        } else {
            val start = fieldsContainer.childCount
            renderFollowBaseKeyColorsToggle()
            for (i in start until fieldsContainer.childCount) fieldsContainer.getChildAt(i).tag = 2
        }
        val colorStart = fieldsContainer.childCount
        renderColorEditors()
        for (i in colorStart until fieldsContainer.childCount) fieldsContainer.getChildAt(i).tag = 2
        organizeFields()
        attachFieldWatchers(fieldsContainer)
        building = wasBuilding
        updateActionButtonState()
    }

    private fun renderComposeOverrideEditorEntry() {
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(8))
        }
        val editButton = EditorUi.button(this, R.string.text_keyboard_layout_compose_override_edit_button, tonal = true) {
            openComposeOverrideEditor()
        }
        actions.addView(editButton)
        fieldsContainer.addView(
            actions,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val statusView = TextView(this).apply {
            text = buildComposeOverrideStatusPreview()
            textSize = 12f
            setTextColor(settingsColor(android.R.attr.textColorSecondary))
            setPadding(dp(8), dp(2), dp(8), dp(8))
        }
        fieldsContainer.addView(
            statusView,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
    }

    private fun buildComposeOverrideStatusPreview(): String {
        return if (composeOverrideData == null) {
            getString(R.string.text_keyboard_layout_compose_override_not_configured)
        } else {
            getString(R.string.text_keyboard_layout_compose_override_configured)
        }
    }

    private fun renderFollowBaseKeyColorsToggle() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val label = TextView(this).apply {
            text = getString(R.string.text_keyboard_layout_compose_override_follow_base_key_colors)
            textSize = 13f
            setTextColor(settingsColor(android.R.attr.textColorSecondary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                weight = 1f
            }
        }
        val switchView = MaterialSwitch(this).apply {
            isChecked = independentColor
            setOnCheckedChangeListener { _, isChecked ->
                persistCurrentDraft()
                independentColor = isChecked
                rebuildFields()
                updateActionButtonState()
            }
        }
        row.addView(label)
        row.addView(switchView)
        fieldsContainer.addView(
            row,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
    }

    /**
     * 「自定义颜色」开关（仅空白占位键）。
     *
     * 关掉时这个键连键底都不画，只有文字可见——这正是"完全空白的占位"那一半需求；
     * 打开后才画真实键底并允许设置各种颜色，用于"不可点击的纯外观键"。
     *
     * 切换时要 `rebuildFields()`：颜色编辑区的可用状态由它决定，不重建的话开关拨过去
     * 下面几行还是灰的，用户会以为开关没生效。
     */
    private fun renderPlaceholderCustomColorToggle() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(4))
        }
        val label = TextView(this).apply {
            text = getString(R.string.text_keyboard_layout_placeholder_custom_color)
            textSize = 13f
            setTextColor(settingsColor(android.R.attr.textColorSecondary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                weight = 1f
            }
        }
        val switchView = MaterialSwitch(this).apply {
            isChecked = placeholderCustomColor
            setOnCheckedChangeListener { _, isChecked ->
                if (placeholderCustomColor == isChecked) return@setOnCheckedChangeListener
                persistCurrentDraft()
                placeholderCustomColor = isChecked
                rebuildFields()
                updateActionButtonState()
            }
        }
        row.addView(label)
        row.addView(switchView)
        fieldsContainer.addView(
            row,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
    }

    private fun openComposeOverrideEditor() {
        persistCurrentDraft()
        val hasOverride = composeOverrideData != null
        val editorData = (composeOverrideData ?: mutableMapOf()).toMutableMap()
        if (editorData["type"] == null) {
            editorData["type"] = selectedType
        }
        if (editorData["independentColor"] !is Boolean) {
            editorData["independentColor"] = false
        }
        val intent = Intent(this, KeyEditorActivity::class.java).apply {
            putExtra(EXTRA_KEY_DATA, toSerializableMap(editorData))
            putExtra(EXTRA_BASE_KEY_COLOR_DATA, toSerializableMap(keyColorOverrides))
            putExtra(EXTRA_ROW_INDEX, -1)
            putExtra(EXTRA_DISABLE_WEIGHT_EDITING, true)
            putExtra(EXTRA_COMPOSE_OVERRIDE_EDITOR_MODE, true)
            putExtra(EXTRA_HAS_INITIAL_COMPOSE_OVERRIDE, hasOverride)
            putExtra(EXTRA_TITLE_OVERRIDE, getString(R.string.text_keyboard_layout_compose_override_editor_title))
        }
        launchCompose(intent)
    }

    private fun persistCurrentDraft() {
        val draft = buildDraftKeyData()
        keyData.clear()
        keyData.putAll(draft)
    }

    fun saveState(outState: Bundle) {
        // Snapshot the draft (including edits typed into fields) so a rotation does not throw
        // it away and silently fall back to the values passed in the Intent.
        runCatching { toSerializableMap(buildDraftKeyData()) }
            .onSuccess { outState.putSerializable(STATE_DRAFT_KEY_DATA, it) }
            .onFailure { android.util.Log.w(TAG, "Failed to save draft key data", it) }
        outState.putString(STATE_PENDING_MACRO_EVENT, pendingMacroEventType)
        outState.putString(STATE_BASELINE, baselineKeySnapshot)
    }

    private fun restoreDraftKeyData(state: Bundle) {
        pendingMacroEventType = state.getString(STATE_PENDING_MACRO_EVENT)
        val draft = serializableBundleCompat<HashMap<String, Any?>>(state, STATE_DRAFT_KEY_DATA)
            ?: return
        keyData = draft.toMutableMap()
        keyColorOverrides = extractColorOverrides(keyData)
        selectedType = keyData["type"] as? String ?: selectedType
        composeOverrideData = (keyData["composeOverride"] as? Map<*, *>)?.let { map ->
            map.entries.associate { (k, v) -> k.toString() to v }.toMutableMap()
        }
        macroTapStepsData = macroStepsOf(keyData["tap"])
        val (macroSwipeUpSteps, macroSwipeDownSteps) = directionalSwipeStepsOf(keyData)
        macroSwipeUpStepsData = macroSwipeUpSteps
        macroSwipeDownStepsData = macroSwipeDownSteps
        macroLongPressStepsData = macroStepsOf(keyData["longPress"])
        nonMacroSwipeStepsData = macroStepsOf(keyData["swipe"])
        val (nonMacroSwipeUpSteps, nonMacroSwipeDownSteps) = directionalSwipeStepsOf(keyData)
        nonMacroSwipeUpStepsData = nonMacroSwipeUpSteps
        nonMacroSwipeDownStepsData = nonMacroSwipeDownSteps
    }

    private fun macroStepsOf(action: Any?): List<Any> =
        ((action as? Map<*, *>)?.get("macro") as? List<*>)?.filterNotNull() ?: emptyList()

    /** 旧单槽字段编辑时跟随已有的新方向槽；否则采用当前方向设置和主题符号位置。 */
    private fun legacySwipeToDown(keyData: Map<String, Any?>): Boolean {
        val hasDirectionalSlots = keyData.containsKey("swipeUp") ||
            keyData.containsKey("swipeDown") ||
            keyData.containsKey("swipeUpLabel") ||
            keyData.containsKey("swipeDownLabel")
        val targetsUp = if (hasDirectionalSlots) {
            LayoutJsonUtils.legacySwipeTargetsUp(
                hasUpMacro = keyData.containsKey("swipeUp"),
                hasDownMacro = keyData.containsKey("swipeDown"),
                hasUpLabel = keyData.containsKey("swipeUpLabel"),
                hasDownLabel = keyData.containsKey("swipeDownLabel")
            )
        } else {
            LayoutJsonUtils.legacySwipeTargetsUpFromSettings(
                AppPrefs.getInstance().keyboard.swipeSymbolDirection.getValue(),
                ThemeManager.prefs.punctuationPosition.getValue()
            )
        }
        return !targetsUp
    }

    private fun directionalSwipeStepsOf(keyData: Map<String, Any?>): Pair<List<Any>, List<Any>> {
        val up = macroStepsOf(keyData["swipeUp"])
        val down = macroStepsOf(keyData["swipeDown"])
        val hasDirectional = keyData.containsKey("swipeUp") || keyData.containsKey("swipeDown")
        if (hasDirectional) return up to down
        val legacy = macroStepsOf(keyData["swipe"])
        return if (legacySwipeToDown(keyData)) emptyList<Any>() to legacy else legacy to emptyList()
    }

    private fun applyDirectionalSwipeDraft(
        draft: MutableMap<String, Any?>,
        upSteps: List<Any>,
        downSteps: List<Any>
    ) {
        draft.remove("swipe")
        if (upSteps.isNotEmpty()) draft["swipeUp"] = mapOf("macro" to upSteps)
        else draft.remove("swipeUp")
        if (downSteps.isNotEmpty()) draft["swipeDown"] = mapOf("macro" to downSteps)
        else draft.remove("swipeDown")
    }

    private fun addDirectionalSwipeLabelEditors(keyData: Map<String, Any?>) {
        val hasDirectionalLabel = keyData.containsKey("swipeUpLabel") || keyData.containsKey("swipeDownLabel")
        val legacyLabel = if (keyData["type"] == "MacroKey") {
            keyData["altLabel"] as? String
        } else {
            keyData["swipeLabel"] as? String
        }
        val upLabel = keyData["swipeUpLabel"] as? String
            ?: if (!hasDirectionalLabel && !legacySwipeToDown(keyData)) legacyLabel.orEmpty() else ""
        val downLabel = keyData["swipeDownLabel"] as? String
            ?: if (!hasDirectionalLabel && legacySwipeToDown(keyData)) legacyLabel.orEmpty() else ""
        val up = uiBuilder.createEditField(
            getString(R.string.text_keyboard_layout_swipe_up_label),
            upLabel
        )
        val down = uiBuilder.createEditField(
            getString(R.string.text_keyboard_layout_swipe_down_label),
            downLabel
        )
        nonMacroSwipeUpLabelEdit = up.second
        nonMacroSwipeDownLabelEdit = down.second
        fieldsContainer.addView(up.first)
        fieldsContainer.addView(down.first)
    }

    private fun appendDirectionalSwipeLabels(draft: MutableMap<String, Any?>) {
        draft.remove("swipeLabel")
        // MacroKey 的旧字段也要清掉：编辑器保存的是原始 JSON 映射，不清的话会和新的方向标签
        // 并存，下次解析时旧值虽被忽略，用户却会看到一份自相矛盾的布局文件。
        draft.remove("altLabel")
        draft.remove("swipeUpLabel")
        draft.remove("swipeDownLabel")
        nonMacroSwipeUpLabelEdit?.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
            ?.let { draft["swipeUpLabel"] = it }
        nonMacroSwipeDownLabelEdit?.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }
            ?.let { draft["swipeDownLabel"] = it }
    }

    private fun renderColorEditors() {
        val theme = ThemeManager.activeTheme
        // 空白占位键的配色由「自定义颜色」开关统一管辖：关着的时候这个键连底都不画，
        // 摆出一排可点的颜色项只会让人以为"改了没生效"。
        val colorEditorEnabled = (!composeOverrideEditorMode || independentColor) &&
            (selectedType != "PlaceholderKey" || placeholderCustomColor)
        availableColorFields().forEach { field ->
            val title = getString(field.labelRes)
            val colorSource = if (colorEditorEnabled) keyColorOverrides else inheritedBaseKeyColorData
            val customColor = parseColorInt(colorSource[field.customKey])
            val colorRef = colorSource[field.monetKey] as? String
            val modeText = when {
                colorRef != null -> formatColorReferenceName(colorRef)
                customColor != null -> formatAndroidColorCode(customColor)
                else -> getString(R.string.text_keyboard_layout_key_color_mode_theme)
            }
            val resolvedColor = resolveColorReference(theme, colorRef) ?: customColor ?: field.themeColorGetter(theme)

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(8), 0, dp(8))
                minimumHeight = dp(56)
                val rippleShape = com.google.android.material.shape.ShapeAppearanceModel.builder()
                    .setAllCornerSizes(dp(12).toFloat()).build()
                background = android.graphics.drawable.RippleDrawable(
                    android.content.res.ColorStateList.valueOf(settingsColor(androidx.appcompat.R.attr.colorControlHighlight)),
                    null, com.google.android.material.shape.MaterialShapeDrawable(rippleShape).apply {
                        fillColor = android.content.res.ColorStateList.valueOf(android.graphics.Color.WHITE)
                    })
                if (colorEditorEnabled) {
                    setOnClickListener { showColorFieldOptions(field) }
                    isClickable = true
                    isFocusable = true
                } else {
                    isClickable = false
                    isFocusable = false
                    alpha = 0.55f
                }

                addView(
                    TextView(this@KeyEditorForm).apply {
                        text = title
                        textSize = 13f
                        setTextColor(settingsColor(android.R.attr.textColorSecondary))
                    },
                    LinearLayout.LayoutParams(dp(96), LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        rightMargin = dp(8)
                    }
                )

                addView(
                    LinearLayout(this@KeyEditorForm).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.END or Gravity.CENTER_VERTICAL

                        addView(
                            TextView(this@KeyEditorForm).apply {
                                text = modeText
                                textSize = 13f
                                setTextColor(settingsColor(android.R.attr.textColorPrimary))
                            },
                            LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                            ).apply {
                                rightMargin = dp(8)
                            }
                        )

                        addView(
                            View(this@KeyEditorForm).apply {
                                background = android.graphics.drawable.GradientDrawable().apply {
                                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                                    cornerRadius = dp(8).toFloat()
                                    setColor(resolvedColor)
                                }
                            },
                            LinearLayout.LayoutParams(dp(28), dp(28))
                        )
                    },
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                        weight = 1f
                    }
                )
            }

            fieldsContainer.addView(
                row,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
        }
    }

    private fun showColorFieldOptions(field: EditableColorField) {
        if (composeOverrideEditorMode && !independentColor) return
        if (selectedType == "PlaceholderKey" && !placeholderCustomColor) return
        val supportsMonet = ThemeMonet.supportsCustomMappingEditor(this)
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()

        options += getString(R.string.text_keyboard_layout_key_color_mode_theme)
        actions += {
            persistCurrentDraft()
            setColorOverride(field, null, null)
            rebuildFields()
            updateActionButtonState()
        }

        options += getString(R.string.text_keyboard_layout_key_color_mode_custom)
        actions += { openCustomColorEditor(field) }

        options += getString(R.string.text_keyboard_layout_key_color_mode_theme_key_pick)
        actions += { openThemeColorTokenPicker(field) }

        if (supportsMonet) {
            options += getString(R.string.text_keyboard_layout_key_color_mode_monet_pick)
            actions += { openMonetColorPicker(field) }
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(field.labelRes)
            .setItems(options.toTypedArray()) { _, which ->
                actions.getOrNull(which)?.invoke()
            }
            .show()
    }

    private fun openThemeColorTokenPicker(field: EditableColorField) {
        val availableTokens = availableThemeTokensForField(field)
        if (availableTokens.isEmpty()) return

        val theme = ThemeManager.activeTheme
        val currentToken = (keyColorOverrides[field.monetKey] as? String)
            ?.takeIf { it.startsWith(THEME_COLOR_REF_PREFIX) }
            ?.removePrefix(THEME_COLOR_REF_PREFIX)
        val checkedIndex = availableTokens.indexOfFirst { it.token == currentToken }

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.text_keyboard_layout_key_color_mode_theme_key_pick)
            .setSingleChoiceItems(
                ThemeColorTokenPreviewAdapter(this, availableTokens, theme),
                checkedIndex
            ) { dialog, which ->
                val token = availableTokens.getOrNull(which)?.token ?: return@setSingleChoiceItems
                persistCurrentDraft()
                setColorOverride(field, null, "$THEME_COLOR_REF_PREFIX$token")
                dialog.dismiss()
                rebuildFields()
                updateActionButtonState()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun openCustomColorEditor(field: EditableColorField) {
        persistCurrentDraft()
        val theme = ThemeManager.activeTheme
        val current = parseColorInt(keyColorOverrides[field.customKey])
            ?: resolveColorReference(theme, keyColorOverrides[field.monetKey] as? String)
            ?: resolveColorReference(theme, inheritedBaseKeyColorData[field.monetKey] as? String)
            ?: parseColorInt(inheritedBaseKeyColorData[field.customKey])
            ?: field.themeColorGetter(theme)
        if (DeviceUtil.isHMOS) {
            launchColor(
                ThemeColorEditorActivity.EditorInput(
                    fieldName = field.customKey,
                    titleRes = field.labelRes,
                    initialColor = current
                )
            )
            return
        }
        launchColor(
            ThemeColorEditorActivity.EditorInput(
                fieldName = field.customKey,
                titleRes = field.labelRes,
                initialColor = current
            )
        )
    }

    private fun openMonetColorPicker(field: EditableColorField) {
        if (!ThemeMonet.supportsCustomMappingEditor(this)) {
            Toast.makeText(this, R.string.text_keyboard_layout_key_color_monet_unavailable, Toast.LENGTH_SHORT).show()
            return
        }
        val available = SystemColorResourceId.getAvailableForSdk(Build.VERSION.SDK_INT)
        val current = (keyColorOverrides[field.monetKey] as? String)
            ?.takeUnless { it.startsWith(THEME_COLOR_REF_PREFIX) }
            ?.let(SystemColorResourceId::fromResourceName)
            ?: available.firstOrNull()
            ?: return
        SystemColorResourcePickerDialog.show(
            this,
            current,
            listener = object : SystemColorResourcePickerDialog.OnColorResourceSelectedListener {
                override fun onColorResourceSelected(resourceId: SystemColorResourceId?) {
                    resourceId ?: return
                    persistCurrentDraft()
                    setColorOverride(field, null, resourceId.resourceId)
                    rebuildFields()
                    updateActionButtonState()
                }
            }
        )
    }

    private fun resolveMonetColor(resourceName: String?): Int? {
        val name = resourceName?.takeIf { it.isNotBlank() } ?: return null
        val colorResId = resources.getIdentifier(name, "color", "android")
        if (colorResId == 0) return null
        return runCatching { getColor(colorResId) }.getOrNull()
    }

    private fun resolveThemeTokenColor(theme: org.fcitx.fcitx5.android.data.theme.Theme, token: String?): Int? {
        val value = token?.takeIf { it.isNotBlank() } ?: return null
        return themeColorTokens.firstOrNull { it.token == value }?.resolver?.invoke(theme)
    }

    private fun resolveColorReference(theme: org.fcitx.fcitx5.android.data.theme.Theme, ref: String?): Int? {
        val value = ref?.takeIf { it.isNotBlank() } ?: return null
        return if (value.startsWith(THEME_COLOR_REF_PREFIX)) {
            resolveThemeTokenColor(theme, value.removePrefix(THEME_COLOR_REF_PREFIX))
        } else {
            resolveMonetColor(value)
        }
    }

    private fun formatColorReferenceName(ref: String): String {
        return if (ref.startsWith(THEME_COLOR_REF_PREFIX)) {
            val token = ref.removePrefix(THEME_COLOR_REF_PREFIX)
            getString(R.string.text_keyboard_layout_key_color_mode_theme_ref, formatThemeColorTokenName(token))
        } else {
            formatMonetResourceName(ref)
        }
    }

    private fun availableThemeTokensForField(field: EditableColorField): List<ThemeColorToken> {
        return themeColorTokens
    }

    private fun formatThemeColorTokenName(token: String): String {
        return themeColorTokens.firstOrNull { it.token == token }?.displayName
            ?: token.replace(Regex("([a-z])([A-Z])"), "$1 $2")
    }

    private class ThemeColorTokenPreviewAdapter(
        private val context: android.content.Context,
        private val tokens: List<ThemeColorToken>,
        private val theme: org.fcitx.fcitx5.android.data.theme.Theme
    ) : BaseAdapter() {
        override fun getCount(): Int = tokens.size
        override fun getItem(position: Int): Any = tokens[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(context.dp(12), context.dp(10), context.dp(12), context.dp(10))
                val colorPreview = View(context).apply {
                    layoutParams = LinearLayout.LayoutParams(context.dp(20), context.dp(20))
                }
                val nameText = TextView(context).apply {
                    setTextColor(context.settingsColor(android.R.attr.textColorPrimary))
                    textSize = 14f
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply {
                        marginStart = context.dp(12)
                    }
                }
                addView(colorPreview)
                addView(nameText)
                tag = ThemeColorTokenRowHolder(colorPreview, nameText)
            }
            val holder = row.tag as ThemeColorTokenRowHolder
            val token = tokens[position]
            holder.colorPreview.background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = context.dp(4).toFloat()
                setColor(token.resolver(theme))
            }
            holder.nameText.text = token.displayName
            return row
        }
    }

    private data class ThemeColorTokenRowHolder(
        val colorPreview: View,
        val nameText: TextView
    )

    private fun formatMonetResourceName(resourceName: String): String {
        return resourceName.removePrefix("system_").replace("_", " ")
    }

    private fun formatAndroidColorCode(color: Int): String {
        return String.format("#%08X", color)
    }

    private fun parseColorInt(value: Any?): Int? {
        return when (value) {
            is Int -> value
            is Number -> value.toInt()
            is String -> {
                val raw = value.trim()
                when {
                    raw.startsWith("#") -> raw.removePrefix("#").toLongOrNull(16)?.toInt()
                    raw.startsWith("0x", ignoreCase = true) -> raw.removePrefix("0x").toLongOrNull(16)?.toInt()
                    else -> raw.toLongOrNull()?.toInt()
                }
            }
            else -> null
        }
    }

    private fun attachFieldWatchers(root: android.view.View) {
        when (root) {
            is EditText -> {
                root.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        updateActionButtonState()
                    }
                    override fun afterTextChanged(s: Editable?) {}
                })
            }
            is android.view.ViewGroup -> {
                for (i in 0 until root.childCount) {
                    attachFieldWatchers(root.getChildAt(i))
                }
            }
        }
    }

    private fun updateActionButtonState() {
        if (building) return
        val snapshot = snapshotOf(buildDraftKeyData())
        if (snapshot != lastPublishedSnapshot) {
            lastPublishedSnapshot = snapshot
            onChange()
        }
    }

    fun hasChanges(): Boolean {
        return snapshotOf(buildDraftKeyData()) != baselineKeySnapshot
    }

    private fun buildDraftKeyData(): MutableMap<String, Any?> {
        val draft = mutableMapOf<String, Any?>()
        draft["type"] = selectedType

        when (selectedType) {
            "AlphabetKey" -> {
                val main = alphabetMainEdit?.text?.toString().orEmpty()
                val alt = alphabetAltEdit?.text?.toString().orEmpty()
                if (main.isNotEmpty()) draft["main"] = main
                if (alt.isNotEmpty()) draft["alt"] = alt
                if (!disableWeightEditing) {
                    parseWeight(alphabetWeightEdit?.text?.toString())?.let { draft["weight"] = it }
                }

                if (alphabetDisplayTextModeSpecific) {
                    val displayTextMap = mutableMapOf<String, String>()
                    alphabetDisplayTextRowBindings.forEach { binding ->
                        val modeName = binding.modeEdit.text?.toString()?.trim().orEmpty()
                        val modeValue = binding.valueEdit.text?.toString()?.trim().orEmpty()
                        // 空值不算设置；显式填写的取值一律保留，**哪怕与主字符相同**——
                        // 那正是「键面恒定显示该大小写」的诉求（见 AlphabetKey 的说明）。
                        if (modeName.isNotEmpty() && modeValue.isNotEmpty()) {
                            displayTextMap[modeName] = modeValue
                        }
                    }
                    if (displayTextMap.isNotEmpty()) {
                        draft["displayText"] = displayTextMap
                    }
                } else {
                    val displayText = alphabetDisplayTextSimpleEdit?.text?.toString()?.trim()
                        ?: alphabetDisplayTextSimpleValue.trim()
                    if (displayText.isNotEmpty()) {
                        draft["displayText"] = displayText
                    }
                }
            }

            "LayoutSwitchKey" -> {
                val label = layoutSwitchLabelEdit?.text?.toString()?.ifEmpty { "?123" }.orEmpty()
                if (label.isNotEmpty()) draft["label"] = label
                val target = (layoutSwitchTargetSpinner?.selectedItem as? KeyboardEditorUiBuilder.SwitchTargetOption)
                    ?.value
                    .orEmpty()
                if (!target.isNullOrEmpty()) draft["subLabel"] = target
                appendDirectionalSwipeLabels(draft)
                if (!disableWeightEditing) {
                    parseWeight(layoutSwitchWeightEdit?.text?.toString())?.let { draft["weight"] = it }
                }
                applyDirectionalSwipeDraft(draft, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
            }

            "SymbolKey" -> {
                val label = symbolLabelEdit?.text?.toString()?.ifEmpty { "." }.orEmpty()
                if (label.isNotEmpty()) draft["label"] = label
                appendDirectionalSwipeLabels(draft)
                if (!disableWeightEditing) {
                    parseWeight(symbolWeightEdit?.text?.toString())?.let { draft["weight"] = it }
                }
                applyDirectionalSwipeDraft(draft, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
            }

            "MacroKey" -> {
                val baseLabel = macroLabelEdit?.text?.toString().orEmpty()
                if (baseLabel.isNotEmpty()) draft["label"] = baseLabel
                appendDirectionalSwipeLabels(draft)
                val longPressLabel = macroLongPressLabelEdit?.text?.toString().orEmpty()
                if (longPressLabel.isNotEmpty()) draft["longPressLabel"] = longPressLabel
                if (!disableWeightEditing) {
                    parseWeight(macroWeightEdit?.text?.toString())?.let { draft["weight"] = it }
                }

                if (macroDisplayTextModeSpecific) {
                    val displayTextMap = mutableMapOf<String, String>()
                    macroDisplayTextRowBindings.forEach { binding ->
                        val modeName = binding.modeEdit.text?.toString()?.trim().orEmpty()
                        val modeValue = binding.valueEdit.text?.toString()?.trim().orEmpty()
                        if (modeName.isNotEmpty() && modeValue.isNotEmpty()) {
                            displayTextMap[modeName] = modeValue
                        }
                    }
                    if (displayTextMap.isNotEmpty()) {
                        draft["displayText"] = displayTextMap
                    }
                } else {
                    val displayText = macroDisplayTextSimpleEdit?.text?.toString()?.trim()
                        ?: macroDisplayTextSimpleValue.trim()
                    if (displayText.isNotEmpty()) {
                        draft["displayText"] = displayText
                    }
                }

                if (macroTapStepsData.isNotEmpty()) {
                    draft["tap"] = mapOf("macro" to macroTapStepsData)
                }

                applyDirectionalSwipeDraft(draft, macroSwipeUpStepsData, macroSwipeDownStepsData)

                if (macroLongPressStepsData.isNotEmpty()) {
                    draft["longPress"] = mapOf("macro" to macroLongPressStepsData)
                }
            }

            "CapsKey", "ReturnKey", "BackspaceKey" -> {
                appendDirectionalSwipeLabels(draft)
                if (!disableWeightEditing) {
                    parseWeight(simpleWeightEdit?.text?.toString())?.let { draft["weight"] = it }
                }
                applyDirectionalSwipeDraft(draft, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
            }

            "CommaKey", "LanguageKey" -> {
                if (!disableWeightEditing) {
                    parseWeight(simpleWeightEdit?.text?.toString())?.let { draft["weight"] = it }
                }
            }

            "SpaceKey" -> {
                if (!disableWeightEditing) {
                    parseWeight(simpleWeightEdit?.text?.toString())?.let { draft["weight"] = it }
                }
                val swipeLabel = nonMacroSwipeLabelEdit?.text?.toString()?.trim().orEmpty()
                if (swipeLabel.isNotEmpty()) draft["swipeLabel"] = swipeLabel
                if (nonMacroSwipeStepsData.isNotEmpty()) {
                    draft["swipe"] = mapOf("macro" to nonMacroSwipeStepsData)
                }
            }

            "NumPadKey" -> {
                val label = numPadLabelEdit?.text?.toString()?.ifEmpty { "0" }.orEmpty()
                if (label.isNotEmpty()) draft["label"] = label
                (numPadSymSpinner?.selectedItem as? KeyboardEditorUiBuilder.NumPadOption)
                    ?.sym
                    ?.let { draft["sym"] = it }
                if (!disableWeightEditing) {
                    parseWeight(simpleWeightEdit?.text?.toString())?.let { draft["weight"] = it }
                }
            }

            "MiniSpaceKey" -> {
                if (!disableWeightEditing) {
                    parseWeight(simpleWeightEdit?.text?.toString())?.let { draft["weight"] = it }
                }
            }

            "PlaceholderKey" -> {
                // 空串不写字段：留空是"这个键上什么都不显示"的合法形态，不是缺省值。
                placeholderMainEdit?.text?.toString()?.takeIf { it.isNotEmpty() }
                    ?.let { draft["main"] = it }
                placeholderAltEdit?.text?.toString()?.takeIf { it.isNotEmpty() }
                    ?.let { draft["alt"] = it }
                if (!disableWeightEditing) {
                    parseWeight(placeholderWeightEdit?.text?.toString())?.let { draft["weight"] = it }
                }
                // 写 false 而不是"省略"：省略会让运行时按类型默认值（透明）处理，
                // 与用户刚打开的自定义颜色相反。见 KeyJson.transparent 的说明。
                if (placeholderCustomColor) draft["transparent"] = false
            }
        }
        if (!composeOverrideEditorMode) {
            // Row height stays in row settings; the split boundary can also be edited on this key.
            keyData["rowHeightPercent"]?.let { draft["rowHeightPercent"] = it }
            if (splitAfterCheckBox?.isChecked == true) draft["splitAfter"] = true
        }
        composeOverrideData?.let { draft["composeOverride"] = toSerializableMap(it) }
        if (composeOverrideEditorMode) {
            draft["independentColor"] = independentColor
        }

        appendColorOverrides(draft)

        return draft
    }

    private fun snapshotOf(value: Any?): String {
        val normalized = normalizeForSnapshot(value)
        // Saved state only needs the baseline fingerprint, never another copy of a large macro.
        return java.security.MessageDigest.getInstance("SHA-256")
            .digest(normalized.toString().toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private fun normalizeForSnapshot(value: Any?): Any? {
        return when (value) {
            is Map<*, *> -> {
                val keys = value.keys.mapNotNull { it?.toString() }.sorted()
                keys.joinToString(prefix = "{", postfix = "}") { key ->
                    "$key=${normalizeForSnapshot(value[key])}"
                }
            }
            is List<*> -> value.map { normalizeForSnapshot(it) }
            is Float -> String.format(java.util.Locale.US, "%.6f", value)
            is Double -> String.format(java.util.Locale.US, "%.6f", value)
            is Array<*> -> Arrays.toString(value)
            else -> value
        }
    }

    private fun createMacroEditorButton(
        title: String,
        previewText: String,
        onClick: () -> Unit
    ): List<View> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(48)
            tag = 1
            addView(TextView(this@KeyEditorForm).apply {
                text = title
                textSize = 13f
            }, LinearLayout.LayoutParams(dp(88), wrapContent))
            addView(TextView(this@KeyEditorForm).apply {
                text = previewText
                textSize = 13f
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(settingsColor(android.R.attr.textColorSecondary))
                setPadding(dp(8), dp(4), dp(8), dp(4))
            }, LinearLayout.LayoutParams(0, wrapContent, 1f))
            addView(EditorUi.button(
                this@KeyEditorForm, R.string.edit, action = onClick).apply {
                    contentDescription = "$title · ${getString(R.string.edit)}"
                    minWidth = dp(56)
                    minimumWidth = dp(56)
                }, LinearLayout.LayoutParams(wrapContent, wrapContent))
        }
        return listOf(row)
    }

    private fun openMacroEditor(
        initialSteps: List<*>,
        eventType: String,
        slot: String,
        callback: (List<Any>) -> Unit
    ) {
        persistCurrentDraft()
        pendingMacroEventType = slot
        val intent = Intent()
        // Echoed back in the result so a recreated host can still apply the edit.
        intent.putExtra(MacroEditorDialogFragment.EXTRA_TARGET_TOKEN, slot)
        if (initialSteps.isNotEmpty()) {
            val serializableSteps = ArrayList<Map<*, *>>()
            initialSteps.forEach { step ->
                (step as? Map<*, *>)?.let { serializableSteps.add(it) }
            }
            if (serializableSteps.isNotEmpty()) {
                intent.putExtra(MacroEditorDialogFragment.EXTRA_MACRO_STEPS, serializableSteps)
            }
        }
        intent.putExtra(MacroEditorDialogFragment.EXTRA_EVENT_TYPE, eventType)
        intent.putStringArrayListExtra(
            MacroEditorDialogFragment.EXTRA_LAYOUT_TARGETS,
            ArrayList(availableLayoutTargets)
        )
        macroEditCallback = callback
        launchMacro(intent)
    }

    /**
     * Write macro [steps] into the given key slot without going through the dialog callback,
     * for results that arrive after the host was recreated.
     */
    private fun applyMacroStepsToSlot(slot: String, steps: List<Any>) {
        val draft = buildDraftKeyData()
        val isMacroKey = keyData["type"] == "MacroKey"
        when (slot) {
            SLOT_TAP -> {
                macroTapStepsData = steps
                draft["tap"] = mapOf("macro" to steps)
            }
            SLOT_SWIPE_UP -> {
                if (isMacroKey) {
                    macroSwipeUpStepsData = steps
                    applyDirectionalSwipeDraft(
                        draft,
                        macroSwipeUpStepsData,
                        macroSwipeDownStepsData
                    )
                } else {
                    nonMacroSwipeUpStepsData = steps
                    appendDirectionalSwipeLabels(draft)
                    applyDirectionalSwipeDraft(
                        draft,
                        nonMacroSwipeUpStepsData,
                        nonMacroSwipeDownStepsData
                    )
                }
            }
            SLOT_SWIPE_DOWN -> {
                if (isMacroKey) {
                    macroSwipeDownStepsData = steps
                    applyDirectionalSwipeDraft(
                        draft,
                        macroSwipeUpStepsData,
                        macroSwipeDownStepsData
                    )
                } else {
                    nonMacroSwipeDownStepsData = steps
                    appendDirectionalSwipeLabels(draft)
                    applyDirectionalSwipeDraft(
                        draft,
                        nonMacroSwipeUpStepsData,
                        nonMacroSwipeDownStepsData
                    )
                }
            }
            SLOT_SWIPE -> {
                nonMacroSwipeStepsData = steps
                if (steps.isNotEmpty()) draft["swipe"] = mapOf("macro" to steps) else draft.remove("swipe")
            }
            SLOT_LONG_PRESS -> {
                macroLongPressStepsData = steps
                draft["longPress"] = mapOf("macro" to steps)
            }
            else -> return
        }
        keyData = draft
        rebuildFields()
        updateActionButtonState()
    }

    private fun buildMacroPreview(macroSteps: List<*>?): String {
        if (macroSteps == null || macroSteps.isEmpty()) {
            return getString(R.string.text_keyboard_layout_macro_no_event)
        }

        val stepTexts = macroSteps.mapNotNull { step ->
            val stepMap = step as? Map<*, *>
            val type = stepMap?.get("type") as? String ?: return@mapNotNull null
            when (type) {
                "tap", "down", "up" -> {
                    val keys = stepMap["keys"] as? List<*>
                    val keysStr = keys?.mapNotNull { key ->
                        (key as? Map<*, *>)?.let {
                            it["fcitx"] as? String ?: it["android"] as? String
                        }
                    }?.joinToString(", ")
                    if (keysStr.isNullOrBlank()) null else "$type:[$keysStr]"
                }
                "edit" -> {
                    val action = stepMap["action"] as? String ?: return@mapNotNull null
                    "$type:$action"
                }
                "app" -> {
                    val id = stepMap["id"] as? String ?: return@mapNotNull null
                    "$type:$id"
                }
                "shortcut" -> {
                    val modifiers = (stepMap["modifiers"] as? List<*>)?.mapNotNull {
                        (it as? Map<*, *>)?.let { m ->
                            m["fcitx"] as? String ?: m["android"] as? String
                        }
                    } ?: emptyList()
                    val key = (stepMap["key"] as? Map<*, *>)?.let {
                        it["fcitx"] as? String ?: it["android"] as? String
                    } ?: return@mapNotNull null
                    "$type:${modifiers.joinToString("+")}+$key"
                }
                "text" -> {
                    val text = stepMap["text"] as? String ?: return@mapNotNull null
                    val displayText = if (text.length > 10) "${text.take(10)}..." else text
                    "$type:\"$displayText\""
                }
                "layer" -> {
                    val target = stepMap["target"] as? String ?: ""
                    val mode = (stepMap["mode"] as? String)?.uppercase() ?: "TO"
                    if (target.isBlank()) "layer($mode)" else "layer($mode):$target"
                }
                else -> type
            }
        }

        return if (stepTexts.size <= 3) {
            stepTexts.joinToString(" -> ")
        } else {
            getString(R.string.text_keyboard_layout_macro_event_preview, stepTexts.take(2).joinToString(" -> "), stepTexts.size)
        }
    }

    fun validatedDraft(showErrors: Boolean = true): MutableMap<String, Any?>? {
        showValidationErrors = showErrors
        return validateAndSave(
            selectedType,
            alphabetMainEdit,
            alphabetAltEdit,
            alphabetWeightEdit,
            alphabetDisplayTextModeSpecific,
            alphabetDisplayTextSimpleEdit,
            alphabetDisplayTextSimpleValue,
            alphabetDisplayTextModeItems,
            alphabetDisplayTextRowBindings,
            layoutSwitchLabelEdit,
            layoutSwitchTargetSpinner,
            layoutSwitchWeightEdit,
            symbolLabelEdit,
            symbolWeightEdit,
            macroLabelEdit,
            macroDisplayTextModeSpecific,
            macroDisplayTextSimpleEdit,
            macroDisplayTextSimpleValue,
            macroDisplayTextModeItems,
            macroDisplayTextRowBindings,
            macroLongPressLabelEdit,
            macroWeightEdit,
            simpleWeightEdit
        )
    }

    fun resultIntent(action: String, key: Map<String, Any?>? = null) = Intent().apply {
        putExtra(EXTRA_RESULT_ACTION, action)
        key?.let { putExtra(EXTRA_RESULT_KEY_DATA, toSerializableMap(it)) }
        putExtra(EXTRA_ROW_INDEX, rowIndex)
        keyIndex?.let { putExtra(EXTRA_KEY_INDEX, it) }
    }

    private fun initDisplayText(
        keyData: Map<String, Any?>,
        isEditingSubModeLayout: Boolean,
        currentSubModeLabel: String?,
        labelTextKey: String = "displayText",
        callback: (Boolean, String, MutableList<KeyboardEditorUiBuilder.DisplayTextItem>) -> Unit
    ) {
        val displayTextData = keyData[labelTextKey]
        val displayTextMap = when (displayTextData) {
            is JsonObject -> displayTextData.mapValues { entry ->
                LayoutJsonUtils.toAny(entry.value)
            }
            is Map<*, *> -> displayTextData
            else -> null
        }

        if (displayTextMap != null && displayTextMap.isNotEmpty()) {
            if (isEditingSubModeLayout && currentSubModeLabel != null) {
                val specificValue = displayTextMap[currentSubModeLabel]?.toString()
                val defaultValue = displayTextMap["default"]?.toString()
                    ?: displayTextMap[""]?.toString()
                callback(false, specificValue ?: defaultValue ?: "", mutableListOf())
            } else {
                val items = mutableListOf<KeyboardEditorUiBuilder.DisplayTextItem>()
                displayTextMap.forEach { (k, v) ->
                    items.add(KeyboardEditorUiBuilder.DisplayTextItem(k?.toString().orEmpty(), v?.toString().orEmpty()))
                }
                callback(true, "", items)
            }
        } else {
            val labelTextSimple = keyData[labelTextKey] as? String
            if (!labelTextSimple.isNullOrBlank()) {
                callback(false, labelTextSimple, mutableListOf())
            } else {
                callback(false, "", mutableListOf())
            }
        }
    }

    private fun validateAndSave(
        selectedType: String,
        alphabetMainEdit: EditText?,
        alphabetAltEdit: EditText?,
        alphabetWeightEdit: EditText?,
        alphabetDisplayTextModeSpecific: Boolean,
        alphabetDisplayTextSimpleEdit: EditText?,
        alphabetDisplayTextSimpleValue: String,
        alphabetDisplayTextModeItems: List<KeyboardEditorUiBuilder.DisplayTextItem>,
        alphabetDisplayTextRowBindings: List<KeyboardEditorUiBuilder.DisplayTextRowBinding>,
        layoutSwitchLabelEdit: EditText?,
        layoutSwitchTargetSpinner: Spinner?,
        layoutSwitchWeightEdit: EditText?,
        symbolLabelEdit: EditText?,
        symbolWeightEdit: EditText?,
        macroLabelEdit: EditText?,
        macroDisplayTextModeSpecific: Boolean,
        macroDisplayTextSimpleEdit: EditText?,
        macroDisplayTextSimpleValue: String,
        macroDisplayTextModeItems: List<KeyboardEditorUiBuilder.DisplayTextItem>,
        macroDisplayTextRowBindings: List<KeyboardEditorUiBuilder.DisplayTextRowBinding>,
        macroLongPressLabelEdit: EditText?,
        macroWeightEdit: EditText?,
        simpleWeightEdit: EditText?
    ): MutableMap<String, Any?>? {
        if (selectedType == "AlphabetKey") {
            val main = alphabetMainEdit?.text?.toString()?.trim().orEmpty()
            val alt = alphabetAltEdit?.text?.toString()?.trim().orEmpty()

            if (main.isEmpty()) {
                if (showValidationErrors) Toast.makeText(this, R.string.text_keyboard_layout_alphabet_key_main_required, Toast.LENGTH_SHORT).show()
                return null
            }
            if (alt.isEmpty()) {
                if (showValidationErrors) Toast.makeText(this, R.string.text_keyboard_layout_alphabet_key_alt_required, Toast.LENGTH_SHORT).show()
                return null
            }
            if (main.length != 1) {
                if (showValidationErrors) Toast.makeText(this, getString(R.string.text_keyboard_layout_alphabet_key_main_length_invalid), Toast.LENGTH_SHORT).show()
                return null
            }
            if (alt.length != 1) {
                if (showValidationErrors) Toast.makeText(this, getString(R.string.text_keyboard_layout_alphabet_key_alt_length_invalid), Toast.LENGTH_SHORT).show()
                return null
            }
        }

        if (selectedType == "MacroKey") {
            val label = macroLabelEdit?.text?.toString()?.trim().orEmpty()
            if (label.isEmpty()) {
                if (showValidationErrors) Toast.makeText(this, R.string.text_keyboard_layout_macro_key_label_required, Toast.LENGTH_SHORT).show()
                return null
            }
            val longPressLabel = macroLongPressLabelEdit?.text?.toString()?.trim().orEmpty()
            if (macroLongPressStepsData.isNotEmpty() && longPressLabel.isEmpty()) {
                if (showValidationErrors) Toast.makeText(this, R.string.text_keyboard_layout_longpress_label_fallback_notice, Toast.LENGTH_SHORT).show()
            }
        }

        val widthFields = listOf(alphabetWeightEdit, layoutSwitchWeightEdit, symbolWeightEdit,
            macroWeightEdit, simpleWeightEdit, placeholderWeightEdit)
        val invalidWidth = widthFields.filterNotNull().firstOrNull {
            it.text.isNotBlank() && parseWeight(it.text.toString()) == null
        }
        if (invalidWidth != null) {
            if (showValidationErrors) {
                invalidWidth.error = getString(R.string.layout_editor_width_invalid)
                invalidWidth.requestFocus()
            }
            return null
        }

        val newKey = mutableMapOf<String, Any?>()
        newKey["type"] = selectedType

        when (selectedType) {
            "AlphabetKey" -> {
                val main = alphabetMainEdit?.text?.toString().orEmpty()
                newKey["main"] = main
                newKey["alt"] = alphabetAltEdit?.text?.toString().orEmpty()
                if (!disableWeightEditing) {
                    parseWeight(alphabetWeightEdit?.text?.toString())?.let { newKey["weight"] = it }
                }

                if (alphabetDisplayTextModeSpecific) {
                    val displayTextMap = mutableMapOf<String, String>()
                    alphabetDisplayTextRowBindings.forEach { binding ->
                        val modeName = binding.modeEdit.text?.toString()?.trim().orEmpty()
                        val modeValue = binding.valueEdit.text?.toString()?.trim().orEmpty()
                        // 空值不算设置；显式填写的取值一律保留，**哪怕与主字符相同**——
                        // 那正是「键面恒定显示该大小写」的诉求（见 AlphabetKey 的说明）。
                        if (modeName.isNotEmpty() && modeValue.isNotEmpty()) {
                            displayTextMap[modeName] = modeValue
                        }
                    }
                    if (displayTextMap.isNotEmpty()) {
                        newKey["displayText"] = displayTextMap
                    }
                } else {
                    val displayText = alphabetDisplayTextSimpleEdit?.text?.toString()?.trim()
                        ?: alphabetDisplayTextSimpleValue.trim()
                    if (displayText.isNotEmpty()) {
                        newKey["displayText"] = displayText
                    }
                }
            }

            "LayoutSwitchKey" -> {
                newKey["label"] = layoutSwitchLabelEdit?.text?.toString()?.ifEmpty { "?123" }.orEmpty()
                val target = (layoutSwitchTargetSpinner?.selectedItem as? KeyboardEditorUiBuilder.SwitchTargetOption)
                    ?.value
                    .orEmpty()
                if (!target.isNullOrEmpty()) newKey["subLabel"] = target
                appendDirectionalSwipeLabels(newKey)
                if (!disableWeightEditing) {
                    parseWeight(layoutSwitchWeightEdit?.text?.toString())?.let { newKey["weight"] = it }
                }
                applyDirectionalSwipeDraft(newKey, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
            }

            "SymbolKey" -> {
                newKey["label"] = symbolLabelEdit?.text?.toString()?.ifEmpty { "." }.orEmpty()
                appendDirectionalSwipeLabels(newKey)
                if (!disableWeightEditing) {
                    parseWeight(symbolWeightEdit?.text?.toString())?.let { newKey["weight"] = it }
                }
                applyDirectionalSwipeDraft(newKey, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
            }

            "MacroKey" -> {
                val baseLabel = macroLabelEdit?.text?.toString().orEmpty()
                newKey["label"] = baseLabel
                appendDirectionalSwipeLabels(newKey)
                val longPressLabel = macroLongPressLabelEdit?.text?.toString().orEmpty()
                if (longPressLabel.isNotEmpty()) newKey["longPressLabel"] = longPressLabel
                if (!disableWeightEditing) {
                    parseWeight(macroWeightEdit?.text?.toString())?.let { newKey["weight"] = it }
                }

                if (macroDisplayTextModeSpecific) {
                    val displayTextMap = mutableMapOf<String, String>()
                    macroDisplayTextRowBindings.forEach { binding ->
                        val modeName = binding.modeEdit.text?.toString()?.trim().orEmpty()
                        val modeValue = binding.valueEdit.text?.toString()?.trim().orEmpty()
                        if (modeName.isNotEmpty() && modeValue.isNotEmpty()) {
                            displayTextMap[modeName] = modeValue
                        }
                    }
                    if (displayTextMap.isNotEmpty()) {
                        newKey["displayText"] = displayTextMap
                    }
                } else {
                    val displayText = macroDisplayTextSimpleEdit?.text?.toString()?.trim()
                        ?: macroDisplayTextSimpleValue.trim()
                    if (displayText.isNotEmpty()) {
                        newKey["displayText"] = displayText
                    }
                }

                if (macroTapStepsData.isNotEmpty()) {
                    newKey["tap"] = mapOf("macro" to macroTapStepsData)
                } else {
                    newKey["tap"] = mapOf(
                        "macro" to listOf(
                            mapOf("type" to "text", "text" to "")
                        )
                    )
                }

                applyDirectionalSwipeDraft(newKey, macroSwipeUpStepsData, macroSwipeDownStepsData)

                if (macroLongPressStepsData.isNotEmpty()) {
                    newKey["longPress"] = mapOf("macro" to macroLongPressStepsData)
                }
            }

            "CapsKey", "ReturnKey", "BackspaceKey" -> {
                appendDirectionalSwipeLabels(newKey)
                if (!disableWeightEditing) {
                    parseWeight(simpleWeightEdit?.text?.toString())?.let { newKey["weight"] = it }
                }
                applyDirectionalSwipeDraft(newKey, nonMacroSwipeUpStepsData, nonMacroSwipeDownStepsData)
            }

            "CommaKey", "LanguageKey" -> {
                if (!disableWeightEditing) {
                    parseWeight(simpleWeightEdit?.text?.toString())?.let { newKey["weight"] = it }
                }
            }

            "SpaceKey" -> {
                if (!disableWeightEditing) {
                    parseWeight(simpleWeightEdit?.text?.toString())?.let { newKey["weight"] = it }
                }
                val swipeLabel = nonMacroSwipeLabelEdit?.text?.toString()?.trim().orEmpty()
                if (swipeLabel.isNotEmpty()) newKey["swipeLabel"] = swipeLabel
                if (nonMacroSwipeStepsData.isNotEmpty()) {
                    newKey["swipe"] = mapOf("macro" to nonMacroSwipeStepsData)
                }
            }

            "NumPadKey" -> {
                newKey["label"] = numPadLabelEdit?.text?.toString()?.ifEmpty { "0" }.orEmpty()
                (numPadSymSpinner?.selectedItem as? KeyboardEditorUiBuilder.NumPadOption)
                    ?.sym
                    ?.let { newKey["sym"] = it }
                if (!disableWeightEditing) {
                    parseWeight(simpleWeightEdit?.text?.toString())?.let { newKey["weight"] = it }
                }
            }

            "MiniSpaceKey" -> {
                if (!disableWeightEditing) {
                    parseWeight(simpleWeightEdit?.text?.toString())?.let { newKey["weight"] = it }
                }
            }

            "PlaceholderKey" -> {
                // 与 buildDraftKeyData 完全一致：空串不写字段，见那里的说明。
                placeholderMainEdit?.text?.toString()?.takeIf { it.isNotEmpty() }
                    ?.let { newKey["main"] = it }
                placeholderAltEdit?.text?.toString()?.takeIf { it.isNotEmpty() }
                    ?.let { newKey["alt"] = it }
                if (!disableWeightEditing) {
                    parseWeight(placeholderWeightEdit?.text?.toString())?.let { newKey["weight"] = it }
                }
                if (placeholderCustomColor) newKey["transparent"] = false
            }
        }
        if (!composeOverrideEditorMode) {
            // Row height stays in row settings; the split boundary can also be edited on this key.
            keyData["rowHeightPercent"]?.let { newKey["rowHeightPercent"] = it }
            if (splitAfterCheckBox?.isChecked == true) newKey["splitAfter"] = true
        }
        composeOverrideData?.let { newKey["composeOverride"] = toSerializableMap(it) }
        if (composeOverrideEditorMode) {
            newKey["independentColor"] = independentColor
        }

        appendColorOverrides(newKey)

        return newKey
    }

    private fun appendColorOverrides(target: MutableMap<String, Any?>) {
        if (composeOverrideEditorMode && !independentColor) return
        // 占位键关掉自定义颜色时不写出任何颜色字段：那些值可能是从上一份键数据继承来的，
        // 留着会让保存结果与界面显示的"全透明"对不上。
        if (selectedType == "PlaceholderKey" && !placeholderCustomColor) return
        availableColorFields().forEach { field ->
            val monet = (keyColorOverrides[field.monetKey] as? String)?.takeIf { it.isNotBlank() }
            if (monet != null) {
                target[field.monetKey] = monet
            } else {
                parseColorInt(keyColorOverrides[field.customKey])?.let { target[field.customKey] = it }
            }
        }
    }

    private fun setColorOverride(field: EditableColorField, customColor: Int?, colorRef: String?) {
        keyColorOverrides.remove(field.customKey)
        keyColorOverrides.remove(field.monetKey)
        keyData.remove(field.customKey)
        keyData.remove(field.monetKey)
        when {
            colorRef != null -> {
                keyColorOverrides[field.monetKey] = colorRef
                keyData[field.monetKey] = colorRef
            }
            customColor != null -> {
                keyColorOverrides[field.customKey] = customColor
                keyData[field.customKey] = customColor
            }
        }
    }

    private fun extractColorOverrides(source: Map<String, Any?>): LinkedHashMap<String, Any?> {
        val colors = LinkedHashMap<String, Any?>()
        editableColorFields.forEach { field ->
            source[field.customKey]?.let { colors[field.customKey] = it }
            source[field.monetKey]?.let { colors[field.monetKey] = it }
        }
        return colors
    }

    private fun restoreColorOverrides(colors: Map<String, Any?>) {
        editableColorFields.forEach { field ->
            keyData.remove(field.customKey)
            keyData.remove(field.monetKey)
        }
        keyColorOverrides = LinkedHashMap(colors)
        colors.forEach { (key, value) ->
            keyData[key] = value
        }
    }

    private fun availableColorFields(): List<EditableColorField> {
        return editableColorFields.filter { field ->
            field.supportedTypes?.contains(selectedType) ?: true
        }
    }

    private fun parseWeight(text: String?): Float? {
        val percent = text?.trim()?.toFloatOrNull()
        return percent?.takeIf { it.isFinite() && it in 0f..100f }?.div(100f)
    }

    companion object {
        const val EXTRA_SECTION = "editor_section"
        private const val STATE_BASELINE = "editor_baseline"
        private const val THEME_COLOR_REF_PREFIX = "theme:"
        private const val TAG = "KeyEditor"

        /** Bundle keys for the unsaved draft (see onSaveInstanceState). */
        private const val STATE_DRAFT_KEY_DATA = "draft_key_data"
        private const val STATE_PENDING_MACRO_EVENT = "pending_macro_event"

        /** Macro slots, used as the target token passed to (and echoed by) MacroEditorDialogFragment. */
        private const val SLOT_TAP = "tap"
        private const val SLOT_SWIPE_UP = "swipeUp"
        private const val SLOT_SWIPE_DOWN = "swipeDown"
        private const val SLOT_SWIPE = "swipe"
        private const val SLOT_LONG_PRESS = "longPress"

        @Suppress("DEPRECATION")
        private inline fun <reified T : Serializable> serializableBundleCompat(
            bundle: Bundle,
            key: String
        ): T? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            bundle.getSerializable(key, T::class.java)
        } else {
            bundle.getSerializable(key) as? T
        }

        const val EXTRA_KEY_DATA = "key_data"
        const val EXTRA_ROW_INDEX = "row_index"
        const val EXTRA_KEY_INDEX = "key_index"
        const val EXTRA_IS_EDITING_SUBMODE_LAYOUT = "is_editing_submode_layout"
        const val EXTRA_CURRENT_SUBMODE_LABEL = "current_submode_label"
        const val EXTRA_HAS_MULTI_SUBMODE_SUPPORT = "has_multi_submode_support"
        const val EXTRA_AVAILABLE_LAYOUT_TARGETS = "available_layout_targets"
        const val EXTRA_LOCK_TYPE_SELECTION = "lock_type_selection"
        const val EXTRA_DISABLE_WEIGHT_EDITING = "disable_weight_editing"
        const val EXTRA_COMPOSE_OVERRIDE_EDITOR_MODE = "compose_override_editor_mode"
        const val EXTRA_HAS_INITIAL_COMPOSE_OVERRIDE = "has_initial_compose_override"
        const val EXTRA_FIXED_TYPE = "fixed_type"
        const val EXTRA_TITLE_OVERRIDE = "title_override"
        private const val EXTRA_BASE_KEY_COLOR_DATA = "base_key_color_data"

        const val EXTRA_RESULT_ACTION = "result_action"
        const val EXTRA_RESULT_KEY_DATA = "result_key_data"

        const val RESULT_ACTION_SAVE = "save"
        const val RESULT_ACTION_DELETE = "delete"

        @JvmStatic
        @Suppress("UNCHECKED_CAST")
        fun toSerializableMap(input: Map<String, Any?>): LinkedHashMap<String, Any?> {
            return normalizeValue(input) as LinkedHashMap<String, Any?>
        }

        private fun normalizeValue(value: Any?): Any? {
            return when (value) {
                is Map<*, *> -> {
                    val normalized = LinkedHashMap<String, Any?>()
                    value.forEach { (k, v) ->
                        val key = k?.toString() ?: return@forEach
                        normalized[key] = normalizeValue(v)
                    }
                    normalized
                }
                is List<*> -> {
                    val normalized = ArrayList<Any?>()
                    value.forEach { item -> normalized.add(normalizeValue(item)) }
                    normalized
                }
                is String, is Number, is Boolean, null -> value
                else -> value.toString()
            }
        }

        @Suppress("DEPRECATION")
        private inline fun <reified T : Serializable> serializableExtraCompat(intent: Intent, key: String): T? {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getSerializableExtra(key, T::class.java)
            } else {
                intent.getSerializableExtra(key) as? T
            }
        }
    }
}
