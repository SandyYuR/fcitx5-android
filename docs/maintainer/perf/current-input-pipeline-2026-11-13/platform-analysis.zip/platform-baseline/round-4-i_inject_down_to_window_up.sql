SELECT s.id,s.ts,s.dur,s.name,t.tid,t.name AS thread,
            (MIN(s.ts+s.dur,66858747163)-MAX(s.ts,66837451386))/1000000.0 AS overlap_ms
            FROM slice s JOIN thread_track tt ON tt.id=s.track_id JOIN thread t ON t.utid=tt.utid
            WHERE t.upid=129 AND s.dur>0 AND s.ts<66858747163 AND s.ts+s.dur>66837451386
            ORDER BY overlap_ms DESC,s.ts LIMIT 40
