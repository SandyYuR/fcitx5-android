SELECT s.id,s.ts,s.dur,s.name,t.tid,t.name AS thread,
            (MIN(s.ts+s.dur,65721176484)-MAX(s.ts,65698503696))/1000000.0 AS overlap_ms
            FROM slice s JOIN thread_track tt ON tt.id=s.track_id JOIN thread t ON t.utid=tt.utid
            WHERE t.upid=129 AND s.dur>0 AND s.ts<65721176484 AND s.ts+s.dur>65698503696
            ORDER BY overlap_ms DESC,s.ts LIMIT 40
