SELECT upid,pid,name,start_ts,end_ts FROM process WHERE pid=2031
