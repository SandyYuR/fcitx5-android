SELECT name,idx,severity,value FROM stats WHERE value>0 AND (severity IN ('error','data_loss') OR name GLOB '*lost*' OR name GLOB '*drop*')
