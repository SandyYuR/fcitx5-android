SELECT s.id,s.ts,s.dur,s.name,t.tid,t.name AS thread,
            (MIN(s.ts+s.dur,67179844691)-MAX(s.ts,67052681698))/1000000.0 AS overlap_ms
            FROM slice s JOIN thread_track tt ON tt.id=s.track_id JOIN thread t ON t.utid=tt.utid
            WHERE t.upid=129 AND s.dur>0 AND s.ts<67179844691 AND s.ts+s.dur>67052681698
            ORDER BY overlap_ms DESC,s.ts LIMIT 40
