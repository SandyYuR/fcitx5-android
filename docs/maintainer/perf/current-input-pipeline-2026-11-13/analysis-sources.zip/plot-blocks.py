from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
x=json.loads((R/'pipeline-results.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none'})
fig,axes=plt.subplots(2,1,figsize=(9,6),layout='constrained')
for ax,(metric,title) in zip(axes,[('i_injected_down_to_dispatch_up_ms','First i: actual DOWN to IME window UP'),('select_dispatch_up_to_ic_ms','First selection: IME window UP to InputConnection')]):
    ax.axvline(0,color='#56636f',linestyle='--',linewidth=1)
    for row,c in enumerate(x['cohorts']):
        p=c['paired']['current']['first'][metric]
        for block,value in enumerate(p['values'],1):
            y=row+(block-3.5)*.07
            ax.scatter(value,y,color='#185c98',s=40,zorder=3)
            ax.annotate(str(block),(value,y),xytext=(4,5),textcoords='offset points',va='bottom',fontsize=8)
        ax.scatter(p['median'],row,marker='D',color='#202a35',s=52,zorder=4)
    ax.set_yticks([0,1],['VM forward','VM reverse']);ax.set_ylim(1.45,-.45)
    ax.set_title(title,loc='left',fontweight='bold');ax.set_xlabel('Paired block difference (current − baseline), ms; negative = faster')
    ax.grid(axis='x',alpha=.2);ax.spines[['top','right','left']].set_visible(False)
fig.suptitle('All 6 paired blocks per VM • dots = block IDs • diamonds = medians',fontsize=12)
fig.savefig(R/'paired-blocks.svg');fig.savefig(R/'paired-blocks.png',dpi=140)
print('Saved every paired observation; no pooled VM data or excluded outliers')
