"""Validate exact product bytes, linkage reports, and actual JVM/device case records."""
from pathlib import Path
import hashlib,json,sys,zipfile,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent;P=R/'products'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
products=json.loads((P/'products.json').read_text());plan=json.loads((P/'pipeline-plan.json').read_text())
assert products['sources']==plan['sources']==json.loads((R/'product.json').read_text())
assert len(set(products['sdk_lock_sha256'].values()))==1
assert next(iter(products['sdk_lock_sha256'].values()))=='6500f364626c863bee98157e51b6539990bb0f4e392c38ec442b6b3e5eeaa92f'
assert len(set(products['signer_sha256'].values()))==1 and len(products['apks'])==4
for name,digest in products['apks'].items():
    assert sha(P/name)==digest,name
    assert products['signer_sha256'][name] in (P/(name+'.signer.txt')).read_text(),name
expected_classes={'org.fcitx.fcitx5.android.'+suffix for suffix in (
    'core.InputBindingStartupTest','core.InputEventQueueTest','core.CandidateActionGuardTest','core.CandidateSelectionQueueTest',
    'input.candidates.CandidateTouchCancellationTest','input.candidates.horizontal.MovingCandidateBadgeTest',
    'input.candidates.CandidateCharacterTest','input.keyboard.CustomGestureViewHoldTest','input.keyboard.CustomGestureViewSwipeTest')}
out={}
for label,source in plan['sources'].items():
    assert (P/(label+'-commit.txt')).read_text().strip()==source
    roots=[ET.parse(p).getroot() for p in (P/(label+'-jvm')).glob('*.xml')]
    cases=[c for root in roots for c in root.iter('testcase')]
    classes={c.attrib['classname'] for c in cases}
    want=expected_classes|({'org.fcitx.fcitx5.android.input.broadcast.CandidateBroadcastTest'} if label=='current' else set())
    assert classes==want,(label,classes,want)
    counts={tag:sum(len(list(root.iter(tag))) for root in roots) for tag in ('failure','error','skipped')}
    assert not any(counts.values()) and sum(int(root.attrib['tests']) for root in roots)==len(cases)
    if label=='current':assert len([c for c in cases if c.attrib['classname'].endswith('.CandidateBroadcastTest')])==4
    audit=json.loads((P/(label+'-apk-audit.json')).read_text())
    assert audit['apk_sha256']==products['apks'][label+'.apk'] and audit['fcitx_dependencies']==[]
    for field in ('obsolete_picker_classes','retired_frontend_classes','legacy_backend_classes'):assert audit[field]==[]
    native_file=P/(label+'-native-link-audit.json');assert sha(native_file)==products['native_audit_sha256'][label]
    native=json.loads(native_file.read_text());assert len(native)==1 and native[0]['fcitx_cpp_symbols']==[]
    with zipfile.ZipFile(P/(label+'.apk')) as z:assert hashlib.sha256(z.read('lib/x86_64/libdirect-rime.so')).hexdigest()==native[0]['apk_native_sha256']
    out[label]=dict(source=source,executed_jvm=len(cases),failures_errors_skipped=counts,apk_sha256=audit['apk_sha256'],
                    native_libraries=audit['native_libraries'],fcitx_native_dependencies=[],fcitx_cpp_symbols=[],native_audit_sha256=sha(native_file))
(R/'jvm-and-apk-validation.json').write_text(json.dumps(dict(products=out,shared_signer_sha256=next(iter(products['signer_sha256'].values())),
    same_sdk_lock_sha256=next(iter(products['sdk_lock_sha256'].values())),four_apk_hashes_verified=True),indent=2)+'\n')
print('Verified products and actual JVM cases:',{k:v['executed_jvm'] for k,v in out.items()})
if '--products-only' in sys.argv:sys.exit(0)
Q=R/'quality';q=json.loads((Q/'quality-summary.json').read_text());assert q['status']=='pass' and q['total_passes']==56 and q['failures_errors_skipped']==0
expected=set(json.loads((R/'expected-device-cases.json').read_text()))
assert len(q['results'])==1
row=q['results'][0];assert row['label']=='current' and row['source']==plan['sources']['current']
root=ET.parse(Q/'current-junit.xml').getroot();cases=list(root.iter('testcase'))
assert {c.attrib['classname']+'#'+c.attrib['name'] for c in cases}==expected and len(cases)==len(expected)==56
assert {c['class']+'#'+c['test'] for c in row['cases']}==expected and len(row['cases'])==56
assert all(c['status_code']==0 for c in row['cases'])
assert not any(c.tag in ('failure','error','skipped') for t in cases for c in t)
(R/'device-quality-validation.json').write_text(json.dumps(dict(source=row['source'],executed=56,failures_errors_skipped=0,
    cases=sorted(expected),junit_sha256=sha(Q/'current-junit.xml')),indent=2)+'\n')
print('Verified all 56 declared device cases including actual candidate gesture and immediate list transition')
