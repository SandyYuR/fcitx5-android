from pathlib import Path
import threading,hashlib,json
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import unquote,urlsplit
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parent;W=Path('/workspace/fcitx5-android-report')
root=W/'docs/.vitepress/dist';prefix='/fcitx5-android/';rel='maintainer/perf/current-input-pipeline-2026-11-13/'
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
 def translate_path(self,path):
  p=unquote(urlsplit(path).path)
  if p.startswith(prefix):p=p[len(prefix):]
  return str(root/p.lstrip('/'))
server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
base=f'http://127.0.0.1:{server.server_port}'+prefix;out={}
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1440,'height':1000});page.route('https://**',lambda r:r.abort())
  response=page.goto(base+rel+'index.html',wait_until='domcontentloaded');assert response.status==200
  assert '当前默认版输入链路' in page.locator('.vp-doc h1').inner_text();out['desktop_report']='pass'
  downloads=[];src=W/'docs'/rel
  for line in (src/'checksums.sha256.txt').read_text().splitlines():
   digest,name=line.split(None,1);name=name.strip()
   if name.startswith('.') or name.endswith('.md'):continue
   response=page.request.get(base+rel+name);assert response.status==200,(name,response.status)
   assert hashlib.sha256(response.body()).hexdigest()==digest,name;downloads.append(name)
  out['download_byte_checks']=downloads
  page.screenshot(path=str(R/'report-desktop.png'))
  page.set_viewport_size({'width':390,'height':844});page.goto(base+rel+'index.html',wait_until='domcontentloaded')
  assert page.locator('.vp-doc h1').is_visible()
  assert page.locator('body').evaluate('(e)=>e.scrollWidth<=window.innerWidth+1')
  page.screenshot(path=str(R/'report-mobile.png'));out['mobile_report_no_page_wide_overflow']='pass'
  page.goto(base+'maintainer/implementation/index.html',wait_until='domcontentloaded')
  assert page.locator('a[href*="current-input-pipeline-2026-11-13"]').count()>0
  out['implementation_entry']='pass';browser.close()
finally:server.shutdown()
(R/'browser-validation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
