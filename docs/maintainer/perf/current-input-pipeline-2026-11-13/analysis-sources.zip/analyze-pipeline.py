"""Validate all cohorts, independently subtract raw ns, and apply the frozen promotion gate."""
from pathlib import Path
import importlib.util, os, sys, json, statistics, math
ROOT=Path(__file__).resolve().parent
TOOLS=Path(os.environ.get('PIPELINE_TOOLS','/workspace/fcitx5-android-pipeline/tools/input-perf'))
sys.path.insert(0,str(TOOLS))
spec=importlib.util.spec_from_file_location('pipeline_study',TOOLS/'run-study.py')
study=importlib.util.module_from_spec(spec);spec.loader.exec_module(study)
plan=json.loads((TOOLS/'pipeline-plan.json').read_text())

def load_cohort(folder,sources,labels,seed,blocks):
 files=list(folder.rglob('samples.json'))
 if len(files)!=1:raise ValueError('Expected one cohort')
 f=files[0];samples=json.loads(f.read_text());expected=study.make_plan(labels,'formal',blocks,seed)
 actual=json.loads((f.parent/'study-plan.json').read_text())
 if actual['seed']!=seed or actual['plan']!=expected or actual['profile'] or actual['sources']!=sources or len(samples)!=sum(map(len,expected)):raise ValueError('Cohort differs from frozen plan')
 positions={(i+1,j+1,label) for i,order in enumerate(expected) for j,label in enumerate(order)}
 if {(x['block'],x['position'],x['label']) for x in samples}!=positions:raise ValueError('Missing/duplicate processes')
 for sample in samples:
  raw=json.loads((f.parent/sample['raw']).read_text())
  if sample['source']!=sources[sample['label']] or raw['ime']['letter_gap_ms']!=100 or raw['ime']['comment_mode']!='visible':raise ValueError('Source or condition changed')
  if study.measurements(raw,sample['source'])!=sample['measurements']:raise ValueError('Raw summary mismatch')
 summary=study.summarize(samples,'baseline')
 if json.loads((f.parent/'summary.json').read_text())['statistics']!=summary:raise ValueError('Cohort summary mismatch')
 paired={}
 for label in labels:
  if label=='baseline':continue
  paired[label]={}
  for phase in ('first','warm_process_median'):
   values={}
   for block in range(1,blocks+1):
    a=[x for x in samples if x['block']==block and x['label']=='baseline'];b=[x for x in samples if x['block']==block and x['label']==label]
    for m in a[0]['measurements'][phase]:values.setdefault(m,[]).append(statistics.mean(x['measurements'][phase][m] for x in b)-statistics.mean(x['measurements'][phase][m] for x in a))
   paired[label][phase]={m:desc(v) for m,v in values.items()}
 return {'paired':paired}

def desc(values):
 return dict(n=len(values),median=statistics.median(values),min=min(values),max=max(values),positive=sum(v>0 for v in values),negative=sum(v<0 for v in values),values=values)

def cohort(stage,side,labels,seed,blocks):
 folder=ROOT/(stage+'-'+side)
 verified=load_cohort(folder,plan['sources'],labels,seed,blocks)
 file=next(folder.rglob('samples.json'));samples=json.loads(file.read_text());rows=[];holds=[]
 for sample in samples:
  raw=json.loads((file.parent/sample['raw']).read_text());rounds=[]
  for i,row in enumerate(raw['ime']['rounds']):
   n,key,tap=row['n'],row['i'],row['select'];ic=raw['editor']['commits'][i]['at_ns']
   values={
    'i_planned_up_to_dispatch_ms':(key['dispatch_up_ns']-key['planned_up_ns'])/1000000,
    'i_injected_up_to_dispatch_ms':(key['dispatch_up_ns']-key['inject_up_ns'])/1000000,
    'i_submission_lateness_ms':(key['inject_up_ns']-key['planned_up_ns'])/1000000,
    'i_injected_down_to_dispatch_up_ms':(key['dispatch_up_ns']-key['inject_down_ns'])/1000000,
    'i_dispatch_down_to_dispatch_up_ms':(key['dispatch_up_ns']-key['dispatch_down_ns'])/1000000,
    'i_actual_hold_ms':(key['inject_up_ns']-key['inject_down_ns'])/1000000,
    'n_planned_down_to_ni_ready_ms':(row['ni_ready_ns']-n['planned_down_ns'])/1000000,
    'n_injected_down_to_ni_ready_ms':(row['ni_ready_ns']-n['inject_down_ns'])/1000000,
    'n_dispatch_down_to_i_dispatch_up_ms':(key['dispatch_up_ns']-n['dispatch_down_ns'])/1000000,
    'select_planned_up_to_ic_ms':(ic-tap['planned_up_ns'])/1000000,
    'select_injected_up_to_ic_ms':(ic-tap['inject_up_ns'])/1000000,
    'select_dispatch_up_to_ic_ms':(ic-tap['dispatch_up_ns'])/1000000,
   }
   for metric,value in values.items():
    if not math.isclose(value,sample['measurements']['rounds'][i][metric],abs_tol=1e-9):raise ValueError('Independent raw ns subtraction disagrees')
   for event in (n,key,tap):
    hold=event['inject_up_ns']-event['inject_down_ns']
    if hold<20000000:raise ValueError('Compressed touch')
    holds.append(hold/1000000)
   rounds.append(values)
  first=rounds[0];warm={m:statistics.median(r[m] for r in rounds[1:]) for m in first}
  for m in first:
   if first[m]!=sample['measurements']['first'][m] or warm[m]!=sample['measurements']['warm_process_median'][m]:raise ValueError('First/warm independent replay disagrees')
  rows.append(dict(label=sample['label'],source=sample['source'],block=sample['block'],position=sample['position'],raw=sample['raw'],first=first,warm=warm))
 pairs={}
 for label in labels:
  if label=='baseline':continue
  pairs[label]={}
  for phase,key in [('first','first'),('warm','warm_process_median')]:
   metrics={}
   for block in range(1,blocks+1):
    a=[r for r in rows if r['label']=='baseline' and r['block']==block];b=[r for r in rows if r['label']==label and r['block']==block]
    for m in a[0][phase]:metrics.setdefault(m,[]).append(statistics.mean(r[phase][m] for r in b)-statistics.mean(r[phase][m] for r in a))
   pairs[label][phase]={m:desc(v) for m,v in metrics.items()}
   for m,v in pairs[label][phase].items():
    other=verified['paired'][label][key][m]
    if v['values']!=other['values']:raise ValueError('Independent block means disagree')
 absolute={label:{phase:{m:desc([r[phase][m] for r in rows if r['label']==label]) for m in rows[0][phase]} for phase in ['first','warm']} for label in labels}
 return dict(stage=stage,vm=side,processes=len(rows),correct_selections=len(rows)*6,source_map=plan['sources'],actual_holds_ms=desc(holds),absolute=absolute,paired=pairs,raw_processes=rows)

results=[cohort('formal',side,tuple(order.split(',')),seed,6) for side,order,seed in zip(['forward','reverse'],plan['formal']['orders'],plan['formal']['seeds'])]
cold=plan['interpretation']['cold_metrics']
benefits=[m for m in cold if all(c['paired']['current']['first'][m]['median']<0 and c['paired']['current']['first'][m]['negative']>=5 for c in results)]
cold_positive=[m for m in cold if all(c['paired']['current']['first'][m]['median']>0 for c in results)]
regressions=[m for m in cold_positive if all(c['paired']['current']['first'][m]['positive']>=4 for c in results)]
warm_risks=[m for m in results[0]['paired']['current']['warm'] if all(c['paired']['current']['warm'][m]['median']>0 and c['paired']['current']['warm'][m]['positive']>=4 for c in results)]
decision=dict(stable_speedup=bool(benefits) and not cold_positive and not warm_risks,replicated_benefit_metrics=benefits,cold_positive_median_metrics=cold_positive,replicated_regression_signal=regressions,warm_consistent_slow_metrics=warm_risks)
output=dict(plan=plan,cohorts=results,decision=decision,fresh_processes=sum(c['processes'] for c in results),correct_selections=sum(c['correct_selections'] for c in results),note='Only counts are totalled; timing and block signs stay separate by VM. Profile excluded.')
(ROOT/'pipeline-results.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(decision,indent=2))
for c in results:print(c['vm'],{m:c['paired']['current']['first'][m] for m in cold})
