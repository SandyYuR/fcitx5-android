"""Attribute ordinary-Debug input intervals to platform scheduling and rendering only."""
import argparse, csv, hashlib, importlib.util, io, json, subprocess
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--data',type=Path,required=True)
p.add_argument('--trace',type=Path,required=True)
p.add_argument('--processor',type=Path,required=True)
p.add_argument('--tools',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
spec=importlib.util.spec_from_file_location('associate',a.tools/'associate-events.py')
associate=importlib.util.module_from_spec(spec);spec.loader.exec_module(associate)
raw=json.loads(a.data.read_text());pid=int(raw['ime']['ime_pid'])
def query(name,sql):
    (a.output/(name+'.sql')).write_text(sql+'\n')
    r=subprocess.run([str(a.processor),'query','--no-agent','--format','csv',str(a.trace),sql],capture_output=True,text=True,check=True)
    (a.output/(name+'.csv')).write_text(r.stdout)
    return list(csv.DictReader(io.StringIO(r.stdout)))
process=query('process',f'SELECT upid,pid,name,start_ts,end_ts FROM process WHERE pid={pid}')
if len(process)!=1:raise ValueError('Ambiguous/missing process identity')
upid=int(process[0]['upid'])
threads=query('threads',f'SELECT utid,tid,name FROM thread WHERE upid={upid}')
selected={}
for label,condition in [('main',lambda t:int(t['tid'])==pid),('render',lambda t:t['name']=='RenderThread'),('owner',lambda t:t['name']=='rime-main')]:
    matches=[t for t in threads if condition(t)]
    if len(matches)!=1:raise ValueError('Ambiguous/missing '+label+' thread')
    selected[label]=int(matches[0]['utid'])
bounds=query('bounds','SELECT * FROM trace_bounds')[0]
stats=query('loss',"SELECT name,idx,severity,value FROM stats WHERE value>0 AND (severity IN ('error','data_loss') OR name GLOB '*lost*' OR name GLOB '*drop*')")
sched_rows=query('sched',f'SELECT s.ts,s.dur,s.utid FROM sched s JOIN thread t USING(utid) WHERE t.upid={upid} AND s.dur>0 ORDER BY s.ts')
state_rows=query('states',f'SELECT s.ts,s.dur,s.utid,s.state FROM thread_state s JOIN thread t USING(utid) WHERE t.upid={upid} AND s.dur>0 ORDER BY s.ts')
sched=[tuple(int(r[k]) for k in ('ts','dur','utid')) for r in sched_rows]
states=[tuple(int(r[k]) for k in ('ts','dur','utid'))+(r['state'],) for r in state_rows]
intervals=[]
for i,r in enumerate(raw['ime']['rounds']):
    ic=raw['editor']['commits'][i]['at_ns']
    for phase,start,end in [('i_inject_down_to_window_up',r['i']['inject_down_ns'],r['i']['dispatch_up_ns']),
                            ('i_inject_up_to_window_up',r['i']['inject_up_ns'],r['i']['dispatch_up_ns']),
                            ('n_inject_down_to_ni_ready',r['n']['inject_down_ns'],r['ni_ready_ns']),
                            ('candidate_window_up_to_ic',r['select']['dispatch_up_ns'],ic)]:
        if not int(bounds['start_ts'])<=start<=end<=int(bounds['end_ts']):raise ValueError('Anchor outside trace/reversed')
        evidence={label:associate.interval_evidence(start,end,utid,sched,states) for label,utid in selected.items()}
        slices=query(f'round-{i+1}-{phase}',f'''SELECT s.id,s.ts,s.dur,s.name,t.tid,t.name AS thread,
            (MIN(s.ts+s.dur,{end})-MAX(s.ts,{start}))/1000000.0 AS overlap_ms
            FROM slice s JOIN thread_track tt ON tt.id=s.track_id JOIN thread t ON t.utid=tt.utid
            WHERE t.upid={upid} AND s.dur>0 AND s.ts<{end} AND s.ts+s.dur>{start}
            ORDER BY overlap_ms DESC,s.ts LIMIT 40''')
        intervals.append(dict(round=i+1,phase=phase,start_ns=start,end_ns=end,duration_ms=(end-start)/1e6,
                              threads=evidence,longest_platform_slices=slices))
result=dict(source=raw['ime']['commit'],pid=pid,trace_sha256=hashlib.sha256(a.trace.read_bytes()).hexdigest(),
            raw_sha256=hashlib.sha256(a.data.read_bytes()).hexdigest(),process=process[0],selected_threads=selected,
            stats=stats,bounds=bounds,intervals=intervals,
            attributable=not stats and all(x['complete'] for r in intervals for x in r['threads'].values()),
            scope='Separate diagnostic VM, ordinary Debug. Platform slices may nest; never sum their overlaps. No native stage timing or performance distribution claim.')
(a.output/'platform.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('source','pid','stats','attributable')}))
