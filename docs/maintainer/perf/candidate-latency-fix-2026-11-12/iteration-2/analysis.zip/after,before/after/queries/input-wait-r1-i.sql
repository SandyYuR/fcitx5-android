SELECT s.id,s.ts,s.dur,s.name,t.utid,t.tid,t.name AS thread,p.pid,
                        p.name AS process FROM slice s JOIN thread_track tt ON s.track_id=tt.id
                        JOIN thread t ON tt.utid=t.utid JOIN process p ON t.upid=p.upid
                        WHERE s.dur>0 AND t.tid=p.pid AND s.ts<159829864283 AND s.ts+s.dur>159746971281
                        AND p.upid IN (SELECT DISTINCT t2.upid FROM slice a
                        JOIN thread_track tt2 ON a.track_id=tt2.id JOIN thread t2 ON tt2.utid=t2.utid
                        WHERE a.name GLOB 'rime.direct.*') ORDER BY s.ts,s.dur DESC
