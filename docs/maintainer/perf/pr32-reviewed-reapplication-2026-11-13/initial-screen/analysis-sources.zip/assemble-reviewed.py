"""Archive accepted raw evidence without changing original ZIP bytes or old reports."""
from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
R=Path(__file__).resolve().parent
W=Path('/workspace/fcitx5-android-report')
D=W/'docs/maintainer/perf/pr32-reviewed-reapplication-2026-11-13/initial-screen'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def zip_files(dest,files):
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
  for p,n in files:z.write(p,n)
def main():
 results=json.loads((R/'reviewed-results.json').read_text());decision=results['promotion'];cohorts=results['cohorts']
 assert results['fresh_processes']==32 and decision['reason']=='confirmation_setup_failed_before_sampling'
 metadata=json.loads((R/'artifacts-final.json').read_text()); by={a['name']:a for a in metadata['artifacts']}
 raw=[('latency-study-products','products.zip'),('reviewed-quality','quality.zip'),('reviewed-screen-forward','screen-forward.zip'),('reviewed-screen-reverse','screen-reverse.zip'),('reviewed-selection','selection.zip')]
 if decision['candidate']!='none':raw.extend([('reviewed-confirm-forward','confirm-forward.zip'),('reviewed-confirm-reverse','confirm-reverse.zip')])
 evidence=[]
 for name,file in raw:
  p=R/file;a=by[name];assert sha(p)==a['digest'].removeprefix('sha256:') and p.stat().st_size==a['size_in_bytes']
  with zipfile.ZipFile(p) as z:assert z.testzip() is None
  evidence.append(dict(file=file,original_github_artifact=a,raw_zip_published=name!='latency-study-products'))
 D.mkdir(parents=True,exist_ok=True)
 files=[file for name,file in raw if name!='latency-study-products']+['reviewed-results.json','local-validation.json','jvm-and-apk-validation.json','device-quality-validation.json','source-scope.json','source-history-verification.txt','reviewed-source-history.bundle','protected-remote-heads-before.txt','promotion-receipt.json','old-manifest-validation.json','aosp-TextPaint.java.txt','confirmation-setup-error.txt']
 for label in ['ui','priority','combined','driver']:files +=[label+'-source.zip',label+'-commits.mbox.txt']
 for name in files:shutil.copyfile(R/name,D/name)
 for name in ['products.json','reapply-plan.json','reviewed-scope.json']:shutil.copyfile(R/'products'/name,D/name)
 (D/'sdk-lock.json').write_bytes(subprocess.check_output(['git','show','2e86e2ec:native/rime-sdk.lock.json'],cwd='/workspace/fcitx5-android'))
 records=[(p,p.relative_to(R/'products').as_posix()) for p in sorted((R/'products').rglob('*')) if p.is_file() and p.suffix in ('.txt','.log','.json','.xml')]
 assert not any(p.suffix in ('.apk','.jks','.keystore') for p,n in records)
 zip_files(D/'build-records.zip',records);dump(D/'build-records-manifest.json',[dict(file=n,sha256=sha(p)) for p,n in records])
 zip_files(D/'analysis-sources.zip',[(R/n,n) for n in ['analyze-reviewed.py','assemble-reviewed.py']])
 zip_files(D/'github-metadata.zip',[(R/n,n) for n in ['artifacts-final.json','latest-run.json','latest-jobs.json','status-watch.log','pr31-before.json','pr32-before.json']])
 source=json.loads((R/'source-map-prepared.json').read_text());source.update(products=json.loads((R/'products/products.json').read_text()),raw_artifacts=evidence,fresh_processes=results['fresh_processes'],correct_selections=results['correct_selections'],decision=decision,final_pr=json.loads((R/'promotion-receipt.json').read_text()),cleanup_policy='push_archive_before_ref_deletion')
 dump(D/'source-map.json',source)
 dump(D/'cleanup-receipt.json',dict(state='archive-prepared-before-deletion',archive_push_required_before_deletion=True,default_branch_pushed=False,user_refactor_branch_touched=False,historical_ci_deleted=False))
 text=(R/'report-static.md').read_text();text=text.replace('{{LEAD}}',(R/'lead.txt').read_text().strip()).replace('{{DECISION}}',(R/'decision.txt').read_text().strip())
 tables=[]
 names={'ui':'ui','priority':'priority','combined':'combined'}
 cold=results['plan']['selection']['cold_metrics']
 tables +=['筛查配对区组差，单位 ms；正值表示试验版更慢，每格为中位数〔正／负区组数〕：','','| VM | 版本 | 首次完整 i | 首次候选 UP → IC | 后五轮完整 i | 后五轮候选 UP → IC |','| --- | --- | ---: | ---: | ---: | ---: |']
 for c in cohorts:
  if c['stage']!='screen':continue
  for label,p in c['paired'].items():
   vals=[p[phase][m] for phase,m in [('first',cold[0]),('first',cold[1]),('warm',cold[0]),('warm',cold[1])]]
   tables.append('| '+c['vm']+' | '+label+' | '+' | '.join(f"{v['median']:+.3f}〔{v['positive']}／{v['negative']}〕" for v in vals)+' |')
 confirms=[c for c in cohorts if c['stage']=='confirm']
 if confirms:
  label=decision['candidate'];tables+=['',f'独立复核选择 **{label}**，与 baseline 使用筛查时完全相同的 APK 字节。每台 24 个新进程、6 个配对区组：','','| VM | 首次阶段 | baseline 中位数 | 试验版中位数 | 配对差中位数 | 六区组差范围 | 正／负 |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
  for c in confirms:
   for m,title in [(cold[0],'i 实际 DOWN → 窗口 UP'),(cold[1],'候选窗口 UP → IC')]:
    a,b=[c['absolute'][l]['first'][m]['median'] for l in ['baseline',label]];v=c['paired'][label]['first'][m]
    tables.append(f"| {c['vm']} | {title} | {a:.3f} | {b:.3f} | {v['median']:+.3f} | {v['min']:+.3f}～{v['max']:+.3f} | {v['positive']}／{v['negative']} |")
  tables+=['','完整复核指标如下，每格为配对差中位数〔正／负区组数〕，单位 ms。`first` 为第一轮，`warm` 为后五轮进程内中位数；刺激保持与注入迟到也保留，不把它们全部解释为产品耗时。','','| 指标 | first forward | first reverse | warm forward | warm reverse |','| --- | ---: | ---: | ---: | ---: |']
  for m in confirms[0]['paired'][label]['first']:
   vals=[c['paired'][label][phase][m] for phase in ['first','warm'] for c in confirms]
   tables.append('| `'+m+'` | '+' | '.join(f"{v['median']:+.3f}〔{v['positive']}／{v['negative']}〕" for v in vals)+' |')
 tables+=['',f"合计 {results['fresh_processes']} 个新进程、{results['correct_selections']} 次正确选词；这里只合计次数，不合并阶段或 VM 的时延分布。所有触摸实际保持均不少于 20ms。"]
 for c in cohorts:
  v=c['actual_holds_ms'];tables.append(f"{c['stage']} {c['vm']} 的实际保持范围 {v['min']:.3f}～{v['max']:.3f}ms。")
 rawlinks='\n\n'.join('、'.join(f'[{name}](./{name}.zip)' for name in group) for group in [['screen-forward','screen-reverse']]+([['confirm-forward','confirm-reverse']] if confirms else []))
 text=text.replace('{{RESULTS}}','\n'.join(tables)).replace('{{RAW_LINKS}}',rawlinks)
 assert '{{' not in text
 # Ensure every published source and patch can be downloaded directly from the report.
 links='\n\n'+'；'.join(f'[{label} 源码](./{label}-source.zip)、[补丁](./{label}-commits.mbox.txt)' for label in ['ui','priority','combined','driver'])+'。\n'
 text=text.replace('[来源映射](./source-map.json)',links+'\n[来源映射](./source-map.json)')
 zip_files(D/'source-history-bundles.zip', [(R/'reviewed-source-history.bundle','reviewed-source-history.bundle')])
 text=text.replace('[精确 Git 历史](./reviewed-source-history.bundle)','[精确 Git 历史包](./source-history-bundles.zip)')
 (D/'index.md').write_text(text)
 (D/'.gitattributes').write_text('*.zip -text\n*.bundle -text\n*.json text eol=lf\n*.md text eol=lf\n*.txt text eol=lf\n*.mbox.txt -whitespace\n')
 manifest=D/'checksums.sha256.txt';manifest.write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(D.iterdir()) if p.is_file() and p!=manifest))
 print('Archived',len(list(D.iterdir())),'files in',D)
if __name__=='__main__':main()
