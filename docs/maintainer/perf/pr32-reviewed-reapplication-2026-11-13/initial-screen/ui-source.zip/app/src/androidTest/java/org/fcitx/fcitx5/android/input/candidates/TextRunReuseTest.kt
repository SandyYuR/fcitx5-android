/* SPDX-License-Identifier: LGPL-2.1-or-later */
package org.fcitx.fcitx5.android.input.candidates

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.style.CharacterStyle
import android.view.Gravity
import android.view.View
import androidx.test.platform.app.InstrumentationRegistry
import org.fcitx.fcitx5.android.input.AutoScaleTextView
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.ceil

/** The oracle draws declared segments with fresh paints, independently of span traversal. */
class TextRunReuseTest {
    private class Run(val text: String, val style: (TextPaint.() -> Unit)? = null)

    private fun runs() = listOf(
        Run("MMMM") { textSize = 52f; typeface = Typeface.SERIF; textScaleX = 1.25f; color = Color.RED },
        Run(" iiii "),
        Run("WWWW") { textSize = 21f; typeface = Typeface.SANS_SERIF; textSkewX = -0.25f; color = Color.BLUE },
        Run(" plain"),
    )

    private fun styled(runs: List<Run>): SpannableString {
        val text = SpannableString(runs.joinToString("") { it.text })
        var start = 0
        for (run in runs) {
            val style = run.style
            if (style != null) {
                // CharacterStyle is intentionally not MetricAffectingSpan. Preserve
                // the original updateDrawState semantics during measurement too.
                text.setSpan(object : CharacterStyle() {
                    override fun updateDrawState(paint: TextPaint) { style(paint) }
                }, start, start + run.text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            start += run.text.length
        }
        return text
    }

    @Test fun measuringStyledRunsRestoresTheBasePaintForEveryPlainSegment() = onMain {
        val runs = runs()
        val base = TextPaint().apply {
            isAntiAlias = true
            textSize = 32f
            typeface = Typeface.MONOSPACE
            color = Color.BLACK
        }
        val before = TextPaint(base)
        var expectedWidth = 0f
        for (run in runs) {
            val paint = TextPaint(before)
            run.style?.invoke(paint)
            expectedWidth += paint.measureText(run.text)
        }
        val expected = ceil(expectedWidth).toInt()
        assertEquals(expected, AutoScaleTextView.measureTextWidth(styled(runs), base))
        assertEquals(before.textSize, base.textSize, 0f)
        assertEquals(before.textScaleX, base.textScaleX, 0f)
        assertEquals(before.textSkewX, base.textSkewX, 0f)
        assertEquals(before.typeface, base.typeface)
        assertEquals(before.color, base.color)
    }

    @Test fun drawingStyledRunsMatchesIndependentFreshPaintSegments() = onMain {
        val runs = runs()
        val view = AutoScaleTextView(InstrumentationRegistry.getInstrumentation().targetContext).apply {
            setPadding(0, 0, 0, 0)
            gravity = Gravity.TOP or Gravity.LEFT
            scaleMode = AutoScaleTextView.Mode.None
            textSize = 32f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.BLACK)
            background = null
            text = styled(runs)
        }
        val width = 800
        val height = 160
        view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY))
        view.layout(0, 0, width, height)
        val actual = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val expected = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        try {
            view.draw(Canvas(actual))
            val base = TextPaint(view.paint).apply { color = Color.BLACK }
            val canvas = Canvas(expected)
            val baseline = -base.fontMetrics.top
            var x = 0f
            for (run in runs) {
                val paint = TextPaint(base)
                run.style?.invoke(paint)
                canvas.drawText(run.text, x, baseline, paint)
                x += paint.measureText(run.text)
            }
            assertTrue("Run state must not leak into following unstyled text", actual.sameAs(expected))
        } finally {
            actual.recycle()
            expected.recycle()
        }
    }

    private fun onMain(block: () -> Unit) {
        var failure: Throwable? = null
        InstrumentationRegistry.getInstrumentation().runOnMainSync {
            try { block() } catch (error: Throwable) { failure = error }
        }
        failure?.let { throw it }
    }
}
