"""Validate all cohorts, independently subtract raw ns, and apply the frozen promotion gate."""
from pathlib import Path
import importlib.util, os, sys, json, statistics, math
ROOT=Path(__file__).resolve().parent
TOOLS=Path(os.environ.get('REVIEWED_TOOLS','/workspace/fcitx5-android-reviewed/tools/input-perf'))
sys.path.insert(0,str(TOOLS))
spec=importlib.util.spec_from_file_location('reviewed_selection',TOOLS/'choose-reviewed-candidate.py')
selection=importlib.util.module_from_spec(spec);spec.loader.exec_module(selection)
plan=json.loads((TOOLS/'reapply-plan.json').read_text())

def desc(values):
 return dict(n=len(values),median=statistics.median(values),min=min(values),max=max(values),positive=sum(v>0 for v in values),negative=sum(v<0 for v in values),values=values)

def cohort(stage,side,labels,seed,blocks):
 folder=ROOT/(stage+'-'+side)
 verified=selection.load_cohort(folder,plan['sources'],labels,seed,blocks)
 file=next(folder.rglob('samples.json'));samples=json.loads(file.read_text());rows=[];holds=[]
 for sample in samples:
  raw=json.loads((file.parent/sample['raw']).read_text());rounds=[]
  for i,row in enumerate(raw['ime']['rounds']):
   n,key,tap=row['n'],row['i'],row['select'];ic=raw['editor']['commits'][i]['at_ns']
   values={
    'i_planned_up_to_dispatch_ms':(key['dispatch_up_ns']-key['planned_up_ns'])/1000000,
    'i_injected_up_to_dispatch_ms':(key['dispatch_up_ns']-key['inject_up_ns'])/1000000,
    'i_submission_lateness_ms':(key['inject_up_ns']-key['planned_up_ns'])/1000000,
    'i_injected_down_to_dispatch_up_ms':(key['dispatch_up_ns']-key['inject_down_ns'])/1000000,
    'i_dispatch_down_to_dispatch_up_ms':(key['dispatch_up_ns']-key['dispatch_down_ns'])/1000000,
    'i_actual_hold_ms':(key['inject_up_ns']-key['inject_down_ns'])/1000000,
    'n_planned_down_to_ni_ready_ms':(row['ni_ready_ns']-n['planned_down_ns'])/1000000,
    'n_injected_down_to_ni_ready_ms':(row['ni_ready_ns']-n['inject_down_ns'])/1000000,
    'n_dispatch_down_to_i_dispatch_up_ms':(key['dispatch_up_ns']-n['dispatch_down_ns'])/1000000,
    'select_planned_up_to_ic_ms':(ic-tap['planned_up_ns'])/1000000,
    'select_injected_up_to_ic_ms':(ic-tap['inject_up_ns'])/1000000,
    'select_dispatch_up_to_ic_ms':(ic-tap['dispatch_up_ns'])/1000000,
   }
   for metric,value in values.items():
    if not math.isclose(value,sample['measurements']['rounds'][i][metric],abs_tol=1e-9):raise ValueError('Independent raw ns subtraction disagrees')
   for event in (n,key,tap):
    hold=event['inject_up_ns']-event['inject_down_ns']
    if hold<20000000:raise ValueError('Compressed touch')
    holds.append(hold/1000000)
   rounds.append(values)
  first=rounds[0];warm={m:statistics.median(r[m] for r in rounds[1:]) for m in first}
  for m in first:
   if first[m]!=sample['measurements']['first'][m] or warm[m]!=sample['measurements']['warm_process_median'][m]:raise ValueError('First/warm independent replay disagrees')
  rows.append(dict(label=sample['label'],source=sample['source'],block=sample['block'],position=sample['position'],raw=sample['raw'],first=first,warm=warm))
 pairs={}
 for label in labels:
  if label=='baseline':continue
  pairs[label]={}
  for phase,key in [('first','first'),('warm','warm_process_median')]:
   metrics={}
   for block in range(1,blocks+1):
    a=[r for r in rows if r['label']=='baseline' and r['block']==block];b=[r for r in rows if r['label']==label and r['block']==block]
    for m in a[0][phase]:metrics.setdefault(m,[]).append(statistics.mean(r[phase][m] for r in b)-statistics.mean(r[phase][m] for r in a))
   pairs[label][phase]={m:desc(v) for m,v in metrics.items()}
   for m,v in pairs[label][phase].items():
    other=verified['paired'][label][key][m]
    if v['values']!=other['values']:raise ValueError('Independent block means disagree')
 absolute={label:{phase:{m:desc([r[phase][m] for r in rows if r['label']==label]) for m in rows[0][phase]} for phase in ['first','warm']} for label in labels}
 return dict(stage=stage,vm=side,processes=len(rows),correct_selections=len(rows)*6,source_map=plan['sources'],actual_holds_ms=desc(holds),absolute=absolute,paired=pairs,raw_processes=rows)

screen=[cohort('screen',side,tuple(order.split(',')),seed,4) for side,order,seed in zip(['forward','reverse'],plan['screen']['orders'],plan['screen']['seeds'])]
selected=json.loads((ROOT/'selection'/'selection.json').read_text())
excluded={label:[metric for metric in plan['selection']['cold_metrics'] if all(x['paired'][label]['first'][metric]['median']>0 and x['paired'][label]['first'][metric]['positive']>=3 for x in screen)] for label in plan['selection']['candidate_preference']}
candidate=next((label for label in plan['selection']['candidate_preference'] if not excluded[label]),'none')
if selected['candidate']!=candidate or selected['exclusion_reasons']!=excluded:raise ValueError('Selection does not follow the predeclared preference')
results=list(screen);decision=dict(candidate=candidate,screen_exclusions=excluded,promote=False,reason='all_screened_variants_excluded')
if candidate!='none':
 confirm=[cohort('confirm',side,labels,seed,6) for side,labels,seed in zip(['forward','reverse'],[('baseline',candidate),(candidate,'baseline')],plan['confirmation']['seeds'])]
 results.extend(confirm)
 cold=plan['selection']['cold_metrics']
 benefit=[m for m in cold if all(x['paired'][candidate]['first'][m]['median']<0 and x['paired'][candidate]['first'][m]['negative']>=5 for x in confirm)]
 cold_risks=[m for m in cold if all(x['paired'][candidate]['first'][m]['median']>0 for x in confirm)]
 warm_risks=[m for m in confirm[0]['paired'][candidate]['warm'] if all(x['paired'][candidate]['warm'][m]['median']>0 and x['paired'][candidate]['warm'][m]['positive']>=4 for x in confirm)]
 decision.update(promote=bool(benefit) and not cold_risks and not warm_risks,replicated_benefit_metrics=benefit,cold_positive_median_metrics=cold_risks,warm_consistent_slow_metrics=warm_risks,reason='meets_frozen_gate' if benefit and not cold_risks and not warm_risks else 'independent_confirmation_did_not_meet_frozen_gate')
output=dict(plan=plan,cohorts=results,promotion=decision,correct_selections=sum(x['correct_selections'] for x in results),fresh_processes=sum(x['processes'] for x in results),note='Counts only are totalled; timing distributions remain separate by stage and VM')
(ROOT/'reviewed-results.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(decision,indent=2))
for c in results:
 for label,p in c['paired'].items():print(c['stage'],c['vm'],label,{m:p['first'][m]['median'] for m in plan['selection']['cold_metrics']})
print('All raw/source/order/clock/geometry/model/word/hold/first/warm/block checks pass')
