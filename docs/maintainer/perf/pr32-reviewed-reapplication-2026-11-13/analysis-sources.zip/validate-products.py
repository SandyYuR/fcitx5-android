from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent;P=R/'products';products=json.loads((P/'products.json').read_text());plan=json.loads((P/'reapply-plan.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert products['sources']==plan['sources']
assert len(set(products['sdk_lock_sha256'].values()))==1
assert len(set(products['signer_sha256'].values()))==1 and len(products['apks'])==8
out={}
for name,digest in products['apks'].items():
 assert sha(P/name)==digest,name
 assert products['signer_sha256'][name] in (P/(name+'.signer.txt')).read_text(),name
for label,source in plan['sources'].items():
 assert (P/(label+'-commit.txt')).read_text().strip()==source
 roots=[ET.parse(p).getroot() for p in (P/(label+'-jvm')).glob('*.xml')];assert len(roots)==7
 cases=[c for root in roots for c in root.iter('testcase')];assert len(cases)==(81 if label in ['priority','combined'] else 79)
 counts={tag:sum(len(list(root.iter(tag))) for root in roots) for tag in ['failure','error','skipped']};assert not any(counts.values())
 if label in ['priority','combined']:assert {'keyResultStatusReadKeepsPriorityAndRestoresTheOwner','keyPublicationFailureStillRestoresTheOwnerThreadPriority'}<={c.attrib['name'] for c in cases}
 a=json.loads((P/(label+'-apk-audit.json')).read_text());assert a['apk_sha256']==products['apks'][label+'.apk'] and a['fcitx_dependencies']==[]
 for field in ['obsolete_picker_classes','retired_frontend_classes','legacy_backend_classes']:assert a[field]==[]
 audit=P/(label+'-native-link-audit.json');assert sha(audit)==products['native_audit_sha256'][label];native=json.loads(audit.read_text());assert len(native)==1 and native[0]['fcitx_cpp_symbols']==[]
 with zipfile.ZipFile(P/(label+'.apk')) as z:assert hashlib.sha256(z.read('lib/x86_64/libdirect-rime.so')).hexdigest()==native[0]['apk_native_sha256']
 out[label]=dict(source=source,executed_jvm=len(cases),failures_errors_skipped=counts,apk_sha256=a['apk_sha256'],native_libraries=a['native_libraries'],fcitx_native_dependencies=[],fcitx_cpp_symbols=[],native_audit_sha256=sha(audit))
(R/'jvm-and-apk-validation.json').write_text(json.dumps(dict(products=out,shared_signer_sha256=next(iter(products['signer_sha256'].values())),same_sdk_lock_sha256=next(iter(products['sdk_lock_sha256'].values())),eight_apk_hashes_verified=True),indent=2)+'\n');print('Verified exact source, eight APK hashes/signers, native audits, and 320 real JVM cases')
Q=R/'quality';q=json.loads((Q/'quality-summary.json').read_text());assert q['status']=='pass' and q['total_passes']==60 and q['failures_errors_skipped']==0
out={}
for row in q['results']:
 label=row['label'];assert row['source']==plan['sources'][label]
 root=ET.parse(Q/(label+'-junit.xml')).getroot();cases=list(root.iter('testcase'));assert len(cases)==15 and len(row['cases'])==15 and all(c['status_code']==0 for c in row['cases'])
 assert not any(c.tag in ['failure','error','skipped'] for t in cases for c in t)
 assert {'measuringStyledRunsRestoresTheBasePaintForEveryPlainSegment','drawingStyledRunsMatchesIndependentFreshPaintSegments'}<={c.attrib['name'] for c in cases}
 out[label]=dict(source=row['source'],executed=15,failures_errors_skipped=0,junit_sha256=sha(Q/(label+'-junit.xml')))
(R/'device-quality-validation.json').write_text(json.dumps(out,indent=2)+'\n');print('Verified all 60 device cases including constructor-equivalent Paint field oracle')
