SELECT s.ts,s.dur,s.utid,s.cpu FROM sched s JOIN thread t USING(utid)
                JOIN process p USING(upid) WHERE p.upid IN
                (SELECT DISTINCT t2.upid FROM slice a JOIN thread_track tt2 ON a.track_id=tt2.id
                 JOIN thread t2 ON tt2.utid=t2.utid WHERE a.name GLOB 'rime.direct.*')
                OR p.name GLOB '*inputbench*' ORDER BY s.ts
