SELECT t.utid,t.tid,t.name,p.pid,p.upid FROM thread t
        JOIN process p USING(upid) WHERE t.upid IN
        (SELECT DISTINCT t2.upid FROM slice s JOIN thread_track tt ON s.track_id=tt.id
         JOIN thread t2 ON tt.utid=t2.utid WHERE s.name GLOB 'rime.direct.*')
