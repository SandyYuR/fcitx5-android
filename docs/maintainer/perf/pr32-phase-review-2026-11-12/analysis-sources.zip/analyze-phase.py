from pathlib import Path
import importlib.util,json,sys,statistics,math,hashlib,zipfile
ROOT=Path('/workspace/rime-pr32-phase-review-2026-11-12')
SPEC=importlib.util.spec_from_file_location('phase_study',Path('/workspace/fcitx5-android-phase-review/tools/input-perf/run-study.py'))
study=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(study)
summary=[]
for label in sys.argv[1:]:
 folder=ROOT/label
 if not folder.exists():
  with zipfile.ZipFile(ROOT/(label+'.zip')) as z:
   assert z.testzip() is None
   for n in z.namelist():assert not n.startswith('/') and '..' not in Path(n).parts
   z.extractall(folder)
 for sample_file in sorted(folder.rglob('samples.json')):
  condition=sample_file.parent.name
  samples=json.loads(sample_file.read_text())
  if not samples:continue
  raw_values=[]
  for s in samples:
   raw=json.loads((sample_file.parent/s['raw']).read_text())
   ime=raw['ime']
   assert ime['driver_identity']['protocol']=='external_input_manager_v1'
   assert ime['driver_identity']['transport']=='loopback_tcp'
   assert ime['driver_identity']['uid'] in (0,2000)
   assert ime['driver_identity']['pid']!=ime['ime_pid']
   validated=study.measurements(raw,s['source'])
   assert validated==s['measurements']
   independent=[]
   for i,row in enumerate(ime['rounds']):
    n,key,sel=row['n'],row['i'],row['select']
    ic=raw['editor']['commits'][i]['at_ns']
    # Separate implementation from measurements(): integer subtraction before division.
    metrics={
     'i_injected_down_to_dispatch_up_ms':(key['dispatch_up_ns']-key['inject_down_ns'])/1_000_000,
     'i_injected_up_to_dispatch_ms':(key['dispatch_up_ns']-key['inject_up_ns'])/1_000_000,
     'n_planned_down_to_ni_ready_ms':(row['ni_ready_ns']-n['planned_down_ns'])/1_000_000,
     'select_dispatch_up_to_ic_ms':(ic-sel['dispatch_up_ns'])/1_000_000,
     'select_injected_up_to_ic_ms':(ic-sel['inject_up_ns'])/1_000_000,
     'i_submission_lateness_ms':(key['inject_up_ns']-key['planned_up_ns'])/1_000_000,
     'i_actual_hold_ms':(key['inject_up_ns']-key['inject_down_ns'])/1_000_000,
    }
    for k,v in metrics.items():assert math.isclose(v,validated['rounds'][i][k],abs_tol=1e-9)
    independent.append(metrics)
   raw_values.append(dict(label=s['label'],block=s['block'],position=s['position'],source=s['source'],raw=s['raw'],driver=ime['driver_identity'],ime_pid=ime['ime_pid'],gap_ms=ime['letter_gap_ms'],comment_mode=ime['comment_mode'],first=independent[0],warm={k:statistics.median(r[k] for r in independent[1:]) for k in independent[0]}))
  recomputed=study.summarize(samples,'baseline')
  original=json.loads((sample_file.parent/'summary.json').read_text())
  # Check field names without relying on an assumed outer summary schema.
  expected=original.get('summary',original)
  if 'products' in expected:assert recomputed==expected
  pairs=[]
  for block in sorted({s['block'] for s in raw_values}):
   base=[s for s in raw_values if s['block']==block and s['label']=='baseline']
   current=[s for s in raw_values if s['block']==block and s['label']=='current']
   if not base or not current:continue
   pairs.append(dict(block=block,deltas={k:statistics.mean(s['first'][k] for s in current)-statistics.mean(s['first'][k] for s in base) for k in base[0]['first']}))
  rows=dict(artifact=label,condition=condition,processes=len(samples),selections=len(samples)*6,products=recomputed['products'],paired_block_deltas=recomputed['paired_block_deltas_vs_reference'],independent_pairs=pairs,raw_process_values=raw_values)
  summary.append(rows)
  metric='i_injected_down_to_dispatch_up_ms'
  b,c=(rows['products'][p]['first'][metric]['median'] for p in ('baseline','current'))
  print(label,condition,'processes',len(samples),'first-full-i',round(b,3),round(c,3),'delta',round(statistics.median(s['deltas'][metric] for s in pairs),3))
(ROOT/'phase-results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print('Independent raw integer differences agree; total',sum(x['selections'] for x in summary),'selections; cohorts remain separate')
