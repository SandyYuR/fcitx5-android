from pathlib import Path
import json,csv,importlib.util
r=Path('/workspace/rime-pr32-phase-review-2026-11-12')
spec=importlib.util.spec_from_file_location('assoc',r/'associate-external.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
rows=[]
for folder in sorted((r/'held-profile-analysis').iterdir()):
 data=json.loads((folder/'associated.json').read_text());assert data['valid']
 gap,label=folder.name.split('-',1)
 raw=next((r/'held-profile/samples'/('gap-'+gap+'-visible')).rglob(label+'-1.json'))
 event=json.loads(raw.read_text());start=event['ime']['rounds'][0]['select']['dispatch_up_ns'];end=event['editor']['commits'][0]['at_ns']
 def table(name):
  with (folder/(name+'.csv')).open() as f:return list(csv.DictReader(f))
 sched=[(int(x['ts']),int(x['dur']),int(x['utid'])) for x in table('sched') if int(x['dur'])>0]
 states=[(int(x['ts']),int(x['dur']),int(x['utid']),x['state']) for x in table('thread_states') if int(x['dur'])>0]
 first=data['input_waits'][0]['thread_coverage'];cpu={}
 for name in ['main','render','owner']:
  e=a.interval_evidence(start,end,first[name]['utid'],sched,states);assert e['complete'];cpu[name]=e
 cores=[]
 for x in table('slices'):
  if x['name']=='rime.direct.action_core' and start<=int(x['ts'])<end:
   cores.append({'wall_ms':int(x['dur'])/1e6,'cpu_ms':sum(max(0,min(int(x['ts'])+int(x['dur']),ts+dur)-max(int(x['ts']),ts)) for ts,dur,u in sched if u==int(x['utid']))/1e6})
 rows.append({'case':folder.name,'window_up_to_ic_ms':(end-start)/1e6,'thread_evidence':cpu,'action_cores':cores})
print(json.dumps([{'case':x['case'],'ic_ms':x['window_up_to_ic_ms'],'cpu':{k:v['cpu_ms'] for k,v in x['thread_evidence'].items()},'cores':x['action_cores']} for x in rows],indent=2))
(r/'select-profile-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
