from pathlib import Path
import importlib.util,copy,sys,unittest
code=Path('/workspace/fcitx5-android/tools/input-perf')
experiment=Path('/workspace/fcitx5-android-phase-review/tools/input-perf')
sys.path.insert(0,str(code))
import test_study
spec=importlib.util.spec_from_file_location('phase_study',experiment/'run-study.py')
study=importlib.util.module_from_spec(spec);spec.loader.exec_module(study)

def raw(gap=100,mode='visible'):
 d=test_study.sample()
 d['ime'].update(injection_protocol=study.PROTOCOL,letter_gap_ms=gap,comment_mode=mode,driver_identity={'pid':222},ime_pid=111)
 for row in d['ime']['rounds']:
  row['first_candidate_comment']='nǐ' if mode=='visible' else ''
  if gap==300:
   for key in row['i']:
    if key.endswith('_ns'): row['i'][key]+=200_000_000
   row['ni_ready_ns']+=200_000_000
   for key in row['select']:
    if key.endswith('_ns'): row['select'][key]+=200_000_000
   d['editor']['commits'][row['round']-1]['at_ns']+=200_000_000
 return d

class Validation(unittest.TestCase):
 def test_all_four_conditions(self):
  for gap in [100,300]:
   for mode in ['visible','hidden']:
    self.assertEqual(6,len(study.measurements(raw(gap,mode),test_study.COMMIT)['rounds']))
 def test_in_process_injector_rejected(self):
  d=raw();d['ime']['driver_identity']['pid']=111
  with self.assertRaises(ValueError):study.measurements(d,test_study.COMMIT)
 def test_wrong_gap_rejected(self):
  d=raw();d['ime']['letter_gap_ms']=300
  with self.assertRaises(ValueError):study.measurements(d,test_study.COMMIT)
 def test_visible_missing_comment_rejected(self):
  d=raw();d['ime']['rounds'][0]['first_candidate_comment']=''
  with self.assertRaises(ValueError):study.measurements(d,test_study.COMMIT)
 def test_hidden_with_comment_rejected(self):
  d=raw(mode='hidden');d['ime']['rounds'][0]['first_candidate_comment']='nǐ'
  with self.assertRaises(ValueError):study.measurements(d,test_study.COMMIT)
 def test_backward_clock_rejected(self):
  d=raw();d['ime']['rounds'][0]['i']['inject_up_return_ns']=d['ime']['rounds'][0]['i']['inject_up_ns']-1
  with self.assertRaises(ValueError):study.measurements(d,test_study.COMMIT)
 def test_wrong_source_rejected(self):
  with self.assertRaises(ValueError):study.measurements(raw(),'b'*40)

unittest.main()
