from pathlib import Path
import hashlib,json,subprocess,zipfile
r=Path(__file__).resolve().parent
scope=json.loads((r/'integration-scope.json').read_text());restore=r/('restore-'+scope['head'][:8]+'.git')
def git(*args,cwd=restore):
 return subprocess.run(['git',*map(str,args)],cwd=cwd,check=True,text=True,capture_output=True).stdout
subprocess.run(['git','init','--bare',str(restore)],check=True,capture_output=True)
for base in dict.fromkeys(['0380d70f16efb6a9946a164821d5cad7118ce4ff','1230ee45bf11cce18a445475f785cdf62bf141b6',scope['base']]):
 git('fetch','--depth','1','--no-tags','https://github.com/SandyYuR/fcitx5-android.git',base)
git('bundle','verify',r/'before-integration.bundle')
git('fetch',r/'before-integration.bundle','refs/heads/fix/first-candidate-latency-20261112:refs/archive/pr32-before','refs/heads/perf/input-pipeline-20261113:refs/archive/pipeline-before')
git('bundle','verify',r/'integrated-history.bundle')
git('fetch',r/'integrated-history.bundle','refs/heads/fix/first-candidate-latency-20261112:refs/heads/fix/first-candidate-latency-20261112')
assert git('rev-parse','refs/archive/pr32-before').strip()=='2e86e2ecbac1a6d4b28a59fc80b0f81fffdf5b18'
assert git('rev-parse','refs/archive/pipeline-before').strip()=='a3c9bea60ef409b93e3c506525a3f510b03bb9c6'
head=git('rev-parse','refs/heads/fix/first-candidate-latency-20261112').strip();assert head==json.loads((r/'integration-scope.json').read_text())['head']
git('archive','--format=zip','-o',r/'restored-source.zip',head)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(r/'restored-source.zip')==digest(r/'integrated-source.zip')
initial=r/'initial-8ee233bc/integrated-history.bundle'
git('bundle','verify',initial)
git('fetch',initial,'refs/heads/fix/first-candidate-latency-20261112:refs/archive/pr32-initial-integration')
assert git('rev-parse','refs/archive/pr32-initial-integration').strip()=='8ee233bc7f75786fc36faff412a89d1a6ccca601'
git('archive','--format=zip','-o',r/'restored-initial-source.zip','refs/archive/pr32-initial-integration')
assert digest(r/'restored-initial-source.zip')==json.loads((r/'initial-8ee233bc/history-validation.json').read_text())['files']['integrated-source.zip']
intermediate=r/'intermediate-82d88f95/integrated-history.bundle'
git('bundle','verify',intermediate)
git('fetch',intermediate,'refs/heads/fix/first-candidate-latency-20261112:refs/archive/pr32-before-pr35')
assert git('rev-parse','refs/archive/pr32-before-pr35').strip()=='82d88f95f18beabfe201bc0cf32fd96286918e40'
for before,base,name in [('2e86e2ec','0380d70f','pr32-before.patch'),('a3c9bea6','88a664d4','pipeline-before.patch')]:
 actual=subprocess.check_output(['git','diff','--binary','--full-index',base,before],cwd=restore)
 assert actual==(r/name).read_bytes()
result=dict(restored_old_pr32=True,restored_deleted_pipeline=True,restored_final_source=True,restored_initial_integration=True,source_zip_byte_identical=True,source_files=len([x for x in zipfile.ZipFile(r/'integrated-source.zip').namelist() if not x.endswith('/')]),head=head,prerequisites=list(dict.fromkeys(['0380d70f16efb6a9946a164821d5cad7118ce4ff','1230ee45bf11cce18a445475f785cdf62bf141b6',scope['base']])),files={name:digest(r/name) for name in ['before-integration.bundle','integrated-history.bundle','integrated-source.zip','pr32-before.patch','pipeline-before.patch','integrated-commits.mbox.txt']})
(r/'history-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
