"""Independent integer subtraction and block aggregation for the frozen font study."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import math
import os
import statistics
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
TOOLS = Path(os.environ.get('PR32_FONT_TOOLS', '/workspace/fcitx5-android-font-review/tools/input-perf'))
sys.path.insert(0, str(TOOLS))
spec = importlib.util.spec_from_file_location('font_study', TOOLS / 'run-study.py')
study = importlib.util.module_from_spec(spec)
spec.loader.exec_module(study)
SOURCES = {'baseline': '0380d70f16efb6a9946a164821d5cad7118ce4ff',
           'current': '2e86e2ecbac1a6d4b28a59fc80b0f81fffdf5b18'}


def describe(values):
    return dict(n=len(values), median=statistics.median(values),
                minimum=min(values), maximum=max(values),
                positive=sum(v > 0 for v in values), negative=sum(v < 0 for v in values), values=values)


def main():
    results = []
    for cohort in sys.argv[1:]:
        folder = ROOT / cohort
        if not folder.exists():
            with zipfile.ZipFile(ROOT / (cohort + '.zip')) as z:
                if z.testzip() is not None:
                    raise ValueError('ZIP CRC failed: ' + cohort)
                for name in z.namelist():
                    if name.startswith('/') or '..' in Path(name).parts:
                        raise ValueError('Unsafe ZIP member')
                z.extractall(folder)
        sample_files = list(folder.rglob('samples.json'))
        if len(sample_files) != 1:
            raise ValueError('Expected one original-configuration condition')
        sample_file = sample_files[0]
        samples = json.loads(sample_file.read_text())
        if len(samples) != 24:
            raise ValueError('A completed VM must contain exactly 24 fresh processes')
        products = json.loads((folder / 'products.json').read_text())
        if products['sources'] != SOURCES:
            raise ValueError('Wrong source pair')
        plan = json.loads((sample_file.parent / 'study-plan.json').read_text())
        expected_seed = 2026111301 if cohort.endswith('forward') else 2026111302
        expected_labels = ('baseline', 'current') if cohort.endswith('forward') else ('current', 'baseline')
        if (plan['seed'] != expected_seed or plan['profile'] or
                plan['plan'] != study.make_plan(expected_labels, 'formal', 6, expected_seed)):
            raise ValueError('Formal plan differs from the predeclared balanced order')
        raw_values, holds = [], []
        for s in samples:
            raw = json.loads((sample_file.parent / s['raw']).read_text())
            ime = raw['ime']
            if (ime['letter_gap_ms'] != 100 or ime['comment_mode'] != 'visible' or
                    ime['driver_identity']['pid'] == ime['ime_pid'] or
                    ime['driver_identity']['uid'] not in (0, 2000) or
                    ime['driver_identity']['transport'] != 'loopback_tcp'):
                raise ValueError('Unexpected injection conditions')
            validated = study.measurements(raw, SOURCES[s['label']])
            if validated != s['measurements']:
                raise ValueError('Archived measurements differ from recalculation')
            independent = []
            for index, row in enumerate(ime['rounds']):
                n, i, selected = row['n'], row['i'], row['select']
                ic = raw['editor']['commits'][index]['at_ns']
                values = {
                    'first_i_actual_down_to_window_up_ms': (i['dispatch_up_ns'] - i['inject_down_ns']) / 1_000_000,
                    'i_up_to_window_up_ms': (i['dispatch_up_ns'] - i['inject_up_ns']) / 1_000_000,
                    'planned_n_to_ni_ms': (row['ni_ready_ns'] - n['planned_down_ns']) / 1_000_000,
                    'injected_n_to_ni_ms': (row['ni_ready_ns'] - n['inject_down_ns']) / 1_000_000,
                    'candidate_window_up_to_ic_ms': (ic - selected['dispatch_up_ns']) / 1_000_000,
                    'candidate_injected_up_to_ic_ms': (ic - selected['inject_up_ns']) / 1_000_000,
                    'i_actual_hold_ms': (i['inject_up_ns'] - i['inject_down_ns']) / 1_000_000,
                    'i_down_lateness_ms': (i['inject_down_ns'] - i['planned_down_ns']) / 1_000_000,
                    'n_down_lateness_ms': (n['inject_down_ns'] - n['planned_down_ns']) / 1_000_000,
                    'actual_n_i_down_gap_ms': (i['inject_down_ns'] - n['inject_down_ns']) / 1_000_000,
                    'select_actual_hold_ms': (selected['inject_up_ns'] - selected['inject_down_ns']) / 1_000_000,
                }
                mapping = {
                    'first_i_actual_down_to_window_up_ms': 'i_injected_down_to_dispatch_up_ms',
                    'i_up_to_window_up_ms': 'i_injected_up_to_dispatch_ms',
                    'planned_n_to_ni_ms': 'n_planned_down_to_ni_ready_ms',
                    'injected_n_to_ni_ms': 'n_injected_down_to_ni_ready_ms',
                    'candidate_window_up_to_ic_ms': 'select_dispatch_up_to_ic_ms',
                    'candidate_injected_up_to_ic_ms': 'select_injected_up_to_ic_ms',
                    'i_actual_hold_ms': 'i_actual_hold_ms',
                }
                for key, other in mapping.items():
                    if not math.isclose(values[key], validated['rounds'][index][other], abs_tol=1e-9):
                        raise ValueError('Independent integer calculation disagrees')
                for key in ('n', 'i', 'select'):
                    event = row[key]
                    hold = event['inject_up_ns'] - event['inject_down_ns']
                    if hold < 20_000_000:
                        raise ValueError('Compressed touch in a declared corrected sample')
                    holds.append(hold / 1_000_000)
                independent.append(values)
            raw_values.append(dict(label=s['label'], block=s['block'], position=s['position'],
                                   raw=s['raw'], first=independent[0], rounds=independent,
                                   warm={key: statistics.median(row[key] for row in independent[1:])
                                         for key in independent[0]}))
        recomputed = study.summarize(samples, 'baseline')
        archived = json.loads((sample_file.parent / 'summary.json').read_text())
        if recomputed != archived['statistics']:
            raise ValueError('Archived summary differs from full independent replay')
        pairs = []
        for block in range(1, 7):
            base = [s for s in raw_values if s['block'] == block and s['label'] == 'baseline']
            current = [s for s in raw_values if s['block'] == block and s['label'] == 'current']
            if len(base) != 2 or len(current) != 2:
                raise ValueError('Missing process in paired block')
            phases = {}
            for phase in ('first', 'warm'):
                phases[phase] = {metric: statistics.mean(s[phase][metric] for s in current) -
                                statistics.mean(s[phase][metric] for s in base)
                                for metric in base[0][phase]}
            pairs.append(dict(block=block, **phases))
        result = dict(cohort=cohort, processes=24, correct_selections=144, source_pair=SOURCES,
                      actual_touch_holds_ms=describe(holds),
                      absolute={label: {phase: {metric: describe([s[phase][metric] for s in raw_values if s['label'] == label])
                                               for metric in raw_values[0][phase]}
                                        for phase in ('first', 'warm')}
                                for label in ('baseline', 'current')},
                      paired={phase: {metric: describe([pair[phase][metric] for pair in pairs])
                                      for metric in pairs[0][phase]} for phase in ('first', 'warm')},
                      paired_blocks=pairs, raw_processes=raw_values)
        results.append(result)
        print(cohort, json.dumps({metric: result['paired']['first'][metric]
                                  for metric in ['first_i_actual_down_to_window_up_ms',
                                                 'candidate_window_up_to_ic_ms']}, ensure_ascii=False))
    (ROOT / 'font-confirmation-results.json').write_text(json.dumps(results, indent=2) + '\n')
    print('Independent subtraction, policy, source and balanced-block checks all pass')


if __name__ == '__main__':
    main()
