"""Publish verified evidence only after both predeclared cohorts complete."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
DOCS = Path('/workspace/fcitx5-android-report')
DEST = DOCS / 'docs/maintainer/perf/pr32-font-confirmation-2026-11-13'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def archive(path, files):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for source, name in files:
            z.write(source, name)


def main():
    results = json.loads((ROOT / 'font-confirmation-results.json').read_text())
    if len(results) != 2 or sum(r['processes'] for r in results) != 48:
        raise ValueError('Both full cohorts must be independently verified before publication')
    if not (ROOT / 'lead.txt').is_file() or not (ROOT / 'interpretation.txt').is_file():
        raise ValueError('Write the evidence-based interpretation after reviewing all results')
    artifacts = json.loads((ROOT / 'artifact-metadata.json').read_text())['artifacts']
    by_name = {a['name']: a for a in artifacts}
    evidence = []
    for name, local in [('latency-study-products', 'products.zip'),
                        ('font-confirmation-forward', 'font-forward.zip'),
                        ('font-confirmation-reverse', 'font-reverse.zip'),
                        ('font-contracts', 'font-contracts.zip')]:
        record = by_name[name]
        path = ROOT / local
        if sha(path) != record['digest'].removeprefix('sha256:'):
            raise ValueError('GitHub digest mismatch: ' + name)
        with zipfile.ZipFile(path) as z:
            if z.testzip() is not None:
                raise ValueError('ZIP CRC error: ' + name)
        evidence.append(dict(file=local, original_github_artifact=record,
                             raw_zip_published=name != 'latency-study-products'))
    DEST.mkdir(parents=True, exist_ok=True)
    files = ['font-forward.zip', 'font-reverse.zip', 'font-contracts.zip',
             'font-confirmation-results.json', 'code2e-frontend-results.zip',
             'code2e-frontend-validation.json', 'local-validation.json',
             'final-product-source.zip', 'study-driver-source.zip',
             'final-product-commits.mbox.txt', 'study-driver-commits.mbox.txt',
             'source-history-bundles.zip', 'observed-heads-during-study.txt', 'code-ci.json']
    for name in files:
        shutil.copyfile(ROOT / name, DEST / name)
    products = ROOT / 'products'
    for name in ['products.json', 'font-confirmation-plan.json', 'font-scope-audit.json',
                 'baseline-apk-audit.json', 'current-apk-audit.json',
                 'baseline-native-link-audit.json', 'current-native-link-audit.json']:
        shutil.copyfile(products / name, DEST / name)
    (DEST / 'sdk-lock.json').write_bytes(subprocess.check_output(
        ['git', 'show', '2e86e2ecbac1a6d4b28a59fc80b0f81fffdf5b18:native/rime-sdk.lock.json']))
    record_files = [(p, p.name) for p in sorted(products.iterdir())
                    if p.is_file() and p.suffix in ('.txt', '.log', '.json')]
    archive(DEST / 'build-records.zip', record_files)
    (DEST / 'build-records-manifest.json').write_text(json.dumps(
        [{'file': name, 'sha256': sha(p)} for p, name in record_files], indent=2) + '\n')
    archive(DEST / 'analysis-sources.zip', [(ROOT / name, name) for name in (
        'analyze-font-confirmation.py', 'assemble-report.py')])
    metadata = [(p, p.name) for p in sorted(ROOT.glob('run-*.json'))]
    metadata += [(ROOT / 'latest-run.json', 'study-final-run.json'),
                 (ROOT / 'latest-jobs.json', 'study-final-jobs.json')]
    archive(DEST / 'github-metadata.zip', metadata)
    source_map = json.loads((ROOT / 'source-map-prepared.json').read_text())
    source_map.pop('current_source_apk_will_be_benchmarked_without_relabeling', None)
    source_map.update(products=json.loads((products / 'products.json').read_text()),
                      raw_artifacts=evidence, current_source_apk_actually_performance_timed=True,
                      fresh_processes=48, correct_selections=288,
                      font_negative_control_expected_failure=1, font_current_passes=4,
                      exact_history_prerequisite='0380d70f16efb6a9946a164821d5cad7118ce4ff',
                      cleanup='archive-prepared-before-deletion')
    (DEST / 'source-map.json').write_text(json.dumps(source_map, indent=2) + '\n')
    (DEST / 'cleanup-receipt.json').write_text(json.dumps(dict(
        state='archive-prepared-before-deletion', branch='test/pr32-font-only-20261113',
        expected_tip='9a26eb811904d1d353ce165bacdf9d8cfa84de86',
        remote_deleted=False, local_deleted=False, worktree_removed=False,
        archive_push_required_before_deletion=True, default_branch_pushed=False,
        historical_ci_deleted=False), indent=2) + '\n')
    lines = ['| VM | 首次阶段 | baseline 中位数 | current 中位数 | 配对差中位数 | 六个区组差范围 | 正／负 |',
             '| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    for result in results:
        vm = result['cohort'].removeprefix('font-')
        for metric, label in [('first_i_actual_down_to_window_up_ms', 'i 实际 DOWN → 窗口 UP'),
                              ('candidate_window_up_to_ic_ms', '候选窗口 UP → IC')]:
            b, c = [result['absolute'][name]['first'][metric]['median'] for name in ('baseline', 'current')]
            d = result['paired']['first'][metric]
            lines.append(f"| {vm} | {label} | {b:.3f} | {c:.3f} | {d['median']:+.3f} | {d['minimum']:+.3f}～{d['maximum']:+.3f} | {d['positive']}／{d['negative']} |")
    lines += ['', '补充阶段同样按区组计算，单位 ms：', '',
              '| VM | 首次 i 实际 UP → 窗口 UP 差 | 首次 n 计划 DOWN → ni 差 | 后五轮完整 i 差 | 后五轮候选 UP → IC 差 |',
              '| --- | ---: | ---: | ---: | ---: |']
    for result in results:
        vm = result['cohort'].removeprefix('font-')
        numbers = [result['paired'][phase][metric]['median'] for phase, metric in (
            ('first', 'i_up_to_window_up_ms'), ('first', 'planned_n_to_ni_ms'),
            ('warm', 'first_i_actual_down_to_window_up_ms'), ('warm', 'candidate_window_up_to_ic_ms'))]
        lines.append('| ' + vm + ' | ' + ' | '.join(f'{v:+.3f}' for v in numbers) + ' |')
    report = (ROOT / 'report-template.md').read_text()
    for token, value in {'{{LEAD}}': (ROOT / 'lead.txt').read_text().strip(),
                         '{{INTERPRETATION}}': (ROOT / 'interpretation.txt').read_text().strip(),
                         '{{PERF_TABLE}}': '\n'.join(lines)}.items():
        report = report.replace(token, value)
    if '{{' in report:
        raise ValueError('Unfilled report field')
    report = report.replace('[独立复算结果](./font-confirmation-results.json)',
                            '[独立复算结果](./font-confirmation-results.json)与[复算源码](./analysis-sources.zip)')
    (DEST / 'index.md').write_text(report)
    (DEST / '.gitattributes').write_text('*.zip -text\n*.json text eol=lf\n*.md text eol=lf\n*.txt text eol=lf\n*.mbox.txt -whitespace\n')
    manifest = DEST / 'checksums.sha256.txt'
    items = sorted(p for p in DEST.iterdir() if p.is_file() and p != manifest)
    manifest.write_text(''.join(f'{sha(p)}  {p.name}\n' for p in items))
    print('Assembled', len(items), 'verified evidence files at', DEST)


if __name__ == '__main__':
    main()
