/*
 * SPDX-License-Identifier: LGPL-2.1-or-later
 * SPDX-FileCopyrightText: Copyright 2026 Fcitx5 for Android Contributors
 */
package org.fcitx.fcitx5.android.input.candidates

import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.ViewGroup
import androidx.test.platform.app.InstrumentationRegistry
import org.fcitx.fcitx5.android.core.CandidateWord
import org.fcitx.fcitx5.android.data.theme.ThemePreset
import org.fcitx.fcitx5.android.input.AutoScaleTextView
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.ceil

class CandidateRenderingTest {
    private val instrumentation = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext

    @Test fun plainAndCommentedCandidatesKeepTextColorsAcrossHighlightChanges() = onMain {
        for (theme in listOf(ThemePreset.MaterialLight, ThemePreset.MaterialDark)) {
            val ui = CandidateItemUi(context, theme, Typeface.MONOSPACE, Typeface.SERIF)
            val text = (ui.root.getChildAt(0) as ViewGroup).getChildAt(0) as AutoScaleTextView
            ui.updateCandidate(CandidateWord("1", "候选", "", false))
            assertEquals("候选", text.text.toString())
            assertFalse("plain candidates do not need spans", text.text is Spanned)
            val original = text.text
            ui.setActive(true)
            assertSame("highlight must not replace plain text", original, text.text)
            assertEquals(theme.genericActiveForegroundColor, text.currentTextColor)
            ui.setActive(false)
            assertEquals(theme.candidateTextColor, text.currentTextColor)

            ui.updateCandidate(CandidateWord("1", "候选", "houxuan", true))
            assertEquals("候选 houxuan", text.text.toString())
            for (active in listOf(false, true, false)) {
                ui.setActive(active)
                val styled = text.text as Spanned
                val color = styled.getSpans(3, styled.length, ForegroundColorSpan::class.java).single()
                assertEquals(if (active) theme.genericActiveForegroundColor else theme.candidateCommentColor,
                    color.foregroundColor)
                assertEquals(if (active) theme.genericActiveForegroundColor else theme.candidateTextColor,
                    text.currentTextColor)
                assertEquals(1, styled.getSpans(3, styled.length, CustomTypefaceSpan::class.java).size)
                assertEquals(1, styled.getSpans(3, styled.length, AbsoluteSizeSpan::class.java).size)
            }
        }
    }

    @Test fun replacingTypefaceRemeasuresTheSameCandidateText() = onMain {
        val text = AutoScaleTextView(context).apply {
            textSize = 32f
            typeface = Typeface.MONOSPACE
            text = "MMMMMMMM"
        }
        measure(text)
        val before = text.measuredWidth
        text.typeface = Typeface.SERIF
        measure(text)
        assertEquals(AutoScaleTextView.measureTextWidth(text.text, text.paint), text.measuredWidth)
        assertNotEquals("fixture must distinguish the two typefaces", before, text.measuredWidth)
    }

    @Test fun spanMeasurementPreservesRunAdvancesAndDoesNotMutateBasePaint() = onMain {
        val paint = TextPaint().apply { typeface = Typeface.MONOSPACE; textSize = 32f }
        val text = SpannableString("word note").apply {
            setSpan(ForegroundColorSpan(0xffaa0000.toInt()), 0, 4, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            setSpan(CustomTypefaceSpan(Typeface.SERIF), 5, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            setSpan(AbsoluteSizeSpan(16), 5, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val comment = TextPaint(paint).apply { typeface = Typeface.SERIF; textSize = 16f }
        val expected = ceil(paint.measureText("word") + paint.measureText(" ") +
            comment.measureText("note")).toInt()
        assertEquals(expected, AutoScaleTextView.measureTextWidth(text, paint))
        assertEquals(32f, paint.textSize, 0f)
        assertSame(Typeface.MONOSPACE, paint.typeface)
    }

    @Test fun explicitlyStyledCandidateKeepsTheDefaultTextViewGeometry() = onMain {
        val standard = AutoScaleTextView(context)
        val candidate = AutoScaleTextView(context, null, 0)
        for (text in listOf(standard, candidate)) {
            text.typeface = Typeface.MONOSPACE
            text.textSize = 20f
            text.isSingleLine = true
            text.gravity = android.view.Gravity.CENTER
            text.text = "候选 candidate"
            measure(text)
        }
        assertEquals(standard.measuredWidth, candidate.measuredWidth)
        assertEquals(standard.measuredHeight, candidate.measuredHeight)
        assertEquals(standard.baseline, candidate.baseline)
        val paint = candidate.paint
        candidate.typeface = candidate.typeface
        assertSame(paint, candidate.paint)
    }

    private fun measure(view: View) {
        view.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(80, View.MeasureSpec.EXACTLY))
        view.layout(0, 0, view.measuredWidth, view.measuredHeight)
    }

    private fun onMain(block: () -> Unit) {
        var failure: Throwable? = null
        instrumentation.runOnMainSync { try { block() } catch (error: Throwable) { failure = error } }
        failure?.let { throw it }
    }
}
