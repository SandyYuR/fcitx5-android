from pathlib import Path
import json,subprocess,csv,io
root=Path('/workspace/rime-candidate-fix-2026-11-12');out=Path('/workspace/rime-i-dispatch-review-2026-11-12/historical-render');out.mkdir(exist_ok=True)
processor='/workspace/rime-latency-investigation-2026-11-11/trace_processor';results=[]
for iteration,d in [(1,root),(2,root/'iteration-2'),(3,root/'iteration-3')]:
 for order in ['before,after','after,before']:
  for product in ['before','after']:
   p=d/order/'traced'/f'{product}-1.json'
   if not p.exists(): p=d/order/f'{product}-1.json'
   data=json.loads(p.read_text());e=data['ime']['rounds'][0]['i'];start,end=e['inject_up_ns'],e['dispatch_up_ns']
   trace=p.with_suffix('.perfetto-trace');dest=out/f'{iteration}-{order}-{product}';dest.mkdir(exist_ok=True)
   def query(name,sql):
    (dest/(name+'.sql')).write_text(sql+'\n');r=subprocess.run([processor,'query','--no-agent','--format','csv',str(trace),sql],text=True,capture_output=True,check=True)
    (dest/(name+'.csv')).write_text(r.stdout);return list(csv.DictReader(io.StringIO(r.stdout)))
   slices=query('graphics-wait',f'''SELECT s.ts,s.dur,s.name,t.utid,t.tid,t.name AS thread,p.pid
    FROM slice s JOIN thread_track tt ON s.track_id=tt.id JOIN thread t USING(utid) JOIN process p USING(upid)
    WHERE s.dur>0 AND s.ts<{end} AND s.ts+s.dur>{start} AND t.upid IN
     (SELECT DISTINCT t2.upid FROM slice s2 JOIN thread_track tt2 ON s2.track_id=tt2.id JOIN thread t2 ON tt2.utid=t2.utid WHERE s2.name='rime.direct.process_key')
    AND (s.name='postAndWait' OR s.name GLOB '*eglSwap*' OR s.name GLOB '*rcCreateSync*') ORDER BY s.ts'''.replace('JOIN thread t USING(utid)','JOIN thread t ON tt.utid=t.utid'))
   cpu=query('graphics-cpu',f'''SELECT t.name,SUM(MIN(s.ts+s.dur,{end})-MAX(s.ts,{start}))/1000000.0 AS cpu_ms
    FROM sched s JOIN thread t USING(utid) WHERE s.dur>0 AND s.ts<{end} AND s.ts+s.dur>{start}
    AND t.upid IN (SELECT DISTINCT t2.upid FROM slice s2 JOIN thread_track tt2 ON s2.track_id=tt2.id JOIN thread t2 ON tt2.utid=t2.utid WHERE s2.name='rime.direct.process_key')
    GROUP BY t.utid ORDER BY cpu_ms DESC''')
   overlap=sum(max(0,min(int(r['ts'])+int(r['dur']),end)-max(int(r['ts']),start)) for r in slices if r['name']=='postAndWait')/1e6
   render=sum(float(r['cpu_ms']) for r in cpu if r['name']=='RenderThread')
   row={'iteration':iteration,'order':order,'product':product,'i_wait_ms':(end-start)/1e6,'post_and_wait_overlap_ms':overlap,'render_thread_cpu_ms':render,'graphics_slices':slices}
   results.append(row);print({k:v for k,v in row.items() if k!='graphics_slices'},flush=True)
(out/'summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
