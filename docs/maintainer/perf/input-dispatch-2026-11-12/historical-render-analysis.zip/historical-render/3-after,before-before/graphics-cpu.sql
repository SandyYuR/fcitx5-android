SELECT t.name,SUM(MIN(s.ts+s.dur,163376091509)-MAX(s.ts,163358288657))/1000000.0 AS cpu_ms
    FROM sched s JOIN thread t USING(utid) WHERE s.dur>0 AND s.ts<163376091509 AND s.ts+s.dur>163358288657
    AND t.upid IN (SELECT DISTINCT t2.upid FROM slice s2 JOIN thread_track tt2 ON s2.track_id=tt2.id JOIN thread t2 ON tt2.utid=t2.utid WHERE s2.name='rime.direct.process_key')
    GROUP BY t.utid ORDER BY cpu_ms DESC
