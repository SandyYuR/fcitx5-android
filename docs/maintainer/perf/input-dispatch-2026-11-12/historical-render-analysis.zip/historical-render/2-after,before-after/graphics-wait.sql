SELECT s.ts,s.dur,s.name,t.utid,t.tid,t.name AS thread,p.pid
    FROM slice s JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid JOIN process p USING(upid)
    WHERE s.dur>0 AND s.ts<159829864283 AND s.ts+s.dur>159746971281 AND t.upid IN
     (SELECT DISTINCT t2.upid FROM slice s2 JOIN thread_track tt2 ON s2.track_id=tt2.id JOIN thread t2 ON tt2.utid=t2.utid WHERE s2.name='rime.direct.process_key')
    AND (s.name='postAndWait' OR s.name GLOB '*eglSwap*' OR s.name GLOB '*rcCreateSync*') ORDER BY s.ts
