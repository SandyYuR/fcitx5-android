SELECT t.tid,t.name AS thread,p.pid,p.name AS process,s.priority,
      SUM(MIN(s.ts+s.dur,210603714640)-MAX(s.ts,210524663652))/1000000.0 AS cpu_ms
    FROM sched s JOIN thread t USING(utid) LEFT JOIN process p USING(upid)
    WHERE s.dur>0 AND s.ts<210603714640 AND s.ts+s.dur>210524663652
    GROUP BY t.utid,s.priority ORDER BY cpu_ms DESC
