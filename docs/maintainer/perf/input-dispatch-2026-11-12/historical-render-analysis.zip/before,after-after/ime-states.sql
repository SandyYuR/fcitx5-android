SELECT t.tid,t.name,s.state,s.io_wait,s.blocked_function,
      SUM(MIN(s.ts+s.dur,210603714640)-MAX(s.ts,210524663652))/1000000.0 AS ms
    FROM thread_state s JOIN thread t USING(utid)
    WHERE t.upid=130 AND s.dur>0 AND s.ts<210603714640 AND s.ts+s.dur>210524663652
    GROUP BY t.utid,s.state,s.io_wait,s.blocked_function ORDER BY t.tid,ms DESC
