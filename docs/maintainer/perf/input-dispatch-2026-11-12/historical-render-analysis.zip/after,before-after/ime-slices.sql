SELECT s.id,s.ts,s.dur,s.name,t.utid,t.tid,t.name AS thread
    FROM slice s JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid
    WHERE t.upid=178 AND s.dur>0 AND s.ts<120146019947 AND s.ts+s.dur>120145213867
    ORDER BY t.tid,s.ts,s.dur DESC
