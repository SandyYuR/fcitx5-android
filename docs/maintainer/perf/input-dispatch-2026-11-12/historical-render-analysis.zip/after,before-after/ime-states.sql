SELECT t.tid,t.name,s.state,s.io_wait,s.blocked_function,
      SUM(MIN(s.ts+s.dur,120146019947)-MAX(s.ts,120145213867))/1000000.0 AS ms
    FROM thread_state s JOIN thread t USING(utid)
    WHERE t.upid=178 AND s.dur>0 AND s.ts<120146019947 AND s.ts+s.dur>120145213867
    GROUP BY t.utid,s.state,s.io_wait,s.blocked_function ORDER BY t.tid,ms DESC
