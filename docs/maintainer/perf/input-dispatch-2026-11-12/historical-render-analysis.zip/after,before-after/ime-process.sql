SELECT DISTINCT t.upid,p.pid FROM slice s JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid JOIN process p ON t.upid=p.upid WHERE s.name='rime.direct.process_key'
