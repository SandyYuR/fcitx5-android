SELECT t.tid,t.name,s.state,s.io_wait,s.blocked_function,
      SUM(MIN(s.ts+s.dur,163376091509)-MAX(s.ts,163358288657))/1000000.0 AS ms
    FROM thread_state s JOIN thread t USING(utid)
    WHERE t.upid=132 AND s.dur>0 AND s.ts<163376091509 AND s.ts+s.dur>163358288657
    GROUP BY t.utid,s.state,s.io_wait,s.blocked_function ORDER BY t.tid,ms DESC
