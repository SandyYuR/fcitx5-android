SELECT s.ts,s.dur,s.name,t.tid FROM slice s
    JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid
    WHERE t.upid=132 AND s.name GLOB 'rime.direct.*' AND s.dur>=0
    AND s.ts>163242044232 AND s.ts<163376091509+10000000 ORDER BY s.ts
