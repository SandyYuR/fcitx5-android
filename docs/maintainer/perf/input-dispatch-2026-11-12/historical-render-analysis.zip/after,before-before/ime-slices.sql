SELECT s.id,s.ts,s.dur,s.name,t.utid,t.tid,t.name AS thread
    FROM slice s JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid
    WHERE t.upid=132 AND s.dur>0 AND s.ts<163376091509 AND s.ts+s.dur>163358288657
    ORDER BY t.tid,s.ts,s.dur DESC
