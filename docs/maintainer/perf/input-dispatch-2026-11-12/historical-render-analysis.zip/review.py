from pathlib import Path
import json,csv,io,subprocess,statistics
root=Path('/workspace/rime-candidate-fix-2026-11-12/iteration-3')
out=Path('/workspace/rime-i-dispatch-review-2026-11-12')
processor='/workspace/rime-latency-investigation-2026-11-11/trace_processor'
def query(trace,label,name,sql):
 d=out/label;d.mkdir(exist_ok=True)
 (d/(name+'.sql')).write_text(sql+'\n')
 r=subprocess.run([processor,'query','--no-agent','--format','csv',str(trace),sql],capture_output=True,text=True,check=True)
 (d/(name+'.csv')).write_text(r.stdout)
 return list(csv.DictReader(io.StringIO(r.stdout)))
results=[]
for order in ['before,after','after,before']:
 for product in ['before','after']:
  path=root/order/'traced'/f'{product}-1.json'
  data=json.loads(path.read_text());event=data['ime']['rounds'][0]['i'];start,end=event['inject_up_ns'],event['dispatch_up_ns']
  n=data['ime']['rounds'][0]['n']
  trace=path.with_suffix('.perfetto-trace');label=order+'-'+product
  procs=query(trace,label,'ime-process',"""SELECT DISTINCT t.upid,p.pid FROM slice s JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid JOIN process p ON t.upid=p.upid WHERE s.name='rime.direct.process_key'""")
  assert len(procs)==1
  upid,pid=int(procs[0]['upid']),int(procs[0]['pid'])
  slices=query(trace,label,'ime-slices',f'''SELECT s.id,s.ts,s.dur,s.name,t.utid,t.tid,t.name AS thread
    FROM slice s JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid
    WHERE t.upid={upid} AND s.dur>0 AND s.ts<{end} AND s.ts+s.dur>{start}
    ORDER BY t.tid,s.ts,s.dur DESC''')
  states=query(trace,label,'ime-states',f'''SELECT t.tid,t.name,s.state,s.io_wait,s.blocked_function,
      SUM(MIN(s.ts+s.dur,{end})-MAX(s.ts,{start}))/1000000.0 AS ms
    FROM thread_state s JOIN thread t USING(utid)
    WHERE t.upid={upid} AND s.dur>0 AND s.ts<{end} AND s.ts+s.dur>{start}
    GROUP BY t.utid,s.state,s.io_wait,s.blocked_function ORDER BY t.tid,ms DESC''')
  cpu=query(trace,label,'system-cpu',f'''SELECT t.tid,t.name AS thread,p.pid,p.name AS process,s.priority,
      SUM(MIN(s.ts+s.dur,{end})-MAX(s.ts,{start}))/1000000.0 AS cpu_ms
    FROM sched s JOIN thread t USING(utid) LEFT JOIN process p USING(upid)
    WHERE s.dur>0 AND s.ts<{end} AND s.ts+s.dur>{start}
    GROUP BY t.utid,s.priority ORDER BY cpu_ms DESC''')
  native=query(trace,label,'native-before-after',f'''SELECT s.ts,s.dur,s.name,t.tid FROM slice s
    JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid
    WHERE t.upid={upid} AND s.name GLOB 'rime.direct.*' AND s.dur>=0
    AND s.ts>{n['dispatch_down_ns']} AND s.ts<{end}+10000000 ORDER BY s.ts''')
  waits=[s for s in slices if s['name']=='postAndWait' and int(s['tid'])==pid]
  wait=sum(max(0,min(int(s['ts'])+int(s['dur']),end)-max(int(s['ts']),start)) for s in waits)/1e6
  row=dict(order=order,product=product,wait_ms=(end-start)/1e6,post_and_wait_overlap_ms=wait,
      main_states=[s for s in states if int(s['tid'])==pid],
      top_cpu=cpu[:10],
      native_slices_inside_wait=[s for s in native if int(s['ts'])<end and int(s['ts'])+int(s['dur'])>start])
  results.append(row)
  print(json.dumps(row,ensure_ascii=False,indent=2))
(out/'traced-review.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
summary=json.loads((root/'analysis/comparison.json').read_text())
rows=summary['untraced_records']
for product in ['before','after']:
 vals=[r['first_i_inject_to_dispatch_ms'] for r in rows if r['product']==product]
 print(product,'six recorded waits',vals,'median',statistics.median(vals),'greater 30ms',sum(v>30 for v in vals))
