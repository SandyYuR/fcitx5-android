SELECT t.tid,t.name,s.state,s.io_wait,s.blocked_function,
      SUM(MIN(s.ts+s.dur,160297438592)-MAX(s.ts,160293884920))/1000000.0 AS ms
    FROM thread_state s JOIN thread t USING(utid)
    WHERE t.upid=136 AND s.dur>0 AND s.ts<160297438592 AND s.ts+s.dur>160293884920
    GROUP BY t.utid,s.state,s.io_wait,s.blocked_function ORDER BY t.tid,ms DESC
