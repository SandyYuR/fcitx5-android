SELECT s.ts,s.dur,s.name,t.tid FROM slice s
    JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid
    WHERE t.upid=136 AND s.name GLOB 'rime.direct.*' AND s.dur>=0
    AND s.ts>160068672456 AND s.ts<160297438592+10000000 ORDER BY s.ts
