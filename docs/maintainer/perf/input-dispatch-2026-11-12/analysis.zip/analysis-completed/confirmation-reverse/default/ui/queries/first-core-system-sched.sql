SELECT t.tid,t.name AS thread,p.pid,p.name AS process,s.priority,
                SUM(MIN(s.ts+s.dur,151070647155)-MAX(s.ts,151041668672))/1000000.0 AS cpu_ms
                FROM sched s JOIN thread t USING(utid) LEFT JOIN process p USING(upid)
                WHERE s.dur>0 AND s.ts<151070647155 AND s.ts+s.dur>151041668672
                GROUP BY t.utid,s.priority ORDER BY cpu_ms DESC
