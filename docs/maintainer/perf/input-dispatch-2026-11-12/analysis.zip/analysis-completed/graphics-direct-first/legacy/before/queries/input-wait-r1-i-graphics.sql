SELECT s.id,s.ts,s.dur,s.name,t.utid,t.tid,t.name AS thread,p.pid
                        FROM slice s JOIN thread_track tt ON s.track_id=tt.id
                        JOIN thread t ON tt.utid=t.utid JOIN process p ON t.upid=p.upid
                        WHERE s.dur>0 AND s.ts<193727614531 AND s.ts+s.dur>193661774249
                        AND (s.name='postAndWait' OR s.name GLOB '*eglSwap*'
                             OR s.name GLOB '*rcCreateSync*')
                        AND p.upid IN (SELECT DISTINCT t2.upid FROM slice a
                        JOIN thread_track tt2 ON a.track_id=tt2.id JOIN thread t2 ON tt2.utid=t2.utid
                        WHERE a.name GLOB 'rime.direct.*') ORDER BY s.ts
