SELECT t.tid,t.name AS thread,p.pid,p.name AS process,s.priority,
                SUM(MIN(s.ts+s.dur,197018215911)-MAX(s.ts,196976344726))/1000000.0 AS cpu_ms
                FROM sched s JOIN thread t USING(utid) LEFT JOIN process p USING(upid)
                WHERE s.dur>0 AND s.ts<197018215911 AND s.ts+s.dur>196976344726
                GROUP BY t.utid,s.priority ORDER BY cpu_ms DESC
