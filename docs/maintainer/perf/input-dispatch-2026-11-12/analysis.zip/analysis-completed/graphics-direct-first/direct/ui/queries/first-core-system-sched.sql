SELECT t.tid,t.name AS thread,p.pid,p.name AS process,s.priority,
                SUM(MIN(s.ts+s.dur,149200113455)-MAX(s.ts,149158200839))/1000000.0 AS cpu_ms
                FROM sched s JOIN thread t USING(utid) LEFT JOIN process p USING(upid)
                WHERE s.dur>0 AND s.ts<149200113455 AND s.ts+s.dur>149158200839
                GROUP BY t.utid,s.priority ORDER BY cpu_ms DESC
