from pathlib import Path
import argparse,csv,io,json,statistics,subprocess
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--trace',action='store_true');a=p.parse_args()
processor='/workspace/rime-latency-investigation-2026-11-11/trace_processor'
analyzer='/workspace/fcitx5-android/tools/input-perf/associate-events.py'
out=a.root/'analysis';out.mkdir(exist_ok=True);records=[];traces=[]
orders=['before,ui,priority,after','after,priority,ui,before'];labels=['before','ui','priority','after']
for order in orders:
 for label in labels:
  files=sorted((a.root/order/'untraced').glob(label+'-*.json'))
  assert len(files)==6,(order,label,len(files))
  for source in files:
   data=json.loads(source.read_text());ime=data['ime'];editor=data['editor'];r=ime['rounds'][0]
   assert len(ime['rounds'])==6 and editor['text']=='你'*6
   assert [c['text'] for c in editor['commits']]==['你']*6
   assert ime['model_mapped'] and not ime['fcitx_core_mapped']
   e=next(e for e in editor['edits'] if e['text']=='你');s=r['select']
   row={'order':order,'product':label,'file':source.name,
    'first_i_wait_ms':(r['i']['dispatch_up_ns']-r['i']['inject_up_ns'])/1e6,
    'first_n_to_preedit_ms':(r['preedit_collected_ns']-r['n']['dispatch_up_ns'])/1e6,
    'select_external_to_ic_ms':(editor['commits'][0]['at_ns']-s['inject_up_ns'])/1e6,
    'select_external_to_edit_ms':(e['at_ns']-s['inject_up_ns'])/1e6,
    'select_dispatch_to_edit_ms':(e['at_ns']-s['dispatch_up_ns'])/1e6,
    'n_down_to_i_inject_up_ms':(r['i']['inject_up_ns']-r['n']['dispatch_down_ns'])/1e6,
    'hot_i_wait_ms':[(rr['i']['dispatch_up_ns']-rr['i']['inject_up_ns'])/1e6 for rr in ime['rounds'][1:]]}
   records.append(row)
  if not a.trace:continue
  source=a.root/order/'traced'/(label+'-1.json');data=json.loads(source.read_text());trace=source.with_suffix('.perfetto-trace');dest=out/order/label
  assert data['editor']['text']=='你'*6
  subprocess.run(['python3',analyzer,'--trace',str(trace),'--data',str(source),'--kind','candidate','--processor',processor,'--output',str(dest)],check=True,capture_output=True,text=True)
  associated=json.loads((dest/'associated.json').read_text());assert not associated['missing_native_anchors'] and not associated['trace_stats']
  first=associated['anchors'][0];start=first['longest_core']['ts']+first['longest_core']['dur'];end=data['ime']['rounds'][0]['i']['dispatch_up_ns']
  sql=f'''SELECT s.id,s.ts,s.dur,s.name,t.utid,t.tid,p.pid FROM slice s JOIN thread_track tt ON s.track_id=tt.id
   JOIN thread t ON tt.utid=t.utid JOIN process p ON t.upid=p.upid WHERE s.name='RV OnLayout' AND s.dur>0
   AND t.tid=p.pid AND p.pid={first['longest_core']['pid']} AND s.ts>={start} AND s.ts<{end} ORDER BY s.ts'''
  (dest/'queries/first-candidate-layout.sql').write_text(sql+'\n')
  proc=subprocess.run([processor,'query','--no-agent','--format','csv',str(trace),sql],capture_output=True,text=True,check=True)
  layouts=list(csv.DictReader(io.StringIO(proc.stdout)));sched=list(csv.DictReader((dest/'sched.csv').open()))
  for r in layouts:
   ts,dur,utid=int(r['ts']),int(r['dur']),int(r['utid'])
   r['cpu_ms']=sum(max(0,min(ts+dur,int(s['ts'])+int(s['dur']))-max(ts,int(s['ts']))) for s in sched if int(s['utid'])==utid and int(s['dur'])>0)/1e6
   r['wall_ms']=dur/1e6
  (dest/'candidate-layouts.json').write_text(json.dumps(layouts,indent=2)+'\n')
  iwait=next(r for r in associated['input_waits'] if r['key']=='i' and r['round']==1)
  traces.append({'order':order,'product':label,'first_n':first,'first_i':iwait,'candidate_layouts':layouts})
metrics=['first_i_wait_ms','first_n_to_preedit_ms','select_external_to_ic_ms','select_external_to_edit_ms','select_dispatch_to_edit_ms','n_down_to_i_inject_up_ms']
summary={}
for order in orders+['all']:
 summary[order]={}
 for label in labels:
  chosen=[r for r in records if r['product']==label and (order=='all' or r['order']==order)]
  summary[order][label]={}
  for metric in metrics:
   values=[r[metric] for r in chosen]
   summary[order][label][metric]={'n':len(values),'median':statistics.median(values),'min':min(values),'max':max(values),'values':values}
  summary[order][label]['i_wait_over_30ms']=sum(r['first_i_wait_ms']>30 for r in chosen)
(out/'summary.json').write_text(json.dumps({'records':records,'summary':summary,'traces':traces},ensure_ascii=False,indent=2)+'\n')
for order in orders+['all']:
 print(order)
 for label in labels:
  s=summary[order][label]
  print(label,{m:round(s[m]['median'],3) for m in metrics},'>30ms',s['i_wait_over_30ms'])
