SELECT s.id,s.ts,s.dur,s.name,t.utid,t.tid,p.pid FROM slice s JOIN thread_track tt ON s.track_id=tt.id
   JOIN thread t ON tt.utid=t.utid JOIN process p ON t.upid=p.upid WHERE s.name='RV OnLayout' AND s.dur>0
   AND t.tid=p.pid AND p.pid=9179 AND s.ts>=354797143900 AND s.ts<354897776202 ORDER BY s.ts
