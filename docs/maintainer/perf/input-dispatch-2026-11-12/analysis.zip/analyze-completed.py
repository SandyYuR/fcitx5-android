from pathlib import Path
import json,subprocess
root=Path('/workspace/rime-i-dispatch-review-2026-11-12');out=root/'analysis-completed';out.mkdir(exist_ok=True)
processor='/workspace/rime-latency-investigation-2026-11-11/trace_processor';analyzer='/workspace/fcitx5-android/tools/input-perf/associate-events.py';records=[]
for name in ['confirmation-forward','confirmation-reverse','graphics-legacy-first','graphics-direct-first','cadence-forward','cadence-reverse']:
 directories=[(mode,root/name/mode/'traced') for mode in ['legacy','direct']] if name.startswith('graphics') else [('',root/name/'traced')]
 for mode,directory in directories:
  for label in ['before','ui']:
   data=directory/(label+'-1.json');trace=data.with_suffix('.perfetto-trace');dest=out/name/(mode or 'default')/label;kind='cadence' if name.startswith('cadence') else 'candidate'
   result=subprocess.run(['python3',analyzer,'--trace',str(trace),'--data',str(data),'--kind',kind,'--processor',processor,'--output',str(dest)],check=True,capture_output=True,text=True)
   o=json.loads((dest/'associated.json').read_text());assert not o['trace_stats'] and not o['missing_native_anchors']
   wait=next(x for x in o['input_waits'] if x['round']==1 and x['key']=='i')
   r={'cohort':name,'mode':mode,'product':label,'native_anchors':len(o['anchors']),'dispatch_intervals':len(o['input_waits']),'i_wait_ms':wait['wait_ms'],'i_thread_cpu_ms':wait['thread_cpu_ms'],'i_post_and_wait_overlap_ms':wait.get('post_and_wait_overlap_ms'),'trace_stats':o['trace_stats']}
   records.append(r);print(r,flush=True)
(out/'summary.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
