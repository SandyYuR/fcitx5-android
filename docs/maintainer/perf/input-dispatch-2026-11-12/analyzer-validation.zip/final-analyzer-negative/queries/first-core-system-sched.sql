SELECT t.tid,t.name AS thread,p.pid,p.name AS process,s.priority,
                SUM(MIN(s.ts+s.dur,210461104372)-MAX(s.ts,210402241052))/1000000.0 AS cpu_ms
                FROM sched s JOIN thread t USING(utid) LEFT JOIN process p USING(upid)
                WHERE s.dur>0 AND s.ts<210461104372 AND s.ts+s.dur>210402241052
                GROUP BY t.utid,s.priority ORDER BY cpu_ms DESC
