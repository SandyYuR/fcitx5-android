SELECT s.id,s.ts,s.dur,s.name,s.parent_id,t.utid,t.tid,t.name AS thread_name,
                 p.pid,p.name AS process_name FROM slice s
                 JOIN thread_track tt ON s.track_id=tt.id JOIN thread t ON tt.utid=t.utid
                 JOIN process p ON t.upid=p.upid
                 WHERE s.dur>=0 AND (s.name GLOB 'rime.*' OR s.name='HandleFcitxEvent'
                 OR s.name GLOB '*InputEvent*' OR s.name GLOB '*inputEvent*'
                 OR s.name GLOB 'Choreographer*' OR s.name GLOB '*JIT*'
                 OR s.name GLOB '*commitText*') ORDER BY s.ts
